<!DOCTYPE HTML>
<html>
<head>
    <title>sirima-G5</title>
    <link rel="stylesheet" type="text/css" media="all" href="css/bootstrap.css" />
</head>
<?php include "headerPage.php"; ?>
<body style="background: #fcdb00;">
<div class="container" style="margin-top: 100px;">
<div class="well">
    <h2 align="center">LIHAT PELAMAR DITERIMA</h2>
    <p>Prodi : S1 Ilmu Komputer Reguler</p>
    <table class="table">
        <thead>
        <tr>
            <th>Id Pendaftaran</th>
            <th>Nama Lengkap</th>
            <th>Alamat</th>
            <th>Jenis Kelamin</th>
            <th>Tanggal Lahir</th>
            <th>No KTP</th>
            <th>Email</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>1</td>
            <td>John Ryan</td>
            <td>Jl. Cendrawasih 90, Depok 16534</td>
            <td>Laki-Laki</td>
            <td>15 Mei 1997</td>
            <td>5267154267300000</td>
            <td>john@gmail.com</td>
        </tr>
        <tr>
            <td>2</td>
            <td>Mcdaniel Lawrence</td>
            <td>Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Jakarta Selatan 13052</td>
            <td>Perempuan</td>
            <td>18 Juli 1998</td>
            <td>1161721111500004</td>
            <td>Mcdaniel.Lawrence96@yahoo.com</td>
        </tr>
        <tr>
            <td>3</td>
            <td>Marsh Jescie</td>
            <td>Jl. Garnisun No. 2 - 3, Surabaya 14612</td>
            <td>Laki-Laki</td>
            <td>22 Februari 1999</td>
            <td>5192319111000008</td>
            <td>Marsh.Jescie68@yahoo.com</td>
        </tr>
        <tr>
            <td>4</td>
            <td>Durham Zoe</td>
            <td>Jl. Jend. Sudirman Kav. 49 , Makasar 14745</td>
            <td>Laki-Laki</td>
            <td>3 Februari 1996</td>
            <td>7131924111500007</td>
            <td>Durham.Zoe1@hotmail.com</td>
        </tr>
        <tr>
            <td>5</td>
            <td>Prince Shana</td>
            <td>Jl. Ciranjang  II No. 20-22, Surabaya 12525</td>
            <td>Perempuan</td>
            <td>25 September 1994</td>
            <td>2091210111400003</td>
            <td>Prince.Shana61@yahoo.com</td>
        </tr>


        </tbody>
    </table>
<div class="row" >
  <ul class="pagination" style="float: right">
    <li class="active"><a href="#">1</a></li>
    <li><a href="#">></a></li>

  </ul>
</div>
</div>
</div>
</body>
<?php include "footerPage.php"; ?>
</html>