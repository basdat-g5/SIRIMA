    <footer class="footer">
        <div class="container">
            <p class="text-muted text-center">Copyright &copy; 2017 SIRIMA-G5</p>
        </div>
    </footer>

    <!-- our JavaScript -->
    <script src="js/bootstrap.js"></script>
    <script type="javascript">
        $(document).ready(function () {
            $('.datepicker').datepicker();
        });
    </script>
    </body>
</html>