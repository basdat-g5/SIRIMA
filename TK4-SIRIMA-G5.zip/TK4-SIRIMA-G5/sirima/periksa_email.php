<?php
session_start();

include "koneksi.php";

// jika ditekan tombol login //
if(isset($_POST['next'])) {
$username = $_POST['username'];
$email = $_POST['email'];
$sql = pg_query("SELECT username FROM pelamar WHERE username = '$username' AND email = '$email'");
$num = pg_num_rows($sql);

// var_dump($num);die;

	if($num==1) {
		//tampilkan password
		$result = pg_query("SELECT password FROM akun where username = '$username'");
		$row = pg_fetch_row($result);
		$password = array_shift($row);		
		?><script language="JavaScript">prompt("Password anda adalah", "<?=$password?>");
		window.location.href = "login.php";</script><?php
		
	}
	else {
	// login salah //
	?><script language="JavaScript">alert('Username atau Email tidak terdaftar');
	document.location='lupa_password.php';</script><?php
	}
}
?>