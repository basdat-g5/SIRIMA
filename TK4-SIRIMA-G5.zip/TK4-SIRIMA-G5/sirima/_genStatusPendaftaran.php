<?php 
include "dbconfig.php";
if (isset($_POST["id_pendaftaran"]))
	$pIdPendaftaran = $_POST["id_pendaftaran"];
if (isset($_POST["biaya_pendaftaran"]))
	$pBiayaPendaftaran = $_POST["biaya_pendaftaran"];
if (isset($_POST["tahun_periode"]))
	$pTahunPeriode = $_POST["tahun_periode"];
if (isset($_POST["nomor_periode"]))
	$pNomorPeriode = $_POST["nomor_periode"];

$getJmlPeserta = "select count(1) + 1 from pendaftaran where nomor_periode = $1 and tahun_periode = $2";
$jmlPeserta = pg_query_params($dbConn, $getJmlPeserta, array($pNomorPeriode, $pTahunPeriode));
$pJmlPeserta = pg_fetch_result($jmlPeserta,0,0);

$pNomorPeserta = substr($pTahunPeriode, 2) . $pNomorPeriode . (strlen($pJmlPeserta) < 7 ? str_repeat("0",(7 - strlen($pJmlPeserta))) : $pJmlPeserta) . $pJmlPeserta;

$getIdPembayaran = "select upd_status_pendaftaran($1, $2, $3)";
$idPembayaran = pg_query_params($dbConn, $getIdPembayaran, array($pIdPendaftaran, $pBiayaPendaftaran,
	$pNomorPeserta));

$pIdPembayaran = pg_fetch_result($idPembayaran,0,0);

pg_close($dbConn);
?>

<form id="genStatusPendaftaran" action="statusPendaftaran.php" method="post">
	<input type="hidden" id="id_pendaftaran" name="id_pendaftaran" value="<?php echo $pIdPendaftaran; ?>">
	<input type="hidden" id="id_pembayaran" name="id_pembayaran" value="<?php echo $pIdPembayaran; ?>">
	<input type="hidden" id="nomor_peserta" name="nomor_peserta" value="<?php echo $pNomorPeserta; ?>">
</form>


<script type="text/javascript">
    document.getElementById('genStatusPendaftaran').submit();
</script>

