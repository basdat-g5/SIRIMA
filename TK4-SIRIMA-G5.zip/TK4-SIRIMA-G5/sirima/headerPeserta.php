<?php
session_start();

if(!isset($_SESSION['username'])){
	die("Anda belum login");
}

if($_SESSION['role'] != "f"){
	die("Anda bukan peserta");
}
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>sirima-G5</title>
    <link rel="stylesheet" type="text/css" media="all" href="css/bootstrap.css" />
</head>
<body style="background: #fcd001">


<!-- Fixed navbar -->
<nav class="navbar navbar-default navbar-fixed-top navbar-inverse">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" style="padding: 10px 10px;" href="homePeserta.php">
                <img src="img/ui_logo.png" width="35" style="display: inline-block;">
                <span style="display: inline-block;">SIRIMA G5</span>
            </a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="<?php if($currentPage == 'pendaftaran'){echo 'active';}?>"><a href="pilihJenjang.php">Pendaftaran</a></li>
                <li class="<?php if($currentPage == 'riwayat_pendaftaran'){echo 'active';}?>"><a href="lihat_riwayat_pendaftaran.php">Riwayat Pendaftaran</a></li>
                <li class="<?php if($currentPage == 'kartu_ujian'){echo 'active';}?>"><a href="lihat_kartu_ujian.php">Kartu Ujian</a></li>
                <li class="<?php if($currentPage == 'hasil_seleksi'){echo 'active';}?>"><a href="lihat_hasil_seleksi.php">Hasil Seleksi</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li style="color:#FFF">
                <span style="padding: 15px 0 15px;display: block;">Anda masuk sebagai,<em><?php echo " ".$_SESSION['username']."";?></em></span>
                </li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</nav>