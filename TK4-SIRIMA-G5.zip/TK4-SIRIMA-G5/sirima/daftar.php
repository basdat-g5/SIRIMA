<?php
 $username      = isset($_GET['username']) ? $_GET['username'] : "";
 $nama_lengkap  = isset($_GET['nama_lengkap']) ? $_GET['nama_lengkap'] : "";
 $no_ktp        = isset($_GET['no_ktp']) ? $_GET['no_ktp'] : "";
 $jenis_kelamin = isset($_GET['jenis_kelamin']) ? $_GET['jenis_kelamin'] : "";
 $tanggal_lahir = isset($_GET['tanggal_lahir']) ? $_GET['tanggal_lahir'] : "";
 $alamat        = isset($_GET['alamat']) ? $_GET['alamat'] : "";
 $email         = isset($_GET['email']) ? $_GET['email'] : "";


?>
<?php include "headerPage.php"; ?>
<style>
* {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  font-family: arial;
}

body {
  background: #FFE63B;
}

h1 {
  color: #999;
  text-align: center;
  font-family: arial;
  font-size: 18px;
}

img {
	display: block;
	margin: auto;
}

form#daftar ol li {
    background: #b9cf6a;
    background: rgba(255,255,255,.3);
    border-color: #e3ebc3;
    border-color: rgba(255,255,255,.6);
    border-style: solid;
    border-width: 2px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    line-height: 30px;
    list-style: none;
    padding: 5px 10px;
    margin-bottom: 2px;
}

form#daftar label{
    float: left;
    font-size: 13px;
    width: 110px;
}

.login-form {
  width: 350px;
  padding: 40px 30px;
  background: #eee;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
  margin: auto;
  position: absolute;
  left: 0;
  right: 0;
  top: 50%;
  -moz-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  -webkit-transform: translateY(-50%);
  transform: translateY(-50%);
}

.signup-form {
  width: 820px;
  padding: 40px 30px;
  background: #eee;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
  margin: auto;
  position: absolute;
  left: 0;
  right: 0;
  top: 70%;
  -moz-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  -webkit-transform: translateY(-50%);
  transform: translateY(-50%);
}

.form-group {
  position: relative;
  margin-bottom: 15px;
}

.form-control {
  width: 30%;
  height: 30px;
  border: none;
  padding: 5px 7px 5px 15px;
  background: #fff;
  color: #666;
  border: 2px solid #ddd;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
}
.form-control:focus, .form-control:focus + .fa {
  border-color: #10CE88;
  color: #10CE88;
}

.area-control {
  width: 50%;
  height: 100px;
  border: none;
  padding: 5px 7px 5px 15px;
  background: #fff;
  color: #666;
  border: 2px solid #ddd;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
}
.area-control:focus, .area-control:focus + .fa {
  border-color: #10CE88;
  color: #10CE88;
}

.select-control {
  width: 26%;
  height: 30px;
  border: none;
  padding: 5px 7px 5px 15px;
  background: #fff;
  color: #666;
  border: 2px solid #ddd;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
}
.select-control:focus, .select-control:focus + .fa {
  border-color: #10CE88;
  color: #10CE88;
}

.form-group .fa {
  position: absolute;
  right: 15px;
  top: 17px;
  color: #999;
}

.log-status.wrong-entry {
  -moz-animation: wrong-log 0.3s;
  -webkit-animation: wrong-log 0.3s;
  animation: wrong-log 0.3s;
}

.log-status.wrong-entry .form-control, .wrong-entry .form-control + .fa {
  border-color: #ed1c24;
  color: #ed1c24;
}

.log-btn {
  background: #0AC986;
  dispaly: inline-block;
  width: 100%;
  font-size: 16px;
  height: 50px;
  color: #fff;
  text-decoration: none;
  border: none;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
}

.signupbtn {
  background: #0AC986;
  dispaly: inline-block;
  width: 30%;
  font-size: 16px;
  height: 50px;
  color: #fff;
  text-decoration: none;
  border: none;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
}

.cancelbtn {
  background: #0AC986;
  dispaly: inline-block;
  width: 30%;
  font-size: 16px;
  height: 50px;
  color: #fff;
  text-decoration: none;
  border: none;
  -moz-border-radius: 4px;
  -webkit-border-radius: 4px;
  border-radius: 4px;
}

.link {
  text-decoration: none;
  color: #C6C6C6;
  float: right;
  font-size: 12px;
  margin-bottom: 15px;
}
.link:hover {
  text-decoration: underline;
  color: #8C918F;
}

.alert {
  display: none;
  font-size: 12px;
  color: #f00;
  float: left;
}

@-moz-keyframes wrong-log {
  0%, 100% {
    left: 0px;
  }
  20% , 60% {
    left: 15px;
  }
  40% , 80% {
    left: -15px;
  }
}
@-webkit-keyframes wrong-log {
  0%, 100% {
    left: 0px;
  }
  20% , 60% {
    left: 15px;
  }
  40% , 80% {
    left: -15px;
  }
}
@keyframes wrong-log {
  0%, 100% {
    left: 0px;
  }
  20% , 60% {
    left: 15px;
  }
  40% , 80% {
    left: -15px;
  }
}
</style>
<script type="text/javascript" src="js/field_validation.js">
</script>

<div class="signup-form" style="margin-top: 50px; margin-bottom: 50px;">
<form id="daftar" name="daftar" action="daftar_akun.php" method="post">
<h2 align="center">FORM PENDAFTARAN PELAMAR</h2>
<ol>

<div class="form-group">
<li>
<label>Username:</label> 
<input value="<?=$username?>" type="text" name="username" class="form-control" required pattern="^[a-zA-Z][a-zA-Z0-9-_\.]{1,20}$" title="tidak boleh menggunakan spasi dan karakter spesial (kecuali '_' dan '.')">

</li>
</div>

<div class="form-group">
<li>
<label>Password:</label> 
<input type="password" id="password" name="password" class="form-control" required pattern="(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$" title="kombinasi dari huruf kapital, alfabet dan angka serta minimal 8 karakter">
</li>
</div>

<div class="form-group">
<li>
<label>Ulangi Password:</label> 
<input type="password" id="confirmpassword" name="confirmpassword" class="form-control" required>
</li>
</div>

<div class="form-group">
<li>
<label>Nama Lengkap:</label> 
<input value="<?=$nama_lengkap?>" type="text" name="nama_lengkap" class="form-control" required>
</li>
</div>

<div class="form-group">
<li>
<label>Nomor Identitas:</label> 
<input value="<?=$no_ktp?>" type="text" name="no_ktp" class="form-control" placeholder="gunakan nomor KTP anda" required pattern="[0-9]{16}" title="hanya terdiri dari angka serta minimal 16 karakter">
</li>
</div>

<div class="form-group">
<li>
<label>Jenis Kelamin:</label>
<select name="jenis_kelamin" class="select-control" required>
	<option value="" <?= $jenis_kelamin == "" ? "selected":"";?>> Pilih Gender </option>
	<option value="l" <?= $jenis_kelamin == "l" ? "selected":"";?>>Pria</option>
    <option value="p" <?= $jenis_kelamin == "p" ? "selected":"";?>>Wanita</option>
</select>
</li>
</div>

<div class="form-group">
<li>
<label>Tanggal Lahir:</label>
<input value="<?=$tanggal_lahir?>" type="date" name="tanggal_lahir" class="form-control" required>
</li>
</div>

<div class="form-group">
<li>
<label>Alamat:</label> 
<textarea name="alamat" class="area-control" rows="5" cols="40" required><?=$alamat?></textarea>
</li>
</div>

<div class="form-group">
<li>
<label>Alamat E-mail:</label>
<input value="<?=$email?>" type="email" id="email" name="email" class="form-control" required placeholder="contoh@ui.ac.id">
</li>
</div>

<div class="form-group">
<li>
<label>Ulangi E-mail:</label>
<input type="email" id="confirmemail" name="confirmemail" class="form-control" required placeholder="contoh@ui.ac.id">
</li>
</div>
<br />
<button id="daftar" name="daftar" value="daftar" class="signupbtn" type="submit">Daftar</button>
<button name="reset" id="reset" value="reset" class="cancelbtn" type="reset">Reset</button>
</ol>
</form>
</div>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

<?php include "footerPage.php"; ?>
