<?php
session_start();

include "koneksi.php";

// jika ditekan tombol login //
if(isset($_POST['login'])) {
$username = $_POST['username'];
$password = $_POST['password'];
$sql = pg_query("SELECT * FROM AKUN WHERE username = '$username' and password = '$password'");
$num = pg_num_rows($sql);

	if($num==1) {
		if (!isset($_SESSION['username'])) {
			$_SESSION['username'] = $username;
		}
		if (!isset($_SESSION['password'])) {
			$_SESSION['password'] = $password;
		}
		if (!isset($_SESSION['role'])) {
			$c = pg_fetch_array($sql);
			$_SESSION['role'] = $c['role'];
		}
		//login admin
		if($_SESSION['role'] === 't'){
			?><script language="javascript">alert('Login berhasil');
			document.location='homeAdmin.php'</script><?php
		}
		//login peserta
		else if($_SESSION['role'] === 'f'){
			?><script language="javascript">alert('Login berhasil');
			document.location='homePeserta.php'</script><?php
		}
	}
	else {
	// login salah //
	?><script language="JavaScript">alert('Username atau Password salah');
	document.location='login.php';</script><?php
	}
}
?>