<?php 
include "dbconfig.php";
if (isset($_POST["jenjang"]))
	$pJenjang = $_POST["jenjang"];
if (isset($_POST["nomor_periode"]))
	$pNomorPeriode = $_POST["nomor_periode"];
if (isset($_POST["tahun_periode"]))
	$pTahunPeriode = $_POST["tahun_periode"];
if (isset($_POST["pelamar"]))
	$pPelamar = $_POST["pelamar"];
if (isset($_POST["asal_sekolah"]))
	$pAsalSekolah = $_POST["asal_sekolah"];
if (isset($_POST["jenis_SMA"]))
	$pJenisSMA = $_POST["jenis_SMA"];
if (isset($_POST["alamat_sekolah"]))
	$pAlamatSekolah = $_POST["alamat_sekolah"];
if (isset($_POST["nisn"]))
	$pNISN = $_POST["nisn"];
if (isset($_POST["tgl_lulus"]))
	$pTglLulus = $_POST["tgl_lulus"];
if (isset($_POST["nilai_UAN"]))
	$pNilaiUAN = $_POST["nilai_UAN"];
if (isset($_POST["prodi1"]))
	$pProdi1 = $_POST["prodi1"];
if (isset($_POST["prodi2"]))
	$pProdi2 = $_POST["prodi2"];
else
	$pProdi2 = null;
if (isset($_POST["prodi3"]))
	$pProdi3 = $_POST["prodi3"];
else
	$pProdi3 = null;
if (isset($_POST["kota_ujian"]))
	$pKotaUjian = $_POST["kota_ujian"];
if (isset($_POST["tempat_ujian"]))
	$pTempatUjian = $_POST["tempat_ujian"];

$getIdPendaftaran = "select ins_pendaftaran_sarjana($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)";
$idPendaftaran = pg_query_params($dbConn, $getIdPendaftaran, array($pNomorPeriode, $pTahunPeriode,
	$pPelamar, $pAsalSekolah, $pJenisSMA, $pAlamatSekolah, $pNISN, $pTglLulus, $pNilaiUAN, $pProdi1, $pProdi2, $pProdi3, $pKotaUjian, $pTempatUjian));

$pIdPendaftaran = pg_fetch_result($idPendaftaran,0,0);
pg_close($dbConn);
?>

<form id="insPendaftaran" action="pembayaran.php" method="post">
	<input type="hidden" id="id_pendaftaran" name="id_pendaftaran" value="<?php echo $pIdPendaftaran; ?>">
	<input type="hidden" id="nomor_periode" name="nomor_periode" value="<?php echo $pNomorPeriode; ?>">
	<input type="hidden" id="tahun_periode" name="tahun_periode" value="<?php echo $pTahunPeriode; ?>">
</form>


<script type="text/javascript">
    document.getElementById('insPendaftaran').submit();
</script>

