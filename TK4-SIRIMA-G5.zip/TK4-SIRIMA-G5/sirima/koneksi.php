<?php
 $conn = pg_connect("host=localhost port=5432 dbname=postgres user=postgres password=admin");

 if (!$conn) {
  die('Could not connect: ' . pg_last_error());
 }
  //echo 'Connected successfully <br>';
  
?>