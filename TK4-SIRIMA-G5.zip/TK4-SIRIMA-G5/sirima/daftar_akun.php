<?php
 include 'koneksi.php';

 $username         = $_POST['username'];
 $password         = $_POST['password'];
 $nama_lengkap     = $_POST['nama_lengkap'];
 $no_ktp           = $_POST['no_ktp'];
 $nama_lengkap     = $_POST['nama_lengkap'];
 $jenis_kelamin    = $_POST['jenis_kelamin'];
 $tanggal_lahir    = $_POST['tanggal_lahir'];
 $alamat           = $_POST['alamat'];
 $email            = $_POST['email'];

 $check = "SELECT username FROM akun WHERE username='$username'";

   $result=pg_query($conn, $check);   
   if (pg_num_rows($result) != 0)
   {
     echo"<script language=javascript> alert(\"Username telah digunakan.\") </script>";
   }

    else
   {
    $query = "INSERT INTO AKUN VALUES
	('$username', 'FALSE', '$password');";

	$query .= "INSERT INTO PELAMAR VALUES
	('$username', '$nama_lengkap', '$alamat', '$jenis_kelamin', '$tanggal_lahir', '$no_ktp', '$email')";
	$hasil = pg_query($conn, $query) or die (pg_last_error($conn));
if ($query) echo"<script language=javascript> alert(\"Data berhasil disimpan.\") </script>";
   }
   
 $username         = $_POST['username'];
 $nama_lengkap     = $_POST['nama_lengkap'];
 $no_ktp           = $_POST['no_ktp'];
 $jenis_kelamin    = $_POST['jenis_kelamin'];
 $tanggal_lahir    = $_POST['tanggal_lahir'];
 $alamat           = $_POST['alamat'];
 $email            = $_POST['email'];
 
   //
   $array = array(
   		'username' => $username,
   		'nama_lengkap' => $nama_lengkap,
		'no_ktp' => $no_ktp,
		'jenis_kelamin' => $jenis_kelamin,
		'tanggal_lahir' => $tanggal_lahir,
		'alamat' => $alamat,
		'email' => $email,
   );
   $query = http_build_query($array);
   
echo"<script>document.location.href='daftar.php?" . $query ."'</script>";

pg_close($conn);
?>