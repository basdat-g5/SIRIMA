<?php session_start();
unset($_SESSION['login']);
session_destroy();
echo "<script>alert ('Anda telah logout')</script>";
echo '<meta http-equiv="refresh" content="0;url=index.php" />';
?>