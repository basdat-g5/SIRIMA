<?php include "headerAdmin.php"; ?>
    <div class="container" style="margin-top: 100px;">
        <div class="jumbotron">
            <h1>SIRIMA G5</h1>
            <p>Selamat Datang di Sistem Penerimaan Mahasiswa G5</p>
        </div>
    </div>
<?php include "footerPage.php"; ?>