--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: sirima; Type: SCHEMA; Schema: -; Owner: arri.kurniawan
--

CREATE SCHEMA sirima;


ALTER SCHEMA sirima OWNER TO "arri.kurniawan";

SET search_path = sirima, pg_catalog;

--
-- Name: hitung_pelamar(); Type: FUNCTION; Schema: sirima; Owner: arri.kurniawan
--

CREATE FUNCTION hitung_pelamar() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ 
BEGIN 
IF (TG_OP = 'INSERT') THEN
UPDATE PENERIMAAN_PRODI PNP 
SET jumlah_pelamar = (coalesce(jumlah_pelamar,0) + 1)
FROM PERIODE_PENERIMAAN PRP
JOIN PENDAFTARAN P 
ON P.NOMOR_PERIODE = PRP.NOMOR 
AND P.TAHUN_PERIODE = PRP.TAHUN
WHERE PRP.NOMOR = PNP.NOMOR_PERIODE 
AND PRP.TAHUN = PNP.TAHUN_PERIODE
AND P.ID = NEW.ID_PENDAFTARAN
AND PNP.KODE_PRODI = NEW.kode_prodi;
ELSEIF (TG_OP = 'UPDATE') THEN
UPDATE PENERIMAAN_PRODI PNP 
SET jumlah_pelamar = (coalesce(jumlah_pelamar,0) + 1)
FROM PERIODE_PENERIMAAN PRP
JOIN PENDAFTARAN P 
ON P.NOMOR_PERIODE = PRP.NOMOR 
AND P.TAHUN_PERIODE = PRP.TAHUN
WHERE PRP.NOMOR = PNP.NOMOR_PERIODE 
AND PRP.TAHUN = PNP.TAHUN_PERIODE
AND P.ID = NEW.ID_PENDAFTARAN
AND PNP.KODE_PRODI = NEW.kode_prodi;

UPDATE PENERIMAAN_PRODI PNP 
SET jumlah_pelamar = (jumlah_pelamar - 1)
FROM PERIODE_PENERIMAAN PRP
JOIN PENDAFTARAN P 
ON P.NOMOR_PERIODE = PRP.NOMOR 
AND P.TAHUN_PERIODE = PRP.TAHUN
WHERE PRP.NOMOR = PNP.NOMOR_PERIODE 
AND PRP.TAHUN = PNP.TAHUN_PERIODE
AND P.ID = OLD.ID_PENDAFTARAN
AND PNP.KODE_PRODI = OLD.kode_prodi;
ELSEIF (TG_OP = 'DELETE') THEN
UPDATE PENERIMAAN_PRODI PNP 
SET jumlah_pelamar = (jumlah_pelamar - 1)
FROM PERIODE_PENERIMAAN PRP
JOIN PENDAFTARAN P 
ON P.NOMOR_PERIODE = PRP.NOMOR 
AND P.TAHUN_PERIODE = PRP.TAHUN
WHERE PRP.NOMOR = PNP.NOMOR_PERIODE 
AND PRP.TAHUN = PNP.TAHUN_PERIODE
AND P.ID = OLD.ID_PENDAFTARAN
AND PNP.KODE_PRODI = OLD.kode_prodi;
END IF;
RETURN NEW;
END;
$$;


ALTER FUNCTION sirima.hitung_pelamar() OWNER TO "arri.kurniawan";

--
-- Name: hitung_pelamar_diterima(); Type: FUNCTION; Schema: sirima; Owner: arri.kurniawan
--

CREATE FUNCTION hitung_pelamar_diterima() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ 
DECLARE
jumlah_lulus INT;
BEGIN 
SELECT COUNT(PP.status_lulus) INTO jumlah_lulus
FROM PENDAFTARAN_PRODI PP
WHERE PP.ID_PENDAFTARAN = NEW.ID_PENDAFTARAN
AND PP.status_lulus = TRUE;

IF (TG_OP = 'UPDATE') THEN
IF(NEW.status_lulus IS TRUE AND OLD.status_lulus IS FALSE) THEN
IF(jumlah_lulus = 1) THEN
UPDATE PENERIMAAN_PRODI PNP 
SET jumlah_diterima = (coalesce(jumlah_diterima,0) + 1)
FROM PERIODE_PENERIMAAN PRP
JOIN PENDAFTARAN P 
ON P.NOMOR_PERIODE = PRP.NOMOR 
AND P.TAHUN_PERIODE = PRP.TAHUN
WHERE PRP.NOMOR = PNP.NOMOR_PERIODE 
AND PRP.TAHUN = PNP.TAHUN_PERIODE
AND P.ID = NEW.ID_PENDAFTARAN
AND PNP.KODE_PRODI = NEW.kode_prodi;
ELSE
RAISE EXCEPTION 'Error : status_lulus untuk id_pendaftaran yang sama maksimal berjumlah 1';
END IF;
ELSEIF(NEW.status_lulus IS FALSE AND OLD.status_lulus IS TRUE) THEN
UPDATE PENERIMAAN_PRODI PNP 
SET jumlah_diterima = (jumlah_diterima - 1)
FROM PERIODE_PENERIMAAN PRP
JOIN PENDAFTARAN P 
ON P.NOMOR_PERIODE = PRP.NOMOR 
AND P.TAHUN_PERIODE = PRP.TAHUN
WHERE PRP.NOMOR = PNP.NOMOR_PERIODE 
AND PRP.TAHUN = PNP.TAHUN_PERIODE
AND P.ID = NEW.ID_PENDAFTARAN
AND PNP.KODE_PRODI = NEW.kode_prodi;
END IF;
END IF;
RETURN NEW;
END;
$$;


ALTER FUNCTION sirima.hitung_pelamar_diterima() OWNER TO "arri.kurniawan";

--
-- Name: ins_pendaftaran_sarjana(integer, character, character varying, character varying, character varying, text, character varying, date, numeric, integer, integer, integer, character varying, character varying); Type: FUNCTION; Schema: sirima; Owner: arri.kurniawan
--

CREATE FUNCTION ins_pendaftaran_sarjana(in_nomor_periode integer, in_tahun_periode character, in_pelamar character varying, in_asal_sekolah character varying, in_jenis_sma character varying, in_alamat_sekolah text, in_nisn character varying, in_tgl_lulus date, in_nilai_uan numeric, in_kode_prodi_1 integer, in_kode_prodi_2 integer, in_kode_prodi_3 integer, in_kota_ujian character varying, in_tempat_ujian character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
DECLARE 
out_id_pendaftaran INTEGER;
BEGIN 
SELECT MAX(id) + 1 FROM PENDAFTARAN INTO out_id_pendaftaran;

INSERT INTO PENDAFTARAN(id, pelamar, nomor_periode, tahun_periode)
VALUES(out_id_pendaftaran, in_pelamar, in_nomor_periode, in_tahun_periode);

INSERT INTO PENDAFTARAN_SEMAS(id_pendaftaran, lokasi_kota, lokasi_tempat)
VALUES(out_id_pendaftaran, in_kota_ujian, in_tempat_ujian);

INSERT INTO PENDAFTARAN_SEMAS_SARJANA(id_pendaftaran, asal_sekolah, jenis_sma, alamat_sekolah, nisn, tgl_lulus, nilai_uan)
VALUES(out_id_pendaftaran, in_asal_sekolah, in_jenis_sma, in_alamat_sekolah, in_nisn, in_tgl_lulus, in_nilai_uan);

INSERT INTO PENDAFTARAN_PRODI(id_pendaftaran, kode_prodi, status_lulus)
VALUES(out_id_pendaftaran, in_kode_prodi_1, false);

IF(in_kode_prodi_2 IS NOT NULL) THEN
INSERT INTO PENDAFTARAN_PRODI(id_pendaftaran, kode_prodi, status_lulus)
VALUES(out_id_pendaftaran, in_kode_prodi_2, false);
END IF;

IF(in_kode_prodi_3 IS NOT NULL) THEN
INSERT INTO PENDAFTARAN_PRODI(id_pendaftaran, kode_prodi, status_lulus)
VALUES(out_id_pendaftaran, in_kode_prodi_3, false);
END IF;

RETURN out_id_pendaftaran;
END;
$$;


ALTER FUNCTION sirima.ins_pendaftaran_sarjana(in_nomor_periode integer, in_tahun_periode character, in_pelamar character varying, in_asal_sekolah character varying, in_jenis_sma character varying, in_alamat_sekolah text, in_nisn character varying, in_tgl_lulus date, in_nilai_uan numeric, in_kode_prodi_1 integer, in_kode_prodi_2 integer, in_kode_prodi_3 integer, in_kota_ujian character varying, in_tempat_ujian character varying) OWNER TO "arri.kurniawan";

--
-- Name: upd_status_pendaftaran(integer, numeric, character); Type: FUNCTION; Schema: sirima; Owner: arri.kurniawan
--

CREATE FUNCTION upd_status_pendaftaran(in_id_pendaftaran integer, in_biaya_pendaftaran numeric, in_nomor_peserta character) RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
DECLARE 
out_id_pembayaran INTEGER;
BEGIN 
SELECT max(id) + 1 FROM pembayaran INTO out_id_pembayaran;

UPDATE pendaftaran_semas SET no_kartu_ujian = in_nomor_peserta 
WHERE id_pendaftaran = in_id_pendaftaran;

INSERT INTO pembayaran(id, waktu_bayar, jumlah_bayar, id_pendaftaran)
VALUES(out_id_pembayaran, current_timestamp, in_biaya_pendaftaran, in_id_pendaftaran);

RETURN out_id_pembayaran;
END;
$$;


ALTER FUNCTION sirima.upd_status_pendaftaran(in_id_pendaftaran integer, in_biaya_pendaftaran numeric, in_nomor_peserta character) OWNER TO "arri.kurniawan";

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: akun; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE akun (
    username character varying(50) NOT NULL,
    role boolean NOT NULL,
    password character varying(20) NOT NULL
);


ALTER TABLE akun OWNER TO "arri.kurniawan";

--
-- Name: jadwal_penting; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE jadwal_penting (
    nomor smallint NOT NULL,
    tahun character(4) NOT NULL,
    jenjang character(2) NOT NULL,
    waktu_mulai timestamp without time zone NOT NULL,
    waktu_selesai timestamp without time zone NOT NULL,
    deskripsi character varying(150) NOT NULL
);


ALTER TABLE jadwal_penting OWNER TO "arri.kurniawan";

--
-- Name: jenjang; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE jenjang (
    nama character(2) NOT NULL
);


ALTER TABLE jenjang OWNER TO "arri.kurniawan";

--
-- Name: lokasi_jadwal; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE lokasi_jadwal (
    kota character varying(100) NOT NULL,
    tempat character varying(150) NOT NULL,
    nomor_periode smallint NOT NULL,
    tahun_periode character(4) NOT NULL,
    jenjang character(2) NOT NULL,
    waktu_awal timestamp without time zone NOT NULL
);


ALTER TABLE lokasi_jadwal OWNER TO "arri.kurniawan";

--
-- Name: lokasi_ujian; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE lokasi_ujian (
    kota character varying(100) NOT NULL,
    tempat character varying(150) NOT NULL
);


ALTER TABLE lokasi_ujian OWNER TO "arri.kurniawan";

--
-- Name: pelamar; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pelamar (
    username character varying(50) NOT NULL,
    nama_lengkap character varying(100) NOT NULL,
    alamat text NOT NULL,
    jenis_kelamin character(1) NOT NULL,
    tanggal_lahir date NOT NULL,
    no_ktp character(16) NOT NULL,
    email character varying(100) NOT NULL
);


ALTER TABLE pelamar OWNER TO "arri.kurniawan";

--
-- Name: pembayaran; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pembayaran (
    id integer NOT NULL,
    waktu_bayar timestamp without time zone NOT NULL,
    jumlah_bayar numeric(10,2) NOT NULL,
    id_pendaftaran integer NOT NULL
);


ALTER TABLE pembayaran OWNER TO "arri.kurniawan";

--
-- Name: pembayaran_id_seq; Type: SEQUENCE; Schema: sirima; Owner: arri.kurniawan
--

CREATE SEQUENCE pembayaran_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pembayaran_id_seq OWNER TO "arri.kurniawan";

--
-- Name: pembayaran_id_seq; Type: SEQUENCE OWNED BY; Schema: sirima; Owner: arri.kurniawan
--

ALTER SEQUENCE pembayaran_id_seq OWNED BY pembayaran.id;


--
-- Name: pendaftaran; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pendaftaran (
    id integer NOT NULL,
    status_lulus boolean,
    status_verifikasi boolean,
    npm character(10),
    pelamar character varying(50) NOT NULL,
    nomor_periode smallint NOT NULL,
    tahun_periode character(4) NOT NULL
);


ALTER TABLE pendaftaran OWNER TO "arri.kurniawan";

--
-- Name: pendaftaran_id_seq; Type: SEQUENCE; Schema: sirima; Owner: arri.kurniawan
--

CREATE SEQUENCE pendaftaran_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pendaftaran_id_seq OWNER TO "arri.kurniawan";

--
-- Name: pendaftaran_id_seq; Type: SEQUENCE OWNED BY; Schema: sirima; Owner: arri.kurniawan
--

ALTER SEQUENCE pendaftaran_id_seq OWNED BY pendaftaran.id;


--
-- Name: pendaftaran_prodi; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pendaftaran_prodi (
    id_pendaftaran integer NOT NULL,
    kode_prodi integer NOT NULL,
    status_lulus boolean NOT NULL
);


ALTER TABLE pendaftaran_prodi OWNER TO "arri.kurniawan";

--
-- Name: pendaftaran_semas; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pendaftaran_semas (
    id_pendaftaran integer NOT NULL,
    status_hadir boolean,
    nilai_ujian integer,
    no_kartu_ujian character(10),
    lokasi_kota character varying(100) NOT NULL,
    lokasi_tempat character varying(150) NOT NULL
);


ALTER TABLE pendaftaran_semas OWNER TO "arri.kurniawan";

--
-- Name: pendaftaran_semas_pascasarjana; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pendaftaran_semas_pascasarjana (
    id_pendaftaran integer NOT NULL,
    nilai_tpa integer NOT NULL,
    nilai_toefl integer NOT NULL,
    jenjang_terakhir character(2) NOT NULL,
    asal_univ character varying(100) NOT NULL,
    alamat_univ text NOT NULL,
    prodi_terakhir character varying(100) NOT NULL,
    nilai_ipk numeric(10,2) NOT NULL,
    no_ijazah character varying(50) NOT NULL,
    tgl_lulus date NOT NULL,
    jenjang character(2) NOT NULL,
    nama_rekomender character varying(100),
    prop_penelitian character varying(100)
);


ALTER TABLE pendaftaran_semas_pascasarjana OWNER TO "arri.kurniawan";

--
-- Name: pendaftaran_semas_sarjana; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pendaftaran_semas_sarjana (
    id_pendaftaran integer NOT NULL,
    asal_sekolah character varying(100) NOT NULL,
    jenis_sma character varying(50) NOT NULL,
    alamat_sekolah text NOT NULL,
    nisn character varying(10) NOT NULL,
    tgl_lulus date NOT NULL,
    nilai_uan numeric(10,2) NOT NULL
);


ALTER TABLE pendaftaran_semas_sarjana OWNER TO "arri.kurniawan";

--
-- Name: pendaftaran_uui; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pendaftaran_uui (
    id_pendaftaran integer NOT NULL,
    rapot character varying(100) NOT NULL,
    surat_rekomendasi character varying(100) NOT NULL,
    asal_sekolah character varying(100) NOT NULL,
    jenis_sma character varying(50) NOT NULL,
    alamat_sekolah text NOT NULL,
    nisn character varying(10) NOT NULL,
    tgl_lulus date NOT NULL,
    nilai_uan numeric(10,2) NOT NULL
);


ALTER TABLE pendaftaran_uui OWNER TO "arri.kurniawan";

--
-- Name: penerimaan_prodi; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE penerimaan_prodi (
    nomor_periode integer NOT NULL,
    tahun_periode character(4) NOT NULL,
    kode_prodi integer NOT NULL,
    kuota integer NOT NULL,
    jumlah_pelamar integer,
    jumlah_diterima integer
);


ALTER TABLE penerimaan_prodi OWNER TO "arri.kurniawan";

--
-- Name: pengawas; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE pengawas (
    nomor_induk character varying(16) NOT NULL,
    nama character varying(100) NOT NULL,
    no_telp text NOT NULL,
    lokasi_kota character varying(100) NOT NULL,
    lokasi_tempat character varying(150) NOT NULL,
    lokasi_id smallint NOT NULL
);


ALTER TABLE pengawas OWNER TO "arri.kurniawan";

--
-- Name: periode_penerimaan; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE periode_penerimaan (
    nomor smallint NOT NULL,
    tahun character(4) NOT NULL,
    status_aktif boolean NOT NULL
);


ALTER TABLE periode_penerimaan OWNER TO "arri.kurniawan";

--
-- Name: program_studi; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE program_studi (
    kode integer NOT NULL,
    nama character varying(100) NOT NULL,
    jenis_kelas character varying(50) NOT NULL,
    nama_fakultas character varying(50) NOT NULL,
    jenjang character(2) NOT NULL
);


ALTER TABLE program_studi OWNER TO "arri.kurniawan";

--
-- Name: program_studi_kode_seq; Type: SEQUENCE; Schema: sirima; Owner: arri.kurniawan
--

CREATE SEQUENCE program_studi_kode_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE program_studi_kode_seq OWNER TO "arri.kurniawan";

--
-- Name: program_studi_kode_seq; Type: SEQUENCE OWNED BY; Schema: sirima; Owner: arri.kurniawan
--

ALTER SEQUENCE program_studi_kode_seq OWNED BY program_studi.kode;


--
-- Name: rekomendasi; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE rekomendasi (
    tgl_review date NOT NULL,
    id_pendaftaran integer NOT NULL,
    status boolean NOT NULL,
    nilai integer NOT NULL,
    komentar text NOT NULL
);


ALTER TABLE rekomendasi OWNER TO "arri.kurniawan";

--
-- Name: ruang_ujian; Type: TABLE; Schema: sirima; Owner: arri.kurniawan
--

CREATE TABLE ruang_ujian (
    kota character varying(100) NOT NULL,
    tempat character varying(150) NOT NULL,
    id smallint NOT NULL
);


ALTER TABLE ruang_ujian OWNER TO "arri.kurniawan";

--
-- Name: pembayaran id; Type: DEFAULT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pembayaran ALTER COLUMN id SET DEFAULT nextval('pembayaran_id_seq'::regclass);


--
-- Name: pendaftaran id; Type: DEFAULT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran ALTER COLUMN id SET DEFAULT nextval('pendaftaran_id_seq'::regclass);


--
-- Name: program_studi kode; Type: DEFAULT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY program_studi ALTER COLUMN kode SET DEFAULT nextval('program_studi_kode_seq'::regclass);


--
-- Data for Name: akun; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY akun (username, role, password) FROM stdin;
admin.kedokteran	t	kedokteranhebat
admin.teknik	t	teknikboleh
admin.biologi	t	biologienak
admin.hukum	t	hukuminaja
super.admin	t	supersaiya
john.ryan12	f	sukses142
Mcdaniel.Lawrence96	f	RXZKzc
Marsh.Jescie68	f	UCrgL1Y
Durham.Zoe1	f	7DMNBp05
Prince.Shana61	f	oaNpY2fCn
Heath.Lisandra14	f	SAOGgRAys
Schultz.Serina100	f	bcLMD9AnU
Aguirre.Minerva83	f	bCJdqnAcUkIO
Pena.Cassidy6	f	SMYkhQ
Osborn.Eaton63	f	Nl631AmJu1bs
Mcdaniel.Pearl74	f	LTZOG0nuAAP5
Lindsay.Leonard67	f	i0XYXU6ax
Lamb.Cyrus58	f	8eIbU63
Barlow.Blake48	f	mQiWjDkX9
Hampton.Burton69	f	FVut59OXE
Knight.Nora65	f	crbrRB
Mclaughlin.Serina79	f	RyzkUMai0l
Graves.Jolene72	f	kaJcHWT
Hopkins.Lucian65	f	sHvZFo3jD6
Valentine.Arsenio34	f	oWAP2v09TH
Herman.Cathleen70	f	WkWlqAcl3mPu
Mathews.Kato5	f	SwXyxy
Andrews.Leo13	f	8t9guMLBeP
Cote.Sonia87	f	DzgMFQprda
Chandler.Grace42	f	S2z3uHTFcnh
Carter.Ebony43	f	NlN0FLArRpNH
Boone.Rhea42	f	Xx0Rb2SIbwVn
Sloan.Kane71	f	GPAdKSfHn
Harvey.Hayes40	f	00miullcy
Wilkins.Knox48	f	Az1TCi
Chan.Beck3	f	pxJZcNuB0Ia
Hinton.Vivian14	f	HkrW3ykHPWhT
Pennington.Hammett78	f	JSu8elk77
Reid.Imani99	f	sx9DWDv65w
Snyder.Jakeem77	f	MP8ombzKfx
Haynes.Isabella41	f	BlyRG9v
Randall.Remedios78	f	HBn33k75uREc
Snider.Phillip9	f	IZyjLNnpay
Brown.Simon42	f	cO07wFZwTS
Bryan.Maggy31	f	FcYweKLKu
Hooper.Juliet59	f	xWKjqp
Mckinney.Dacey28	f	HKr2M7c
Flynn.Heather100	f	Kn7nL47wtYBf
Sheppard.Hiram65	f	vkCTXoyazRpu
Wilkins.Dillon80	f	qIyp7HvgJ
Velez.Wyoming83	f	xfmyxo8Kg3T
Mays.Quin98	f	6Z9UY90
Daniels.Nicholas77	f	KsNK6VKK
Maynard.Jordan71	f	gX6A2KEKwYk
Lee.Phillip23	f	QKDrRcge
Aguirre.Xantha24	f	5s43HU
Oneill.Hollee91	f	CP1CyfZB
Madden.Meghan98	f	v8mPQF
Fischer.Samantha75	f	WEoUpGGimjfB
Lester.Xena97	f	3LWKKV
Tanner.Lareina50	f	cAMVV1Sa
Blake.Angelica72	f	ULgw1S
Conner.Patrick63	f	1bfhxrc
Garrison.Maile14	f	q29CobNc
Kirby.Keane59	f	kVYaoyd
Cross.Perry87	f	GahCPXzX
Marks.Adam39	f	7SNtwB8oe
Burt.Duncan60	f	7vvyWc4h
Matthews.Stella66	f	a9c5VCSSa
Luna.Imogene30	f	JTFLeFzHk
Morales.Candace97	f	p6aCCoHZ
Flowers.Gary39	f	PZv0DZ
Montoya.Lucius18	f	4AjIlv
Hatfield.Miranda37	f	FOPhW05z
Padilla.Declan90	f	pkH0CKNcKZL
Ramos.Amery55	f	c6j5rTV
Farley.Latifah29	f	6Boj8YZTL
Berry.Castor46	f	b8BIWbqg
Workman.Harding82	f	66Czk0bCXNH
Weeks.Tanya9	f	DsX3rZ5U6T5E
Ballard.Malcolm67	f	NEdwlej
Strickland.Charde28	f	98RhoX4
Carlson.Gemma63	f	ftYOqQ
Chang.Ferdinand77	f	wzUMMj
Rasmussen.Lawrence20	f	Jw2Ys71XF
Livingston.Cassandra78	f	ENY8DfPqe
Lawson.Nathaniel45	f	2WrTF05xfE
Decker.Cameron45	f	af5tw3AZXgM
Velez.Candace35	f	mwSDNtwKTB
Brock.Amal86	f	XIUawKssb
Hayes.Kim51	f	EQtRbWX
Schwartz.Carolyn13	f	6Kj8bEK9
Bell.Mary50	f	4IEHraWm0d
Barnes.Ruth27	f	t1BjseY
Valenzuela.Sydnee91	f	qHtJON5WrX
Sweeney.Mercedes15	f	wOOZfAS8QgGk
Rose.Andrew30	f	tMspAkx4D
Obrien.Iris93	f	GLZIgQ4
Albert.Kylan57	f	si26vaW7
Mcintyre.Veda6	f	XKi26f
Mendez.Barry62	f	1wG8ttdlFKS0
Giles.Carissa92	f	eSmaRhg4su
Hull.Armando46	f	ACm2N5lU3FMZ
Griffith.Kristen63	f	bvJkjF5r10
Walton.Thaddeus29	f	FceKsQA0RJ3E
Ortega.Gwendolyn97	f	Rq612cJJ
Lang.Ivana14	f	pi2RKh11
Brady.Rina10	f	syc5z0BpS
Reed.Gregory100	f	u0C91qzxNVJ
Roman.Camille22	f	bfyHZH
Mcintyre.Roth95	f	QHmlubBrNhQI
Roy.Stewart30	f	3ei7ysES1O8
Hunter.Rhoda8	f	fzLs3LltQfM5
Stanley.Cameran48	f	uDq7bGc
Knox.Yoko92	f	m3ym3caQ3
Allison.Phelan83	f	98Dj3UVwU0
Kent.Donna54	f	LlbCWTs
Moody.Gray92	f	BxPH0HW
Mendez.Avram60	f	XtnQMvaycFRk
Stevens.Chase10	f	2HOpCtCk
Deleon.Ursa16	f	bYZdhCq
Raymond.Gary62	f	8lMNbKrybaZf
Cole.Kermit6	f	mA0JeSFlcip
Morin.Abdul17	f	mLJR7OhtLFL
Durham.Marny28	f	I7CzXjUZ
Henson.Benjamin34	f	OHDXGl
Bridges.Tucker7	f	fZHPL6zi
Mitchell.Xyla20	f	GbuNou7RLv
Chan.Nomlanga48	f	07DASbT9pF
Nelson.Xena38	f	HSzURgHp3
Tillman.Rajah56	f	xaoXaOr3w
Roth.Nolan16	f	hDxT8m8VCP7
Rhodes.Lara22	f	JWG7fhHX1E
Keller.Minerva36	f	QPqhtGW2t
Burke.Eugenia70	f	Sq4alwHz
Gilmore.Clinton33	f	Dv9X2VQJGz
Turner.Amela17	f	cnwakGF
Levy.Cherokee62	f	ZbnE6K
Yates.Olivia55	f	nEkDfldAOQhZ
Singleton.Brynne89	f	GUr9cmPcvZ0
Miles.Nicole92	f	UHJEIhrxlHk
Petersen.Cairo68	f	EyJ3pD0DKT
Mcfadden.Sharon10	f	reLYuBL76te
Atkins.Judah32	f	WuKugcYphC4r
Dunn.Montana12	f	gWiiU79JF
Daugherty.Fallon98	f	yh92n5FV5
Farmer.Dora53	f	P2YjNg
Moon.Emerald95	f	HR5IH1jnB
Michael.Hiroko23	f	wBK5edyvI6G
Collins.Darius81	f	jmTySsdw
Garrett.Zeph49	f	NmNJMo
Colon.Ursa10	f	oxfedipDE
Estes.Jarrod4	f	SFsYMB
Hobbs.Karen39	f	20cOwC1obuO
Jacobs.Callie84	f	kRh1xtf
Jackson.Dahlia87	f	hzHGZy
Stevenson.Madaline67	f	PYoRrB9ngZ
Kennedy.Alice96	f	Qx5YhN41jgl
Jordan.Roanna91	f	lAsFS1P
Lawson.Asher8	f	FnyLhkaIWtTa
Curry.Cailin95	f	LIYUCM1zkg4
Booker.Imelda6	f	pc6FQ5B
Contreras.Kirsten46	f	uF45NTF9Pxp
Burgess.Warren34	f	7X6x47j3Alkd
Downs.Steel2	f	iuP3QY7
Benjamin.Jessica87	f	4j1VPbYhTP
Harper.Jonas23	f	TIBchpS9HS
Walls.Christopher5	f	0FenI1iUk8q
Skinner.Ruby31	f	ZPhGFhTc
Graham.Phelan12	f	P8OApTP2BE2
Mckee.Emery64	f	1lRJlt
Cole.Lillith48	f	KQnM0AkDm7
Wagner.Hayden86	f	kbNGz6AvdX2c
Noel.Yuli88	f	a2XQTu33d1
Jackson.Shelly76	f	OEc6GMkz5cq
Gamble.Hoyt29	f	hDSKOK
Scott.Mira46	f	338xeJsXUpi
Sykes.Eliana60	f	zZbJSs
Macias.Irene77	f	IMVzYNw
Romero.Margaret4	f	z1b7ADO
Newton.Logan47	f	Cf4QuQN5Q
Dawson.Jasper77	f	tHZlWlM
Bray.Mallory49	f	Rh6EH5ctll3
Barron.Lewis19	f	93sbhz
Carney.Tanya48	f	EgO2ClF
Nolan.Lani42	f	COSivwQ
Hansen.Candace3	f	U5i90rkBZrIt
Horn.Emery41	f	sK09y1
Collier.Ashely24	f	GZYxwU2yi
Barton.Michelle11	f	4F4xXsmlXy
Allen.James4	f	wdPfCUGwHL7
Hoffman.Clark45	f	DvgOM8N1
Shields.Emi97	f	0rdi5A7Y8E
Holden.Martena56	f	2gNsTh4c
Trevino.Remedios97	f	a5BnS19
Aguilar.Jeremy92	f	4PqFkvT
Ortega.Abbot37	f	AZTGqVjexSVr
Villarreal.Hyacinth58	f	lRwvA1SQo
Gibson.Ferris81	f	bZQiFQZvv
Castillo.Indigo58	f	qbCGstogrg
Schroeder.Kermit67	f	MFVV665P
Jacobson.Kelsie21	f	jQQV2JLmG
Howard.Cooper71	f	lnISVnGP0r
Burton.Wylie56	f	NCmgysJw
Gaines.Drake14	f	MrmDg4XK
Carpenter.Ahmed11	f	eH4dMTjYLCWL
Richardson.Aquila57	f	OXqhNoOd
Mcdowell.Celeste67	f	LZWDQlFRS
Lowery.Celeste58	f	cebAbBr1i
Petty.Ferdinand76	f	ppQHMaAQmlg
Hernandez.Phyllis11	f	SS8aSBHHJJhA
Mcleod.Clinton15	f	HQfN12
Hayes.Hyacinth38	f	QzRl1SP42
Mcknight.Kyle46	f	fSt7t9
Walsh.Tiger42	f	CYSGO0n
Finch.Ross78	f	4aAAudpq5
Ingram.Leo88	f	CozUAl
Hudson.Aileen4	f	jJFx3laD
Mullins.Willa79	f	cEz0jbG95kgv
Sweet.Quamar7	f	szed49QDMH
Dejesus.Kyle72	f	9Etyi8HYW87
Whitehead.Maggie96	f	WBOXUEXsq
Solomon.Jemima13	f	PIuEL8unqOv
Grimes.Marvin9	f	r2tJQg0hIs0j
Garner.Echo30	f	42GOnadWKkw
Sellers.Mira68	f	UgnXHpICK
Nichols.Colton17	f	OMwGrHKz0A
Blanchard.Felix40	f	njAxVY
Powell.Quintessa88	f	oY09qzp
Guthrie.Bernard47	f	vseKh4NXLLYK
Hart.Calista7	f	rsp0RTjp
Swanson.Oliver20	f	Vy8I1o
Myers.Duncan11	f	1y5TJnR
Boone.Jamal86	f	S1RYmsfLC2yj
Wynn.Lionel64	f	yF5WnKzI3M1G
Dickerson.Natalie18	f	JQ4BTcSJlqZ
Martin.Channing22	f	Jj2gqPf1
Miller.Zephania48	f	LvuhmCtrqV2
Leon.Evangeline61	f	6oWswu
Bridges.Serena88	f	qppYkbl5N
Cross.Kimberley4	f	YN4jiAUB
Andrews.Jenna22	f	qW930W2Q
Snider.Nehru79	f	MigHuUJ
Roth.Kyle3	f	vkQzLiQVQ
Rodgers.Moses15	f	6nydCjG
Christian.Rhona26	f	moZWlg6
Perry.Tara71	f	Uds9tyfOdKA
Atkins.Yvette30	f	1BT0XVJ
Estes.Gemma55	f	u5d4oil1qfo
Fernandez.Chaim55	f	rOcbgE
Castaneda.Riley8	f	iifC261AIC
Day.Felicia2	f	3nMd3hYrs4
Collins.Holly20	f	pswNh6fn8RjO
Frye.Maggie98	f	GkTedm
Osborne.Georgia12	f	r9jxxDOPbBo
Harper.Lance100	f	iFBdTG6S
Bowman.Naomi94	f	S6ae3nH
Pittman.Lydia91	f	YiGlwEue
Franco.Keegan61	f	30ePpIACfFu
Crosby.Julian52	f	9c3wTzkgd
Pratt.Regina12	f	OimmLnwG
Alston.Dominic65	f	zf7LWD3mRc
Madden.Duncan12	f	W3pmWfgEWJm
Head.Isaiah78	f	LZ57gdUemYK
Hayden.Gretchen22	f	kyxHGSFK
Phillips.Germaine2	f	uAHhnX
Palmer.Clare90	f	brZbq8IvjcD
Dunlap.Graiden85	f	rTOLR1J4
Miller.Mannix38	f	TznV5QHHfptV
Bass.Maite38	f	hsIvOG
Alvarez.Lael34	f	NM97qKlR
Lucas.Burton24	f	HvgJiK
Cash.Sierra87	f	OQeGfo
Greene.Maggie23	f	da2GSOqFe
Miranda.Elijah5	f	kor3tGzy3
Estrada.Ulysses96	f	Gs1Lgt2DrSVk
Stafford.Maris17	f	fWrBfbGx
Guy.Brenna41	f	92gBXxQx
Fischer.Kato95	f	vVkvtn4e
Moody.Wesley2	f	7DcPfQFPR381
Lynch.Kimberley27	f	pEC49dWKM
Riddle.Julie74	f	0GVuN9MqpKK
Hancock.Alfreda49	f	mTGa6spt
Pace.Victoria83	f	FGveHt
Conley.Sylvia58	f	jv5qfqha88
Dyer.Kiayada19	f	gpyAPmbKQ9ez
Huffman.Ferdinand12	f	R1MWr3PyzYN
Larsen.Macaulay53	f	yiyoAc5Kfnk
Boyd.Rhea4	f	bLHlh4UPE
Fowler.Iris54	f	xeUXZtyoCjfS
Morton.Galvin95	f	dXoInG8jf0HG
Hunter.Sybil43	f	elzltIyWlYHr
Larsen.Brady45	f	qNAmDghR
Harding.Fritz24	f	XOkA9jLkir
Mercado.Aimee93	f	0fTRzGqtq
Kemp.Sydney66	f	LGwTbK
Boyle.Inga72	f	O0d1ns
Stevenson.Ulla58	f	kYsb3aHso
Higgins.Alec20	f	e3OTxkiWD9qn
Lawson.Ashton51	f	w6FmMZVIKb4
Figueroa.Orla61	f	f1ehwsH1
Pace.Madison82	f	yCGGty
Mclaughlin.Nadine93	f	quzLG9bBb
Hardy.Leslie67	f	oAWaDEwr
Key.Simone25	f	27uIBywJ
Gibbs.Lance11	f	PY4RMezQ0yl
Suarez.Martina50	f	5ZzWil
Stevenson.Oren10	f	sBfK1T2Y
Rogers.Nora79	f	ZHIp9oYb
Lowe.Kristen68	f	6eQ68FSXkqG5
Deleon.Hollee41	f	VSde4ak
Watkins.Echo23	f	wxMUNb7Gcws
Richardson.Mollie88	f	ZhBoUKPNz
Hewitt.Dolan87	f	G16ftyXAmWz
Huffman.Felicia60	f	G6uiXlIOQ
Moran.Chiquita100	f	p4gCmfN9Lm
Fitzpatrick.Holmes75	f	HJWi0v
Webster.Amity84	f	JYMguI8vYK
Roman.Kieran63	f	er6Sbr
Wolfe.Curran44	f	OFm9Fj
Ramsey.Yvette25	f	XPJV7MqUAvG
Carney.Noble15	f	JGjsblddl
Hudson.Thor22	f	PnJegVY24GM
David.Joshua39	f	46qz9d
Hamilton.Herrod37	f	pVzWcrQQKop
Dale.Leroy26	f	HQ77Tma
Whitley.Heidi25	f	F5Hj0x710ip
Stark.Cody92	f	TQXhL505
Ryan.Grace96	f	xoBTjw66
Stanton.Fay51	f	lBVVLl4twu
Lamb.Lydia34	f	sVI01eqk
Sloan.Elliott92	f	8ukGs7C22B
Beard.Dacey17	f	6MUOfddVfuF
Turner.Emily41	f	DbuYJ7nQctP
Martinez.Quentin83	f	QwhOgpSq
Vaughn.Francesca36	f	O8PmgzPOjL
Higgins.Gannon55	f	BHLP89p
Park.Iliana41	f	wbUPMo0fn
Daniel.Brandon11	f	piXfPD8dvTK
Reed.Cora15	f	ybAKIQRaI7
Green.Robin52	f	LiCV9cFXp
Poole.Alisa1	f	AhEvbZnu
Castro.Yuri6	f	wO2CIhZ
Horne.Hollee43	f	CxR8RxGCeQR
Sampson.Rooney97	f	OYH4UB4wjZ
Atkins.Winifred10	f	UkbyLh
Joseph.Keegan13	f	rllw95Qp
Marsh.Jorden96	f	lO5SnYELI
Bennett.Mary57	f	lfG6WiOMwE
Rowland.Adele41	f	J6JSbDZU2HAC
Forbes.David77	f	8jloza1h3Tj8
Meyer.Michael57	f	ULB2ept3dEa
Donaldson.Dillon18	f	eznhUaL
Klein.Yael79	f	8CQKuLBJb
Gould.Ferris72	f	FHA29EsEVMs
Vasquez.Kaseem21	f	A6NCkKVuUMq
Oconnor.Fritz50	f	n0ebyzddrG
Hardin.Evan67	f	sVgyjYXpGd
Weaver.Janna59	f	ZjwM66zIWKMS
Hoover.Raya40	f	LW8dceh
Casey.Kendall70	f	QSvoN8r
Guy.Clare17	f	RzYh3Q
Graham.Gillian83	f	eAujmbVQiBaH
Oliver.Venus52	f	N36S9REMmvh
Buckner.Heather43	f	5GH1fbBgr
Warren.Hyacinth69	f	FF6zvi76DN
Daniel.Quamar92	f	DHY2cUgnM
Good.Shaine54	f	XCNsR3ubu
Schultz.Maite82	f	RMWhH83
Benjamin.Allistair71	f	Ttn8lh
Barber.Shannon83	f	ZQIMYsm2
Mcgee.Boris66	f	REYhtmvD
Combs.Libby96	f	qVkwsXL
Middleton.Aretha35	f	ZMOTuCKsAD
Farmer.Isaiah3	f	gPdoNr2Ac
Mejia.Montana71	f	HseH2RtlF
Velazquez.Shelly91	f	ji5WEtS
Albert.Dorothy22	f	RsHlMe6O9
Tucker.Lucian78	f	TeZ2pqqZg
Mays.Zelenia2	f	G9NaduLt
Mcknight.Dorothy30	f	hzAVUa4r6
Odonnell.Deacon8	f	Rem7MbNOpw
Compton.Demetria66	f	OAC8vWq
Vang.Anjolie13	f	fB9yt3JDsj
Burke.Martha6	f	r2OMYZ6fZ
Reyes.Harding37	f	Vs9n5xL1
Pena.Hayes97	f	aXnM1xLl9
Grimes.Gray62	f	c4Gwtss
Velez.Bertha40	f	ZczXQ6j5S0X
Gould.Darrel85	f	cAOKVcS
Fernandez.Deborah38	f	bQT22QRV
Conrad.Idola55	f	EydQNSZVCKN
Moon.Harding14	f	yVnhPoc0
James.Denton32	f	ZAPF7t5W
Roberts.Stephen1	f	TcV0b45Lql
Robbins.Erica16	f	wbfxXGemB
Rodriguez.Stone40	f	PAsdDgVlhue
Finley.Shelly100	f	6WotAqQpOZA
Abbott.Owen53	f	Po5uXwboWSQc
Curtis.Michael78	f	j9bULn1YWqg
Waller.Jena96	f	JvHwoik
Salazar.Coby19	f	eimgfR
Schwartz.Megan66	f	AMTQhtP7G3Y
Ryan.Aladdin11	f	TWMlp1UCw
Mclaughlin.Austin97	f	hpgIpQc9P2
Chase.Chaim30	f	bN5xfA
Woods.Kennan17	f	fsAKyQ9
Phelps.Illana89	f	DOQaAK
Cooley.Talon70	f	ZxKDB1r91ig
Mann.Brian16	f	tEtLU1JzT
Gilmore.Alden89	f	rCfLAo2
Wells.Vincent91	f	avNXNX3
Beck.Sybil86	f	AZwhmnqKM
Douglas.Davis20	f	dGB3IWxK
Rivera.Kelsie6	f	tApSAsKM5KN
Fernandez.Colton64	f	FDeqwR6Vn2
Barber.Yael97	f	Aa5FkFg4BjSS
Gilmore.Porter80	f	U3b4abGAiTz
Townsend.Leah8	f	fVvDMtYIo
Davis.Jordan9	f	K1s7MD
Kemp.Wynter61	f	2Y3maOdbGEz0
Stuart.Juliet6	f	JGXFzubhx
Gonzales.Indigo58	f	ewqD7AV4Ri
Kidd.Alma42	f	WQAmrXaD
Christian.Xyla72	f	xBce38dUP
Snyder.India67	f	c73IXpar
Short.Laith32	f	IEq0g6L
Haynes.Lilah97	f	D0YHg7nvhA6
Dejesus.Bevis5	f	HpoWO55
Bonner.Martin82	f	J225Izw9b
Roman.Shana89	f	gHkOzZICc0
Paul.Griffith99	f	MUY9IP
Smith.Julian76	f	Djd7bhP
Roach.Nyssa62	f	YvY0JXGEp4
Reeves.Merritt36	f	A98C55Wcwj
Irwin.Porter90	f	YtcdT6
Santos.Brett11	f	e7HS0eVAjbmV
Doyle.Whoopi68	f	9yrWMz1Ju
Castro.Sean47	f	Tqg7NlnuMwJ
Davidson.Meghan49	f	VlT6g5Aoh4
Byers.Bert51	f	JxtsSkqgL
Rowe.Adrian64	f	MHyl4I9j6H
Horne.Porter57	f	YuwhFxu4k
Snow.Brett59	f	G8PiTuMFF2x
May.Dorothy63	f	E1gWZzlI
Dunlap.Irma4	f	gtkIp2
Howe.Raven27	f	VFCpV5H
Ferguson.Jael67	f	iMjzJNHw
Donaldson.Eric52	f	q1jaNrUx
Schmidt.Mufutau78	f	DUWvNdPYH
Harrington.Peter98	f	JHc5wW
Gillespie.Uta93	f	ThHkwaI8AOb
Davenport.Louis2	f	LoRdAD
Guy.Bernard63	f	ZH8cpN
May.Zenaida90	f	KoNzzvP
Jensen.Judith77	f	4HvbM9sPf2
Reyes.Scarlett68	f	WVSyQRp
Oneal.Channing81	f	NiRVEj
Nunez.Madeline78	f	azb6gdU1i
Hopkins.Barbara4	f	G10QxWSMvKmQ
Carrillo.Hedley46	f	44kn6g
Farrell.Samuel79	f	flNoMqc5r
Rowland.Kevyn66	f	9iUcCIHe4lh
Carey.Madonna75	f	ItH0s7
Sosa.Sasha51	f	SSADhvv
Andrews.Shaeleigh9	f	H9WsVQL
Mccormick.Guinevere28	f	xViiIhYEo
Logan.Wing49	f	WhPUZqk
Gamble.Chastity15	f	kMuaBzv52WB
Burton.Carly6	f	LVuNAYt7nl
Mcintosh.Roary89	f	PGi2Rj
Duncan.Berk75	f	MOOg916Y
Compton.May41	f	NI1doKZO6cdU
Chen.Kelsey73	f	OINbMlPQ
Clark.Neville89	f	nfU1M0OEv
Boyd.Daquan50	f	f2J26Q
Roberson.Mari59	f	jKAzIhCIRrR3
Hendricks.Wilma48	f	4iCeHUrhkONL
Howell.Kitra87	f	WRNw43qyzB
Perkins.Merrill87	f	thzatxaUiOI5
Christensen.Constance90	f	TbxqLa
Mendoza.Christopher100	f	rVdcS0c
Peters.Cherokee71	f	zFYtExjXG
Kaufman.Ciara5	f	5BGHYWppJHf
Moody.Hall39	f	lV6bCg
Gross.Adena8	f	wI0uRaX
Joyce.Kareem51	f	rn0TnX
Guy.Grant10	f	DmylAT
Albert.Ina45	f	fzPIDhmbHIj
Mcclain.Elliott76	f	uf9nuWD
Rutledge.Teagan33	f	UgsMo4y
Ramos.Jamal78	f	g1he7H96q
Barrett.Echo100	f	v56i1NfL1Ov
Glass.Aristotle86	f	Dc9mXkZTjp
Herring.Adele60	f	u8gPxv4EKwC
Rich.Adrienne97	f	jXa2azwniSC6
Rivers.Ingrid95	f	DpQgW1VUmFT
Mcmillan.Mariko69	f	eRCCAOsOXC
Carson.Herrod88	f	PRg8xUOx
Lewis.Wayne43	f	Kc1gwNtXMwJ5
Dunlap.Harper2	f	1pGWf1y4Bq
Bird.Branden18	f	yQCnbsaTVj
Garcia.Reed1	f	GtBff4uS6Yzt
Mcguire.Mia1	f	j4r09OCBorT
Short.Nathan42	f	NZDcTK
arri.kurniawan	f	basdat123!!
\.


--
-- Data for Name: jadwal_penting; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY jadwal_penting (nomor, tahun, jenjang, waktu_mulai, waktu_selesai, deskripsi) FROM stdin;
1	2016	S1	2016-02-13 00:00:00	2016-03-25 23:59:00	Periode Upload Berkas Persyaratan UUI
1	2016	S1	2016-02-15 00:00:00	2016-03-25 23:59:00	Periode Pendaftaran Online UUI
1	2016	S1	2016-02-17 00:00:00	2016-03-27 23:59:00	Periode Pembayaran Biaya Pendaftaran UUI
1	2016	S1	2016-05-02 00:00:00	2016-05-05 23:59:00	Pengumuman Hasil Seleksi Masuk Jalur UUI
1	2016	S2	2016-02-13 00:00:00	2016-03-25 23:59:00	Pendaftaran Online
1	2016	S2	2016-02-14 00:00:00	2016-03-25 23:59:00	Pembayaran
1	2016	S2	2016-03-26 00:00:00	2016-03-31 23:59:00	Pencetakan Kartu Tanda Ujian
1	2016	S2	2016-04-02 09:00:00	2016-04-02 14:00:00	Ujian Saringan Masuk
1	2016	S2	2016-05-02 00:00:00	2016-05-05 23:59:00	Pengumuman Hasil Seleksi Masuk
1	2016	S3	2016-02-13 00:00:00	2016-03-25 23:59:00	Pendaftaran Online
1	2016	S3	2016-02-14 00:00:00	2016-03-25 23:59:00	Pembayaran
1	2016	S3	2016-03-26 00:00:00	2016-03-31 23:59:00	Pencetakan Kartu Tanda Ujian
1	2016	S3	2016-04-02 09:00:00	2016-04-02 14:00:00	Ujian Saringan Masuk
1	2016	S3	2016-05-02 00:00:00	2016-05-05 23:59:00	Pengumuman Hasil Seleksi Masuk
2	2016	S1	2016-04-10 00:00:00	2016-05-08 23:59:00	Pendaftaran Online
2	2016	S1	2016-04-11 00:00:00	2016-05-08 23:59:00	Pembayaran
2	2016	S1	2016-05-19 00:00:00	2016-05-20 23:59:00	Pencetakan Kartu Tanda Ujian
2	2016	S1	2016-05-21 09:00:00	2016-05-21 14:00:00	Ujian Saringan Masuk
2	2016	S1	2016-06-21 00:00:00	2016-06-30 23:59:00	Pengumuman Hasil Seleksi Masuk
2	2016	S2	2016-04-10 00:00:00	2016-05-08 23:59:00	Pendaftaran Online
2	2016	S2	2016-04-11 00:00:00	2016-05-08 23:59:00	Pembayaran
2	2016	S2	2016-05-19 00:00:00	2016-05-20 23:59:00	Pencetakan Kartu Tanda Ujian
2	2016	S2	2016-05-21 09:00:00	2016-05-21 14:00:00	Ujian Saringan Masuk
2	2016	S2	2016-06-21 00:00:00	2016-06-30 23:59:00	Pengumuman Hasil Seleksi Masuk
2	2016	S3	2016-04-10 00:00:00	2016-05-08 23:59:00	Pendaftaran Online
2	2016	S3	2016-04-11 00:00:00	2016-05-08 23:59:00	Pembayaran
2	2016	S3	2016-05-19 00:00:00	2016-05-20 23:59:00	Pencetakan Kartu Tanda Ujian
2	2016	S3	2016-05-21 09:00:00	2016-05-21 14:00:00	Ujian Saringan Masuk
2	2016	S3	2016-06-21 00:00:00	2016-06-30 23:59:00	Pengumuman Hasil Seleksi Masuk
3	2016	S1	2016-06-19 00:00:00	2016-07-14 23:59:00	Pendaftaran Online
3	2016	S1	2016-06-20 00:00:00	2016-07-14 23:59:00	Pembayaran
3	2016	S1	2016-07-15 00:00:00	2016-07-20 23:59:00	Pencetakan Kartu Tanda Ujian
3	2016	S1	2016-07-23 09:00:00	2016-07-23 14:00:00	Ujian Saringan Masuk
3	2016	S1	2016-07-31 00:00:00	2016-08-02 23:59:00	Pengumuman Hasil Seleksi Masuk
4	2016	S2	2016-10-02 00:00:00	2016-11-03 23:59:00	Pendaftaran Online
4	2016	S2	2016-10-03 00:00:00	2016-11-03 23:59:00	Pembayaran
4	2016	S2	2016-10-15 00:00:00	2016-11-09 23:59:00	Pencetakan Kartu Tanda Ujian
4	2016	S2	2016-11-12 09:00:00	2016-11-12 14:00:00	Ujian Saringan Masuk
4	2016	S2	2016-12-11 00:00:00	2016-12-15 23:59:00	Pengumuman Hasil Seleksi Masuk
4	2016	S3	2016-10-02 00:00:00	2016-11-03 23:59:00	Pendaftaran Online
4	2016	S3	2016-10-03 00:00:00	2016-11-03 23:59:00	Pembayaran
4	2016	S3	2016-10-15 00:00:00	2016-11-09 23:59:00	Pencetakan Kartu Tanda Ujian
4	2016	S3	2016-11-12 09:00:00	2016-11-12 14:00:00	Ujian Saringan Masuk
4	2016	S3	2016-12-11 00:00:00	2016-12-15 23:59:00	Pengumuman Hasil Seleksi Masuk
1	2017	S1	2017-02-13 00:00:00	2017-03-25 23:59:00	Periode Upload Berkas Persyaratan UUI
1	2017	S1	2017-02-15 00:00:00	2017-03-25 23:59:00	Periode Pendaftaran Online UUI
1	2017	S1	2017-02-17 00:00:00	2017-03-27 23:59:00	Periode Pembayaran Biaya Pendaftaran UUI
1	2017	S1	2017-05-02 00:00:00	2017-05-05 23:59:00	Pengumuman Hasil Seleksi Masuk Jalur UUI
1	2017	S2	2017-02-13 00:00:00	2017-03-25 23:59:00	Pendaftaran Online
1	2017	S2	2017-02-14 00:00:00	2017-03-25 23:59:00	Pembayaran
1	2017	S2	2017-03-26 00:00:00	2017-03-31 23:59:00	Pencetakan Kartu Tanda Ujian
1	2017	S2	2017-04-02 09:00:00	2017-04-02 14:00:00	Ujian Saringan Masuk
1	2017	S2	2017-05-02 00:00:00	2017-05-05 23:59:00	Pengumuman Hasil Seleksi Masuk
1	2017	S3	2017-02-13 00:00:00	2017-03-25 23:59:00	Pendaftaran Online
1	2017	S3	2017-02-14 00:00:00	2017-03-25 23:59:00	Pembayaran
1	2017	S3	2017-03-26 00:00:00	2017-03-31 23:59:00	Pencetakan Kartu Tanda Ujian
1	2017	S3	2017-04-02 09:00:00	2017-04-02 14:00:00	Ujian Saringan Masuk
1	2017	S3	2017-05-02 00:00:00	2017-05-05 23:59:00	Pengumuman Hasil Seleksi Masuk
2	2017	S1	2017-04-10 00:00:00	2017-05-08 23:59:00	Pendaftaran Online
2	2017	S1	2017-04-11 00:00:00	2017-05-08 23:59:00	Pembayaran
2	2017	S1	2017-05-19 00:00:00	2017-05-20 23:59:00	Pencetakan Kartu Tanda Ujian
2	2017	S1	2017-05-21 09:00:00	2017-05-21 14:00:00	Ujian Saringan Masuk
2	2017	S1	2017-06-21 00:00:00	2017-06-30 23:59:00	Pengumuman Hasil Seleksi Masuk
2	2017	S2	2017-04-10 00:00:00	2017-05-08 23:59:00	Pendaftaran Online
2	2017	S2	2017-04-11 00:00:00	2017-05-08 23:59:00	Pembayaran
2	2017	S2	2017-05-19 00:00:00	2017-05-20 23:59:00	Pencetakan Kartu Tanda Ujian
2	2017	S2	2017-05-21 09:00:00	2017-05-21 14:00:00	Ujian Saringan Masuk
2	2017	S2	2017-06-21 00:00:00	2017-06-30 23:59:00	Pengumuman Hasil Seleksi Masuk
2	2017	S3	2017-04-10 00:00:00	2017-05-08 23:59:00	Pendaftaran Online
2	2017	S3	2017-04-11 00:00:00	2017-05-08 23:59:00	Pembayaran
2	2017	S3	2017-05-19 00:00:00	2017-05-20 23:59:00	Pencetakan Kartu Tanda Ujian
2	2017	S3	2017-05-21 09:00:00	2017-05-21 14:00:00	Ujian Saringan Masuk
2	2017	S3	2017-06-21 00:00:00	2017-06-30 23:59:00	Pengumuman Hasil Seleksi Masuk
\.


--
-- Data for Name: jenjang; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY jenjang (nama) FROM stdin;
S1
S2
S3
\.


--
-- Data for Name: lokasi_jadwal; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY lokasi_jadwal (kota, tempat, nomor_periode, tahun_periode, jenjang, waktu_awal) FROM stdin;
Depok	Kampus UI Depok	1	2016	S2	2016-04-02 09:00:00
Jakarta Pusat	Kampus UI Salemba	1	2016	S2	2016-04-02 09:00:00
Depok	Kampus UI Depok	1	2016	S3	2016-04-02 09:00:00
Jakarta Pusat	Kampus UI Salemba	1	2016	S3	2016-04-02 09:00:00
Depok	Kampus UI Depok	2	2016	S1	2016-05-21 09:00:00
Jakarta Pusat	Kampus UI Salemba	2	2016	S1	2016-05-21 09:00:00
Jakarta Pusat	Gedung Serbaguna Jakpus	2	2016	S1	2016-05-21 09:00:00
Jakarta Timur	Gedung Serbaguna Jaktim	2	2016	S1	2016-05-21 09:00:00
Jakarta Selatan	Gedung Serbaguna Jaksel	2	2016	S1	2016-05-21 09:00:00
Depok	Gedung Serbaguna Depok	2	2016	S1	2016-05-21 09:00:00
Bekasi	Gedung Serbaguna Bekasi	2	2016	S1	2016-05-21 09:00:00
Tangerang	Gedung Serbaguna Tangerang	2	2016	S1	2016-05-21 09:00:00
Tangerang Selatan	Gedung Serbaguna Tangsel	2	2016	S1	2016-05-21 09:00:00
Bogor	Gedung Serbaguna Bogor	2	2016	S1	2016-05-21 09:00:00
Bandung	Gedung Serbaguna Bandung	2	2016	S1	2016-05-21 09:00:00
Jogjakarta	Gedung Serbaguna Jogjakarta	2	2016	S1	2016-05-21 09:00:00
Surabaya	Gedung Serbaguna Surabaya	2	2016	S1	2016-05-21 09:00:00
Makasar	Gedung Serbaguna Makasar	2	2016	S1	2016-05-21 09:00:00
Medan	Gedung Serbaguna Medan	2	2016	S1	2016-05-21 09:00:00
Padang	Gedung Serbaguna Padang	2	2016	S1	2016-05-21 09:00:00
Palembang	Gedung Serbaguna Palembang	2	2016	S1	2016-05-21 09:00:00
Depok	Kampus UI Depok	2	2016	S2	2016-05-21 09:00:00
Jakarta Pusat	Kampus UI Salemba	2	2016	S2	2016-05-21 09:00:00
Jakarta Pusat	Gedung Serbaguna Jakpus	2	2016	S2	2016-05-21 09:00:00
Jakarta Timur	Gedung Serbaguna Jaktim	2	2016	S2	2016-05-21 09:00:00
Jakarta Selatan	Gedung Serbaguna Jaksel	2	2016	S2	2016-05-21 09:00:00
Depok	Gedung Serbaguna Depok	2	2016	S2	2016-05-21 09:00:00
Bekasi	Gedung Serbaguna Bekasi	2	2016	S2	2016-05-21 09:00:00
Tangerang	Gedung Serbaguna Tangerang	2	2016	S2	2016-05-21 09:00:00
Tangerang Selatan	Gedung Serbaguna Tangsel	2	2016	S2	2016-05-21 09:00:00
Bogor	Gedung Serbaguna Bogor	2	2016	S2	2016-05-21 09:00:00
Bandung	Gedung Serbaguna Bandung	2	2016	S2	2016-05-21 09:00:00
Jogjakarta	Gedung Serbaguna Jogjakarta	2	2016	S2	2016-05-21 09:00:00
Surabaya	Gedung Serbaguna Surabaya	2	2016	S2	2016-05-21 09:00:00
Makasar	Gedung Serbaguna Makasar	2	2016	S2	2016-05-21 09:00:00
Medan	Gedung Serbaguna Medan	2	2016	S2	2016-05-21 09:00:00
Padang	Gedung Serbaguna Padang	2	2016	S2	2016-05-21 09:00:00
Palembang	Gedung Serbaguna Palembang	2	2016	S2	2016-05-21 09:00:00
Depok	Kampus UI Depok	2	2016	S3	2016-05-21 09:00:00
Jakarta Pusat	Kampus UI Salemba	2	2016	S3	2016-05-21 09:00:00
Jakarta Pusat	Gedung Serbaguna Jakpus	2	2016	S3	2016-05-21 09:00:00
Jakarta Timur	Gedung Serbaguna Jaktim	2	2016	S3	2016-05-21 09:00:00
Jakarta Selatan	Gedung Serbaguna Jaksel	2	2016	S3	2016-05-21 09:00:00
Depok	Gedung Serbaguna Depok	2	2016	S3	2016-05-21 09:00:00
Bekasi	Gedung Serbaguna Bekasi	2	2016	S3	2016-05-21 09:00:00
Tangerang	Gedung Serbaguna Tangerang	2	2016	S3	2016-05-21 09:00:00
Tangerang Selatan	Gedung Serbaguna Tangsel	2	2016	S3	2016-05-21 09:00:00
Bogor	Gedung Serbaguna Bogor	2	2016	S3	2016-05-21 09:00:00
Bandung	Gedung Serbaguna Bandung	2	2016	S3	2016-05-21 09:00:00
Jogjakarta	Gedung Serbaguna Jogjakarta	2	2016	S3	2016-05-21 09:00:00
Surabaya	Gedung Serbaguna Surabaya	2	2016	S3	2016-05-21 09:00:00
Makasar	Gedung Serbaguna Makasar	2	2016	S3	2016-05-21 09:00:00
Medan	Gedung Serbaguna Medan	2	2016	S3	2016-05-21 09:00:00
Padang	Gedung Serbaguna Padang	2	2016	S3	2016-05-21 09:00:00
Palembang	Gedung Serbaguna Palembang	2	2016	S3	2016-05-21 09:00:00
Depok	Kampus UI Depok	3	2016	S1	2016-07-23 09:00:00
Jakarta Pusat	Kampus UI Salemba	3	2016	S1	2016-07-23 09:00:00
Depok	Kampus UI Depok	4	2016	S2	2016-11-12 09:00:00
Jakarta Pusat	Kampus UI Salemba	4	2016	S2	2016-11-12 09:00:00
Depok	Kampus UI Depok	4	2016	S3	2016-11-12 09:00:00
Jakarta Pusat	Kampus UI Salemba	4	2016	S3	2016-11-12 09:00:00
Depok	Kampus UI Depok	1	2017	S2	2017-04-02 09:00:00
Jakarta Pusat	Kampus UI Salemba	1	2017	S2	2017-04-02 09:00:00
Depok	Kampus UI Depok	1	2017	S3	2017-04-02 09:00:00
Jakarta Pusat	Kampus UI Salemba	1	2017	S3	2017-04-02 09:00:00
Depok	Kampus UI Depok	2	2017	S1	2017-05-21 09:00:00
Jakarta Pusat	Kampus UI Salemba	2	2017	S1	2017-05-21 09:00:00
Jakarta Pusat	Gedung Serbaguna Jakpus	2	2017	S1	2017-05-21 09:00:00
Jakarta Timur	Gedung Serbaguna Jaktim	2	2017	S1	2017-05-21 09:00:00
Jakarta Selatan	Gedung Serbaguna Jaksel	2	2017	S1	2017-05-21 09:00:00
Depok	Gedung Serbaguna Depok	2	2017	S1	2017-05-21 09:00:00
Bekasi	Gedung Serbaguna Bekasi	2	2017	S1	2017-05-21 09:00:00
Tangerang	Gedung Serbaguna Tangerang	2	2017	S1	2017-05-21 09:00:00
Tangerang Selatan	Gedung Serbaguna Tangsel	2	2017	S1	2017-05-21 09:00:00
Bogor	Gedung Serbaguna Bogor	2	2017	S1	2017-05-21 09:00:00
Bandung	Gedung Serbaguna Bandung	2	2017	S1	2017-05-21 09:00:00
Jogjakarta	Gedung Serbaguna Jogjakarta	2	2017	S1	2017-05-21 09:00:00
Surabaya	Gedung Serbaguna Surabaya	2	2017	S1	2017-05-21 09:00:00
Makasar	Gedung Serbaguna Makasar	2	2017	S1	2017-05-21 09:00:00
Medan	Gedung Serbaguna Medan	2	2017	S1	2017-05-21 09:00:00
Padang	Gedung Serbaguna Padang	2	2017	S1	2017-05-21 09:00:00
Palembang	Gedung Serbaguna Palembang	2	2017	S1	2017-05-21 09:00:00
Depok	Kampus UI Depok	2	2017	S2	2017-05-21 09:00:00
Jakarta Pusat	Kampus UI Salemba	2	2017	S2	2017-05-21 09:00:00
Jakarta Pusat	Gedung Serbaguna Jakpus	2	2017	S2	2017-05-21 09:00:00
Jakarta Timur	Gedung Serbaguna Jaktim	2	2017	S2	2017-05-21 09:00:00
Jakarta Selatan	Gedung Serbaguna Jaksel	2	2017	S2	2017-05-21 09:00:00
Depok	Gedung Serbaguna Depok	2	2017	S2	2017-05-21 09:00:00
Bekasi	Gedung Serbaguna Bekasi	2	2017	S2	2017-05-21 09:00:00
Tangerang	Gedung Serbaguna Tangerang	2	2017	S2	2017-05-21 09:00:00
Tangerang Selatan	Gedung Serbaguna Tangsel	2	2017	S2	2017-05-21 09:00:00
Bogor	Gedung Serbaguna Bogor	2	2017	S2	2017-05-21 09:00:00
Bandung	Gedung Serbaguna Bandung	2	2017	S2	2017-05-21 09:00:00
Jogjakarta	Gedung Serbaguna Jogjakarta	2	2017	S2	2017-05-21 09:00:00
Surabaya	Gedung Serbaguna Surabaya	2	2017	S2	2017-05-21 09:00:00
Makasar	Gedung Serbaguna Makasar	2	2017	S2	2017-05-21 09:00:00
Medan	Gedung Serbaguna Medan	2	2017	S2	2017-05-21 09:00:00
Padang	Gedung Serbaguna Padang	2	2017	S2	2017-05-21 09:00:00
Palembang	Gedung Serbaguna Palembang	2	2017	S2	2017-05-21 09:00:00
Depok	Kampus UI Depok	2	2017	S3	2017-05-21 09:00:00
Jakarta Pusat	Kampus UI Salemba	2	2017	S3	2017-05-21 09:00:00
Jakarta Pusat	Gedung Serbaguna Jakpus	2	2017	S3	2017-05-21 09:00:00
Jakarta Timur	Gedung Serbaguna Jaktim	2	2017	S3	2017-05-21 09:00:00
Jakarta Selatan	Gedung Serbaguna Jaksel	2	2017	S3	2017-05-21 09:00:00
Depok	Gedung Serbaguna Depok	2	2017	S3	2017-05-21 09:00:00
Bekasi	Gedung Serbaguna Bekasi	2	2017	S3	2017-05-21 09:00:00
Tangerang	Gedung Serbaguna Tangerang	2	2017	S3	2017-05-21 09:00:00
Tangerang Selatan	Gedung Serbaguna Tangsel	2	2017	S3	2017-05-21 09:00:00
Bogor	Gedung Serbaguna Bogor	2	2017	S3	2017-05-21 09:00:00
Bandung	Gedung Serbaguna Bandung	2	2017	S3	2017-05-21 09:00:00
Jogjakarta	Gedung Serbaguna Jogjakarta	2	2017	S3	2017-05-21 09:00:00
Surabaya	Gedung Serbaguna Surabaya	2	2017	S3	2017-05-21 09:00:00
Makasar	Gedung Serbaguna Makasar	2	2017	S3	2017-05-21 09:00:00
Medan	Gedung Serbaguna Medan	2	2017	S3	2017-05-21 09:00:00
Padang	Gedung Serbaguna Padang	2	2017	S3	2017-05-21 09:00:00
Palembang	Gedung Serbaguna Palembang	2	2017	S3	2017-05-21 09:00:00
\.


--
-- Data for Name: lokasi_ujian; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY lokasi_ujian (kota, tempat) FROM stdin;
Depok	Kampus UI Depok
Jakarta Pusat	Kampus UI Salemba
Jakarta Pusat	Gedung Serbaguna Jakpus
Jakarta Timur	Gedung Serbaguna Jaktim
Jakarta Selatan	Gedung Serbaguna Jaksel
Depok	Gedung Serbaguna Depok
Bekasi	Gedung Serbaguna Bekasi
Tangerang	Gedung Serbaguna Tangerang
Tangerang Selatan	Gedung Serbaguna Tangsel
Bogor	Gedung Serbaguna Bogor
Bandung	Gedung Serbaguna Bandung
Jogjakarta	Gedung Serbaguna Jogjakarta
Surabaya	Gedung Serbaguna Surabaya
Makasar	Gedung Serbaguna Makasar
Medan	Gedung Serbaguna Medan
Padang	Gedung Serbaguna Padang
Palembang	Gedung Serbaguna Palembang
\.


--
-- Data for Name: pelamar; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pelamar (username, nama_lengkap, alamat, jenis_kelamin, tanggal_lahir, no_ktp, email) FROM stdin;
john.ryan12	John Ryan	Jl. Cendrawasih 90, Depok 16534	L	1997-05-15	5267154267300000	john@gmail.com
Mcdaniel.Lawrence96	Mcdaniel Lawrence	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Jakarta Selatan 13052	P	1998-07-18	1161721111500004	Mcdaniel.Lawrence96@yahoo.com
Marsh.Jescie68	Marsh Jescie	Jl. Garnisun No. 2 - 3, Surabaya 14612	L	1999-02-22	5192319111000008	Marsh.Jescie68@yahoo.com
Durham.Zoe1	Durham Zoe	Jl. Jend. Sudirman Kav. 49 , Makasar 14745	L	1996-02-03	7131924111500007	Durham.Zoe1@hotmail.com
Prince.Shana61	Prince Shana	Jl. Ciranjang  II No. 20-22, Surabaya 12525	P	1994-09-25	2091210111400003	Prince.Shana61@yahoo.com
Heath.Lisandra14	Heath Lisandra	Jl. Bukit Gading Raya Kav. II, Cilacap 15170	L	1995-01-24	0011625101600009	Heath.Lisandra14@hotmail.com
Schultz.Serina100	Schultz Serina	Jl. Taman Brawijaya No. 1, Makasar 13173	P	1997-12-30	3011419101500006	Schultz.Serina100@gmail.com
Aguirre.Minerva83	Aguirre Minerva	Jl. Pemuda No. 80  RT.001 RW.08, Surabaya 14152	L	1995-05-06	2191912121000008	Aguirre.Minerva83@hotmail.com
Pena.Cassidy6	Pena Cassidy	Jl. Letjen S. Parman Kav. 84-86, Jakarta Selatan 12863	L	1992-08-18	3132925101600003	Pena.Cassidy6@yahoo.com
Osborn.Eaton63	Osborn Eaton	Jl. Ciranjang  II No. 20-22, Surabaya 12729	P	1989-12-25	1153024101500005	Osborn.Eaton63@gmail.com
Mcdaniel.Pearl74	Mcdaniel Pearl	Jl. Kyai Maja No. 43, Bandung 16110	L	1990-07-15	4173421121600000	Mcdaniel.Pearl74@gmail.com
Lindsay.Leonard67	Lindsay Leonard	Jl. Dharmawangsa Raya No. 13  Blok P II, Tasikmalaya 12127	P	1998-05-01	5131827101500002	Lindsay.Leonard67@gmail.com
Lamb.Cyrus58	Lamb Cyrus	Jl. Kedoya Raya / Al-Kamal No. 2, Balikpapan 15320	L	1997-01-30	6153219111400004	Lamb.Cyrus58@yahoo.com
Barlow.Blake48	Barlow Blake	Jl. Garnisun No. 2 - 3, Garut 14579	L	1991-01-20	2173429121400006	Barlow.Blake48@yahoo.com
Hampton.Burton69	Hampton Burton	Jl. Raya Bogor  Km. 19  No. 3.a, Tasikmalaya 13187	P	1993-11-22	0142816101000005	Hampton.Burton69@gmail.com
Knight.Nora65	Knight Nora	Jl. Senayan No. 26, Depok 13657	L	1998-09-27	6193110101600008	Knight.Nora65@yahoo.com
Mclaughlin.Serina79	Mclaughlin Serina	Jl. Jenderal Gatot Subroto Kav. 59, Samarinda 15523	P	1990-07-11	3181527111200001	Mclaughlin.Serina79@hotmail.com
Graves.Jolene72	Graves Jolene	Jl. Daan Mogot No. 34, Surabaya 14132	L	1995-06-29	3031925121100004	Graves.Jolene72@gmail.com
Hopkins.Lucian65	Hopkins Lucian	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Aceh 14070	L	1992-01-17	1031129101400000	Hopkins.Lucian65@yahoo.com
Valentine.Arsenio34	Valentine Arsenio	Jl. Budi Kemuliaan No. 25 , Aceh 13027	P	1991-11-28	3013428101400005	Valentine.Arsenio34@hotmail.com
Herman.Cathleen70	Herman Cathleen	Jl. Taman Brawijaya No. 1, Bogor 13425	L	1993-12-06	3033112101400002	Herman.Cathleen70@hotmail.com
Mathews.Kato5	Mathews Kato	Jl. Siak J-5 No. 14, Bogor 15132	P	1999-09-23	6051728121500000	Mathews.Kato5@hotmail.com
Andrews.Leo13	Andrews Leo	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Makasar 15637	L	1998-03-31	4172523121500002	Andrews.Leo13@gmail.com
Cote.Sonia87	Cote Sonia	Jl. RS Fatmawati No. 74 , Garut 13261	L	1995-09-29	1071422101100008	Cote.Sonia87@gmail.com
Chandler.Grace42	Chandler Grace	Jl. Ciputat Raya No. 40, Semarang 12966	P	1992-11-21	0092621121600006	Chandler.Grace42@hotmail.com
Carter.Ebony43	Carter Ebony	Jl. Kramat Raya No. 17 A, Medan 13946	L	1995-09-15	7072310121500000	Carter.Ebony43@yahoo.com
Boone.Rhea42	Boone Rhea	Jl. Raya Cilandak  KKO, Samarinda 15493	P	1998-11-12	5082915121400006	Boone.Rhea42@hotmail.com
Sloan.Kane71	Sloan Kane	Jl. Taman Brawijaya No. 1, Bogor 14073	L	1992-01-30	0123129121500003	Sloan.Kane71@hotmail.com
Harvey.Hayes40	Harvey Hayes	Jl. Taman Brawijaya No. 1, Surabaya 15836	L	1992-07-21	5041316111500003	Harvey.Hayes40@gmail.com
Wilkins.Knox48	Wilkins Knox	Jl. Teuku Cik Ditiro No. 41, Bogor 14145	P	1998-06-24	8092211111100001	Wilkins.Knox48@yahoo.com
Chan.Beck3	Chan Beck	Jl. Teuku Cik Ditiro No. 41, Balikpapan 13799	L	1996-01-09	6021514111300002	Chan.Beck3@yahoo.com
Hinton.Vivian14	Hinton Vivian	Jl. Bukit Gading Raya Kav. II, Balikpapan 13421	P	1995-09-20	5091824121200008	Hinton.Vivian14@hotmail.com
Pennington.Hammett78	Pennington Hammett	Jl. Pluit Raya No. 2, Bontang 14167	L	1994-11-05	9011315101600005	Pennington.Hammett78@yahoo.com
Reid.Imani99	Reid Imani	Jl. Bina Warga RT. 009 / RW. 07, Kalibata, Bandung 15047	L	1993-10-10	7032811101300002	Reid.Imani99@hotmail.com
Snyder.Jakeem77	Snyder Jakeem	Jl. Bina Warga RT. 009 / RW. 07, Kalibata, Medan 13298	L	1993-12-22	4071623121000009	Snyder.Jakeem77@hotmail.com
Haynes.Isabella41	Haynes Isabella	Jl. Jatinegara Barat No. 126 , Balikpapan 13774	P	1989-02-23	6132011101500007	Haynes.Isabella41@hotmail.com
Randall.Remedios78	Randall Remedios	Jl. Panglima Polim I  No. 34, Jakarta Utara 13777	L	1991-05-20	0023217121100000	Randall.Remedios78@yahoo.com
Snider.Phillip9	Snider Phillip	Jl. Kramat Jaya, Tanjung Priok, Jakarta Utara 14372	L	1999-11-15	4133223121100009	Snider.Phillip9@yahoo.com
Brown.Simon42	Brown Simon	Jl. Sirsak No. 21, Balikpapan 15739	P	1989-11-10	1143415121300006	Brown.Simon42@hotmail.com
Bryan.Maggy31	Bryan Maggy	Jl. Mohamad Kahfi Raya 1, Surabaya 12324	L	1997-04-21	8111130101100007	Bryan.Maggy31@gmail.com
Hooper.Juliet59	Hooper Juliet	Jl. Pahlawan Komarudin Raya No. 5, Depok 14639	P	1998-06-08	3141526101000004	Hooper.Juliet59@hotmail.com
Mckinney.Dacey28	Mckinney Dacey	Jl. Raya Bogor  Km. 19  No. 3.a, Bogor 14806	L	1994-08-08	1053113111400005	Mckinney.Dacey28@hotmail.com
Flynn.Heather100	Flynn Heather	Jl. Warung Silah No. 1, Surabaya 12277	L	1994-07-12	7122326121400003	Flynn.Heather100@yahoo.com
Sheppard.Hiram65	Sheppard Hiram	Jl. Raden Inten, Medan 13820	P	1993-06-08	0172628111200007	Sheppard.Hiram65@gmail.com
Wilkins.Dillon80	Wilkins Dillon	Jl. MT. Haryono No. 8, Balikpapan 15314	L	1996-08-17	1112019111300008	Wilkins.Dillon80@hotmail.com
Velez.Wyoming83	Velez Wyoming	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Cilacap 13564	P	1990-07-27	1193410101600008	Velez.Wyoming83@hotmail.com
Mays.Quin98	Mays Quin	Jl. Bunga Rampai X - Perumnas Klender, Tasikmalaya 14679	L	1989-04-09	2192414101100007	Mays.Quin98@gmail.com
Daniels.Nicholas77	Daniels Nicholas	Jl. Siaga Raya Kav. 4 - 8, Tasikmalaya 15220	L	1999-02-17	1032020101200002	Daniels.Nicholas77@hotmail.com
Maynard.Jordan71	Maynard Jordan	Jl. HR. Rasuna Said, Kuningan, Surabaya 13078	P	1992-02-12	1092530121600009	Maynard.Jordan71@gmail.com
Lee.Phillip23	Lee Phillip	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Aceh 15610	L	1991-02-24	7033018121000001	Lee.Phillip23@yahoo.com
Aguirre.Xantha24	Aguirre Xantha	Jl. Raden Inten, Balikpapan 14644	P	1998-04-02	8162617111100001	Aguirre.Xantha24@yahoo.com
Oneill.Hollee91	Oneill Hollee	Jl. RS Fatmawati No. 80 - 82, Makasar 14293	L	1993-10-11	0031715101200008	Oneill.Hollee91@yahoo.com
Madden.Meghan98	Madden Meghan	Jl. Dharmawangsa Raya No. 13  Blok P II, Bontang 14931	L	1995-12-13	8111311101300006	Madden.Meghan98@hotmail.com
Fischer.Samantha75	Fischer Samantha	Jl. Balai Pustaka Raya No. 29-31, Samarinda 13464	P	1997-04-06	2072520101000003	Fischer.Samantha75@hotmail.com
Lester.Xena97	Lester Xena	Jl. Raya Bogor KM. 22 No. 44, Garut 13273	L	1999-02-18	3151912121400008	Lester.Xena97@hotmail.com
Tanner.Lareina50	Tanner Lareina	Jl. Ciputat Raya No. 40, Tasikmalaya 12730	P	1990-06-20	8163110111400003	Tanner.Lareina50@hotmail.com
Blake.Angelica72	Blake Angelica	Jl. Enggano No. 10, Bogor 14610	L	1995-07-08	5131611121100001	Blake.Angelica72@gmail.com
Conner.Patrick63	Conner Patrick	Jl. Ganggeng Raya No.9, Jakarta Selatan 14200	L	1990-02-15	7081917101000007	Conner.Patrick63@hotmail.com
Garrison.Maile14	Garrison Maile	Jl. LapanganTembak No. 75, Medan 14580	P	1995-03-27	0041929101500009	Garrison.Maile14@hotmail.com
Kirby.Keane59	Kirby Keane	Jl. Rawamangun No. 47, Papua 14347	L	1997-01-20	3051113111600008	Kirby.Keane59@hotmail.com
Cross.Perry87	Cross Perry	Jl. Gandaria I / 20, Bandung 15661	P	1997-04-05	2083022101200000	Cross.Perry87@yahoo.com
Marks.Adam39	Marks Adam	Jl. Sirsak No. 21, Cilacap 13533	L	1993-09-02	5172130101200004	Marks.Adam39@yahoo.com
Burt.Duncan60	Burt Duncan	Jl. Pulomas Barat VI No. 20, Bontang 15330	L	1991-01-06	0161924101000004	Burt.Duncan60@gmail.com
Matthews.Stella66	Matthews Stella	Jl. Kayu Putih Raya, Makasar 15627	P	1999-03-08	8031219111500005	Matthews.Stella66@yahoo.com
Luna.Imogene30	Luna Imogene	Jl. Prof. Dr. Latumeten No. 1, Depok 13384	L	1997-12-19	3121927121500000	Luna.Imogene30@yahoo.com
Morales.Candace97	Morales Candace	Jl. Dharmawangsa Raya No. 13  Blok P II, Balikpapan 15589	P	1997-01-23	1072914121200008	Morales.Candace97@hotmail.com
Flowers.Gary39	Flowers Gary	Jl. Ampera Raya No. 34, Balikpapan 14113	L	1992-01-10	7171222101000000	Flowers.Gary39@yahoo.com
Montoya.Lucius18	Montoya Lucius	Jl. Proklamasi  No. 43 , Balikpapan 13389	L	1992-07-12	7062612101400000	Montoya.Lucius18@gmail.com
Hatfield.Miranda37	Hatfield Miranda	Jl. Dharmawangsa Raya No. 13  Blok P II, Bandung 15970	L	1994-04-30	9093330111500007	Hatfield.Miranda37@yahoo.com
Padilla.Declan90	Padilla Declan	Jl. Tipar Cakung No. 5, Semarang 12180	P	1991-06-10	9023213111600005	Padilla.Declan90@hotmail.com
Ramos.Amery55	Ramos Amery	Jl. Pulomas Barat VI No. 20, Cilacap 16067	L	1991-08-11	9171529101100006	Ramos.Amery55@hotmail.com
Farley.Latifah29	Farley Latifah	Jl. Raya Cilandak  KKO, Aceh 14119	L	1995-10-03	6021223121600006	Farley.Latifah29@yahoo.com
Berry.Castor46	Berry Castor	Jl. Kali Pasir  No. 9, Garut 12537	P	1993-11-06	9032412111300000	Berry.Castor46@gmail.com
Workman.Harding82	Workman Harding	Jl. Bukit Gading Raya Kav. II, Papua 14605	L	1994-12-11	4131423111400005	Workman.Harding82@hotmail.com
Weeks.Tanya9	Weeks Tanya	Jl. Panjang Arteri 26, Aceh 13383	P	1998-02-04	3061122101500002	Weeks.Tanya9@gmail.com
Ballard.Malcolm67	Ballard Malcolm	Jl. Salemba Tengah 26 - 28, Medan 14510	L	1993-07-28	4061322101200009	Ballard.Malcolm67@hotmail.com
Strickland.Charde28	Strickland Charde	Jl. Siak J-5 No. 14, Bontang 14453	P	1990-10-21	6111525111400001	Strickland.Charde28@hotmail.com
Carlson.Gemma63	Carlson Gemma	Jl. Jenderal Gatot Subroto Kav. 59, Surabaya 14454	L	1992-11-28	0071314121200005	Carlson.Gemma63@gmail.com
Chang.Ferdinand77	Chang Ferdinand	Jl. Jend. Sudirman Kav. 49 , Makasar 12888	L	1996-10-27	2152629121600007	Chang.Ferdinand77@hotmail.com
Rasmussen.Lawrence20	Rasmussen Lawrence	Jl. Raden Saleh No. 40 , Bogor 14707	P	1990-09-05	1112527101000004	Rasmussen.Lawrence20@gmail.com
Livingston.Cassandra78	Livingston Cassandra	Jl. Lebak Bulus 1, Papua 14551	L	1998-06-11	9021114121200007	Livingston.Cassandra78@gmail.com
Lawson.Nathaniel45	Lawson Nathaniel	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Makasar 16017	P	1994-04-13	4062622111100000	Lawson.Nathaniel45@gmail.com
Decker.Cameron45	Decker Cameron	Jl. H. Rohimin No. 30, Surabaya 12239	L	1998-05-05	1082030111300003	Decker.Cameron45@hotmail.com
Velez.Candace35	Velez Candace	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Makasar 15376	L	1989-04-01	1062319121300004	Velez.Candace35@yahoo.com
Brock.Amal86	Brock Amal	Jl. Duren Tiga Raya No. 20, Bandung 14791	P	1997-08-03	3111427101400005	Brock.Amal86@hotmail.com
Hayes.Kim51	Hayes Kim	Jl. Tawes No. 18-20 , Makasar 14090	L	1993-02-09	6091918101100003	Hayes.Kim51@hotmail.com
Schwartz.Carolyn13	Schwartz Carolyn	Jl. Kesehatan No. 9, Balikpapan 13814	P	1989-05-31	2152511121400004	Schwartz.Carolyn13@hotmail.com
Bell.Mary50	Bell Mary	Jl. Raya Pondok Gede No. 4, Depok 13986	L	1997-06-27	0133318101100009	Bell.Mary50@gmail.com
Barnes.Ruth27	Barnes Ruth	Jl. Puri Indah Raya  Blok S-2, Tasikmalaya 12761	L	1997-05-12	4193121101000007	Barnes.Ruth27@yahoo.com
Valenzuela.Sydnee91	Valenzuela Sydnee	Jl. Ganggeng Raya No.9, Bontang 12814	P	1999-04-08	2011823121100009	Valenzuela.Sydnee91@yahoo.com
Sweeney.Mercedes15	Sweeney Mercedes	Jl. Bintaro Permai Raya No. 3, Balikpapan 12768	L	1989-02-14	6042627111000002	Sweeney.Mercedes15@gmail.com
Rose.Andrew30	Rose Andrew	Jl. Raya Cilandak  KKO, Bogor 14997	P	1996-10-09	8082826111300005	Rose.Andrew30@yahoo.com
Obrien.Iris93	Obrien Iris	Jl. Raya Pondok Gede No. 4, Depok 15340	L	1993-11-24	7112410111200003	Obrien.Iris93@gmail.com
Albert.Kylan57	Albert Kylan	Jl. Metro Duta Kav. UE,  Pondok Indah, Depok 13333	L	1992-04-13	0042410111200005	Albert.Kylan57@gmail.com
Mcintyre.Veda6	Mcintyre Veda	Jl. RS. Fatmawati, Balikpapan 12518	P	1997-09-27	6112017111300006	Mcintyre.Veda6@yahoo.com
Mendez.Barry62	Mendez Barry	Jl. Anggrek No. 2 B, Tasikmalaya 14426	L	1991-08-19	1071210111400006	Mendez.Barry62@hotmail.com
Giles.Carissa92	Giles Carissa	Jl. Bintaro Permai Raya No. 3, Depok 12626	P	1992-10-18	1141719101600003	Giles.Carissa92@gmail.com
Hull.Armando46	Hull Armando	Jl. Duri Raya No. 22, Jakarta Utara 14364	L	1993-01-02	5072413121400008	Hull.Armando46@hotmail.com
Griffith.Kristen63	Griffith Kristen	Jl. MT. Haryono No. 8, Medan 12400	L	1997-10-14	2032010111300005	Griffith.Kristen63@gmail.com
Walton.Thaddeus29	Walton Thaddeus	Jl. Kramat Jaya, Tanjung Priok, Garut 13911	P	1990-05-10	9071620111500002	Walton.Thaddeus29@hotmail.com
Ortega.Gwendolyn97	Ortega Gwendolyn	Jl. Lebak Bulus 1, Medan 14350	L	1997-04-03	1063315121300006	Ortega.Gwendolyn97@yahoo.com
Lang.Ivana14	Lang Ivana	Jl. Raya Bekasi Timur 170 C, Papua 12120	P	1995-01-09	8071128121100008	Lang.Ivana14@hotmail.com
Brady.Rina10	Brady Rina	Jl. Taman Brawijaya No. 1, Semarang 15666	L	1991-01-02	0031516111600002	Brady.Rina10@yahoo.com
Reed.Gregory100	Reed Gregory	Jl. Raya Pejuangan Kav. 8, Bogor 14831	L	1993-12-25	3122810101500001	Reed.Gregory100@hotmail.com
Roman.Camille22	Roman Camille	Jl. Basuki Rachmat  No. 31, Tasikmalaya 15397	P	1999-07-23	9152627121300005	Roman.Camille22@yahoo.com
Mcintyre.Roth95	Mcintyre Roth	Jl. Pulomas Barat VI No. 20, Medan 14657	L	1996-09-06	8071819101400005	Mcintyre.Roth95@yahoo.com
Roy.Stewart30	Roy Stewart	Jl. Baru Sunter Permai Raya, Makasar 13251	P	1991-05-28	6063012111000000	Roy.Stewart30@gmail.com
Hunter.Rhoda8	Hunter Rhoda	Jl. Teuku Cik Ditiro No. 46  M, Bontang 15172	L	1995-07-01	4041324101000009	Hunter.Rhoda8@hotmail.com
Stanley.Cameran48	Stanley Cameran	Jl. Jenderal Gatot Subroto Kav. 59, Jakarta Selatan 12318	L	1991-01-11	1013416121400003	Stanley.Cameran48@gmail.com
Knox.Yoko92	Knox Yoko	Jl. Taman Brawijaya No. 1, Garut 12642	L	1997-10-11	4111518101400006	Knox.Yoko92@hotmail.com
Allison.Phelan83	Allison Phelan	Jl. LetJen S. Parman Kav. 87, Bontang 13463	P	1997-01-29	0061328111600004	Allison.Phelan83@gmail.com
Kent.Donna54	Kent Donna	Jl. H. Rohimin No. 30, Surabaya 13266	L	1998-12-19	6052818101400003	Kent.Donna54@yahoo.com
Moody.Gray92	Moody Gray	Jl. Kramat Raya No. 128, Bandung 15639	L	1999-08-03	0042818101000002	Moody.Gray92@yahoo.com
Mendez.Avram60	Mendez Avram	Jl. Tanah Sereal VII / 9, Jakarta Utara 13395	P	1990-06-18	2181726111400009	Mendez.Avram60@gmail.com
Stevens.Chase10	Stevens Chase	Jl. Raya Bogor  Km. 19  No. 3.a, Bontang 12977	L	1997-01-28	8023225121400004	Stevens.Chase10@gmail.com
Deleon.Ursa16	Deleon Ursa	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Tasikmalaya 15497	P	1992-05-25	1083118101100000	Deleon.Ursa16@yahoo.com
Raymond.Gary62	Raymond Gary	JL. Duren Sawit Raya Blok K.3 No.1, Garut 15189	L	1999-01-25	9112525101100006	Raymond.Gary62@hotmail.com
Cole.Kermit6	Cole Kermit	Jl. Duren Tiga Raya No. 5, Surabaya 14243	L	1990-12-07	3051316101000004	Cole.Kermit6@hotmail.com
Morin.Abdul17	Morin Abdul	Jl. Persahabatan Raya , Depok 14504	P	1992-03-09	0022211101300000	Morin.Abdul17@gmail.com
Durham.Marny28	Durham Marny	Jl. Proklamasi  No. 43 , Balikpapan 15393	L	1990-06-13	5112128101200001	Durham.Marny28@hotmail.com
Henson.Benjamin34	Henson Benjamin	Jl. Balai Pustaka Raya No. 29-31, Bogor 14281	P	1995-12-10	2023314101000007	Henson.Benjamin34@hotmail.com
Bridges.Tucker7	Bridges Tucker	Jl. Salemba Raya, Tasikmalaya 14420	L	1991-07-27	4192828111200001	Bridges.Tucker7@yahoo.com
Mitchell.Xyla20	Mitchell Xyla	Jl. Jend. Sudirman Kav. 49 , Bontang 14724	L	1992-10-31	4132014111400004	Mitchell.Xyla20@yahoo.com
Chan.Nomlanga48	Chan Nomlanga	Jl. Raya Bogor  Km. 19  No. 3.a, Bandung 13533	P	1991-04-06	8172530101500002	Chan.Nomlanga48@yahoo.com
Nelson.Xena38	Nelson Xena	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Cilacap 15145	L	1993-06-04	3073116121300003	Nelson.Xena38@hotmail.com
Tillman.Rajah56	Tillman Rajah	Jl. Bukit Gading Raya Kav. II, Surabaya 12291	P	1992-04-03	2093016111600001	Tillman.Rajah56@gmail.com
Roth.Nolan16	Roth Nolan	Jl. Siaga Raya Kav. 4 - 8, Semarang 13094	L	1989-07-18	3041721121500006	Roth.Nolan16@hotmail.com
Rhodes.Lara22	Rhodes Lara	Jl. Salemba I  No. 13, Semarang 13984	L	1991-07-28	7083015101200003	Rhodes.Lara22@hotmail.com
Keller.Minerva36	Keller Minerva	Jl. Panglima Polim I  No. 34, Bontang 13013	P	1991-11-04	1011126121100004	Keller.Minerva36@gmail.com
Burke.Eugenia70	Burke Eugenia	Jl. Dr. Abdul Rachman Saleh 24, Papua 15589	L	1998-09-20	2012913101400003	Burke.Eugenia70@yahoo.com
Gilmore.Clinton33	Gilmore Clinton	Jl. Senayan No. 26, Aceh 13563	P	1990-04-03	2192723101200004	Gilmore.Clinton33@yahoo.com
Turner.Amela17	Turner Amela	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan 12241	L	1997-07-28	3163017101500009	Turner.Amela17@hotmail.com
Levy.Cherokee62	Levy Cherokee	Jl. Tanah Sereal VII / 9, Aceh 14654	L	1995-05-24	9172926101200008	Levy.Cherokee62@yahoo.com
Yates.Olivia55	Yates Olivia	Jl. Garnisun No. 2 - 3, Surabaya 12121	P	1989-08-22	4051422121500001	Yates.Olivia55@gmail.com
Singleton.Brynne89	Singleton Brynne	Jl. Raya Pondok Gede No. 4, Makasar 14891	L	1998-05-04	2112830121100001	Singleton.Brynne89@yahoo.com
Miles.Nicole92	Miles Nicole	Jl. Gereja Theresia No. 22, Depok 15795	P	1998-10-29	4082225101300007	Miles.Nicole92@gmail.com
Petersen.Cairo68	Petersen Cairo	Jl. Siak J-5 No. 14, Medan 12805	L	1999-11-30	0121922101400002	Petersen.Cairo68@hotmail.com
Mcfadden.Sharon10	Mcfadden Sharon	Jl. Kyai Tapa No. , Jakarta Utara 15731	L	1998-11-23	8181118111200003	Mcfadden.Sharon10@hotmail.com
Atkins.Judah32	Atkins Judah	Jl. Prof. Dr. Latumeten No. 1, Bogor 14281	P	1995-06-22	6061710101600008	Atkins.Judah32@hotmail.com
Dunn.Montana12	Dunn Montana	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Jakarta Selatan 13415	L	1989-09-10	3051510121600006	Dunn.Montana12@gmail.com
Daugherty.Fallon98	Daugherty Fallon	Jl. Sultan Agung No. 67, Tasikmalaya 14839	L	1996-03-06	4122117101400008	Daugherty.Fallon98@hotmail.com
Farmer.Dora53	Farmer Dora	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Bogor 12414	P	1999-11-05	2141522101600006	Farmer.Dora53@yahoo.com
Moon.Emerald95	Moon Emerald	Jl. H. Rohimin No. 30, Papua 15921	L	1998-10-04	4052923121200000	Moon.Emerald95@yahoo.com
Michael.Hiroko23	Michael Hiroko	Jl. Panglima Polim I  No. 34, Jakarta Utara 14116	P	1994-04-30	5081225111600002	Michael.Hiroko23@hotmail.com
Collins.Darius81	Collins Darius	Jl. Teuku Cik Ditiro No. 28, Bandung 14116	L	1991-08-05	0071523101200005	Collins.Darius81@hotmail.com
Garrett.Zeph49	Garrett Zeph	Jl. Panglima Polim I  No. 34, Garut 13558	L	1998-03-15	9182130111400000	Garrett.Zeph49@yahoo.com
Colon.Ursa10	Colon Ursa	Jl. Jend. Sudirman Kav. 49 , Surabaya 12113	P	1996-06-30	0042529111000003	Colon.Ursa10@yahoo.com
Estes.Jarrod4	Estes Jarrod	Jl. Kali Pasir  No. 9, Papua 13774	L	1997-04-16	5142813121400000	Estes.Jarrod4@hotmail.com
Hobbs.Karen39	Hobbs Karen	Jl. Raya Bogor, Garut 13224	P	1997-08-17	0012326101600002	Hobbs.Karen39@yahoo.com
Jacobs.Callie84	Jacobs Callie	Jl. Boulevard Timur Raya RT. 006 / 02, Semarang 13565	L	1992-04-13	5092526101100000	Jacobs.Callie84@yahoo.com
Jackson.Dahlia87	Jackson Dahlia	Jl. Duren Tiga Raya No. 5, Surabaya 13289	L	1991-06-05	2011920121100006	Jackson.Dahlia87@hotmail.com
Stevenson.Madaline67	Stevenson Madaline	Jl. Kyai Caringin No. 7, Samarinda 12789	P	1989-02-01	2132918111200007	Stevenson.Madaline67@gmail.com
Kennedy.Alice96	Kennedy Alice	Jl. Siaga Raya Kav. 4 - 8, Jakarta Utara 12960	L	1990-10-01	7112621101300000	Kennedy.Alice96@yahoo.com
Jordan.Roanna91	Jordan Roanna	Jl. Kayu Putih Raya, Balikpapan 15251	P	1993-11-12	1042226101500004	Jordan.Roanna91@gmail.com
Kemp.Wynter61	Kemp Wynter	Jl. H. Ten, Bogor 13182	P	1998-11-05	4182822101100005	Kemp.Wynter61@yahoo.com
Lawson.Asher8	Lawson Asher	Jl. Baru Sunter Permai Raya, Papua 14743	L	1998-07-20	3121722121600008	Lawson.Asher8@hotmail.com
Curry.Cailin95	Curry Cailin	Jl. Raya Mangga Besar Raya 137 / 139, Jakarta Selatan 15462	L	1989-08-02	4032429101200001	Curry.Cailin95@gmail.com
Booker.Imelda6	Booker Imelda	Jl. Dr. Saharjo No. 120, Cilacap 13935	P	1990-04-13	8153429111400003	Booker.Imelda6@hotmail.com
Contreras.Kirsten46	Contreras Kirsten	Jl. Ciputat Raya No. 5, Depok 12377	L	1996-05-23	9091627111600009	Contreras.Kirsten46@hotmail.com
Burgess.Warren34	Burgess Warren	Jl. Raya Cilandak  KKO, Medan 13700	P	1993-08-28	8022430101000001	Burgess.Warren34@yahoo.com
Downs.Steel2	Downs Steel	Jl. HR. Rasuna Said, Kuningan, Surabaya 14163	L	1992-10-03	0093323111500007	Downs.Steel2@gmail.com
Benjamin.Jessica87	Benjamin Jessica	Jl. Boulevard Timur Raya RT. 006 / 02, Papua 13505	L	1990-03-08	3041625111400007	Benjamin.Jessica87@yahoo.com
Harper.Jonas23	Harper Jonas	Jl. Taman Malaka Selatan No. 6, Bogor 14636	P	1996-04-23	5131915121000000	Harper.Jonas23@yahoo.com
Walls.Christopher5	Walls Christopher	Jl. Gereja Theresia No. 22, Bontang 13617	L	1998-01-04	8062724111600009	Walls.Christopher5@yahoo.com
Skinner.Ruby31	Skinner Ruby	Jl. Mohamad Kahfi Raya 1, Bontang 13889	P	1992-01-30	3072018101000009	Skinner.Ruby31@yahoo.com
Graham.Phelan12	Graham Phelan	Jl. Proklamasi  No. 43 , Cilacap 12833	L	1989-11-05	4072922101200002	Graham.Phelan12@gmail.com
Mckee.Emery64	Mckee Emery	Jl. RS Fatmawati No. 74 , Medan 13195	P	1990-07-19	4022326111300003	Mckee.Emery64@yahoo.com
Cole.Lillith48	Cole Lillith	Jl. Raya Jatinegara Timur No. 85 - 87, Surabaya 13584	L	1995-12-01	1091116101500006	Cole.Lillith48@hotmail.com
Wagner.Hayden86	Wagner Hayden	Jl Sungai Bambu  No. 5, Samarinda 12985	L	1994-08-30	4113326111000009	Wagner.Hayden86@yahoo.com
Noel.Yuli88	Noel Yuli	Jl. Senayan No. 26, Papua 12833	P	1989-11-18	4171329121500001	Noel.Yuli88@yahoo.com
Jackson.Shelly76	Jackson Shelly	Jl. Pemuda No. 80  RT.001 RW.08, Samarinda 15353	L	1994-06-06	4192318111200006	Jackson.Shelly76@hotmail.com
Gamble.Hoyt29	Gamble Hoyt	Jl. Duren Sawit Baru No. 2, Semarang 15037	P	1989-08-19	6133028121200009	Gamble.Hoyt29@hotmail.com
Scott.Mira46	Scott Mira	Jl. HR. Rasuna Said, Kuningan, Aceh 12931	L	1998-09-09	2072510121400002	Scott.Mira46@hotmail.com
Sykes.Eliana60	Sykes Eliana	Jl. Raya Pluit Selatan No. 2, Aceh 15487	L	1991-09-04	0192821101200007	Sykes.Eliana60@gmail.com
Macias.Irene77	Macias Irene	Jl. Ganggeng Raya No.9, Tasikmalaya 15126	P	1993-05-01	4052710121400006	Macias.Irene77@yahoo.com
Romero.Margaret4	Romero Margaret	Jl. Salemba I  No. 13, Papua 15503	L	1999-12-24	3052219111100001	Romero.Margaret4@yahoo.com
Newton.Logan47	Newton Logan	Jl. Sumur Batu Raya Blok A3 No. 13, Semarang 15985	P	1994-03-12	2162521111400002	Newton.Logan47@hotmail.com
Dawson.Jasper77	Dawson Jasper	Jl. Sirsak No. 21, Jakarta Selatan 12332	L	1990-08-06	2022818101300005	Dawson.Jasper77@gmail.com
Bray.Mallory49	Bray Mallory	Jl. HR. Rasuna Said, Kuningan, Jakarta Utara 14684	L	1990-02-20	0092322121400002	Bray.Mallory49@gmail.com
Barron.Lewis19	Barron Lewis	Jl. Balai Pustaka Baru No. 19, Surabaya 14746	P	1990-03-02	3033320121300009	Barron.Lewis19@gmail.com
Carney.Tanya48	Carney Tanya	Jl. Teuku Cik Ditiro No. 41, Cilacap 15012	L	1992-04-20	3072713111300008	Carney.Tanya48@hotmail.com
Nolan.Lani42	Nolan Lani	Jl. Raya Cilandak  KKO, Medan 14143	P	1990-09-29	0083221111200002	Nolan.Lani42@yahoo.com
Hansen.Candace3	Hansen Candace	Jl. Jenderal Gatot Subroto Kav. 59, Jakarta Selatan 15084	L	1989-11-02	0081128121100003	Hansen.Candace3@gmail.com
Horn.Emery41	Horn Emery	Jl. Pahlawan Revolusi No. 100, Jakarta Utara 16036	L	1991-01-10	1193025111400000	Horn.Emery41@gmail.com
Collier.Ashely24	Collier Ashely	Jl. Taman Brawijaya No. 1, Cilacap 13124	P	1995-07-21	4072725101200009	Collier.Ashely24@hotmail.com
Barton.Michelle11	Barton Michelle	Jl. RS Fatmawati No. 74 , Depok 15506	L	1996-09-25	9023030111000007	Barton.Michelle11@hotmail.com
Allen.James4	Allen James	Jl. Balai Pustaka Raya No. 29-31, Semarang 16067	P	1999-11-18	1012212121600009	Allen.James4@gmail.com
Hoffman.Clark45	Hoffman Clark	Jl. Ampera Raya No. 34, Tasikmalaya 14739	L	1995-11-28	1033316121600003	Hoffman.Clark45@gmail.com
Shields.Emi97	Shields Emi	Jl. Salemba I  No. 13, Bontang 13697	L	1993-01-02	4021916111500005	Shields.Emi97@hotmail.com
Holden.Martena56	Holden Martena	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Jakarta Selatan 14103	L	1996-01-10	2141826111100003	Holden.Martena56@yahoo.com
Trevino.Remedios97	Trevino Remedios	Jl. Tanah Sereal VII / 9, Makasar 16012	P	1995-12-17	1072920101600002	Trevino.Remedios97@hotmail.com
Aguilar.Jeremy92	Aguilar Jeremy	Jl. Pemuda No. 80  RT.001 RW.08, Bontang 15768	L	1992-04-30	7132816121200009	Aguilar.Jeremy92@hotmail.com
Ortega.Abbot37	Ortega Abbot	Jl. Raya Pasar Minggu No. 3 A, Makasar 12881	L	1992-11-13	8051414111500009	Ortega.Abbot37@yahoo.com
Villarreal.Hyacinth58	Villarreal Hyacinth	Jl. Mohamad Kahfi Raya 1, Semarang 14322	P	1995-05-28	8072621101000007	Villarreal.Hyacinth58@gmail.com
Gibson.Ferris81	Gibson Ferris	Jl. Kyai Tapa No. 1, Depok 14665	L	1991-03-28	3011324101200007	Gibson.Ferris81@gmail.com
Castillo.Indigo58	Castillo Indigo	Jl. Raya Pluit Selatan No. 2, Bogor 12845	P	1997-07-08	4052218121500007	Castillo.Indigo58@gmail.com
Schroeder.Kermit67	Schroeder Kermit	Jl. RS Fatmawati No. 74 , Semarang 15425	L	1997-10-22	2013410101300003	Schroeder.Kermit67@hotmail.com
Jacobson.Kelsie21	Jacobson Kelsie	Jl. Boulevard Timur Raya RT. 006 / 02, Makasar 13363	L	1998-12-26	5013429101300000	Jacobson.Kelsie21@gmail.com
Howard.Cooper71	Howard Cooper	Jl. MT. Haryono No. 8, Cilacap 12645	P	1989-11-05	8122220101600001	Howard.Cooper71@gmail.com
Burton.Wylie56	Burton Wylie	Jl. Kyai Tapa No. 1, Tasikmalaya 14051	L	1995-06-10	3152115121600003	Burton.Wylie56@yahoo.com
Gaines.Drake14	Gaines Drake	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan 14957	P	1990-05-31	2123015111200008	Gaines.Drake14@gmail.com
Carpenter.Ahmed11	Carpenter Ahmed	Jl. Panglima Polim I  No. 34, Aceh 13013	L	1996-01-27	1143220121400008	Carpenter.Ahmed11@hotmail.com
Richardson.Aquila57	Richardson Aquila	Jl. MT. Haryono No. 8, Makasar 14471	L	1999-07-11	2023029111000006	Richardson.Aquila57@yahoo.com
Mcdowell.Celeste67	Mcdowell Celeste	Jl. Letjen S. Parman Kav. 84-86, Bogor 13754	P	1997-11-03	1182630111300004	Mcdowell.Celeste67@hotmail.com
Lowery.Celeste58	Lowery Celeste	Jl. Prof. Dr. Latumeten No. 1, Semarang 13118	L	1997-10-17	9151129101500007	Lowery.Celeste58@gmail.com
Petty.Ferdinand76	Petty Ferdinand	Jl. Ciputat Raya No. 5, Bandung 14241	P	1995-07-10	5092017111300000	Petty.Ferdinand76@hotmail.com
Hernandez.Phyllis11	Hernandez Phyllis	Jl. Kesehatan No. 9, Makasar 15404	L	1993-03-08	9033329121300005	Hernandez.Phyllis11@yahoo.com
Mcleod.Clinton15	Mcleod Clinton	Jl. Raya Bogor KM. 22 No. 44, Aceh 15604	L	1989-02-24	8063329121200000	Mcleod.Clinton15@gmail.com
Hayes.Hyacinth38	Hayes Hyacinth	Jl. Teuku Cik Ditiro No. 28, Bontang 14199	P	1997-07-29	2171829111000006	Hayes.Hyacinth38@gmail.com
Mcknight.Kyle46	Mcknight Kyle	Jl. Pemuda No. 80  RT.001 RW.08, Papua 14570	L	1996-03-14	9132115121500007	Mcknight.Kyle46@yahoo.com
Walsh.Tiger42	Walsh Tiger	Jl. LapanganTembak No. 75, Makasar 15327	P	1992-07-26	8043023101000002	Walsh.Tiger42@gmail.com
Finch.Ross78	Finch Ross	Jl. Boulevard Timur Raya RT. 006 / 02, Balikpapan 16068	L	1997-08-08	2121312121100003	Finch.Ross78@yahoo.com
Ingram.Leo88	Ingram Leo	Jl. MT. Haryono No. 8, Jakarta Utara 15932	L	1996-02-21	4083128121200001	Ingram.Leo88@gmail.com
Hudson.Aileen4	Hudson Aileen	Jl. Kaji No. 40, Jakarta Selatan 13818	P	1990-04-16	8192423111000006	Hudson.Aileen4@yahoo.com
Mullins.Willa79	Mullins Willa	Jl. Ciputat Raya No. 5, Jakarta Utara 12889	L	1999-04-17	7061626111500002	Mullins.Willa79@hotmail.com
Sweet.Quamar7	Sweet Quamar	Jl. Panglima Polim I  No. 34, Cilacap 13547	P	1995-06-05	7151411111200007	Sweet.Quamar7@gmail.com
Dejesus.Kyle72	Dejesus Kyle	Jl. Kyai Caringin No. 7, Jakarta Utara 13609	L	1996-12-11	5062419101100009	Dejesus.Kyle72@gmail.com
Whitehead.Maggie96	Whitehead Maggie	Jl. Duren Tiga Raya No. 5, Samarinda 13990	L	1997-07-16	0032415101400002	Whitehead.Maggie96@gmail.com
Solomon.Jemima13	Solomon Jemima	Jl. Budi Kemuliaan No. 25 , Papua 12541	P	1993-05-12	4022612101200006	Solomon.Jemima13@hotmail.com
Grimes.Marvin9	Grimes Marvin	Jl. Raya Bogor  Km. 19  No. 3.a, Medan 15422	L	1993-07-07	1163317111100004	Grimes.Marvin9@hotmail.com
Garner.Echo30	Garner Echo	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Bandung 13064	L	1993-04-24	3171923111600005	Garner.Echo30@yahoo.com
Sellers.Mira68	Sellers Mira	Jl. Tanah Sereal VII / 9, Papua 14289	P	1991-10-19	2141426101000009	Sellers.Mira68@yahoo.com
Nichols.Colton17	Nichols Colton	Jl. Budi Kemuliaan No. 25 , Surabaya 12802	L	1995-11-08	7091324121000007	Nichols.Colton17@yahoo.com
Blanchard.Felix40	Blanchard Felix	Jl. HOS Cokroaminoto No. 31 - 33, Jakarta Selatan 15129	P	1993-03-27	4192823121600004	Blanchard.Felix40@hotmail.com
Powell.Quintessa88	Powell Quintessa	Jl. HR. Rasuna Said, Kuningan, Bogor 15494	L	1994-04-11	4172423121300007	Powell.Quintessa88@hotmail.com
Guthrie.Bernard47	Guthrie Bernard	Jl. Kramat Jaya, Tanjung Priok, Aceh 13669	L	1994-08-13	9071613111000004	Guthrie.Bernard47@gmail.com
Hart.Calista7	Hart Calista	Jl. Warung Silah No. 1, Samarinda 14680	P	1992-09-15	3053417111500004	Hart.Calista7@yahoo.com
Swanson.Oliver20	Swanson Oliver	Jl. Taman Brawijaya No. 1, Depok 12181	L	1990-06-30	7051510111200005	Swanson.Oliver20@yahoo.com
Myers.Duncan11	Myers Duncan	Jl. Senayan No. 26, Surabaya 14370	L	1990-06-18	1053320101400001	Myers.Duncan11@yahoo.com
Boone.Jamal86	Boone Jamal	Jl. H. Rohimin No. 30, Cilacap 13411	P	1998-07-12	6012112101400000	Boone.Jamal86@gmail.com
Wynn.Lionel64	Wynn Lionel	Jl. Raden Saleh No. 40 , Semarang 15927	L	1998-02-07	0122129101500008	Wynn.Lionel64@gmail.com
Dickerson.Natalie18	Dickerson Natalie	Jl. Salemba I  No. 13, Depok 13764	L	1998-01-05	1151429111200006	Dickerson.Natalie18@yahoo.com
Martin.Channing22	Martin Channing	Jl. Sultan Agung No. 67, Semarang 13259	P	1996-02-20	4032616101400007	Martin.Channing22@yahoo.com
Miller.Zephania48	Miller Zephania	Jl. Ganggeng Raya No.9, Semarang 14286	L	1996-10-13	9152429101100000	Miller.Zephania48@yahoo.com
Leon.Evangeline61	Leon Evangeline	Jl. Sawo No. 58 - 60, Medan 14272	P	1997-04-08	3033130101500008	Leon.Evangeline61@hotmail.com
Bridges.Serena88	Bridges Serena	Jl. Raya Jatinegara Timur No. 85 - 87, Semarang 12814	L	1993-08-21	6192028121500007	Bridges.Serena88@gmail.com
Cross.Kimberley4	Cross Kimberley	Jl. Raya Pluit Selatan No. 2, Jakarta Selatan 12369	L	1991-03-26	7091117101100007	Cross.Kimberley4@gmail.com
Andrews.Jenna22	Andrews Jenna	Jl. Raya Cilandak  KKO, Jakarta Utara 13491	P	1990-07-24	8042228121600001	Andrews.Jenna22@gmail.com
Snider.Nehru79	Snider Nehru	Jl. Taman Malaka Selatan No. 6, Semarang 14678	L	1992-06-29	6192218101400007	Snider.Nehru79@hotmail.com
Roth.Kyle3	Roth Kyle	Jl. Raya Pluit Selatan No. 2, Semarang 14304	P	1995-11-11	4152912111200002	Roth.Kyle3@hotmail.com
Rodgers.Moses15	Rodgers Moses	Jl. Kamal Raya, Bumi Cengkareng Indah, Semarang 14787	L	1991-06-22	8123030121000009	Rodgers.Moses15@gmail.com
Christian.Rhona26	Christian Rhona	Jl. Raya Bogor KM. 22 No. 44, Jakarta Utara 12837	L	1998-08-07	0071914121000009	Christian.Rhona26@yahoo.com
Perry.Tara71	Perry Tara	Jl. Ganggeng Raya No.9, Balikpapan 14002	P	1998-06-22	5112522101500001	Perry.Tara71@hotmail.com
Atkins.Yvette30	Atkins Yvette	Jl. Ciputat Raya No. 40, Medan 12614	L	1989-07-31	9161527121200002	Atkins.Yvette30@gmail.com
Estes.Gemma55	Estes Gemma	Jl. Warung Silah No. 1, Papua 15785	P	1993-04-01	9081930121300003	Estes.Gemma55@gmail.com
Fernandez.Chaim55	Fernandez Chaim	Jl. Dharmawangsa Raya No. 13  Blok P II, Bogor 13099	L	1991-08-01	4123323111300005	Fernandez.Chaim55@hotmail.com
Castaneda.Riley8	Castaneda Riley	Jl. Pemuda No. 80  RT.001 RW.08, Bogor 15229	L	1995-03-06	9021823121000006	Castaneda.Riley8@hotmail.com
Day.Felicia2	Day Felicia	Jl. Kyai Maja No. 43, Depok 15203	P	1989-08-17	0071819121100004	Day.Felicia2@hotmail.com
Collins.Holly20	Collins Holly	Jl. Ganggeng Raya No.9, Surabaya 12161	L	1992-12-28	6012328121000002	Collins.Holly20@gmail.com
Frye.Maggie98	Frye Maggie	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Jakarta Selatan 13574	P	1995-05-23	4093320111400009	Frye.Maggie98@hotmail.com
Osborne.Georgia12	Osborne Georgia	Jl. Kramat Jaya, Tanjung Priok, Depok 14634	L	1997-05-31	7091510121600009	Osborne.Georgia12@yahoo.com
Harper.Lance100	Harper Lance	Jl. Taman Brawijaya No. 1, Bandung 12142	L	1992-04-01	0111329111100007	Harper.Lance100@gmail.com
Bowman.Naomi94	Bowman Naomi	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Tasikmalaya 15914	P	1992-01-07	5153122121600000	Bowman.Naomi94@hotmail.com
Pittman.Lydia91	Pittman Lydia	Jl. Raya Pluit Selatan No. 2, Balikpapan 12416	L	1995-12-22	2081319111100009	Pittman.Lydia91@hotmail.com
Franco.Keegan61	Franco Keegan	Jl. Proklamasi  No. 43 , Cilacap 15438	P	1989-01-19	2042613111500006	Franco.Keegan61@gmail.com
Crosby.Julian52	Crosby Julian	Jl. TB Simatupang No. 71 Jak-Tim, Jakarta Utara 14266	L	1993-06-15	1013330101000000	Crosby.Julian52@gmail.com
Pratt.Regina12	Pratt Regina	Jl. Sumur Batu Raya Blok A3 No. 13, Surabaya 14264	L	1991-06-18	4031119111200004	Pratt.Regina12@gmail.com
Alston.Dominic65	Alston Dominic	Jl. Jend. Sudirman Kav. 49 , Semarang 14936	P	1992-02-08	3071113101100001	Alston.Dominic65@gmail.com
Madden.Duncan12	Madden Duncan	Jl. Letjen T. B. Simatupang No. 30, Samarinda 15857	L	1998-05-14	8042329101400001	Madden.Duncan12@gmail.com
Head.Isaiah78	Head Isaiah	Jl. RS Fatmawati No. 74 , Papua 13307	P	1998-04-15	9022411121600007	Head.Isaiah78@gmail.com
Hayden.Gretchen22	Hayden Gretchen	Jl. Pulomas Timur K. No.2, Bogor 13672	L	1991-02-08	5033222121300005	Hayden.Gretchen22@gmail.com
Phillips.Germaine2	Phillips Germaine	Jl. Teuku Cik Ditiro No. 41, Bandung 15170	L	1991-07-31	9182215101500009	Phillips.Germaine2@yahoo.com
Palmer.Clare90	Palmer Clare	Jl. Warung Buncit Raya No. 15, Jakarta Utara 14177	L	1994-10-13	9072320111100005	Palmer.Clare90@gmail.com
Dunlap.Graiden85	Dunlap Graiden	Jl. LapanganTembak No. 75, Bandung 12311	P	1991-05-09	2153215121400009	Dunlap.Graiden85@hotmail.com
Miller.Mannix38	Miller Mannix	Pluit Mas I Blok A No. 2A - 5A, Depok 15590	L	1993-05-16	6191921101000009	Miller.Mannix38@yahoo.com
Bass.Maite38	Bass Maite	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Tasikmalaya 13226	P	1998-06-30	9041212101400009	Bass.Maite38@hotmail.com
Alvarez.Lael34	Alvarez Lael	Jl. Tambak No. 18, Garut 13722	L	1994-01-11	1043315121100001	Alvarez.Lael34@gmail.com
Lucas.Burton24	Lucas Burton	Jl. Duren Tiga Raya No. 5, Jakarta Selatan 12853	L	1998-11-16	1182023101100008	Lucas.Burton24@yahoo.com
Cash.Sierra87	Cash Sierra	Jl. Warung Buncit Raya No. 15, Tasikmalaya 12507	P	1996-11-03	1081530121500004	Cash.Sierra87@yahoo.com
Greene.Maggie23	Greene Maggie	Jl. H. Rohimin No. 30, Cilacap 15945	L	1991-01-31	9183421101100008	Greene.Maggie23@yahoo.com
Miranda.Elijah5	Miranda Elijah	Jl. MT. Haryono No. 8, Semarang 13428	P	1989-08-12	7133315111500002	Miranda.Elijah5@gmail.com
Estrada.Ulysses96	Estrada Ulysses	Jl. Sumur Batu Raya Blok A3 No. 13, Surabaya 12326	L	1999-02-28	1052113111400002	Estrada.Ulysses96@gmail.com
Stafford.Maris17	Stafford Maris	Jl. Ciledug Raya No. 94 - 96, Jakarta Selatan 12927	L	1994-05-25	0071530121100005	Stafford.Maris17@yahoo.com
Guy.Brenna41	Guy Brenna	Jl. Raya Pasar Minggu No. 3 A, Aceh 13931	P	1995-04-30	4011229111300000	Guy.Brenna41@hotmail.com
Fischer.Kato95	Fischer Kato	Jl. Ciputat Raya No. 40, Aceh 13970	L	1996-02-27	4032717121200005	Fischer.Kato95@gmail.com
Moody.Wesley2	Moody Wesley	Jl. Jenderal Sudirman Kavling 86, Garut 15315	P	1991-08-01	9092822121600008	Moody.Wesley2@hotmail.com
Lynch.Kimberley27	Lynch Kimberley	Jl. Balai Pustaka Baru No. 19, Balikpapan 15989	L	1999-03-30	6062516101400009	Lynch.Kimberley27@hotmail.com
Riddle.Julie74	Riddle Julie	Jl. Sultan Agung No. 67, Jakarta Utara 12713	L	1995-04-26	3011726121500009	Riddle.Julie74@gmail.com
Hancock.Alfreda49	Hancock Alfreda	Jl. Kramat Raya No. 128, Bogor 14335	P	1993-02-06	2063316101000001	Hancock.Alfreda49@yahoo.com
Pace.Victoria83	Pace Victoria	Jl. Duren Tiga Raya No. 20, Bogor 15752	L	1992-08-30	9061316101500004	Pace.Victoria83@gmail.com
Conley.Sylvia58	Conley Sylvia	Jl. Duren Tiga Raya No. 5, Jakarta Selatan 13519	P	1999-11-12	7133224111400007	Conley.Sylvia58@gmail.com
Dyer.Kiayada19	Dyer Kiayada	Jl. Cempaka Putih Tengah I / 1, Bontang 15615	L	1994-05-03	3012421121300009	Dyer.Kiayada19@yahoo.com
Huffman.Ferdinand12	Huffman Ferdinand	Jl. Raya Bogor KM. 22 No. 44, Depok 13039	L	1999-03-04	2061822111500001	Huffman.Ferdinand12@hotmail.com
Larsen.Macaulay53	Larsen Macaulay	Jl. Senayan No. 26, Balikpapan 13142	P	1995-01-11	7051216101300006	Larsen.Macaulay53@hotmail.com
Boyd.Rhea4	Boyd Rhea	Jl. Proklamasi  No. 43 , Jakarta Selatan 15837	L	1991-04-13	1092920121000007	Boyd.Rhea4@hotmail.com
Fowler.Iris54	Fowler Iris	Jl. RS. Fatmawati, Makasar 13925	P	1996-09-17	8163113121200003	Fowler.Iris54@hotmail.com
Morton.Galvin95	Morton Galvin	Jl. Ciranjang  II No. 20-22, Balikpapan 15363	L	1993-02-06	1163025111200005	Morton.Galvin95@hotmail.com
Hunter.Sybil43	Hunter Sybil	Jl. Prof. Dr. Latumeten No. 1, Semarang 13742	L	1993-08-13	1042627111400004	Hunter.Sybil43@yahoo.com
Larsen.Brady45	Larsen Brady	Jl. Raya Jatinegara Timur No. 85 - 87, Bontang 12566	P	1994-12-26	6012219111100000	Larsen.Brady45@gmail.com
Harding.Fritz24	Harding Fritz	Jl. Salemba Tengah 26 - 28, Semarang 15017	L	1995-07-12	6053016111200000	Harding.Fritz24@hotmail.com
Mercado.Aimee93	Mercado Aimee	Jl. Bintaro Permai Raya No. 3, Papua 14845	P	1990-05-06	2153316101400007	Mercado.Aimee93@hotmail.com
Kemp.Sydney66	Kemp Sydney	Jl. Daan Mogot No. 34, Bogor 15075	L	1993-03-05	4031813101100003	Kemp.Sydney66@gmail.com
Boyle.Inga72	Boyle Inga	Jl. Raya Kebayoran Lama No. 64 , Jakarta Utara 14676	L	1989-01-02	8022529121100003	Boyle.Inga72@yahoo.com
Stevenson.Ulla58	Stevenson Ulla	Jl. Kyai Maja No. 43, Garut 14865	P	1992-03-12	8032630101500008	Stevenson.Ulla58@hotmail.com
Higgins.Alec20	Higgins Alec	Jl. Raya Bogor KM. 22 No. 44, Bogor 15942	L	1991-09-01	9163215111300004	Higgins.Alec20@yahoo.com
Lawson.Ashton51	Lawson Ashton	Jl. Bintaro Permai Raya No. 3, Depok 14838	P	1993-01-09	6121916121100006	Lawson.Ashton51@yahoo.com
Figueroa.Orla61	Figueroa Orla	Pluit Mas I Blok A No. 2A - 5A, Garut 14375	L	1992-06-20	6181425121600002	Figueroa.Orla61@gmail.com
Pace.Madison82	Pace Madison	Jl. Raya Bogor KM. 22 No. 44, Bandung 14723	L	1989-11-15	4092022101400009	Pace.Madison82@hotmail.com
Mclaughlin.Nadine93	Mclaughlin Nadine	Jl. Lebak Bulus 1, Balikpapan 14809	L	1996-01-18	2052121111600009	Mclaughlin.Nadine93@hotmail.com
Hardy.Leslie67	Hardy Leslie	Jl. Warung Buncit Raya No. 15, Depok 15049	P	1997-08-23	7062611101400006	Hardy.Leslie67@gmail.com
Key.Simone25	Key Simone	Jl. Senayan No. 26, Bogor 12992	L	1996-10-23	2162626121500001	Key.Simone25@hotmail.com
Gibbs.Lance11	Gibbs Lance	Jl. Mohamad Kahfi Raya 1, Bontang 14919	L	1989-03-24	2181622101500008	Gibbs.Lance11@gmail.com
Suarez.Martina50	Suarez Martina	Jl. Prof. Dr. Latumeten No. 1, Semarang 14338	P	1991-10-04	4071328121400007	Suarez.Martina50@yahoo.com
Stevenson.Oren10	Stevenson Oren	Jl. Garnisun No. 2 - 3, Tasikmalaya 14502	L	1991-02-25	7161710111000005	Stevenson.Oren10@yahoo.com
Rogers.Nora79	Rogers Nora	Jl. Kali Pasir  No. 9, Balikpapan 12812	L	1996-02-22	4061223111200008	Rogers.Nora79@yahoo.com
Lowe.Kristen68	Lowe Kristen	Jl. Sawo No. 58 - 60, Medan 13550	P	1989-03-14	6161927121300003	Lowe.Kristen68@gmail.com
Deleon.Hollee41	Deleon Hollee	Jl. Raya kamal Outer Ring Road, Bandung 13912	L	1989-04-22	4083011101600002	Deleon.Hollee41@gmail.com
Watkins.Echo23	Watkins Echo	Jl. Pulomas Timur K. No.2, Bontang 12602	P	1998-06-17	3111920121300004	Watkins.Echo23@gmail.com
Richardson.Mollie88	Richardson Mollie	Jl. Warung Buncit Raya No. 15, Bandung 12364	L	1998-04-15	1093013101400008	Richardson.Mollie88@gmail.com
Hewitt.Dolan87	Hewitt Dolan	Jl. Metro Duta Kav. UE,  Pondok Indah, Bandung 14164	L	1989-11-19	3162311101100000	Hewitt.Dolan87@yahoo.com
Huffman.Felicia60	Huffman Felicia	Jl. Raya Pasar Minggu No. 3 A, Depok 14062	P	1997-02-11	9152911101400003	Huffman.Felicia60@gmail.com
Moran.Chiquita100	Moran Chiquita	Jl. Gandaria I / 20, Makasar 16078	L	1993-08-02	4032224111000007	Moran.Chiquita100@hotmail.com
Fitzpatrick.Holmes75	Fitzpatrick Holmes	Jl. Mohamad Kahfi Raya 1, Makasar 15535	P	1989-02-13	4083418101100005	Fitzpatrick.Holmes75@hotmail.com
Webster.Amity84	Webster Amity	Jl. Kramat Jaya, Tanjung Priok, Bogor 15409	L	1996-03-22	1041810101500004	Webster.Amity84@hotmail.com
Roman.Kieran63	Roman Kieran	Jl. Letjen S. Parman Kav. 84-86, Surabaya 12275	L	1999-11-09	1051927111300009	Roman.Kieran63@yahoo.com
Wolfe.Curran44	Wolfe Curran	Jl. Aipda K. S. Tubun No. 79, Bogor 16074	P	1998-10-30	0142710111100009	Wolfe.Curran44@hotmail.com
Ramsey.Yvette25	Ramsey Yvette	Jl. Pesanggrahan No. 1, Garut 14775	L	1996-12-29	9181917101500001	Ramsey.Yvette25@hotmail.com
Carney.Noble15	Carney Noble	Jl. Jenderal Sudirman Kavling 86, Medan 15579	P	1999-07-27	5072727101100005	Carney.Noble15@hotmail.com
Hudson.Thor22	Hudson Thor	Jl. Salemba Raya No. 41, Semarang 13495	L	1995-12-26	1021429121000005	Hudson.Thor22@hotmail.com
David.Joshua39	David Joshua	Jl. Pemuda, Tasikmalaya 14651	L	1989-11-05	3073328121000004	David.Joshua39@yahoo.com
Hamilton.Herrod37	Hamilton Herrod	Jl. Aipda K. S. Tubun No. 79, Bontang 12957	P	1997-09-17	5071927111200007	Hamilton.Herrod37@hotmail.com
Dale.Leroy26	Dale Leroy	Jl. Mahoni, Pasar Rebo, Cijantung II , Balikpapan 12878	L	1992-06-29	2152229121600007	Dale.Leroy26@gmail.com
Whitley.Heidi25	Whitley Heidi	Jl. Balai Pustaka Raya No. 29-31, Jakarta Selatan 15676	P	1995-08-04	3111123101200001	Whitley.Heidi25@yahoo.com
Stark.Cody92	Stark Cody	Jl. Pesanggrahan No. 1, Balikpapan 15834	L	1995-12-14	4082519101000001	Stark.Cody92@gmail.com
Ryan.Grace96	Ryan Grace	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Cilacap 12388	L	1999-04-16	3113417101500006	Ryan.Grace96@gmail.com
Stanton.Fay51	Stanton Fay	Jl. LapanganTembak No. 75, Surabaya 14198	P	1994-11-05	9122923101100006	Stanton.Fay51@hotmail.com
Lamb.Lydia34	Lamb Lydia	Jl. Salemba Raya, Depok 15815	L	1994-10-13	4163116111100005	Lamb.Lydia34@yahoo.com
Sloan.Elliott92	Sloan Elliott	Jl. Raden Inten, Jakarta Selatan 13041	P	1995-03-07	2122312111000007	Sloan.Elliott92@gmail.com
Beard.Dacey17	Beard Dacey	Jl. Senayan No. 26, Aceh 14204	L	1996-08-01	8142111121200007	Beard.Dacey17@gmail.com
Turner.Emily41	Turner Emily	Jl. Kyai Tapa No. , Papua 13836	L	1998-04-07	3072830121300000	Turner.Emily41@gmail.com
Martinez.Quentin83	Martinez Quentin	Jl. Gereja Theresia No. 22, Medan 12924	L	1999-10-21	3182726111000008	Martinez.Quentin83@yahoo.com
Vaughn.Francesca36	Vaughn Francesca	Jl. Tipar Cakung No. 5, Semarang 15745	P	1993-03-13	3071519121300005	Vaughn.Francesca36@hotmail.com
Higgins.Gannon55	Higgins Gannon	Jl. R. C. Veteran No. 178, Depok 13035	L	1989-12-22	2181126101100004	Higgins.Gannon55@hotmail.com
Park.Iliana41	Park Iliana	Jl. Duren Sawit Baru No. 2, Bogor 12111	L	1992-06-16	3193024121500000	Park.Iliana41@gmail.com
Daniel.Brandon11	Daniel Brandon	Jl. Taman Brawijaya No. 1, Garut 15566	P	1996-01-31	2121616101000009	Daniel.Brandon11@yahoo.com
Reed.Cora15	Reed Cora	Jl. Pluit Raya No. 2, Makasar 15578	L	1998-07-12	9041717121600000	Reed.Cora15@hotmail.com
Green.Robin52	Green Robin	Jl. Landas Pacu Timur, Bogor 13852	P	1995-04-23	8131414121100006	Green.Robin52@yahoo.com
Poole.Alisa1	Poole Alisa	Jl. Raya Pondok Kopi, Surabaya 15313	L	1991-09-27	5091425121500000	Poole.Alisa1@hotmail.com
Castro.Yuri6	Castro Yuri	Jl. Pahlawan Komarudin Raya No. 5, Semarang 15902	L	1996-01-06	2161421121400006	Castro.Yuri6@yahoo.com
Horne.Hollee43	Horne Hollee	Jl. Letjen S. Parman Kav. 84-86, Samarinda 13442	P	1993-08-28	6133319111400000	Horne.Hollee43@yahoo.com
Sampson.Rooney97	Sampson Rooney	Jl. Duren Sawit Baru No. 2, Samarinda 14763	L	1989-09-08	9062226121300004	Sampson.Rooney97@hotmail.com
Atkins.Winifred10	Atkins Winifred	Jl. Bintaro Permai Raya No. 3, Jakarta Selatan 15299	P	1999-07-23	3072126121100004	Atkins.Winifred10@gmail.com
Joseph.Keegan13	Joseph Keegan	Jl. Pemuda, Balikpapan 15416	L	1998-05-28	4062222121000009	Joseph.Keegan13@yahoo.com
Marsh.Jorden96	Marsh Jorden	Jl. Panjang Arteri 26, Samarinda 13296	L	1996-07-08	8092922121000003	Marsh.Jorden96@gmail.com
Bennett.Mary57	Bennett Mary	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Surabaya 12503	P	1994-03-07	1093020101200008	Bennett.Mary57@hotmail.com
Rowland.Adele41	Rowland Adele	Jl. RS Fatmawati No. 74 , Jakarta Utara 12374	L	1998-07-07	2172214101100002	Rowland.Adele41@gmail.com
Forbes.David77	Forbes David	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Medan 13767	P	1989-11-02	1171615101400002	Forbes.David77@hotmail.com
Meyer.Michael57	Meyer Michael	Jl. RS Polri, Jakarta Utara 15531	L	1990-06-15	8182221121000005	Meyer.Michael57@yahoo.com
Donaldson.Dillon18	Donaldson Dillon	Jl. Raya Pasar Minggu No. 3 A, Surabaya 13795	L	1993-10-12	7133226121500003	Donaldson.Dillon18@gmail.com
Klein.Yael79	Klein Yael	Jl. Ciranjang  II No. 20-22, Jakarta Selatan 14640	P	1989-02-04	9171330101000002	Klein.Yael79@hotmail.com
Gould.Ferris72	Gould Ferris	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Jakarta Utara 14492	L	1997-04-14	4161827121000004	Gould.Ferris72@yahoo.com
Vasquez.Kaseem21	Vasquez Kaseem	Jl. Jenderal Gatot Subroto Kav. 59, Bandung 15299	P	1989-12-20	0111127121200005	Vasquez.Kaseem21@gmail.com
Oconnor.Fritz50	Oconnor Fritz	Jl. Gereja Theresia No. 22, Tasikmalaya 15928	L	1995-09-09	4173321121300001	Oconnor.Fritz50@yahoo.com
Hardin.Evan67	Hardin Evan	Jl. Balai Pustaka Raya No. 29-31, Cilacap 14055	L	1998-04-14	6122230121200003	Hardin.Evan67@gmail.com
Weaver.Janna59	Weaver Janna	Jl. Siaga Raya Kav. 4 - 8, Bandung 13849	L	1989-07-20	4172720101500003	Weaver.Janna59@hotmail.com
Hoover.Raya40	Hoover Raya	Jl. Pulomas Timur K. No.2, Medan 12119	P	1989-08-23	2062618101100002	Hoover.Raya40@gmail.com
Casey.Kendall70	Casey Kendall	Jl. Duren Tiga Raya No. 5, Garut 13434	L	1991-05-27	8161714101500004	Casey.Kendall70@hotmail.com
Guy.Clare17	Guy Clare	Jl. LapanganTembak No. 75, Papua 14897	L	1990-01-14	5133215121600002	Guy.Clare17@hotmail.com
Graham.Gillian83	Graham Gillian	Jl. Pulomas Barat VI No. 20, Papua 15994	P	1993-07-08	7121612111400005	Graham.Gillian83@gmail.com
Oliver.Venus52	Oliver Venus	Jl. RS Fatmawati No. 74 , Papua 12960	L	1989-01-28	9112315101000000	Oliver.Venus52@gmail.com
Buckner.Heather43	Buckner Heather	Jl. Sultan Agung No. 67, Makasar 13409	P	1989-06-17	5192511121400008	Buckner.Heather43@hotmail.com
Warren.Hyacinth69	Warren Hyacinth	Jl. Kesehatan No. 9, Tasikmalaya 15385	L	1996-02-16	2191827121600005	Warren.Hyacinth69@hotmail.com
Daniel.Quamar92	Daniel Quamar	Jl. Tarum Barat - Kalimalang, Bandung 14555	L	1993-09-15	9141830101600001	Daniel.Quamar92@hotmail.com
Good.Shaine54	Good Shaine	Jl. RS. Fatmawati, Aceh 12400	P	1995-04-15	6061629121300009	Good.Shaine54@hotmail.com
Schultz.Maite82	Schultz Maite	Jl. LetJen S. Parman Kav. 87, Slipi, Aceh 12120	L	1996-03-07	4072325111500006	Schultz.Maite82@gmail.com
Benjamin.Allistair71	Benjamin Allistair	Jl. RS Fatmawati No. 80 - 82, Tasikmalaya 12486	P	1994-12-30	4151928121100004	Benjamin.Allistair71@yahoo.com
Barber.Shannon83	Barber Shannon	Jl. Bintaro Permai Raya No. 3, Balikpapan 12185	L	1996-06-16	8132214111300001	Barber.Shannon83@yahoo.com
Mcgee.Boris66	Mcgee Boris	Jl. Kaji No. 40, Samarinda 14514	L	1991-02-13	2092010121200002	Mcgee.Boris66@yahoo.com
Combs.Libby96	Combs Libby	Jl. Raya Pasar Minggu No. 3 A, Depok 12472	P	1990-02-15	4172818101100002	Combs.Libby96@gmail.com
Middleton.Aretha35	Middleton Aretha	Jl. Prof. Dr. Latumeten No. 1, Samarinda 15000	L	1999-11-25	2191815121000000	Middleton.Aretha35@hotmail.com
Farmer.Isaiah3	Farmer Isaiah	Jl. Kramat Jaya, Tanjung Priok, Makasar 12390	P	1993-07-23	5062127121500003	Farmer.Isaiah3@yahoo.com
Mejia.Montana71	Mejia Montana	Jl. Raya Pondok Kopi, Garut 12537	L	1993-12-11	9042021101000005	Mejia.Montana71@hotmail.com
Velazquez.Shelly91	Velazquez Shelly	Jl. Sawo No. 58 - 60, Bogor 15632	L	1993-06-20	2111730121100007	Velazquez.Shelly91@gmail.com
Albert.Dorothy22	Albert Dorothy	Jl. R. C. Veteran No. 178, Samarinda 14473	P	1992-01-26	9161717101600004	Albert.Dorothy22@gmail.com
Tucker.Lucian78	Tucker Lucian	Jl. Pluit Raya No. 2, Bontang 14868	L	1995-11-26	2142317111300009	Tucker.Lucian78@hotmail.com
Mays.Zelenia2	Mays Zelenia	Jl. Garnisun No. 2 - 3, Jakarta Utara 12415	L	1992-05-16	1172818101500003	Mays.Zelenia2@yahoo.com
Mcknight.Dorothy30	Mcknight Dorothy	Jl. Raya Bogor, Jakarta Utara 12396	P	1991-12-21	5112018101400002	Mcknight.Dorothy30@yahoo.com
Odonnell.Deacon8	Odonnell Deacon	Jl. Bintaro Permai Raya No. 3, Cilacap 13603	L	1995-11-22	1011411121000008	Odonnell.Deacon8@yahoo.com
Compton.Demetria66	Compton Demetria	Jl. RS Fatmawati No. 74 , Semarang 14040	P	1999-09-04	3092017121200003	Compton.Demetria66@gmail.com
Vang.Anjolie13	Vang Anjolie	Jl. Raya Pasar Minggu No. 3 A, Garut 15796	L	1994-04-09	4071923101200007	Vang.Anjolie13@hotmail.com
Burke.Martha6	Burke Martha	Jl. Jend. Sudirman Kav. 49 , Jakarta Selatan 15057	L	1992-06-21	4011811121200001	Burke.Martha6@gmail.com
Reyes.Harding37	Reyes Harding	Jl. LetJen S. Parman Kav. 87, Slipi, Aceh 15780	P	1992-03-10	0092920101100008	Reyes.Harding37@hotmail.com
Pena.Hayes97	Pena Hayes	Jl. Raya Pondok Gede No. 4, Jakarta Selatan 12955	L	1997-08-25	7012320101000008	Pena.Hayes97@gmail.com
Grimes.Gray62	Grimes Gray	Jl. TB Simatupang No. 71 Jak-Tim, Makasar 14766	P	1998-11-30	4192710111300000	Grimes.Gray62@hotmail.com
Velez.Bertha40	Velez Bertha	Jl. Panglima Polim I  No. 34, Medan 12723	L	1998-12-16	3193213121500003	Velez.Bertha40@yahoo.com
Gould.Darrel85	Gould Darrel	Jl. Ciledug Raya No. 94 - 96, Bontang 12714	L	1997-10-01	8043121121600007	Gould.Darrel85@hotmail.com
Fernandez.Deborah38	Fernandez Deborah	Jl. Raya Cilandak  KKO, Bandung 15898	P	1994-02-01	2052427101100007	Fernandez.Deborah38@hotmail.com
Conrad.Idola55	Conrad Idola	Jl. MT. Haryono No. 8, Cilacap 13830	L	1996-09-04	2033424111000002	Conrad.Idola55@gmail.com
Moon.Harding14	Moon Harding	Jl. RS Fatmawati No. 80 - 82, Jakarta Selatan 13391	P	1992-04-08	3013221121200009	Moon.Harding14@gmail.com
James.Denton32	James Denton	Jl. Sultan Agung No. 67, Cilacap 12580	L	1990-01-08	3193129111500000	James.Denton32@yahoo.com
Roberts.Stephen1	Roberts Stephen	Jl. Raya Cilandak  KKO, Balikpapan 15585	L	1990-11-08	3011628101400007	Roberts.Stephen1@yahoo.com
Robbins.Erica16	Robbins Erica	Jl. Warung Silah No. 1, Surabaya 12148	P	1990-02-22	6033413101200004	Robbins.Erica16@hotmail.com
Rodriguez.Stone40	Rodriguez Stone	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya 15945	L	1997-04-22	9082626121200007	Rodriguez.Stone40@yahoo.com
Finley.Shelly100	Finley Shelly	Jl. Warung Buncit Raya No. 15, Depok 12886	P	1993-02-09	5042327101200002	Finley.Shelly100@yahoo.com
Abbott.Owen53	Abbott Owen	Jl. Diponegoro No. 71, Garut 13439	L	1995-06-16	4132423101600000	Abbott.Owen53@yahoo.com
Curtis.Michael78	Curtis Michael	Jl. Pemuda No. 80  RT.001 RW.08, Bandung 15642	L	1996-05-16	4081620101300001	Curtis.Michael78@gmail.com
Waller.Jena96	Waller Jena	Jl. Perintis Kemerdekaan Kav. 149, Jakarta Selatan 14390	P	1990-10-14	8041821111500007	Waller.Jena96@hotmail.com
Salazar.Coby19	Salazar Coby	Jl. Duren Tiga Raya No. 5, Tasikmalaya 14376	L	1999-03-14	5111519111100006	Salazar.Coby19@hotmail.com
Schwartz.Megan66	Schwartz Megan	Jl. Jend. Sudirman Kav. 49 , Balikpapan 13951	P	1998-12-16	3073413111500006	Schwartz.Megan66@yahoo.com
Ryan.Aladdin11	Ryan Aladdin	Jl. Kesehatan No. 9, Tasikmalaya 14923	L	1999-09-24	0192023101200007	Ryan.Aladdin11@gmail.com
Mclaughlin.Austin97	Mclaughlin Austin	Jl. Raya Bogor  Km. 19  No. 3.a, Medan 15893	L	1990-02-24	0132125111100006	Mclaughlin.Austin97@hotmail.com
Chase.Chaim30	Chase Chaim	Jl. Daan Mogot No. 34, Cilacap 15491	P	1992-06-10	7073021101400001	Chase.Chaim30@yahoo.com
Woods.Kennan17	Woods Kennan	Jl. Salemba Raya No. 41, Cilacap 14665	L	1999-10-01	8062510101600000	Woods.Kennan17@hotmail.com
Phelps.Illana89	Phelps Illana	JL. Duren Sawit Raya Blok K.3 No.1, Aceh 13769	P	1993-02-24	2193315101400007	Phelps.Illana89@hotmail.com
Cooley.Talon70	Cooley Talon	Jl. Ciputat Raya No. 40, Jakarta Selatan 12145	L	1995-06-20	7183418101500004	Cooley.Talon70@hotmail.com
Mann.Brian16	Mann Brian	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Makasar 15174	L	1989-09-21	4111229111600003	Mann.Brian16@gmail.com
Gilmore.Alden89	Gilmore Alden	Jl. Pemuda No. 80  RT.001 RW.08, Makasar 14927	P	1995-09-27	4182230101100006	Gilmore.Alden89@yahoo.com
Wells.Vincent91	Wells Vincent	Jl. Bina Warga RT. 009 / RW. 07, Kalibata, Semarang 13342	L	1994-03-10	2181410111000003	Wells.Vincent91@gmail.com
Beck.Sybil86	Beck Sybil	Jl. Garnisun No. 2 - 3, Bogor 15089	P	1991-02-23	7061221101600002	Beck.Sybil86@hotmail.com
Douglas.Davis20	Douglas Davis	Jl. Raya Pondok Kopi, Papua 14099	L	1989-04-17	2143318111600001	Douglas.Davis20@hotmail.com
Rivera.Kelsie6	Rivera Kelsie	Jl. Siaga Raya Kav. 4 - 8, Jakarta Utara 14656	L	1995-10-03	2132713101500007	Rivera.Kelsie6@hotmail.com
Fernandez.Colton64	Fernandez Colton	Jl. Jend. Sudirman Kav. 49 , Balikpapan 12217	P	1993-03-14	7073326121300003	Fernandez.Colton64@hotmail.com
Barber.Yael97	Barber Yael	Jl. Aipda K. S. Tubun No. 79, Depok 14201	L	1993-04-06	0161616101000000	Barber.Yael97@hotmail.com
Gilmore.Porter80	Gilmore Porter	Jl. Kali Pasir  No. 9, Balikpapan 13673	P	1994-09-28	3182611101100009	Gilmore.Porter80@gmail.com
Townsend.Leah8	Townsend Leah	Jl. Raya Bogor  Km. 19  No. 3.a, Tasikmalaya 12428	L	1995-03-11	8062314101500009	Townsend.Leah8@yahoo.com
Davis.Jordan9	Davis Jordan	Jl. Duren Tiga Raya No. 20, Garut 14515	L	1989-09-09	7061217111000005	Davis.Jordan9@hotmail.com
Stuart.Juliet6	Stuart Juliet	Jl. Daan Mogot No. 34, Depok 15543	L	1989-09-19	3071730111400002	Stuart.Juliet6@gmail.com
Gonzales.Indigo58	Gonzales Indigo	Jl. LetJen S. Parman Kav. 87, Makasar 12244	P	1995-04-13	6061710121500000	Gonzales.Indigo58@gmail.com
Kidd.Alma42	Kidd Alma	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Papua 15521	L	1993-06-03	3092024121500005	Kidd.Alma42@hotmail.com
Christian.Xyla72	Christian Xyla	Jl. Agung Utara Raya Blok A No. 1, Depok 15486	L	1991-11-15	3091530111000009	Christian.Xyla72@hotmail.com
Snyder.India67	Snyder India	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Utara 13160	P	1996-11-29	1053410101200003	Snyder.India67@gmail.com
Short.Laith32	Short Laith	Jl. Mohamad Kahfi Raya 1, Medan 15185	L	1996-09-21	8142229101500006	Short.Laith32@hotmail.com
Haynes.Lilah97	Haynes Lilah	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Bandung 12966	L	1997-08-12	8141725101600003	Haynes.Lilah97@yahoo.com
Dejesus.Bevis5	Dejesus Bevis	Jl. Prof. Dr. Latumeten No. 1, Cilacap 13024	P	1995-07-21	0013322101600001	Dejesus.Bevis5@gmail.com
Bonner.Martin82	Bonner Martin	Jl. Pahlawan Komarudin Raya No. 5, Aceh 15394	L	1995-09-23	9083026101400003	Bonner.Martin82@gmail.com
Roman.Shana89	Roman Shana	Jl. Raden Saleh No. 40 , Medan 13195	P	1996-02-10	5163411121600009	Roman.Shana89@gmail.com
Paul.Griffith99	Paul Griffith	Jl. Mohamad Kahfi Raya 1, Balikpapan 14907	L	1998-02-14	2051116101100002	Paul.Griffith99@yahoo.com
Smith.Julian76	Smith Julian	Jl. Pemuda No. 80  RT.001 RW.08, Balikpapan 15254	L	1996-07-09	6023012101300008	Smith.Julian76@gmail.com
Roach.Nyssa62	Roach Nyssa	Jl. Salemba Tengah 26 - 28, Depok 14114	P	1998-08-19	8042319121100004	Roach.Nyssa62@yahoo.com
Reeves.Merritt36	Reeves Merritt	Jl. Sirsak No. 21, Balikpapan 14837	L	1990-07-13	5143013111600007	Reeves.Merritt36@hotmail.com
Irwin.Porter90	Irwin Porter	Jl. Persahabatan Raya , Bandung 14918	P	1992-02-18	1022826121000009	Irwin.Porter90@yahoo.com
Santos.Brett11	Santos Brett	Jl. H. Rohimin No. 30, Depok 12470	L	1995-02-21	3032914101300007	Santos.Brett11@hotmail.com
Doyle.Whoopi68	Doyle Whoopi	Jl. Sultan Agung No. 67, Semarang 15988	L	1998-12-07	4011330111100001	Doyle.Whoopi68@gmail.com
Castro.Sean47	Castro Sean	Jl. Kyai Caringin No. 7, Medan 14577	P	1998-08-03	2063119121300004	Castro.Sean47@hotmail.com
Davidson.Meghan49	Davidson Meghan	Jl. Raya Pasar Minggu No. 3 A, Samarinda 15610	L	1995-08-03	6141524101100000	Davidson.Meghan49@hotmail.com
Byers.Bert51	Byers Bert	Jl. Jenderal Gatot Subroto Kav. 59, Aceh 14248	L	1993-02-07	6141819101300005	Byers.Bert51@yahoo.com
Rowe.Adrian64	Rowe Adrian	Jl. Kaji No. 40, Depok 15841	P	1999-09-29	5092417121100008	Rowe.Adrian64@gmail.com
Horne.Porter57	Horne Porter	Jl. Balai Pustaka Baru No. 19, Tasikmalaya 14570	L	1999-09-11	9071922101400004	Horne.Porter57@yahoo.com
Snow.Brett59	Snow Brett	Jl. Warung Buncit Raya No. 15, Tasikmalaya 12612	L	1994-04-18	1122923111600001	Snow.Brett59@yahoo.com
May.Dorothy63	May Dorothy	Jl. Garnisun No. 2 - 3, Garut 14876	P	1998-11-21	1132230101500000	May.Dorothy63@gmail.com
Dunlap.Irma4	Dunlap Irma	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Bogor 14585	L	1989-09-16	2112711111400008	Dunlap.Irma4@hotmail.com
Howe.Raven27	Howe Raven	Jl. Gereja Theresia No. 22, Bogor 14712	P	1989-04-02	5012125111400005	Howe.Raven27@yahoo.com
Ferguson.Jael67	Ferguson Jael	Jl. Pluit Raya No. 2, Papua 13256	L	1998-10-14	1162713101100000	Ferguson.Jael67@gmail.com
Donaldson.Eric52	Donaldson Eric	Jl. Prof. Dr. Latumeten No. 1, Papua 15154	L	1995-02-16	1042522121100009	Donaldson.Eric52@gmail.com
Schmidt.Mufutau78	Schmidt Mufutau	Jl. Dr. Saharjo No. 120, Cilacap 12694	P	1990-10-22	9091728121400000	Schmidt.Mufutau78@gmail.com
Harrington.Peter98	Harrington Peter	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Samarinda 13122	L	1998-04-09	4082917101000002	Harrington.Peter98@hotmail.com
Gillespie.Uta93	Gillespie Uta	Jl. Boulevard Timur Raya RT. 006 / 02, Bontang 14598	P	1992-05-11	1182725121600002	Gillespie.Uta93@yahoo.com
Davenport.Louis2	Davenport Louis	Jl. R. C. Veteran No. 178, Depok 15780	L	1990-12-18	0071314101600005	Davenport.Louis2@yahoo.com
Guy.Bernard63	Guy Bernard	Jl. LetJen S. Parman Kav. 87, Slipi, Medan 15586	L	1995-03-01	6122025121300000	Guy.Bernard63@yahoo.com
May.Zenaida90	May Zenaida	Jl. LetJen S. Parman Kav. 87, Slipi, Semarang 13647	P	1994-04-15	2191129101500007	May.Zenaida90@yahoo.com
Jensen.Judith77	Jensen Judith	Jl. Raya Pondok Gede No. 4, Balikpapan 13387	L	1989-02-12	2113221111000006	Jensen.Judith77@gmail.com
Reyes.Scarlett68	Reyes Scarlett	Jl. R. C. Veteran No. 178, Jakarta Utara 15739	P	1990-01-23	7023021121300007	Reyes.Scarlett68@yahoo.com
Oneal.Channing81	Oneal Channing	Jl. Boulevard Timur Raya RT. 006 / 02, Jakarta Selatan 14178	L	1991-03-19	2141710101500007	Oneal.Channing81@gmail.com
Nunez.Madeline78	Nunez Madeline	Jl. H. Ten, Balikpapan 15193	L	1996-08-13	9151619111400001	Nunez.Madeline78@gmail.com
Hopkins.Barbara4	Hopkins Barbara	Jl. Raya Pondok Gede No. 4, Bontang 13282	P	1998-08-22	4042315121300006	Hopkins.Barbara4@yahoo.com
Carrillo.Hedley46	Carrillo Hedley	Jl. Ciputat Raya No. 40, Balikpapan 16017	L	1998-08-28	1022217111500000	Carrillo.Hedley46@yahoo.com
Farrell.Samuel79	Farrell Samuel	Jl. Jenderal Gatot Subroto Kav. 59, Garut 14045	P	1992-06-23	1033427101500001	Farrell.Samuel79@hotmail.com
Rowland.Kevyn66	Rowland Kevyn	Jl. Duren Tiga Raya No. 5, Cilacap 14771	L	1991-04-15	5082116101000004	Rowland.Kevyn66@gmail.com
Carey.Madonna75	Carey Madonna	Jl. Duren Tiga Raya No. 20, Jakarta Utara 14088	L	1991-04-24	1032424101200005	Carey.Madonna75@gmail.com
Sosa.Sasha51	Sosa Sasha	Jl. MT. Haryono No. 8, Semarang 14124	P	1993-09-13	2012213121100009	Sosa.Sasha51@yahoo.com
Andrews.Shaeleigh9	Andrews Shaeleigh	Jl. HR. Rasuna Said, Kuningan, Cilacap 13014	L	1996-03-28	9121714111500000	Andrews.Shaeleigh9@hotmail.com
Mccormick.Guinevere28	Mccormick Guinevere	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Bandung 15053	P	1996-08-31	4133120101200003	Mccormick.Guinevere28@gmail.com
Logan.Wing49	Logan Wing	Jl. Warung Silah No. 1, Bontang 12243	L	1989-06-25	2043016111600007	Logan.Wing49@gmail.com
Gamble.Chastity15	Gamble Chastity	Jl. Bukit Gading Raya Kav. II, Makasar 15061	L	1994-03-04	6171516111000004	Gamble.Chastity15@hotmail.com
Burton.Carly6	Burton Carly	Jl. Raya Cilandak  KKO, Tasikmalaya 12898	P	1990-02-16	3023210101200007	Burton.Carly6@yahoo.com
Mcintosh.Roary89	Mcintosh Roary	Jl. Raya Pluit Selatan No. 2, Bontang 14643	L	1998-02-04	0011910101400002	Mcintosh.Roary89@gmail.com
Duncan.Berk75	Duncan Berk	Jl. Warung Buncit Raya No. 15, Cilacap 13469	P	1994-12-03	0083228101500009	Duncan.Berk75@yahoo.com
Compton.May41	Compton May	Jl. Raya Pluit Selatan No. 2, Depok 15529	L	1998-02-22	6041428101400001	Compton.May41@gmail.com
Chen.Kelsey73	Chen Kelsey	Jl. Pahlawan Revolusi No. 47, Tasikmalaya 13267	L	1989-03-31	8123329121600005	Chen.Kelsey73@hotmail.com
Clark.Neville89	Clark Neville	Jl. Tipar Cakung No. 5, Surabaya 15879	P	1994-05-09	5163010101100004	Clark.Neville89@yahoo.com
Boyd.Daquan50	Boyd Daquan	Jl. Raya kamal Outer Ring Road, Papua 12659	L	1996-02-07	3051415101400009	Boyd.Daquan50@yahoo.com
Roberson.Mari59	Roberson Mari	Jl. Dharmawangsa Raya No. 13  Blok P II, Bontang 12523	P	1993-02-04	5021117101300001	Roberson.Mari59@hotmail.com
Hendricks.Wilma48	Hendricks Wilma	Jl. Siak J-5 No. 14, Samarinda 13447	L	1990-12-24	8133111101500005	Hendricks.Wilma48@gmail.com
Howell.Kitra87	Howell Kitra	Jl. Taman Brawijaya No. 1, Aceh 15534	L	1996-10-07	0033015121100004	Howell.Kitra87@gmail.com
Perkins.Merrill87	Perkins Merrill	Jl. Taman Brawijaya No. 1, Jakarta Utara 14881	P	1998-01-11	6042521101500005	Perkins.Merrill87@gmail.com
Christensen.Constance90	Christensen Constance	Jl. Siaga Raya Kav. 4 - 8, Makasar 12559	L	1991-10-01	4132417121100007	Christensen.Constance90@gmail.com
Mendoza.Christopher100	Mendoza Christopher	Jl. RS. Fatmawati, Jakarta Utara 13954	P	1989-08-11	3051222101000008	Mendoza.Christopher100@hotmail.com
Peters.Cherokee71	Peters Cherokee	Jl. Boulevard Timur Raya RT. 006 / 02, Surabaya 13647	L	1995-07-01	0123125121400003	Peters.Cherokee71@hotmail.com
Kaufman.Ciara5	Kaufman Ciara	Jl. Jend. Sudirman Kav. 49 , Depok 14305	L	1989-12-23	2072825121100004	Kaufman.Ciara5@yahoo.com
Moody.Hall39	Moody Hall	Jl. Kramat Raya No. 17 A, Aceh 14822	P	1999-03-04	1031530111600006	Moody.Hall39@gmail.com
Gross.Adena8	Gross Adena	Jl. Pemuda, Surabaya 14290	L	1990-06-17	5081722121600007	Gross.Adena8@hotmail.com
Joyce.Kareem51	Joyce Kareem	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Tasikmalaya 13751	L	1989-04-09	1171216111600005	Joyce.Kareem51@hotmail.com
Guy.Grant10	Guy Grant	Jl. Ciranjang  II No. 20-22, Medan 15177	P	1992-07-23	3082111121400009	Guy.Grant10@hotmail.com
Albert.Ina45	Albert Ina	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Bogor 13000	L	1994-06-08	6132824111100003	Albert.Ina45@gmail.com
Mcclain.Elliott76	Mcclain Elliott	Jl. Jend. Sudirman Kav. 49 , Makasar 14864	P	1992-01-19	6092110101500004	Mcclain.Elliott76@yahoo.com
Rutledge.Teagan33	Rutledge Teagan	Jl. Garnisun No. 2 - 3, Tasikmalaya 13439	L	1999-01-01	3112626101100000	Rutledge.Teagan33@hotmail.com
Ramos.Jamal78	Ramos Jamal	Jl. Kaji No. 40, Medan 14054	L	1990-05-12	7123223101100004	Ramos.Jamal78@gmail.com
Barrett.Echo100	Barrett Echo	Jl. Pulomas Barat VI No. 20, Makasar 13829	P	1992-07-04	6183017101600000	Barrett.Echo100@yahoo.com
Glass.Aristotle86	Glass Aristotle	Jl. Bintaro Permai Raya No. 3, Tasikmalaya 14839	L	1992-12-10	3011622111200006	Glass.Aristotle86@hotmail.com
Herring.Adele60	Herring Adele	Jl. Gandaria I / 20, Aceh 15558	P	1990-01-05	0132915101300000	Herring.Adele60@yahoo.com
Rich.Adrienne97	Rich Adrienne	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Papua 14497	L	1996-12-03	1132627111500005	Rich.Adrienne97@hotmail.com
Rivers.Ingrid95	Rivers Ingrid	Jl. Ciputat Raya No. 40, Aceh 13458	L	1997-06-05	4171510101400001	Rivers.Ingrid95@hotmail.com
Mcmillan.Mariko69	Mcmillan Mariko	Jl. Raya Bekasi Timur 170 C, Samarinda 12832	P	1996-10-23	1191524121100003	Mcmillan.Mariko69@gmail.com
Carson.Herrod88	Carson Herrod	Jl. Pluit Raya No. 2, Makasar 12330	L	1998-11-22	3182528101400008	Carson.Herrod88@hotmail.com
Lewis.Wayne43	Lewis Wayne	Jl. Cempaka Putih Tengah I / 1, Garut 15703	P	1996-05-16	1022330101200008	Lewis.Wayne43@yahoo.com
Dunlap.Harper2	Dunlap Harper	Jl. Pemuda No. 80  RT.001 RW.08, Bogor 13335	L	1998-01-08	1091218121000008	Dunlap.Harper2@gmail.com
Bird.Branden18	Bird Branden	Jl. Pemuda No. 80  RT.001 RW.08, Samarinda 12817	L	1992-02-01	9161713121000006	Bird.Branden18@gmail.com
Garcia.Reed1	Garcia Reed	Jl. Panglima Polim I  No. 34, Bontang 13356	P	1995-01-25	1113410101300002	Garcia.Reed1@yahoo.com
Mcguire.Mia1	Mcguire Mia	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Tasikmalaya 13880	L	1997-02-10	5052016101500005	Mcguire.Mia1@gmail.com
Short.Nathan42	Short Nathan	Jl. Ciputat Raya No. 5, Jakarta Utara 12930	P	1992-01-30	3192615101100005	Short.Nathan42@hotmail.com
arri.kurniawan	Arri Kurniawan	Jl. Jati No. 1, Garut	L	1994-08-02	1194316151011234	arri.kurniawan@gmail.com
\.


--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pembayaran (id, waktu_bayar, jumlah_bayar, id_pendaftaran) FROM stdin;
1	2017-05-01 00:00:00	500000.00	201
2	2017-04-24 00:00:00	500000.00	202
3	2017-05-03 00:00:00	500000.00	203
4	2017-04-04 00:00:00	500000.00	204
5	2017-05-10 00:00:00	500000.00	205
6	2017-04-24 00:00:00	500000.00	206
7	2017-05-04 00:00:00	500000.00	207
8	2017-05-02 00:00:00	500000.00	208
9	2017-04-14 00:00:00	500000.00	209
10	2017-05-14 00:00:00	500000.00	210
11	2017-04-03 00:00:00	500000.00	211
12	2017-05-10 00:00:00	500000.00	212
13	2017-04-01 00:00:00	500000.00	213
14	2017-04-02 00:00:00	500000.00	214
15	2017-04-24 00:00:00	500000.00	215
16	2017-04-04 00:00:00	500000.00	216
17	2017-05-04 00:00:00	500000.00	217
18	2017-05-14 00:00:00	500000.00	218
19	2017-04-21 00:00:00	500000.00	219
20	2017-04-19 00:00:00	500000.00	220
21	2017-05-12 00:00:00	500000.00	221
22	2017-04-29 00:00:00	500000.00	222
23	2017-04-30 00:00:00	500000.00	223
24	2017-05-03 00:00:00	500000.00	224
25	2017-04-08 00:00:00	500000.00	225
26	2017-05-15 00:00:00	500000.00	226
27	2017-05-05 00:00:00	500000.00	227
28	2017-04-09 00:00:00	500000.00	228
29	2017-04-24 00:00:00	500000.00	229
30	2017-05-04 00:00:00	500000.00	230
31	2017-04-18 00:00:00	500000.00	231
32	2017-04-24 00:00:00	500000.00	232
33	2017-04-01 00:00:00	500000.00	233
34	2017-04-03 00:00:00	500000.00	234
35	2017-05-01 00:00:00	500000.00	235
36	2017-04-24 00:00:00	500000.00	236
37	2017-05-04 00:00:00	500000.00	237
38	2017-05-11 00:00:00	500000.00	238
39	2017-05-11 00:00:00	500000.00	239
40	2017-04-28 00:00:00	500000.00	240
41	2017-04-04 00:00:00	500000.00	241
42	2017-05-05 00:00:00	500000.00	242
43	2017-04-30 00:00:00	500000.00	243
44	2017-05-01 00:00:00	500000.00	244
45	2017-05-13 00:00:00	500000.00	245
46	2017-04-04 00:00:00	500000.00	246
47	2017-05-11 00:00:00	500000.00	247
48	2017-04-11 00:00:00	500000.00	248
49	2017-04-28 00:00:00	500000.00	249
50	2017-05-03 00:00:00	500000.00	250
51	2017-04-25 00:00:00	500000.00	251
52	2017-04-14 00:00:00	500000.00	252
53	2017-05-03 00:00:00	500000.00	253
54	2017-05-12 00:00:00	500000.00	254
55	2017-04-28 00:00:00	500000.00	255
56	2017-05-12 00:00:00	500000.00	256
57	2017-05-04 00:00:00	500000.00	257
58	2017-04-18 00:00:00	500000.00	258
59	2017-04-02 00:00:00	500000.00	259
60	2017-04-10 00:00:00	500000.00	260
61	2017-04-10 00:00:00	500000.00	261
62	2017-04-24 00:00:00	500000.00	262
63	2017-05-03 00:00:00	500000.00	263
64	2017-04-20 00:00:00	500000.00	264
65	2017-04-25 00:00:00	500000.00	265
66	2017-04-23 00:00:00	500000.00	266
67	2017-04-15 00:00:00	500000.00	267
68	2017-05-03 00:00:00	500000.00	268
69	2017-04-15 00:00:00	500000.00	269
70	2017-05-13 00:00:00	500000.00	270
71	2017-04-24 00:00:00	500000.00	271
72	2017-04-11 00:00:00	500000.00	272
73	2017-05-11 00:00:00	500000.00	273
74	2017-05-04 00:00:00	500000.00	274
75	2017-05-02 00:00:00	500000.00	275
76	2017-05-03 00:00:00	500000.00	276
77	2017-05-09 00:00:00	500000.00	277
78	2017-04-05 00:00:00	500000.00	278
79	2017-05-03 00:00:00	500000.00	279
80	2017-04-25 00:00:00	500000.00	280
81	2017-05-11 00:00:00	500000.00	281
82	2017-04-24 00:00:00	500000.00	282
83	2017-04-25 00:00:00	500000.00	283
84	2017-04-25 00:00:00	500000.00	284
85	2017-05-10 00:00:00	500000.00	285
86	2017-05-04 00:00:00	500000.00	286
87	2017-04-05 00:00:00	500000.00	287
88	2017-04-24 00:00:00	500000.00	288
89	2017-05-09 00:00:00	500000.00	289
90	2017-04-20 00:00:00	500000.00	290
91	2017-04-20 00:00:00	500000.00	291
92	2017-04-24 00:00:00	500000.00	292
93	2017-04-18 00:00:00	500000.00	293
94	2017-05-13 00:00:00	500000.00	294
95	2017-04-25 00:00:00	500000.00	295
96	2017-05-13 00:00:00	500000.00	296
97	2017-04-24 00:00:00	500000.00	297
98	2017-05-10 00:00:00	500000.00	298
99	2017-04-24 00:00:00	500000.00	299
100	2017-04-10 00:00:00	500000.00	300
101	2017-04-20 00:00:00	500000.00	301
102	2017-04-15 00:00:00	500000.00	302
103	2017-04-30 00:00:00	500000.00	303
104	2017-04-18 00:00:00	500000.00	304
105	2017-05-04 00:00:00	500000.00	305
106	2017-05-15 00:00:00	500000.00	306
107	2017-05-08 00:00:00	500000.00	307
108	2017-04-24 00:00:00	500000.00	308
109	2017-04-13 00:00:00	500000.00	309
110	2017-05-12 00:00:00	500000.00	310
111	2017-05-04 00:00:00	500000.00	311
112	2017-05-08 00:00:00	500000.00	312
113	2017-04-20 00:00:00	500000.00	313
114	2017-05-01 00:00:00	500000.00	314
115	2017-04-29 00:00:00	500000.00	315
116	2017-04-15 00:00:00	500000.00	316
117	2017-04-09 00:00:00	500000.00	317
118	2017-04-04 00:00:00	500000.00	318
119	2017-05-05 00:00:00	500000.00	319
120	2017-04-30 00:00:00	500000.00	320
121	2017-04-24 00:00:00	500000.00	321
122	2017-04-23 00:00:00	500000.00	322
123	2017-05-09 00:00:00	500000.00	323
124	2017-05-04 00:00:00	500000.00	324
125	2017-05-14 00:00:00	500000.00	325
126	2017-04-15 00:00:00	500000.00	326
127	2017-04-01 00:00:00	500000.00	327
128	2017-04-21 00:00:00	500000.00	328
129	2017-04-25 00:00:00	500000.00	329
130	2017-05-15 00:00:00	500000.00	330
131	2017-04-22 00:00:00	500000.00	331
132	2017-04-20 00:00:00	500000.00	332
133	2017-04-15 00:00:00	500000.00	333
134	2017-04-05 00:00:00	500000.00	334
135	2017-05-04 00:00:00	500000.00	335
136	2017-04-08 00:00:00	500000.00	336
137	2017-05-05 00:00:00	500000.00	337
138	2017-05-14 00:00:00	500000.00	338
139	2017-04-30 00:00:00	500000.00	339
140	2017-05-02 00:00:00	500000.00	340
141	2017-04-10 00:00:00	500000.00	341
142	2017-04-25 00:00:00	500000.00	342
143	2017-04-12 00:00:00	500000.00	343
144	2017-04-05 00:00:00	500000.00	344
145	2017-04-28 00:00:00	500000.00	345
146	2017-05-13 00:00:00	500000.00	346
147	2017-05-15 00:00:00	500000.00	347
148	2017-04-30 00:00:00	500000.00	348
149	2017-04-04 00:00:00	500000.00	349
150	2017-05-04 00:00:00	500000.00	350
151	2017-04-25 00:00:00	500000.00	351
152	2017-04-15 00:00:00	500000.00	352
153	2017-04-18 00:00:00	500000.00	353
154	2017-05-04 00:00:00	500000.00	354
155	2017-04-04 00:00:00	500000.00	355
156	2017-05-04 00:00:00	500000.00	356
157	2017-05-11 00:00:00	500000.00	357
158	2017-04-30 00:00:00	500000.00	358
159	2017-04-14 00:00:00	500000.00	359
160	2017-04-05 00:00:00	500000.00	360
161	2017-04-20 00:00:00	500000.00	361
162	2017-04-05 00:00:00	500000.00	362
163	2017-04-19 00:00:00	500000.00	363
164	2017-04-29 00:00:00	500000.00	364
165	2017-04-23 00:00:00	500000.00	365
166	2017-05-09 00:00:00	500000.00	366
167	2017-04-25 00:00:00	500000.00	367
168	2017-04-25 00:00:00	500000.00	368
169	2017-05-11 00:00:00	500000.00	369
170	2017-05-02 00:00:00	500000.00	370
171	2017-04-19 00:00:00	500000.00	371
172	2017-05-03 00:00:00	500000.00	372
173	2017-04-05 00:00:00	500000.00	373
174	2017-05-05 00:00:00	500000.00	374
175	2017-05-09 00:00:00	500000.00	375
176	2017-04-15 00:00:00	500000.00	376
177	2017-04-24 00:00:00	500000.00	377
178	2017-04-09 00:00:00	500000.00	378
179	2017-05-11 00:00:00	500000.00	379
180	2017-05-09 00:00:00	500000.00	380
181	2017-04-30 00:00:00	500000.00	381
182	2017-04-20 00:00:00	500000.00	382
183	2017-04-09 00:00:00	500000.00	383
184	2017-04-02 00:00:00	500000.00	384
185	2017-05-12 00:00:00	500000.00	385
186	2017-04-05 00:00:00	500000.00	386
187	2017-05-01 00:00:00	500000.00	387
188	2017-04-29 00:00:00	500000.00	388
189	2017-04-15 00:00:00	500000.00	389
190	2017-04-09 00:00:00	500000.00	390
191	2017-04-09 00:00:00	500000.00	391
192	2017-04-11 00:00:00	500000.00	392
193	2017-05-10 00:00:00	500000.00	393
194	2017-04-04 00:00:00	500000.00	394
195	2017-05-14 00:00:00	500000.00	395
196	2017-04-04 00:00:00	500000.00	396
197	2017-05-08 00:00:00	500000.00	397
198	2017-05-15 00:00:00	500000.00	398
199	2017-04-12 00:00:00	500000.00	399
200	2017-04-12 00:00:00	500000.00	400
201	2017-04-19 00:00:00	500000.00	401
202	2017-04-01 00:00:00	500000.00	402
203	2017-04-04 00:00:00	500000.00	403
204	2017-04-29 00:00:00	500000.00	404
205	2017-04-22 00:00:00	500000.00	405
206	2017-05-04 00:00:00	500000.00	406
207	2017-05-02 00:00:00	500000.00	407
208	2017-04-03 00:00:00	500000.00	408
209	2017-04-14 00:00:00	500000.00	409
210	2017-05-04 00:00:00	500000.00	410
211	2017-04-11 00:00:00	500000.00	411
212	2017-04-03 00:00:00	500000.00	412
213	2017-05-09 00:00:00	500000.00	413
214	2017-04-05 00:00:00	500000.00	414
215	2017-04-23 00:00:00	500000.00	415
216	2017-05-02 00:00:00	500000.00	416
217	2017-04-13 00:00:00	500000.00	417
218	2017-05-10 00:00:00	500000.00	418
219	2017-04-01 00:00:00	500000.00	419
220	2017-04-24 00:00:00	500000.00	420
221	2017-05-03 00:00:00	500000.00	421
222	2017-04-19 00:00:00	500000.00	422
223	2017-04-28 00:00:00	500000.00	423
224	2017-05-10 00:00:00	500000.00	424
225	2017-04-01 00:00:00	500000.00	425
226	2017-04-23 00:00:00	500000.00	426
227	2017-04-22 00:00:00	500000.00	427
228	2017-04-24 00:00:00	500000.00	428
229	2017-04-05 00:00:00	500000.00	429
230	2017-04-12 00:00:00	500000.00	430
231	2017-04-22 00:00:00	500000.00	431
232	2017-05-14 00:00:00	500000.00	432
233	2017-05-09 00:00:00	500000.00	433
234	2017-04-14 00:00:00	500000.00	434
235	2017-05-04 00:00:00	500000.00	435
236	2017-04-11 00:00:00	500000.00	436
237	2017-04-05 00:00:00	500000.00	437
238	2017-04-05 00:00:00	500000.00	438
239	2017-04-28 00:00:00	500000.00	439
240	2017-05-05 00:00:00	500000.00	440
241	2017-04-03 00:00:00	500000.00	441
242	2017-04-05 00:00:00	500000.00	442
243	2017-05-15 00:00:00	500000.00	443
244	2017-04-22 00:00:00	500000.00	444
245	2017-05-05 00:00:00	500000.00	445
246	2017-04-01 00:00:00	500000.00	446
247	2017-04-03 00:00:00	500000.00	447
248	2017-04-18 00:00:00	500000.00	448
249	2017-05-09 00:00:00	500000.00	449
250	2017-04-04 00:00:00	500000.00	450
251	2017-04-15 00:00:00	500000.00	451
252	2017-04-24 00:00:00	500000.00	452
253	2017-05-02 00:00:00	500000.00	453
254	2017-04-04 00:00:00	500000.00	454
255	2017-04-05 00:00:00	500000.00	455
256	2017-05-03 00:00:00	500000.00	456
257	2017-04-24 00:00:00	500000.00	457
258	2017-04-19 00:00:00	500000.00	458
259	2017-05-05 00:00:00	500000.00	459
260	2017-05-02 00:00:00	500000.00	460
261	2017-05-12 00:00:00	500000.00	461
262	2017-04-14 00:00:00	500000.00	462
263	2017-04-18 00:00:00	500000.00	463
264	2017-05-05 00:00:00	500000.00	464
265	2017-04-21 00:00:00	500000.00	465
266	2017-05-12 00:00:00	500000.00	466
267	2017-04-28 00:00:00	500000.00	467
268	2017-04-15 00:00:00	500000.00	468
269	2017-05-03 00:00:00	500000.00	469
270	2017-04-29 00:00:00	500000.00	470
271	2017-05-03 00:00:00	500000.00	471
272	2017-04-23 00:00:00	500000.00	472
273	2017-05-03 00:00:00	500000.00	473
274	2017-04-24 00:00:00	500000.00	474
275	2017-04-12 00:00:00	500000.00	475
276	2017-05-05 00:00:00	500000.00	476
277	2017-05-01 00:00:00	500000.00	477
278	2017-04-03 00:00:00	500000.00	478
279	2017-04-18 00:00:00	500000.00	479
280	2017-05-15 00:00:00	500000.00	480
281	2017-05-13 00:00:00	500000.00	481
282	2017-05-11 00:00:00	500000.00	482
283	2017-05-10 00:00:00	500000.00	483
284	2017-04-25 00:00:00	500000.00	484
285	2017-05-10 00:00:00	500000.00	485
286	2017-05-13 00:00:00	500000.00	486
287	2017-04-20 00:00:00	500000.00	487
288	2017-04-18 00:00:00	500000.00	488
289	2017-05-04 00:00:00	500000.00	489
290	2017-05-11 00:00:00	500000.00	490
291	2017-04-29 00:00:00	500000.00	491
292	2017-05-05 00:00:00	500000.00	492
293	2017-04-05 00:00:00	500000.00	493
294	2017-05-08 00:00:00	500000.00	494
295	2017-05-05 00:00:00	500000.00	495
296	2017-05-03 00:00:00	500000.00	496
297	2017-05-02 00:00:00	500000.00	497
298	2017-05-04 00:00:00	500000.00	498
299	2017-04-14 00:00:00	500000.00	499
300	2017-05-15 00:00:00	500000.00	500
301	2017-05-09 00:00:00	500000.00	501
302	2017-04-20 00:00:00	500000.00	502
303	2017-04-13 00:00:00	500000.00	503
304	2017-04-21 00:00:00	500000.00	504
305	2017-05-14 00:00:00	500000.00	505
306	2017-04-04 00:00:00	500000.00	506
307	2017-04-30 00:00:00	500000.00	507
308	2017-04-14 00:00:00	500000.00	508
309	2017-04-12 00:00:00	500000.00	509
310	2017-04-03 00:00:00	500000.00	510
311	2017-04-25 00:00:00	500000.00	511
312	2017-05-05 00:00:00	500000.00	512
313	2017-04-09 00:00:00	500000.00	513
314	2017-05-15 00:00:00	500000.00	514
315	2017-04-23 00:00:00	500000.00	515
316	2017-04-04 00:00:00	500000.00	516
317	2017-05-11 00:00:00	500000.00	517
318	2017-04-04 00:00:00	500000.00	518
319	2017-05-02 00:00:00	500000.00	519
320	2017-04-24 00:00:00	500000.00	520
321	2017-04-23 00:00:00	500000.00	521
322	2017-04-21 00:00:00	500000.00	522
323	2017-05-13 00:00:00	500000.00	523
324	2017-04-24 00:00:00	500000.00	524
325	2017-05-13 00:00:00	500000.00	525
326	2017-04-30 00:00:00	500000.00	526
327	2017-04-21 00:00:00	500000.00	527
328	2017-05-12 00:00:00	500000.00	528
329	2017-04-03 00:00:00	500000.00	529
330	2017-04-09 00:00:00	500000.00	530
331	2017-05-11 00:00:00	500000.00	531
332	2017-04-10 00:00:00	500000.00	532
333	2017-04-09 00:00:00	500000.00	533
334	2017-05-12 00:00:00	500000.00	534
335	2017-04-15 00:00:00	500000.00	535
336	2017-04-01 00:00:00	500000.00	536
337	2017-04-20 00:00:00	500000.00	537
338	2017-04-30 00:00:00	500000.00	538
339	2017-05-15 00:00:00	500000.00	539
340	2017-05-02 00:00:00	500000.00	540
341	2017-04-28 00:00:00	500000.00	541
342	2017-04-29 00:00:00	500000.00	542
343	2017-04-15 00:00:00	500000.00	543
344	2017-04-02 00:00:00	500000.00	544
345	2017-05-05 00:00:00	500000.00	545
346	2017-05-04 00:00:00	500000.00	546
347	2017-04-11 00:00:00	500000.00	547
348	2017-05-05 00:00:00	500000.00	548
349	2017-04-18 00:00:00	500000.00	549
350	2017-05-04 00:00:00	500000.00	550
351	2017-04-03 00:00:00	500000.00	551
352	2017-05-09 00:00:00	500000.00	552
353	2017-04-25 00:00:00	500000.00	553
354	2017-04-30 00:00:00	500000.00	554
355	2017-05-09 00:00:00	500000.00	555
356	2017-05-10 00:00:00	500000.00	556
357	2017-05-11 00:00:00	500000.00	557
358	2017-05-09 00:00:00	500000.00	558
359	2017-04-05 00:00:00	500000.00	559
360	2017-04-15 00:00:00	500000.00	560
361	2017-04-04 00:00:00	500000.00	561
362	2017-04-13 00:00:00	500000.00	562
363	2017-05-04 00:00:00	500000.00	563
364	2017-04-03 00:00:00	500000.00	564
365	2017-04-18 00:00:00	500000.00	565
366	2017-04-09 00:00:00	500000.00	566
367	2017-04-08 00:00:00	500000.00	567
368	2017-05-09 00:00:00	500000.00	568
369	2017-04-12 00:00:00	500000.00	569
370	2017-05-09 00:00:00	500000.00	570
371	2017-05-04 00:00:00	500000.00	571
372	2017-04-24 00:00:00	500000.00	572
373	2017-04-12 00:00:00	500000.00	573
374	2017-04-24 00:00:00	500000.00	574
375	2017-04-20 00:00:00	500000.00	575
376	2017-05-14 00:00:00	500000.00	576
377	2017-05-03 00:00:00	500000.00	577
378	2017-04-24 00:00:00	500000.00	578
379	2017-04-24 00:00:00	500000.00	579
380	2017-04-24 00:00:00	500000.00	580
381	2017-04-23 00:00:00	500000.00	581
382	2017-05-13 00:00:00	500000.00	582
383	2017-05-04 00:00:00	500000.00	583
384	2017-05-15 00:00:00	500000.00	584
385	2017-04-05 00:00:00	500000.00	585
386	2017-04-08 00:00:00	500000.00	586
387	2017-05-04 00:00:00	500000.00	587
388	2017-04-24 00:00:00	500000.00	588
389	2017-04-05 00:00:00	500000.00	589
390	2017-04-28 00:00:00	500000.00	590
391	2017-04-25 00:00:00	500000.00	591
392	2017-04-28 00:00:00	500000.00	592
393	2017-04-25 00:00:00	500000.00	593
394	2017-04-13 00:00:00	500000.00	594
395	2017-05-12 00:00:00	500000.00	595
396	2017-04-19 00:00:00	500000.00	596
397	2017-04-13 00:00:00	500000.00	597
398	2017-04-12 00:00:00	500000.00	598
399	2017-04-30 00:00:00	500000.00	599
400	2017-04-11 00:00:00	500000.00	600
401	2017-04-15 00:00:00	500000.00	601
402	2017-04-28 00:00:00	500000.00	602
403	2017-05-13 00:00:00	500000.00	603
404	2017-05-04 00:00:00	500000.00	604
405	2017-05-09 00:00:00	500000.00	605
406	2017-05-04 00:00:00	500000.00	606
407	2017-05-13 00:00:00	500000.00	607
408	2017-04-22 00:00:00	500000.00	608
409	2017-05-01 00:00:00	500000.00	609
410	2017-05-04 00:00:00	500000.00	610
411	2017-04-24 00:00:00	500000.00	611
412	2017-05-12 00:00:00	500000.00	612
413	2017-04-15 00:00:00	500000.00	613
414	2017-05-05 00:00:00	500000.00	614
415	2017-04-28 00:00:00	500000.00	615
416	2017-04-09 00:00:00	500000.00	616
417	2017-04-22 00:00:00	500000.00	617
418	2017-05-11 00:00:00	500000.00	618
419	2017-05-03 00:00:00	500000.00	619
420	2017-04-15 00:00:00	500000.00	620
421	2017-04-24 00:00:00	500000.00	621
422	2017-04-28 00:00:00	500000.00	622
423	2017-05-02 00:00:00	500000.00	623
424	2017-04-08 00:00:00	500000.00	624
425	2017-04-09 00:00:00	500000.00	625
426	2017-05-01 00:00:00	500000.00	626
427	2017-04-04 00:00:00	500000.00	627
428	2017-04-22 00:00:00	500000.00	628
429	2017-05-10 00:00:00	500000.00	629
430	2017-05-04 00:00:00	500000.00	630
431	2017-05-13 00:00:00	500000.00	631
432	2017-04-22 00:00:00	500000.00	632
433	2017-04-12 00:00:00	500000.00	633
434	2017-04-13 00:00:00	500000.00	634
435	2017-05-14 00:00:00	500000.00	635
436	2017-04-01 00:00:00	500000.00	636
437	2017-04-25 00:00:00	500000.00	637
438	2017-04-01 00:00:00	500000.00	638
439	2017-05-09 00:00:00	500000.00	639
440	2017-04-15 00:00:00	500000.00	640
441	2017-04-24 00:00:00	500000.00	641
442	2017-04-30 00:00:00	500000.00	642
443	2017-05-15 00:00:00	500000.00	643
444	2017-04-14 00:00:00	500000.00	644
445	2017-04-15 00:00:00	500000.00	645
446	2017-05-11 00:00:00	500000.00	646
447	2017-04-19 00:00:00	500000.00	647
448	2017-04-21 00:00:00	500000.00	648
449	2017-05-05 00:00:00	500000.00	649
450	2017-04-18 00:00:00	500000.00	650
451	2017-04-11 00:00:00	500000.00	651
452	2017-05-05 00:00:00	500000.00	652
453	2017-05-04 00:00:00	500000.00	653
454	2017-05-10 00:00:00	500000.00	654
455	2017-04-12 00:00:00	500000.00	655
456	2017-05-13 00:00:00	500000.00	656
457	2017-04-21 00:00:00	500000.00	657
458	2017-04-29 00:00:00	500000.00	658
459	2017-05-01 00:00:00	500000.00	659
460	2017-04-22 00:00:00	500000.00	660
461	2017-04-03 00:00:00	500000.00	661
462	2017-05-11 00:00:00	500000.00	662
463	2017-05-05 00:00:00	500000.00	663
464	2017-05-15 00:00:00	500000.00	664
465	2017-05-05 00:00:00	500000.00	665
466	2017-04-24 00:00:00	500000.00	666
467	2017-04-20 00:00:00	500000.00	667
468	2017-04-20 00:00:00	500000.00	668
469	2017-04-02 00:00:00	500000.00	669
470	2017-05-10 00:00:00	500000.00	670
471	2017-04-15 00:00:00	500000.00	671
472	2017-04-25 00:00:00	500000.00	672
473	2017-04-23 00:00:00	500000.00	673
474	2017-04-23 00:00:00	500000.00	674
475	2017-04-13 00:00:00	500000.00	675
476	2017-04-09 00:00:00	500000.00	676
477	2017-05-11 00:00:00	500000.00	677
478	2017-05-04 00:00:00	500000.00	678
479	2017-05-02 00:00:00	500000.00	679
480	2017-04-03 00:00:00	500000.00	680
481	2017-04-25 00:00:00	500000.00	681
482	2017-04-23 00:00:00	500000.00	682
483	2017-04-09 00:00:00	500000.00	683
484	2017-05-04 00:00:00	500000.00	684
485	2017-05-11 00:00:00	500000.00	685
486	2017-05-12 00:00:00	500000.00	686
487	2017-04-18 00:00:00	500000.00	687
488	2017-05-15 00:00:00	500000.00	688
489	2017-04-25 00:00:00	500000.00	689
490	2017-04-22 00:00:00	500000.00	690
491	2017-04-03 00:00:00	500000.00	691
492	2017-04-02 00:00:00	500000.00	692
493	2017-05-11 00:00:00	500000.00	693
494	2017-04-10 00:00:00	500000.00	694
495	2017-04-13 00:00:00	500000.00	695
496	2017-04-22 00:00:00	500000.00	696
497	2017-04-09 00:00:00	500000.00	697
498	2017-04-23 00:00:00	500000.00	698
499	2017-04-03 00:00:00	500000.00	699
500	2017-04-25 00:00:00	500000.00	700
501	2017-04-03 00:00:00	500000.00	701
502	2017-04-15 00:00:00	500000.00	702
503	2017-04-20 00:00:00	500000.00	703
504	2017-04-01 00:00:00	500000.00	704
505	2017-04-24 00:00:00	500000.00	705
506	2017-04-19 00:00:00	500000.00	706
507	2017-05-04 00:00:00	500000.00	707
508	2017-05-09 00:00:00	500000.00	708
509	2017-04-11 00:00:00	500000.00	709
510	2017-05-01 00:00:00	500000.00	710
511	2017-05-03 00:00:00	500000.00	711
512	2017-05-10 00:00:00	500000.00	712
513	2017-04-20 00:00:00	500000.00	713
514	2017-05-12 00:00:00	500000.00	714
515	2017-05-04 00:00:00	500000.00	715
516	2017-04-23 00:00:00	500000.00	716
517	2017-05-02 00:00:00	500000.00	717
518	2017-05-15 00:00:00	500000.00	718
519	2017-05-05 00:00:00	500000.00	719
520	2017-05-02 00:00:00	500000.00	720
521	2017-05-15 00:00:00	500000.00	721
522	2017-05-08 00:00:00	500000.00	722
523	2017-05-02 00:00:00	500000.00	723
524	2017-04-21 00:00:00	500000.00	724
525	2017-04-09 00:00:00	500000.00	725
526	2017-04-05 00:00:00	500000.00	726
527	2017-04-21 00:00:00	500000.00	727
528	2017-04-24 00:00:00	500000.00	728
529	2017-04-04 00:00:00	500000.00	729
530	2017-04-22 00:00:00	500000.00	730
531	2017-04-14 00:00:00	500000.00	731
532	2017-04-10 00:00:00	500000.00	732
533	2017-04-05 00:00:00	500000.00	733
534	2017-05-09 00:00:00	500000.00	734
535	2017-04-29 00:00:00	500000.00	735
536	2017-04-25 00:00:00	500000.00	736
537	2017-05-05 00:00:00	500000.00	737
538	2017-05-04 00:00:00	500000.00	738
539	2017-05-05 00:00:00	500000.00	739
540	2017-05-15 00:00:00	500000.00	740
541	2017-04-25 00:00:00	500000.00	741
542	2017-04-25 00:00:00	500000.00	742
543	2017-04-29 00:00:00	500000.00	743
544	2017-04-19 00:00:00	500000.00	744
545	2017-04-19 00:00:00	500000.00	745
546	2017-04-08 00:00:00	500000.00	746
547	2017-04-02 00:00:00	500000.00	747
548	2017-05-12 00:00:00	500000.00	748
549	2017-04-05 00:00:00	500000.00	749
550	2017-05-03 00:00:00	500000.00	750
551	2017-05-05 00:00:00	500000.00	751
552	2017-05-01 00:00:00	500000.00	752
553	2017-04-03 00:00:00	500000.00	753
554	2017-04-30 00:00:00	500000.00	754
555	2017-04-14 00:00:00	500000.00	755
556	2017-04-05 00:00:00	500000.00	756
557	2017-04-21 00:00:00	500000.00	757
558	2017-04-20 00:00:00	500000.00	758
559	2017-04-13 00:00:00	500000.00	759
560	2017-04-14 00:00:00	500000.00	760
561	2017-05-03 00:00:00	500000.00	761
562	2017-05-05 00:00:00	500000.00	762
563	2017-05-14 00:00:00	500000.00	763
564	2017-04-28 00:00:00	500000.00	764
565	2017-05-01 00:00:00	500000.00	765
566	2017-05-03 00:00:00	500000.00	766
567	2017-04-25 00:00:00	500000.00	767
568	2017-04-22 00:00:00	500000.00	768
569	2017-04-22 00:00:00	500000.00	769
570	2017-04-05 00:00:00	500000.00	770
571	2017-04-19 00:00:00	500000.00	771
572	2017-05-02 00:00:00	500000.00	772
573	2017-05-04 00:00:00	500000.00	773
574	2017-04-04 00:00:00	500000.00	774
575	2017-04-28 00:00:00	500000.00	775
576	2017-05-05 00:00:00	500000.00	776
577	2017-04-15 00:00:00	500000.00	777
578	2017-04-02 00:00:00	500000.00	778
579	2017-05-13 00:00:00	500000.00	779
580	2017-04-15 00:00:00	500000.00	780
581	2017-04-15 00:00:00	500000.00	781
582	2017-04-20 00:00:00	500000.00	782
583	2017-04-08 00:00:00	500000.00	783
584	2017-05-05 00:00:00	500000.00	784
585	2017-04-05 00:00:00	500000.00	785
586	2017-05-08 00:00:00	500000.00	786
587	2017-04-10 00:00:00	500000.00	787
588	2017-05-01 00:00:00	500000.00	788
589	2017-05-05 00:00:00	500000.00	789
590	2017-04-03 00:00:00	500000.00	790
591	2017-04-28 00:00:00	500000.00	791
592	2017-05-12 00:00:00	500000.00	792
593	2017-04-20 00:00:00	500000.00	793
594	2017-05-01 00:00:00	500000.00	794
595	2017-05-08 00:00:00	500000.00	795
596	2017-05-05 00:00:00	500000.00	796
597	2017-05-04 00:00:00	500000.00	797
598	2017-04-11 00:00:00	500000.00	798
599	2017-04-09 00:00:00	500000.00	799
600	2017-05-02 00:00:00	500000.00	800
601	2017-04-24 00:00:00	500000.00	801
602	2017-04-11 00:00:00	500000.00	802
603	2017-04-28 00:00:00	500000.00	803
604	2017-05-05 00:00:00	500000.00	804
605	2017-05-08 00:00:00	500000.00	805
606	2017-05-03 00:00:00	500000.00	806
607	2017-05-01 00:00:00	500000.00	807
608	2017-05-05 00:00:00	500000.00	808
609	2017-04-24 00:00:00	500000.00	809
610	2017-04-19 00:00:00	500000.00	810
611	2017-04-04 00:00:00	500000.00	811
612	2017-04-20 00:00:00	500000.00	812
613	2017-04-19 00:00:00	500000.00	813
614	2017-05-10 00:00:00	500000.00	814
615	2017-05-08 00:00:00	500000.00	815
616	2017-05-05 00:00:00	500000.00	816
617	2017-04-08 00:00:00	500000.00	817
618	2017-05-14 00:00:00	500000.00	818
619	2017-04-08 00:00:00	500000.00	819
620	2017-04-04 00:00:00	500000.00	820
621	2017-05-01 00:00:00	500000.00	821
622	2017-04-15 00:00:00	500000.00	822
623	2017-04-15 00:00:00	500000.00	823
624	2017-04-15 00:00:00	500000.00	824
625	2017-04-22 00:00:00	500000.00	825
626	2017-05-13 00:00:00	500000.00	826
627	2017-04-04 00:00:00	500000.00	827
628	2017-04-05 00:00:00	500000.00	828
629	2017-04-04 00:00:00	500000.00	829
630	2017-05-14 00:00:00	500000.00	830
631	2017-04-04 00:00:00	500000.00	831
632	2017-04-13 00:00:00	500000.00	832
633	2017-04-12 00:00:00	500000.00	833
634	2017-05-05 00:00:00	500000.00	834
635	2017-04-14 00:00:00	500000.00	835
636	2017-04-05 00:00:00	500000.00	836
637	2017-04-01 00:00:00	500000.00	837
638	2017-05-01 00:00:00	500000.00	838
639	2017-04-15 00:00:00	500000.00	839
640	2017-04-22 00:00:00	500000.00	840
641	2017-05-15 00:00:00	500000.00	841
642	2017-04-25 00:00:00	500000.00	842
643	2017-04-15 00:00:00	500000.00	843
644	2017-04-13 00:00:00	500000.00	844
645	2017-05-04 00:00:00	500000.00	845
646	2017-05-05 00:00:00	500000.00	846
647	2017-05-05 00:00:00	500000.00	847
648	2017-04-14 00:00:00	500000.00	848
649	2017-05-14 00:00:00	500000.00	849
650	2017-04-23 00:00:00	500000.00	850
651	2017-04-01 00:00:00	500000.00	851
652	2017-05-02 00:00:00	500000.00	852
653	2017-05-05 00:00:00	500000.00	853
654	2017-04-15 00:00:00	500000.00	854
655	2017-04-19 00:00:00	500000.00	855
656	2017-05-02 00:00:00	500000.00	856
657	2017-04-02 00:00:00	500000.00	857
658	2017-05-15 00:00:00	500000.00	858
659	2017-05-04 00:00:00	500000.00	859
660	2017-04-22 00:00:00	500000.00	860
661	2017-04-24 00:00:00	500000.00	861
662	2017-04-08 00:00:00	500000.00	862
663	2017-05-04 00:00:00	500000.00	863
664	2017-04-13 00:00:00	500000.00	864
665	2017-04-01 00:00:00	500000.00	865
666	2017-05-05 00:00:00	500000.00	866
667	2017-04-21 00:00:00	500000.00	867
668	2017-04-19 00:00:00	500000.00	868
669	2017-04-29 00:00:00	500000.00	869
670	2017-04-05 00:00:00	500000.00	870
671	2017-05-10 00:00:00	500000.00	871
672	2017-04-23 00:00:00	500000.00	872
673	2017-04-28 00:00:00	500000.00	873
674	2017-04-20 00:00:00	500000.00	874
675	2017-04-04 00:00:00	500000.00	875
676	2017-05-13 00:00:00	500000.00	876
677	2017-04-05 00:00:00	500000.00	877
678	2017-04-02 00:00:00	500000.00	878
679	2017-04-01 00:00:00	500000.00	879
680	2017-05-01 00:00:00	500000.00	880
681	2017-04-12 00:00:00	500000.00	881
682	2017-04-22 00:00:00	500000.00	882
683	2017-04-02 00:00:00	500000.00	883
684	2017-04-09 00:00:00	500000.00	884
685	2017-04-19 00:00:00	500000.00	885
686	2017-05-05 00:00:00	500000.00	886
687	2017-04-14 00:00:00	500000.00	887
688	2017-04-02 00:00:00	500000.00	888
689	2017-05-15 00:00:00	500000.00	889
690	2017-04-04 00:00:00	500000.00	890
691	2017-05-05 00:00:00	500000.00	891
692	2017-04-01 00:00:00	500000.00	892
693	2017-05-09 00:00:00	500000.00	893
694	2017-04-04 00:00:00	500000.00	894
695	2017-04-23 00:00:00	500000.00	895
696	2017-04-12 00:00:00	500000.00	896
697	2017-04-11 00:00:00	500000.00	897
698	2017-04-01 00:00:00	500000.00	898
699	2017-04-21 00:00:00	500000.00	899
700	2017-05-04 00:00:00	500000.00	900
701	2017-04-25 00:00:00	500000.00	901
702	2017-04-02 00:00:00	500000.00	902
703	2017-04-15 00:00:00	500000.00	903
704	2017-05-05 00:00:00	500000.00	904
705	2017-05-09 00:00:00	500000.00	905
706	2017-04-04 00:00:00	500000.00	906
707	2017-04-14 00:00:00	500000.00	907
708	2017-04-05 00:00:00	500000.00	908
709	2017-05-13 00:00:00	500000.00	909
710	2017-04-14 00:00:00	500000.00	910
711	2017-05-05 00:00:00	500000.00	911
712	2017-04-12 00:00:00	500000.00	912
713	2017-04-10 00:00:00	500000.00	913
714	2017-04-15 00:00:00	500000.00	914
715	2017-04-02 00:00:00	500000.00	915
716	2017-04-10 00:00:00	500000.00	916
717	2017-04-10 00:00:00	500000.00	917
718	2017-04-02 00:00:00	500000.00	918
719	2017-04-03 00:00:00	500000.00	919
720	2017-04-22 00:00:00	500000.00	920
721	2017-04-20 00:00:00	500000.00	921
722	2017-04-05 00:00:00	500000.00	922
723	2017-04-10 00:00:00	500000.00	923
724	2017-04-08 00:00:00	500000.00	924
725	2017-04-30 00:00:00	500000.00	925
726	2017-04-11 00:00:00	500000.00	926
727	2017-04-30 00:00:00	500000.00	927
728	2017-04-14 00:00:00	500000.00	928
729	2017-04-12 00:00:00	500000.00	929
730	2017-04-24 00:00:00	500000.00	930
731	2017-05-14 00:00:00	500000.00	931
732	2017-04-15 00:00:00	500000.00	932
733	2017-04-05 00:00:00	500000.00	933
734	2017-05-04 00:00:00	500000.00	934
735	2017-05-02 00:00:00	500000.00	935
736	2017-04-10 00:00:00	500000.00	936
737	2017-05-13 00:00:00	500000.00	937
738	2017-04-02 00:00:00	500000.00	938
739	2017-04-11 00:00:00	500000.00	939
740	2017-05-04 00:00:00	500000.00	940
741	2017-05-02 00:00:00	500000.00	941
742	2017-04-14 00:00:00	500000.00	942
743	2017-05-03 00:00:00	500000.00	943
744	2017-04-14 00:00:00	500000.00	944
745	2017-04-11 00:00:00	500000.00	945
746	2017-04-01 00:00:00	500000.00	946
747	2017-04-09 00:00:00	500000.00	947
748	2017-04-04 00:00:00	500000.00	948
749	2017-04-23 00:00:00	500000.00	949
750	2017-04-03 00:00:00	500000.00	950
751	2017-05-10 00:00:00	500000.00	951
752	2017-04-28 00:00:00	500000.00	952
753	2017-04-20 00:00:00	500000.00	953
754	2017-05-04 00:00:00	500000.00	954
755	2017-05-03 00:00:00	500000.00	955
756	2017-04-04 00:00:00	500000.00	956
757	2017-04-24 00:00:00	500000.00	957
758	2017-04-05 00:00:00	500000.00	958
759	2017-04-15 00:00:00	500000.00	959
760	2017-04-05 00:00:00	500000.00	960
761	2017-05-04 00:00:00	500000.00	961
762	2017-04-24 00:00:00	500000.00	962
763	2017-04-15 00:00:00	500000.00	963
764	2017-04-22 00:00:00	500000.00	964
765	2017-04-21 00:00:00	500000.00	965
766	2017-04-10 00:00:00	500000.00	966
767	2017-05-10 00:00:00	500000.00	967
768	2017-05-11 00:00:00	500000.00	968
769	2017-05-02 00:00:00	500000.00	969
770	2017-04-30 00:00:00	500000.00	970
771	2017-04-25 00:00:00	500000.00	971
772	2017-05-02 00:00:00	500000.00	972
773	2017-04-24 00:00:00	500000.00	973
774	2017-04-01 00:00:00	500000.00	974
775	2017-05-14 00:00:00	500000.00	975
776	2017-05-01 00:00:00	500000.00	976
777	2017-04-24 00:00:00	500000.00	977
778	2017-04-25 00:00:00	500000.00	978
779	2017-04-28 00:00:00	500000.00	979
780	2017-04-12 00:00:00	500000.00	980
781	2017-04-10 00:00:00	500000.00	981
782	2017-04-13 00:00:00	500000.00	982
783	2017-05-10 00:00:00	500000.00	983
784	2017-04-01 00:00:00	500000.00	984
785	2017-05-04 00:00:00	500000.00	985
786	2017-05-04 00:00:00	500000.00	986
787	2017-04-10 00:00:00	500000.00	987
788	2017-04-15 00:00:00	500000.00	988
789	2017-05-08 00:00:00	500000.00	989
790	2017-04-21 00:00:00	500000.00	990
791	2017-04-10 00:00:00	500000.00	991
792	2017-04-25 00:00:00	500000.00	992
793	2017-04-14 00:00:00	500000.00	993
794	2017-04-13 00:00:00	500000.00	994
795	2017-05-03 00:00:00	500000.00	995
796	2017-05-05 00:00:00	500000.00	996
797	2017-04-03 00:00:00	500000.00	997
798	2017-04-02 00:00:00	500000.00	998
799	2017-05-14 00:00:00	500000.00	999
800	2017-04-29 00:00:00	500000.00	1000
801	2017-04-02 00:00:00	750000.00	1001
802	2017-05-04 00:00:00	750000.00	1002
803	2017-05-08 00:00:00	750000.00	1003
804	2017-04-18 00:00:00	750000.00	1004
805	2017-04-24 00:00:00	750000.00	1005
806	2017-04-19 00:00:00	750000.00	1006
807	2017-04-29 00:00:00	750000.00	1007
808	2017-04-14 00:00:00	750000.00	1008
809	2017-04-04 00:00:00	750000.00	1009
810	2017-05-04 00:00:00	750000.00	1010
811	2017-05-02 00:00:00	750000.00	1011
812	2017-04-15 00:00:00	750000.00	1012
813	2017-04-11 00:00:00	750000.00	1013
814	2017-05-05 00:00:00	750000.00	1014
815	2017-05-13 00:00:00	750000.00	1015
816	2017-05-08 00:00:00	750000.00	1016
817	2017-04-23 00:00:00	750000.00	1017
818	2017-05-04 00:00:00	750000.00	1018
819	2017-04-20 00:00:00	750000.00	1019
820	2017-04-29 00:00:00	750000.00	1020
821	2017-04-02 00:00:00	750000.00	1021
822	2017-04-11 00:00:00	750000.00	1022
823	2017-05-05 00:00:00	750000.00	1023
824	2017-05-08 00:00:00	750000.00	1024
825	2017-04-12 00:00:00	750000.00	1025
826	2017-04-15 00:00:00	750000.00	1026
827	2017-04-11 00:00:00	750000.00	1027
828	2017-04-22 00:00:00	750000.00	1028
829	2017-04-24 00:00:00	750000.00	1029
830	2017-04-19 00:00:00	750000.00	1030
831	2017-04-24 00:00:00	750000.00	1031
832	2017-05-08 00:00:00	750000.00	1032
833	2017-05-04 00:00:00	750000.00	1033
834	2017-04-18 00:00:00	750000.00	1034
835	2017-05-03 00:00:00	750000.00	1035
836	2017-04-12 00:00:00	750000.00	1036
837	2017-04-25 00:00:00	750000.00	1037
838	2017-04-04 00:00:00	750000.00	1038
839	2017-05-09 00:00:00	750000.00	1039
840	2017-04-24 00:00:00	750000.00	1040
841	2017-05-15 00:00:00	750000.00	1041
842	2017-04-02 00:00:00	750000.00	1042
843	2017-04-12 00:00:00	750000.00	1043
844	2017-04-20 00:00:00	750000.00	1044
845	2017-04-21 00:00:00	750000.00	1045
846	2017-04-09 00:00:00	750000.00	1046
847	2017-04-14 00:00:00	750000.00	1047
848	2017-05-02 00:00:00	750000.00	1048
849	2017-04-19 00:00:00	750000.00	1049
850	2017-05-08 00:00:00	750000.00	1050
851	2017-04-03 00:00:00	750000.00	1051
852	2017-04-22 00:00:00	750000.00	1052
853	2017-04-25 00:00:00	750000.00	1053
854	2017-04-22 00:00:00	750000.00	1054
855	2017-05-10 00:00:00	750000.00	1055
856	2017-04-24 00:00:00	750000.00	1056
857	2017-04-15 00:00:00	750000.00	1057
858	2017-05-11 00:00:00	750000.00	1058
859	2017-05-08 00:00:00	750000.00	1059
860	2017-04-05 00:00:00	750000.00	1060
861	2017-04-24 00:00:00	750000.00	1061
862	2017-04-05 00:00:00	750000.00	1062
863	2017-05-04 00:00:00	750000.00	1063
864	2017-05-13 00:00:00	750000.00	1064
865	2017-04-25 00:00:00	750000.00	1065
866	2017-05-11 00:00:00	750000.00	1066
867	2017-05-09 00:00:00	750000.00	1067
868	2017-05-03 00:00:00	750000.00	1068
869	2017-04-14 00:00:00	750000.00	1069
870	2017-04-03 00:00:00	750000.00	1070
871	2017-05-15 00:00:00	750000.00	1071
872	2017-04-09 00:00:00	750000.00	1072
873	2017-05-11 00:00:00	750000.00	1073
874	2017-05-04 00:00:00	750000.00	1074
875	2017-04-21 00:00:00	750000.00	1075
876	2017-04-04 00:00:00	750000.00	1076
877	2017-04-05 00:00:00	750000.00	1077
878	2017-05-03 00:00:00	750000.00	1078
879	2017-05-15 00:00:00	750000.00	1079
880	2017-04-28 00:00:00	750000.00	1080
881	2017-04-10 00:00:00	750000.00	1081
882	2017-04-25 00:00:00	750000.00	1082
883	2017-05-04 00:00:00	750000.00	1083
884	2017-05-08 00:00:00	750000.00	1084
885	2017-04-14 00:00:00	750000.00	1085
886	2017-04-25 00:00:00	750000.00	1086
887	2017-05-13 00:00:00	750000.00	1087
888	2017-05-13 00:00:00	750000.00	1088
889	2017-04-21 00:00:00	750000.00	1089
890	2017-05-10 00:00:00	750000.00	1090
891	2017-04-29 00:00:00	750000.00	1091
892	2017-05-11 00:00:00	750000.00	1092
893	2017-04-02 00:00:00	750000.00	1093
894	2017-04-24 00:00:00	750000.00	1094
895	2017-04-12 00:00:00	750000.00	1095
896	2017-04-24 00:00:00	750000.00	1096
897	2017-04-14 00:00:00	750000.00	1097
898	2017-04-15 00:00:00	750000.00	1098
899	2017-05-05 00:00:00	750000.00	1099
900	2017-05-04 00:00:00	750000.00	1100
901	2017-05-05 00:00:00	750000.00	1101
902	2017-05-01 00:00:00	750000.00	1102
903	2017-05-01 00:00:00	750000.00	1103
904	2017-04-15 00:00:00	750000.00	1104
905	2017-04-02 00:00:00	750000.00	1105
906	2017-05-01 00:00:00	750000.00	1106
907	2017-05-08 00:00:00	750000.00	1107
908	2017-05-05 00:00:00	750000.00	1108
909	2017-04-02 00:00:00	750000.00	1109
910	2017-04-12 00:00:00	750000.00	1110
911	2017-04-29 00:00:00	750000.00	1111
912	2017-05-11 00:00:00	750000.00	1112
913	2017-04-05 00:00:00	750000.00	1113
914	2017-05-15 00:00:00	750000.00	1114
915	2017-04-03 00:00:00	750000.00	1115
916	2017-04-13 00:00:00	750000.00	1116
917	2017-05-05 00:00:00	750000.00	1117
918	2017-04-25 00:00:00	750000.00	1118
919	2017-04-19 00:00:00	750000.00	1119
920	2017-04-05 00:00:00	750000.00	1120
921	2017-04-15 00:00:00	750000.00	1121
922	2017-04-19 00:00:00	750000.00	1122
923	2017-04-30 00:00:00	750000.00	1123
924	2017-04-25 00:00:00	750000.00	1124
925	2017-04-01 00:00:00	750000.00	1125
926	2017-05-05 00:00:00	750000.00	1126
927	2017-04-14 00:00:00	750000.00	1127
928	2017-04-14 00:00:00	750000.00	1128
929	2017-05-05 00:00:00	750000.00	1129
930	2017-04-23 00:00:00	750000.00	1130
931	2017-04-19 00:00:00	750000.00	1131
932	2017-04-20 00:00:00	750000.00	1132
933	2017-04-04 00:00:00	750000.00	1133
934	2017-04-09 00:00:00	750000.00	1134
935	2017-04-29 00:00:00	750000.00	1135
936	2017-04-20 00:00:00	750000.00	1136
937	2017-05-08 00:00:00	750000.00	1137
938	2017-04-25 00:00:00	750000.00	1138
939	2017-05-03 00:00:00	750000.00	1139
940	2017-05-11 00:00:00	750000.00	1140
941	2017-05-15 00:00:00	750000.00	1141
942	2017-05-05 00:00:00	750000.00	1142
943	2017-04-10 00:00:00	750000.00	1143
944	2017-04-24 00:00:00	750000.00	1144
945	2017-04-05 00:00:00	750000.00	1145
946	2017-04-04 00:00:00	750000.00	1146
947	2017-04-02 00:00:00	750000.00	1147
948	2017-04-13 00:00:00	750000.00	1148
949	2017-05-08 00:00:00	750000.00	1149
950	2017-04-05 00:00:00	750000.00	1150
951	2017-04-30 00:00:00	1000000.00	1151
952	2017-04-04 00:00:00	1000000.00	1152
953	2017-04-14 00:00:00	1000000.00	1153
954	2017-04-19 00:00:00	1000000.00	1154
955	2017-04-25 00:00:00	1000000.00	1155
956	2017-04-23 00:00:00	1000000.00	1156
957	2017-04-28 00:00:00	1000000.00	1157
958	2017-05-15 00:00:00	1000000.00	1158
959	2017-05-03 00:00:00	1000000.00	1159
960	2017-04-19 00:00:00	1000000.00	1160
961	2017-05-05 00:00:00	1000000.00	1161
962	2017-04-21 00:00:00	1000000.00	1162
963	2017-04-14 00:00:00	1000000.00	1163
964	2017-04-25 00:00:00	1000000.00	1164
965	2017-04-14 00:00:00	1000000.00	1165
966	2017-05-08 00:00:00	1000000.00	1166
967	2017-04-25 00:00:00	1000000.00	1167
968	2017-05-05 00:00:00	1000000.00	1168
969	2017-04-14 00:00:00	1000000.00	1169
970	2017-05-13 00:00:00	1000000.00	1170
971	2017-04-24 00:00:00	1000000.00	1171
972	2017-04-04 00:00:00	1000000.00	1172
973	2017-04-22 00:00:00	1000000.00	1173
974	2017-04-18 00:00:00	1000000.00	1174
975	2017-04-10 00:00:00	1000000.00	1175
976	2017-04-24 00:00:00	1000000.00	1176
977	2017-04-14 00:00:00	1000000.00	1177
978	2017-05-15 00:00:00	1000000.00	1178
979	2017-04-05 00:00:00	1000000.00	1179
980	2017-04-14 00:00:00	1000000.00	1180
981	2017-05-09 00:00:00	1000000.00	1181
982	2017-04-01 00:00:00	1000000.00	1182
983	2017-05-09 00:00:00	1000000.00	1183
984	2017-05-04 00:00:00	1000000.00	1184
985	2017-04-20 00:00:00	1000000.00	1185
986	2017-05-03 00:00:00	1000000.00	1186
987	2017-04-04 00:00:00	1000000.00	1187
988	2017-04-10 00:00:00	1000000.00	1188
989	2017-04-04 00:00:00	1000000.00	1189
990	2017-04-20 00:00:00	1000000.00	1190
991	2017-05-03 00:00:00	1000000.00	1191
992	2017-04-14 00:00:00	1000000.00	1192
993	2017-04-15 00:00:00	1000000.00	1193
994	2017-05-01 00:00:00	1000000.00	1194
995	2017-04-18 00:00:00	1000000.00	1195
996	2017-04-25 00:00:00	1000000.00	1196
997	2017-04-11 00:00:00	1000000.00	1197
998	2017-04-28 00:00:00	1000000.00	1198
999	2017-05-04 00:00:00	1000000.00	1199
1000	2017-05-13 00:00:00	1000000.00	1200
1001	2017-05-20 21:46:31.307135	500000.00	1201
\.


--
-- Name: pembayaran_id_seq; Type: SEQUENCE SET; Schema: sirima; Owner: arri.kurniawan
--

SELECT pg_catalog.setval('pembayaran_id_seq', 1, false);


--
-- Data for Name: pendaftaran; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pendaftaran (id, status_lulus, status_verifikasi, npm, pelamar, nomor_periode, tahun_periode) FROM stdin;
1	t	t	1608261321	john.ryan12	1	2016
2	t	t	1608261323	Mcdaniel.Lawrence96	1	2016
3	t	t	1608261325	Marsh.Jescie68	1	2016
4	t	t	1608261327	Durham.Zoe1	1	2016
5	t	t	1608261329	Prince.Shana61	1	2016
6	t	t	1608261331	Heath.Lisandra14	1	2016
7	t	t	1608261333	Schultz.Serina100	1	2016
8	t	t	1608261335	Aguirre.Minerva83	1	2016
9	t	t	1608261337	Pena.Cassidy6	1	2016
10	t	t	1608261339	Osborn.Eaton63	1	2016
11	t	t	1608261341	Mcdaniel.Pearl74	1	2016
12	t	t	1608261343	Lindsay.Leonard67	1	2016
13	t	t	1608261345	Lamb.Cyrus58	1	2016
14	t	t	1608261347	Barlow.Blake48	1	2016
15	t	t	1608261349	Hampton.Burton69	1	2016
16	t	t	1608261351	Knight.Nora65	1	2016
17	t	t	1608261353	Mclaughlin.Serina79	1	2016
18	t	t	1608261355	Graves.Jolene72	1	2016
19	t	t	1608261357	Hopkins.Lucian65	1	2016
20	t	t	1608261359	Valentine.Arsenio34	1	2016
21	t	t	1608261361	Herman.Cathleen70	1	2016
22	t	t	1608261363	Mathews.Kato5	1	2016
23	t	t	1608261365	Andrews.Leo13	1	2016
24	t	t	1608261367	Cote.Sonia87	1	2016
25	t	t	1608261369	Chandler.Grace42	1	2016
26	t	t	1608261371	Carter.Ebony43	1	2016
27	t	t	1608261373	Boone.Rhea42	1	2016
28	t	t	1608261375	Sloan.Kane71	1	2016
29	t	t	1608261377	Harvey.Hayes40	1	2016
30	t	t	1608261379	Wilkins.Knox48	1	2016
31	t	t	1608261381	Chan.Beck3	1	2016
32	t	t	1608261383	Hinton.Vivian14	1	2016
33	t	t	1608261385	Pennington.Hammett78	1	2016
34	t	t	1608261387	Reid.Imani99	1	2016
35	t	t	1608261389	Snyder.Jakeem77	1	2016
36	t	t	1608261391	Haynes.Isabella41	1	2016
37	t	t	1608261393	Randall.Remedios78	1	2016
38	t	t	1608261395	Snider.Phillip9	1	2016
39	t	t	1608261397	Brown.Simon42	1	2016
40	t	t	1608261399	Bryan.Maggy31	1	2016
41	t	t	1608261401	Hooper.Juliet59	1	2016
42	t	t	1608261403	Mckinney.Dacey28	1	2016
43	t	t	1608261405	Flynn.Heather100	1	2016
44	t	t	1608261407	Sheppard.Hiram65	1	2016
45	t	t	1608261409	Wilkins.Dillon80	1	2016
46	t	t	1608261411	Velez.Wyoming83	1	2016
47	t	t	1608261413	Mays.Quin98	1	2016
48	t	t	1608261415	Daniels.Nicholas77	1	2016
49	t	t	1608261417	Maynard.Jordan71	1	2016
50	t	t	1608261419	Lee.Phillip23	1	2016
51	t	t	1608261421	Aguirre.Xantha24	1	2016
52	t	t	1608261423	Oneill.Hollee91	1	2016
53	t	t	1608261425	Madden.Meghan98	1	2016
54	t	t	1608261427	Fischer.Samantha75	1	2016
55	t	t	1608261429	Lester.Xena97	1	2016
56	t	t	1608261431	Tanner.Lareina50	1	2016
57	t	t	1608261433	Blake.Angelica72	1	2016
58	t	t	1608261435	Conner.Patrick63	1	2016
59	t	t	1608261437	Garrison.Maile14	1	2016
60	t	t	1608261439	Kirby.Keane59	1	2016
61	t	t	1608261441	Cross.Perry87	1	2016
62	t	t	1608261443	Marks.Adam39	1	2016
63	t	t	1608261445	Burt.Duncan60	1	2016
64	t	t	1608261447	Matthews.Stella66	1	2016
65	f	t	1608261467	Luna.Imogene30	1	2016
66	f	t	1608261469	Morales.Candace97	1	2016
67	f	t	1608261471	Flowers.Gary39	1	2016
68	f	t	1608261473	Montoya.Lucius18	1	2016
69	f	t	1608261477	Hatfield.Miranda37	1	2016
70	f	t	1608261475	Padilla.Declan90	1	2016
71	f	t	          	Ramos.Amery55	1	2016
72	f	t	          	Farley.Latifah29	1	2016
73	f	t	          	Berry.Castor46	1	2016
74	t	t	1608261467	Schultz.Serina100	1	2016
75	t	t	1608261469	Aguirre.Minerva83	1	2016
76	t	t	1608261471	Pena.Cassidy6	1	2016
77	t	t	1608261473	Osborn.Eaton63	1	2016
78	t	t	1608261475	Mcdaniel.Pearl74	1	2016
79	t	t	1608261477	Lindsay.Leonard67	1	2016
80	f	f	          	Lamb.Cyrus58	1	2016
81	f	f	          	Barlow.Blake48	1	2016
82	f	f	          	Hampton.Burton69	1	2016
83	f	f	          	Knight.Nora65	1	2016
84	f	f	          	Mclaughlin.Serina79	1	2016
85	f	f	          	Graves.Jolene72	1	2016
86	f	f	          	Hopkins.Lucian65	1	2016
87	f	f	          	Valentine.Arsenio34	1	2016
88	f	f	          	Herman.Cathleen70	1	2016
89	f	f	          	Mathews.Kato5	1	2016
90	f	f	          	Andrews.Leo13	1	2016
91	f	f	          	Cote.Sonia87	1	2016
92	f	f	          	Chandler.Grace42	1	2016
93	f	f	          	Carter.Ebony43	1	2016
94	f	f	          	Boone.Rhea42	1	2016
95	f	f	          	Sloan.Kane71	1	2016
96	f	f	          	Harvey.Hayes40	1	2016
97	f	f	          	Wilkins.Knox48	1	2016
98	f	f	          	Chan.Beck3	1	2016
99	f	f	          	Hinton.Vivian14	1	2016
100	f	f	          	Pennington.Hammett78	1	2016
101	f	t	          	Reid.Imani99	1	2017
102	f	t	          	Snyder.Jakeem77	1	2017
103	f	t	          	Haynes.Isabella41	1	2017
104	f	t	          	Randall.Remedios78	1	2017
105	f	t	          	Snider.Phillip9	1	2017
106	f	t	          	Brown.Simon42	1	2017
107	f	t	          	Bryan.Maggy31	1	2017
108	f	t	          	Hooper.Juliet59	1	2017
109	f	t	          	Mckinney.Dacey28	1	2017
110	f	t	          	Flynn.Heather100	1	2017
111	f	t	          	Sheppard.Hiram65	1	2017
112	f	t	          	Wilkins.Dillon80	1	2017
113	f	t	          	Velez.Wyoming83	1	2017
114	f	t	          	Mays.Quin98	1	2017
115	f	t	          	Daniels.Nicholas77	1	2017
116	f	t	          	Maynard.Jordan71	1	2017
117	t	t	1708261553	Lee.Phillip23	1	2017
118	t	t	1708261555	Aguirre.Xantha24	1	2017
119	t	t	1708261557	Oneill.Hollee91	1	2017
120	t	t	1708261559	Madden.Meghan98	1	2017
121	t	t	1708261561	Fischer.Samantha75	1	2017
122	t	t	1708261563	Lester.Xena97	1	2017
123	t	t	1708261565	Tanner.Lareina50	1	2017
124	t	t	1708261567	Blake.Angelica72	1	2017
125	t	t	1708261569	Conner.Patrick63	1	2017
126	t	t	1708261571	Garrison.Maile14	1	2017
127	t	t	1708261573	Kirby.Keane59	1	2017
128	t	t	1708261575	Cross.Perry87	1	2017
129	t	t	1708261577	Marks.Adam39	1	2017
130	t	t	1708261579	Burt.Duncan60	1	2017
131	t	t	1708261581	Matthews.Stella66	1	2017
132	t	t	1708261583	Luna.Imogene30	1	2017
133	t	t	1708261585	Morales.Candace97	1	2017
134	t	t	1708261587	Flowers.Gary39	1	2017
135	t	t	1708261589	Montoya.Lucius18	1	2017
136	t	t	1708261591	Hatfield.Miranda37	1	2017
137	t	t	1708261593	Padilla.Declan90	1	2017
138	t	t	1708261595	Ramos.Amery55	1	2017
139	t	t	1708261597	Farley.Latifah29	1	2017
140	t	t	1708261599	Berry.Castor46	1	2017
141	t	t	1708261601	Barlow.Blake48	1	2017
142	t	t	1708261603	Hampton.Burton69	1	2017
143	t	t	1708261605	Knight.Nora65	1	2017
144	t	t	1708261607	Mclaughlin.Serina79	1	2017
145	t	t	1708261609	Graves.Jolene72	1	2017
146	t	t	1708261611	Hopkins.Lucian65	1	2017
147	t	t	1708261613	Valentine.Arsenio34	1	2017
148	t	t	1708261615	Herman.Cathleen70	1	2017
149	t	t	1708261617	Mathews.Kato5	1	2017
150	t	t	1708261619	Andrews.Leo13	1	2017
151	t	t	1708261621	Cote.Sonia87	1	2017
152	t	t	1708261623	Chandler.Grace42	1	2017
153	t	t	1708261625	Carter.Ebony43	1	2017
154	t	t	1708261627	Boone.Rhea42	1	2017
155	t	t	1708261629	Sloan.Kane71	1	2017
156	t	t	1708261631	Harvey.Hayes40	1	2017
157	t	t	1708261633	Wilkins.Knox48	1	2017
158	t	t	1708261635	Chan.Beck3	1	2017
159	t	t	1708261637	Hinton.Vivian14	1	2017
160	t	t	1708261639	Pennington.Hammett78	1	2017
161	t	t	1708261641	Reid.Imani99	1	2017
162	t	t	1708261643	Snyder.Jakeem77	1	2017
163	t	t	1708261645	Haynes.Isabella41	1	2017
164	t	t	1708261647	Randall.Remedios78	1	2017
165	t	t	1708261649	Snider.Phillip9	1	2017
166	t	t	1708261651	Brown.Simon42	1	2017
167	t	t	1708261653	Bryan.Maggy31	1	2017
168	t	t	1708261655	Hooper.Juliet59	1	2017
169	t	t	1708261657	Mckinney.Dacey28	1	2017
170	t	t	1708261659	Flynn.Heather100	1	2017
171	t	t	1708261661	Sheppard.Hiram65	1	2017
172	t	t	1708261663	Wilkins.Dillon80	1	2017
173	t	t	1708261665	Velez.Wyoming83	1	2017
174	t	t	1708261667	Mays.Quin98	1	2017
175	t	t	1708261669	Daniels.Nicholas77	1	2017
176	t	t	1708261671	Maynard.Jordan71	1	2017
177	f	t	          	Lee.Phillip23	1	2017
178	f	t	          	Aguirre.Xantha24	1	2017
179	f	t	          	Oneill.Hollee91	1	2017
180	f	f	          	Madden.Meghan98	1	2017
181	f	f	          	Fischer.Samantha75	1	2017
182	f	f	          	Lester.Xena97	1	2017
183	f	f	          	Tanner.Lareina50	1	2017
184	f	f	          	Blake.Angelica72	1	2017
185	f	f	          	Conner.Patrick63	1	2017
186	f	f	          	Garrison.Maile14	1	2017
187	f	f	          	Kirby.Keane59	1	2017
188	f	f	          	Cross.Perry87	1	2017
189	f	f	          	Marks.Adam39	1	2017
190	f	f	          	Burt.Duncan60	1	2017
191	f	f	          	Matthews.Stella66	1	2017
192	f	f	          	Luna.Imogene30	1	2017
193	f	f	          	Morales.Candace97	1	2017
194	f	f	          	Flowers.Gary39	1	2017
195	f	f	          	Montoya.Lucius18	1	2017
196	f	f	          	Hatfield.Miranda37	1	2017
197	f	f	          	Padilla.Declan90	1	2017
198	f	f	          	Ramos.Amery55	1	2017
199	f	f	          	Farley.Latifah29	1	2017
200	f	f	          	Berry.Castor46	1	2017
201	\N	t	\N	Schultz.Serina100	2	2017
202	\N	t	\N	Aguirre.Minerva83	2	2017
203	\N	t	\N	Pena.Cassidy6	2	2017
204	\N	t	\N	Osborn.Eaton63	2	2017
205	\N	t	\N	Mcdaniel.Pearl74	2	2017
206	\N	t	\N	Lindsay.Leonard67	2	2017
207	\N	t	\N	Lamb.Cyrus58	2	2017
208	\N	t	\N	Barlow.Blake48	2	2017
209	\N	t	\N	Hampton.Burton69	2	2017
210	\N	t	\N	Knight.Nora65	2	2017
211	\N	t	\N	Mclaughlin.Serina79	2	2017
212	\N	t	\N	Graves.Jolene72	2	2017
213	\N	t	\N	Hopkins.Lucian65	2	2017
214	\N	t	\N	Valentine.Arsenio34	2	2017
215	\N	t	\N	Herman.Cathleen70	2	2017
216	\N	t	\N	Mathews.Kato5	2	2017
217	\N	t	\N	Andrews.Leo13	2	2017
218	\N	t	\N	Cote.Sonia87	2	2017
219	\N	t	\N	Chandler.Grace42	2	2017
220	\N	t	\N	Carter.Ebony43	2	2017
221	\N	t	\N	Boone.Rhea42	2	2017
222	\N	t	\N	Sloan.Kane71	2	2017
223	\N	t	\N	Harvey.Hayes40	2	2017
224	\N	t	\N	Wilkins.Knox48	2	2017
225	\N	t	\N	Chan.Beck3	2	2017
226	\N	t	\N	Hinton.Vivian14	2	2017
227	\N	t	\N	Pennington.Hammett78	2	2017
228	\N	t	\N	Reid.Imani99	2	2017
229	\N	t	\N	Snyder.Jakeem77	2	2017
230	\N	t	\N	Haynes.Isabella41	2	2017
231	\N	t	\N	Randall.Remedios78	2	2017
232	\N	t	\N	Snider.Phillip9	2	2017
233	\N	t	\N	Brown.Simon42	2	2017
234	\N	t	\N	Bryan.Maggy31	2	2017
235	\N	t	\N	Hooper.Juliet59	2	2017
236	\N	t	\N	Mckinney.Dacey28	2	2017
237	\N	t	\N	Flynn.Heather100	2	2017
238	\N	t	\N	Sheppard.Hiram65	2	2017
239	\N	t	\N	Wilkins.Dillon80	2	2017
240	\N	t	\N	Velez.Wyoming83	2	2017
241	\N	t	\N	Mays.Quin98	2	2017
242	\N	t	\N	Daniels.Nicholas77	2	2017
243	\N	t	\N	Maynard.Jordan71	2	2017
244	\N	t	\N	Lee.Phillip23	2	2017
245	\N	t	\N	Aguirre.Xantha24	2	2017
246	\N	t	\N	Oneill.Hollee91	2	2017
247	\N	t	\N	Madden.Meghan98	2	2017
248	\N	t	\N	Fischer.Samantha75	2	2017
249	\N	t	\N	Lester.Xena97	2	2017
250	\N	t	\N	Tanner.Lareina50	2	2017
251	\N	t	\N	Blake.Angelica72	2	2017
252	\N	t	\N	Conner.Patrick63	2	2017
253	\N	t	\N	Garrison.Maile14	2	2017
254	\N	t	\N	Kirby.Keane59	2	2017
255	\N	t	\N	Cross.Perry87	2	2017
256	\N	t	\N	Marks.Adam39	2	2017
257	\N	t	\N	Burt.Duncan60	2	2017
258	\N	t	\N	Matthews.Stella66	2	2017
259	\N	t	\N	Luna.Imogene30	2	2017
260	\N	t	\N	Morales.Candace97	2	2017
261	\N	t	\N	Flowers.Gary39	2	2017
262	\N	t	\N	Montoya.Lucius18	2	2017
263	\N	t	\N	Hatfield.Miranda37	2	2017
264	\N	t	\N	Padilla.Declan90	2	2017
265	\N	t	\N	Ramos.Amery55	2	2017
266	\N	t	\N	Farley.Latifah29	2	2017
267	\N	t	\N	Berry.Castor46	2	2017
268	\N	t	\N	Workman.Harding82	2	2017
269	\N	t	\N	Weeks.Tanya9	2	2017
270	\N	t	\N	Ballard.Malcolm67	2	2017
271	\N	t	\N	Strickland.Charde28	2	2017
272	\N	t	\N	Carlson.Gemma63	2	2017
273	\N	t	\N	Chang.Ferdinand77	2	2017
274	\N	t	\N	Rasmussen.Lawrence20	2	2017
275	\N	t	\N	Livingston.Cassandra78	2	2017
276	\N	t	\N	Lawson.Nathaniel45	2	2017
277	\N	t	\N	Decker.Cameron45	2	2017
278	\N	t	\N	Velez.Candace35	2	2017
279	\N	t	\N	Brock.Amal86	2	2017
280	\N	t	\N	Hayes.Kim51	2	2017
281	\N	t	\N	Schwartz.Carolyn13	2	2017
282	\N	t	\N	Bell.Mary50	2	2017
283	\N	t	\N	Barnes.Ruth27	2	2017
284	\N	t	\N	Valenzuela.Sydnee91	2	2017
285	\N	t	\N	Sweeney.Mercedes15	2	2017
286	\N	t	\N	Rose.Andrew30	2	2017
287	\N	t	\N	Obrien.Iris93	2	2017
288	\N	t	\N	Albert.Kylan57	2	2017
289	\N	t	\N	Mcintyre.Veda6	2	2017
290	\N	t	\N	Mendez.Barry62	2	2017
291	\N	t	\N	Giles.Carissa92	2	2017
292	\N	t	\N	Hull.Armando46	2	2017
293	\N	t	\N	Griffith.Kristen63	2	2017
294	\N	t	\N	Walton.Thaddeus29	2	2017
295	\N	t	\N	Ortega.Gwendolyn97	2	2017
296	\N	t	\N	Lang.Ivana14	2	2017
297	\N	t	\N	Brady.Rina10	2	2017
298	\N	t	\N	Reed.Gregory100	2	2017
299	\N	t	\N	Roman.Camille22	2	2017
300	\N	t	\N	Mcintyre.Roth95	2	2017
301	\N	t	\N	Roy.Stewart30	2	2017
302	\N	t	\N	Hunter.Rhoda8	2	2017
303	\N	t	\N	Stanley.Cameran48	2	2017
304	\N	t	\N	Knox.Yoko92	2	2017
305	\N	t	\N	Allison.Phelan83	2	2017
306	\N	t	\N	Kent.Donna54	2	2017
307	\N	t	\N	Moody.Gray92	2	2017
308	\N	t	\N	Mendez.Avram60	2	2017
309	\N	t	\N	Stevens.Chase10	2	2017
310	\N	t	\N	Deleon.Ursa16	2	2017
311	\N	t	\N	Raymond.Gary62	2	2017
312	\N	t	\N	Cole.Kermit6	2	2017
313	\N	t	\N	Morin.Abdul17	2	2017
314	\N	t	\N	Durham.Marny28	2	2017
315	\N	t	\N	Henson.Benjamin34	2	2017
316	\N	t	\N	Bridges.Tucker7	2	2017
317	\N	t	\N	Mitchell.Xyla20	2	2017
318	\N	t	\N	Chan.Nomlanga48	2	2017
319	\N	t	\N	Nelson.Xena38	2	2017
320	\N	t	\N	Tillman.Rajah56	2	2017
321	\N	t	\N	Roth.Nolan16	2	2017
322	\N	t	\N	Rhodes.Lara22	2	2017
323	\N	t	\N	Keller.Minerva36	2	2017
324	\N	t	\N	Burke.Eugenia70	2	2017
325	\N	t	\N	Gilmore.Clinton33	2	2017
326	\N	t	\N	Turner.Amela17	2	2017
327	\N	t	\N	Levy.Cherokee62	2	2017
328	\N	t	\N	Yates.Olivia55	2	2017
329	\N	t	\N	Singleton.Brynne89	2	2017
330	\N	t	\N	Miles.Nicole92	2	2017
331	\N	t	\N	Petersen.Cairo68	2	2017
332	\N	t	\N	Mcfadden.Sharon10	2	2017
333	\N	t	\N	Atkins.Judah32	2	2017
334	\N	t	\N	Dunn.Montana12	2	2017
335	\N	t	\N	Daugherty.Fallon98	2	2017
336	\N	t	\N	Farmer.Dora53	2	2017
337	\N	t	\N	Moon.Emerald95	2	2017
338	\N	t	\N	Michael.Hiroko23	2	2017
339	\N	t	\N	Collins.Darius81	2	2017
340	\N	t	\N	Garrett.Zeph49	2	2017
341	\N	t	\N	Colon.Ursa10	2	2017
342	\N	t	\N	Estes.Jarrod4	2	2017
343	\N	t	\N	Hobbs.Karen39	2	2017
344	\N	t	\N	Jacobs.Callie84	2	2017
345	\N	t	\N	Jackson.Dahlia87	2	2017
346	\N	t	\N	Stevenson.Madaline67	2	2017
347	\N	t	\N	Kennedy.Alice96	2	2017
348	\N	t	\N	Jordan.Roanna91	2	2017
349	\N	t	\N	Lawson.Asher8	2	2017
350	\N	t	\N	Curry.Cailin95	2	2017
351	\N	t	\N	Booker.Imelda6	2	2017
352	\N	t	\N	Contreras.Kirsten46	2	2017
353	\N	t	\N	Burgess.Warren34	2	2017
354	\N	t	\N	Downs.Steel2	2	2017
355	\N	t	\N	Benjamin.Jessica87	2	2017
356	\N	t	\N	Harper.Jonas23	2	2017
357	\N	t	\N	Walls.Christopher5	2	2017
358	\N	t	\N	Skinner.Ruby31	2	2017
359	\N	t	\N	Graham.Phelan12	2	2017
360	\N	t	\N	Mckee.Emery64	2	2017
361	\N	t	\N	Cole.Lillith48	2	2017
362	\N	t	\N	Wagner.Hayden86	2	2017
363	\N	t	\N	Noel.Yuli88	2	2017
364	\N	t	\N	Jackson.Shelly76	2	2017
365	\N	t	\N	Gamble.Hoyt29	2	2017
366	\N	t	\N	Scott.Mira46	2	2017
367	\N	t	\N	Sykes.Eliana60	2	2017
368	\N	t	\N	Macias.Irene77	2	2017
369	\N	t	\N	Romero.Margaret4	2	2017
370	\N	t	\N	Newton.Logan47	2	2017
371	\N	t	\N	Dawson.Jasper77	2	2017
372	\N	t	\N	Bray.Mallory49	2	2017
373	\N	t	\N	Barron.Lewis19	2	2017
374	\N	t	\N	Carney.Tanya48	2	2017
375	\N	t	\N	Nolan.Lani42	2	2017
376	\N	t	\N	Hansen.Candace3	2	2017
377	\N	t	\N	Horn.Emery41	2	2017
378	\N	t	\N	Collier.Ashely24	2	2017
379	\N	t	\N	Barton.Michelle11	2	2017
380	\N	t	\N	Allen.James4	2	2017
381	\N	t	\N	Hoffman.Clark45	2	2017
382	\N	t	\N	Shields.Emi97	2	2017
383	\N	t	\N	Holden.Martena56	2	2017
384	\N	t	\N	Trevino.Remedios97	2	2017
385	\N	t	\N	Aguilar.Jeremy92	2	2017
386	\N	t	\N	Ortega.Abbot37	2	2017
387	\N	t	\N	Villarreal.Hyacinth58	2	2017
388	\N	t	\N	Gibson.Ferris81	2	2017
389	\N	t	\N	Castillo.Indigo58	2	2017
390	\N	t	\N	Schroeder.Kermit67	2	2017
391	\N	t	\N	Jacobson.Kelsie21	2	2017
392	\N	t	\N	Howard.Cooper71	2	2017
393	\N	t	\N	Burton.Wylie56	2	2017
394	\N	t	\N	Gaines.Drake14	2	2017
395	\N	t	\N	Carpenter.Ahmed11	2	2017
396	\N	t	\N	Richardson.Aquila57	2	2017
397	\N	t	\N	Mcdowell.Celeste67	2	2017
398	\N	t	\N	Lowery.Celeste58	2	2017
399	\N	t	\N	Petty.Ferdinand76	2	2017
400	\N	t	\N	Hernandez.Phyllis11	2	2017
401	\N	t	\N	Mcleod.Clinton15	2	2017
402	\N	t	\N	Hayes.Hyacinth38	2	2017
403	\N	t	\N	Mcknight.Kyle46	2	2017
404	\N	t	\N	Walsh.Tiger42	2	2017
405	\N	t	\N	Finch.Ross78	2	2017
406	\N	t	\N	Ingram.Leo88	2	2017
407	\N	t	\N	Hudson.Aileen4	2	2017
408	\N	t	\N	Mullins.Willa79	2	2017
409	\N	t	\N	Sweet.Quamar7	2	2017
410	\N	t	\N	Dejesus.Kyle72	2	2017
411	\N	t	\N	Whitehead.Maggie96	2	2017
412	\N	t	\N	Solomon.Jemima13	2	2017
413	\N	t	\N	Grimes.Marvin9	2	2017
414	\N	t	\N	Garner.Echo30	2	2017
415	\N	t	\N	Sellers.Mira68	2	2017
416	\N	t	\N	Nichols.Colton17	2	2017
417	\N	t	\N	Blanchard.Felix40	2	2017
418	\N	t	\N	Powell.Quintessa88	2	2017
419	\N	t	\N	Guthrie.Bernard47	2	2017
420	\N	t	\N	Hart.Calista7	2	2017
421	\N	t	\N	Swanson.Oliver20	2	2017
422	\N	t	\N	Myers.Duncan11	2	2017
423	\N	t	\N	Boone.Jamal86	2	2017
424	\N	t	\N	Wynn.Lionel64	2	2017
425	\N	t	\N	Dickerson.Natalie18	2	2017
426	\N	t	\N	Martin.Channing22	2	2017
427	\N	t	\N	Miller.Zephania48	2	2017
428	\N	t	\N	Leon.Evangeline61	2	2017
429	\N	t	\N	Bridges.Serena88	2	2017
430	\N	t	\N	Cross.Kimberley4	2	2017
431	\N	t	\N	Andrews.Jenna22	2	2017
432	\N	t	\N	Snider.Nehru79	2	2017
433	\N	t	\N	Roth.Kyle3	2	2017
434	\N	t	\N	Rodgers.Moses15	2	2017
435	\N	t	\N	Christian.Rhona26	2	2017
436	\N	t	\N	Perry.Tara71	2	2017
437	\N	t	\N	Atkins.Yvette30	2	2017
438	\N	t	\N	Estes.Gemma55	2	2017
439	\N	t	\N	Fernandez.Chaim55	2	2017
440	\N	t	\N	Castaneda.Riley8	2	2017
441	\N	t	\N	Day.Felicia2	2	2017
442	\N	t	\N	Collins.Holly20	2	2017
443	\N	t	\N	Frye.Maggie98	2	2017
444	\N	t	\N	Osborne.Georgia12	2	2017
445	\N	t	\N	Harper.Lance100	2	2017
446	\N	t	\N	Bowman.Naomi94	2	2017
447	\N	t	\N	Pittman.Lydia91	2	2017
448	\N	t	\N	Franco.Keegan61	2	2017
449	\N	t	\N	Crosby.Julian52	2	2017
450	\N	t	\N	Pratt.Regina12	2	2017
451	\N	t	\N	Alston.Dominic65	2	2017
452	\N	t	\N	Madden.Duncan12	2	2017
453	\N	t	\N	Head.Isaiah78	2	2017
454	\N	t	\N	Hayden.Gretchen22	2	2017
455	\N	t	\N	Phillips.Germaine2	2	2017
456	\N	t	\N	Palmer.Clare90	2	2017
457	\N	t	\N	Dunlap.Graiden85	2	2017
458	\N	t	\N	Miller.Mannix38	2	2017
459	\N	t	\N	Bass.Maite38	2	2017
460	\N	t	\N	Alvarez.Lael34	2	2017
461	\N	t	\N	Lucas.Burton24	2	2017
462	\N	t	\N	Cash.Sierra87	2	2017
463	\N	t	\N	Greene.Maggie23	2	2017
464	\N	t	\N	Miranda.Elijah5	2	2017
465	\N	t	\N	Estrada.Ulysses96	2	2017
466	\N	t	\N	Stafford.Maris17	2	2017
467	\N	t	\N	Guy.Brenna41	2	2017
468	\N	t	\N	Fischer.Kato95	2	2017
469	\N	t	\N	Moody.Wesley2	2	2017
470	\N	t	\N	Lynch.Kimberley27	2	2017
471	\N	t	\N	Riddle.Julie74	2	2017
472	\N	t	\N	Hancock.Alfreda49	2	2017
473	\N	t	\N	Pace.Victoria83	2	2017
474	\N	t	\N	Conley.Sylvia58	2	2017
475	\N	t	\N	Dyer.Kiayada19	2	2017
476	\N	t	\N	Huffman.Ferdinand12	2	2017
477	\N	t	\N	Larsen.Macaulay53	2	2017
478	\N	t	\N	Boyd.Rhea4	2	2017
479	\N	t	\N	Fowler.Iris54	2	2017
480	\N	t	\N	Morton.Galvin95	2	2017
481	\N	t	\N	Hunter.Sybil43	2	2017
482	\N	t	\N	Larsen.Brady45	2	2017
483	\N	t	\N	Harding.Fritz24	2	2017
484	\N	t	\N	Mercado.Aimee93	2	2017
485	\N	t	\N	Kemp.Sydney66	2	2017
486	\N	t	\N	Boyle.Inga72	2	2017
487	\N	t	\N	Stevenson.Ulla58	2	2017
488	\N	t	\N	Higgins.Alec20	2	2017
489	\N	t	\N	Lawson.Ashton51	2	2017
490	\N	t	\N	Figueroa.Orla61	2	2017
491	\N	t	\N	Pace.Madison82	2	2017
492	\N	t	\N	Mclaughlin.Nadine93	2	2017
493	\N	t	\N	Hardy.Leslie67	2	2017
494	\N	t	\N	Key.Simone25	2	2017
495	\N	t	\N	Barlow.Blake48	2	2017
496	\N	t	\N	Hampton.Burton69	2	2017
497	\N	t	\N	Knight.Nora65	2	2017
498	\N	t	\N	Mclaughlin.Serina79	2	2017
499	\N	t	\N	Graves.Jolene72	2	2017
500	\N	t	\N	Hopkins.Lucian65	2	2017
501	\N	t	\N	Valentine.Arsenio34	2	2017
502	\N	t	\N	Herman.Cathleen70	2	2017
503	\N	t	\N	Mathews.Kato5	2	2017
504	\N	t	\N	Andrews.Leo13	2	2017
505	\N	t	\N	Cote.Sonia87	2	2017
506	\N	t	\N	Chandler.Grace42	2	2017
507	\N	t	\N	Carter.Ebony43	2	2017
508	\N	t	\N	Boone.Rhea42	2	2017
509	\N	t	\N	Sloan.Kane71	2	2017
510	\N	t	\N	Harvey.Hayes40	2	2017
511	\N	t	\N	Wilkins.Knox48	2	2017
512	\N	t	\N	Chan.Beck3	2	2017
513	\N	t	\N	Hinton.Vivian14	2	2017
514	\N	t	\N	Pennington.Hammett78	2	2017
515	\N	t	\N	Reid.Imani99	2	2017
516	\N	t	\N	Snyder.Jakeem77	2	2017
517	\N	t	\N	Haynes.Isabella41	2	2017
518	\N	t	\N	Randall.Remedios78	2	2017
519	\N	t	\N	Snider.Phillip9	2	2017
520	\N	t	\N	Brown.Simon42	2	2017
521	\N	t	\N	Bryan.Maggy31	2	2017
522	\N	t	\N	Hooper.Juliet59	2	2017
523	\N	t	\N	Mckinney.Dacey28	2	2017
524	\N	t	\N	Flynn.Heather100	2	2017
525	\N	t	\N	Sheppard.Hiram65	2	2017
526	\N	t	\N	Wilkins.Dillon80	2	2017
527	\N	t	\N	Velez.Wyoming83	2	2017
528	\N	t	\N	Mays.Quin98	2	2017
529	\N	t	\N	Daniels.Nicholas77	2	2017
530	\N	t	\N	Maynard.Jordan71	2	2017
531	\N	t	\N	Lee.Phillip23	2	2017
532	\N	t	\N	Aguirre.Xantha24	2	2017
533	\N	t	\N	Oneill.Hollee91	2	2017
534	\N	t	\N	Madden.Meghan98	2	2017
535	\N	t	\N	Fischer.Samantha75	2	2017
536	\N	t	\N	Lester.Xena97	2	2017
537	\N	t	\N	Tanner.Lareina50	2	2017
538	\N	t	\N	Blake.Angelica72	2	2017
539	\N	t	\N	Conner.Patrick63	2	2017
540	\N	t	\N	Garrison.Maile14	2	2017
541	\N	t	\N	Kirby.Keane59	2	2017
542	\N	t	\N	Cross.Perry87	2	2017
543	\N	t	\N	Marks.Adam39	2	2017
544	\N	t	\N	Burt.Duncan60	2	2017
545	\N	t	\N	Matthews.Stella66	2	2017
546	\N	t	\N	Luna.Imogene30	2	2017
547	\N	t	\N	Morales.Candace97	2	2017
548	\N	t	\N	Flowers.Gary39	2	2017
549	\N	t	\N	Montoya.Lucius18	2	2017
550	\N	t	\N	Hatfield.Miranda37	2	2017
551	\N	t	\N	Padilla.Declan90	2	2017
552	\N	t	\N	Ramos.Amery55	2	2017
553	\N	t	\N	Farley.Latifah29	2	2017
554	\N	t	\N	Berry.Castor46	2	2017
555	\N	t	\N	Workman.Harding82	2	2017
556	\N	t	\N	Weeks.Tanya9	2	2017
557	\N	t	\N	Ballard.Malcolm67	2	2017
558	\N	t	\N	Strickland.Charde28	2	2017
559	\N	t	\N	Carlson.Gemma63	2	2017
560	\N	t	\N	Chang.Ferdinand77	2	2017
561	\N	t	\N	Rasmussen.Lawrence20	2	2017
562	\N	t	\N	Livingston.Cassandra78	2	2017
563	\N	t	\N	Lawson.Nathaniel45	2	2017
564	\N	t	\N	Decker.Cameron45	2	2017
565	\N	t	\N	Velez.Candace35	2	2017
566	\N	t	\N	Brock.Amal86	2	2017
567	\N	t	\N	Hayes.Kim51	2	2017
568	\N	t	\N	Schwartz.Carolyn13	2	2017
569	\N	t	\N	Bell.Mary50	2	2017
570	\N	t	\N	Barnes.Ruth27	2	2017
571	\N	t	\N	Valenzuela.Sydnee91	2	2017
572	\N	t	\N	Sweeney.Mercedes15	2	2017
573	\N	t	\N	Rose.Andrew30	2	2017
574	\N	t	\N	Obrien.Iris93	2	2017
575	\N	t	\N	Albert.Kylan57	2	2017
576	\N	t	\N	Mcintyre.Veda6	2	2017
577	\N	t	\N	Mendez.Barry62	2	2017
578	\N	t	\N	Giles.Carissa92	2	2017
579	\N	t	\N	Hull.Armando46	2	2017
580	\N	t	\N	Griffith.Kristen63	2	2017
581	\N	t	\N	Walton.Thaddeus29	2	2017
582	\N	t	\N	Ortega.Gwendolyn97	2	2017
583	\N	t	\N	Lang.Ivana14	2	2017
584	\N	t	\N	Brady.Rina10	2	2017
585	\N	t	\N	Reed.Gregory100	2	2017
586	\N	t	\N	Roman.Camille22	2	2017
587	\N	t	\N	Mcintyre.Roth95	2	2017
588	\N	t	\N	Roy.Stewart30	2	2017
589	\N	t	\N	Hunter.Rhoda8	2	2017
590	\N	t	\N	Stanley.Cameran48	2	2017
591	\N	t	\N	Knox.Yoko92	2	2017
592	\N	t	\N	Allison.Phelan83	2	2017
593	\N	t	\N	Kent.Donna54	2	2017
594	\N	t	\N	Moody.Gray92	2	2017
595	\N	t	\N	Mendez.Avram60	2	2017
596	\N	t	\N	Stevens.Chase10	2	2017
597	\N	t	\N	Deleon.Ursa16	2	2017
598	\N	t	\N	Raymond.Gary62	2	2017
599	\N	t	\N	Cole.Kermit6	2	2017
600	\N	t	\N	Morin.Abdul17	2	2017
601	\N	t	\N	Durham.Marny28	2	2017
602	\N	t	\N	Henson.Benjamin34	2	2017
603	\N	t	\N	Bridges.Tucker7	2	2017
604	\N	t	\N	Mitchell.Xyla20	2	2017
605	\N	t	\N	Chan.Nomlanga48	2	2017
606	\N	t	\N	Nelson.Xena38	2	2017
607	\N	t	\N	Tillman.Rajah56	2	2017
608	\N	t	\N	Roth.Nolan16	2	2017
609	\N	t	\N	Rhodes.Lara22	2	2017
610	\N	t	\N	Keller.Minerva36	2	2017
611	\N	t	\N	Burke.Eugenia70	2	2017
612	\N	t	\N	Gilmore.Clinton33	2	2017
613	\N	t	\N	Turner.Amela17	2	2017
614	\N	t	\N	Levy.Cherokee62	2	2017
615	\N	t	\N	Yates.Olivia55	2	2017
616	\N	t	\N	Singleton.Brynne89	2	2017
617	\N	t	\N	Miles.Nicole92	2	2017
618	\N	t	\N	Petersen.Cairo68	2	2017
619	\N	t	\N	Mcfadden.Sharon10	2	2017
620	\N	t	\N	Atkins.Judah32	2	2017
621	\N	t	\N	Dunn.Montana12	2	2017
622	\N	t	\N	Daugherty.Fallon98	2	2017
623	\N	t	\N	Farmer.Dora53	2	2017
624	\N	t	\N	Moon.Emerald95	2	2017
625	\N	t	\N	Michael.Hiroko23	2	2017
626	\N	t	\N	Collins.Darius81	2	2017
627	\N	t	\N	Garrett.Zeph49	2	2017
628	\N	t	\N	Colon.Ursa10	2	2017
629	\N	t	\N	Estes.Jarrod4	2	2017
630	\N	t	\N	Hobbs.Karen39	2	2017
631	\N	t	\N	Jacobs.Callie84	2	2017
632	\N	t	\N	Jackson.Dahlia87	2	2017
633	\N	t	\N	Stevenson.Madaline67	2	2017
634	\N	t	\N	Kennedy.Alice96	2	2017
635	\N	t	\N	Jordan.Roanna91	2	2017
636	\N	t	\N	Lawson.Asher8	2	2017
637	\N	t	\N	Curry.Cailin95	2	2017
638	\N	t	\N	Booker.Imelda6	2	2017
639	\N	t	\N	Contreras.Kirsten46	2	2017
640	\N	t	\N	Burgess.Warren34	2	2017
641	\N	t	\N	Downs.Steel2	2	2017
642	\N	t	\N	Benjamin.Jessica87	2	2017
643	\N	t	\N	Harper.Jonas23	2	2017
644	\N	t	\N	Walls.Christopher5	2	2017
645	\N	t	\N	Skinner.Ruby31	2	2017
646	\N	t	\N	Graham.Phelan12	2	2017
647	\N	t	\N	Mckee.Emery64	2	2017
648	\N	t	\N	Cole.Lillith48	2	2017
649	\N	t	\N	Wagner.Hayden86	2	2017
650	\N	t	\N	Noel.Yuli88	2	2017
651	\N	t	\N	Jackson.Shelly76	2	2017
652	\N	t	\N	Gamble.Hoyt29	2	2017
653	\N	t	\N	Scott.Mira46	2	2017
654	\N	t	\N	Sykes.Eliana60	2	2017
655	\N	t	\N	Macias.Irene77	2	2017
656	\N	t	\N	Romero.Margaret4	2	2017
657	\N	t	\N	Newton.Logan47	2	2017
658	\N	t	\N	Dawson.Jasper77	2	2017
659	\N	t	\N	Bray.Mallory49	2	2017
660	\N	t	\N	Barron.Lewis19	2	2017
661	\N	t	\N	Carney.Tanya48	2	2017
662	\N	t	\N	Nolan.Lani42	2	2017
663	\N	t	\N	Hansen.Candace3	2	2017
664	\N	t	\N	Horn.Emery41	2	2017
665	\N	t	\N	Collier.Ashely24	2	2017
666	\N	t	\N	Barton.Michelle11	2	2017
667	\N	t	\N	Allen.James4	2	2017
668	\N	t	\N	Hoffman.Clark45	2	2017
669	\N	t	\N	Shields.Emi97	2	2017
670	\N	t	\N	Holden.Martena56	2	2017
671	\N	t	\N	Trevino.Remedios97	2	2017
672	\N	t	\N	Aguilar.Jeremy92	2	2017
673	\N	t	\N	Ortega.Abbot37	2	2017
674	\N	t	\N	Villarreal.Hyacinth58	2	2017
675	\N	t	\N	Gibson.Ferris81	2	2017
676	\N	t	\N	Castillo.Indigo58	2	2017
677	\N	t	\N	Schroeder.Kermit67	2	2017
678	\N	t	\N	Jacobson.Kelsie21	2	2017
679	\N	t	\N	Howard.Cooper71	2	2017
680	\N	t	\N	Burton.Wylie56	2	2017
681	\N	t	\N	Gaines.Drake14	2	2017
682	\N	t	\N	Carpenter.Ahmed11	2	2017
683	\N	t	\N	Richardson.Aquila57	2	2017
684	\N	t	\N	Mcdowell.Celeste67	2	2017
685	\N	t	\N	Lowery.Celeste58	2	2017
686	\N	t	\N	Petty.Ferdinand76	2	2017
687	\N	t	\N	Hernandez.Phyllis11	2	2017
688	\N	t	\N	Mcleod.Clinton15	2	2017
689	\N	t	\N	Hayes.Hyacinth38	2	2017
690	\N	t	\N	Mcknight.Kyle46	2	2017
691	\N	t	\N	Walsh.Tiger42	2	2017
692	\N	t	\N	Finch.Ross78	2	2017
693	\N	t	\N	Ingram.Leo88	2	2017
694	\N	t	\N	Hudson.Aileen4	2	2017
695	\N	t	\N	Mullins.Willa79	2	2017
696	\N	t	\N	Sweet.Quamar7	2	2017
697	\N	t	\N	Dejesus.Kyle72	2	2017
698	\N	t	\N	Whitehead.Maggie96	2	2017
699	\N	t	\N	Solomon.Jemima13	2	2017
700	\N	t	\N	Grimes.Marvin9	2	2017
701	\N	t	\N	Garner.Echo30	2	2017
702	\N	t	\N	Sellers.Mira68	2	2017
703	\N	t	\N	Nichols.Colton17	2	2017
704	\N	t	\N	Blanchard.Felix40	2	2017
705	\N	t	\N	Powell.Quintessa88	2	2017
706	\N	t	\N	Guthrie.Bernard47	2	2017
707	\N	t	\N	Hart.Calista7	2	2017
708	\N	t	\N	Swanson.Oliver20	2	2017
709	\N	t	\N	Myers.Duncan11	2	2017
710	\N	t	\N	Boone.Jamal86	2	2017
711	\N	t	\N	Wynn.Lionel64	2	2017
712	\N	t	\N	Dickerson.Natalie18	2	2017
713	\N	t	\N	Martin.Channing22	2	2017
714	\N	t	\N	Miller.Zephania48	2	2017
715	\N	t	\N	Leon.Evangeline61	2	2017
716	\N	t	\N	Bridges.Serena88	2	2017
717	\N	t	\N	Cross.Kimberley4	2	2017
718	\N	t	\N	Andrews.Jenna22	2	2017
719	\N	t	\N	Snider.Nehru79	2	2017
720	\N	t	\N	Roth.Kyle3	2	2017
721	\N	t	\N	Rodgers.Moses15	2	2017
722	\N	t	\N	Christian.Rhona26	2	2017
723	\N	t	\N	Perry.Tara71	2	2017
724	\N	t	\N	Atkins.Yvette30	2	2017
725	\N	t	\N	Estes.Gemma55	2	2017
726	\N	t	\N	Fernandez.Chaim55	2	2017
727	\N	t	\N	Castaneda.Riley8	2	2017
728	\N	t	\N	Day.Felicia2	2	2017
729	\N	t	\N	Collins.Holly20	2	2017
730	\N	t	\N	Frye.Maggie98	2	2017
731	\N	t	\N	Osborne.Georgia12	2	2017
732	\N	t	\N	Harper.Lance100	2	2017
733	\N	t	\N	Bowman.Naomi94	2	2017
734	\N	t	\N	Pittman.Lydia91	2	2017
735	\N	t	\N	Franco.Keegan61	2	2017
736	\N	t	\N	Crosby.Julian52	2	2017
737	\N	t	\N	Pratt.Regina12	2	2017
738	\N	t	\N	Alston.Dominic65	2	2017
739	\N	t	\N	Madden.Duncan12	2	2017
740	\N	t	\N	Head.Isaiah78	2	2017
741	\N	t	\N	Hayden.Gretchen22	2	2017
742	\N	t	\N	Phillips.Germaine2	2	2017
743	\N	t	\N	Palmer.Clare90	2	2017
744	\N	t	\N	Dunlap.Graiden85	2	2017
745	\N	t	\N	Miller.Mannix38	2	2017
746	\N	t	\N	Bass.Maite38	2	2017
747	\N	t	\N	Alvarez.Lael34	2	2017
748	\N	t	\N	Lucas.Burton24	2	2017
749	\N	t	\N	Cash.Sierra87	2	2017
750	\N	t	\N	Greene.Maggie23	2	2017
751	\N	t	\N	Miranda.Elijah5	2	2017
752	\N	t	\N	Estrada.Ulysses96	2	2017
753	\N	t	\N	Stafford.Maris17	2	2017
754	\N	t	\N	Guy.Brenna41	2	2017
755	\N	t	\N	Fischer.Kato95	2	2017
756	\N	t	\N	Moody.Wesley2	2	2017
757	\N	t	\N	Lynch.Kimberley27	2	2017
758	\N	t	\N	Riddle.Julie74	2	2017
759	\N	t	\N	Hancock.Alfreda49	2	2017
760	\N	t	\N	Pace.Victoria83	2	2017
761	\N	t	\N	Conley.Sylvia58	2	2017
762	\N	t	\N	Mathews.Kato5	2	2017
763	\N	t	\N	Andrews.Leo13	2	2017
764	\N	t	\N	Cote.Sonia87	2	2017
765	\N	t	\N	Chandler.Grace42	2	2017
766	\N	t	\N	Carter.Ebony43	2	2017
767	\N	t	\N	Boone.Rhea42	2	2017
768	\N	t	\N	Sloan.Kane71	2	2017
769	\N	t	\N	Harvey.Hayes40	2	2017
770	\N	t	\N	Wilkins.Knox48	2	2017
771	\N	t	\N	Chan.Beck3	2	2017
772	\N	t	\N	Hinton.Vivian14	2	2017
773	\N	t	\N	Pennington.Hammett78	2	2017
774	\N	t	\N	Reid.Imani99	2	2017
775	\N	t	\N	Snyder.Jakeem77	2	2017
776	\N	t	\N	Haynes.Isabella41	2	2017
777	\N	t	\N	Randall.Remedios78	2	2017
778	\N	t	\N	Snider.Phillip9	2	2017
779	\N	t	\N	Brown.Simon42	2	2017
780	\N	t	\N	Bryan.Maggy31	2	2017
781	\N	t	\N	Hooper.Juliet59	2	2017
782	\N	t	\N	Mckinney.Dacey28	2	2017
783	\N	t	\N	Flynn.Heather100	2	2017
784	\N	t	\N	Sheppard.Hiram65	2	2017
785	\N	t	\N	Wilkins.Dillon80	2	2017
786	\N	t	\N	Velez.Wyoming83	2	2017
787	\N	t	\N	Mays.Quin98	2	2017
788	\N	t	\N	Daniels.Nicholas77	2	2017
789	\N	t	\N	Maynard.Jordan71	2	2017
790	\N	t	\N	Lee.Phillip23	2	2017
791	\N	t	\N	Aguirre.Xantha24	2	2017
792	\N	t	\N	Oneill.Hollee91	2	2017
793	\N	t	\N	Madden.Meghan98	2	2017
794	\N	t	\N	Fischer.Samantha75	2	2017
795	\N	t	\N	Lester.Xena97	2	2017
796	\N	t	\N	Tanner.Lareina50	2	2017
797	\N	t	\N	Blake.Angelica72	2	2017
798	\N	t	\N	Conner.Patrick63	2	2017
799	\N	t	\N	Garrison.Maile14	2	2017
800	\N	t	\N	Kirby.Keane59	2	2017
801	\N	t	\N	Cross.Perry87	2	2017
802	\N	t	\N	Marks.Adam39	2	2017
803	\N	t	\N	Burt.Duncan60	2	2017
804	\N	t	\N	Matthews.Stella66	2	2017
805	\N	t	\N	Luna.Imogene30	2	2017
806	\N	t	\N	Morales.Candace97	2	2017
807	\N	t	\N	Flowers.Gary39	2	2017
808	\N	t	\N	Montoya.Lucius18	2	2017
809	\N	t	\N	Hatfield.Miranda37	2	2017
810	\N	t	\N	Padilla.Declan90	2	2017
811	\N	t	\N	Ramos.Amery55	2	2017
812	\N	t	\N	Farley.Latifah29	2	2017
813	\N	t	\N	Berry.Castor46	2	2017
814	\N	t	\N	Workman.Harding82	2	2017
815	\N	t	\N	Weeks.Tanya9	2	2017
816	\N	t	\N	Ballard.Malcolm67	2	2017
817	\N	t	\N	Strickland.Charde28	2	2017
818	\N	t	\N	Carlson.Gemma63	2	2017
819	\N	t	\N	Chang.Ferdinand77	2	2017
820	\N	t	\N	Rasmussen.Lawrence20	2	2017
821	\N	t	\N	Livingston.Cassandra78	2	2017
822	\N	t	\N	Lawson.Nathaniel45	2	2017
823	\N	t	\N	Decker.Cameron45	2	2017
824	\N	t	\N	Velez.Candace35	2	2017
825	\N	t	\N	Brock.Amal86	2	2017
826	\N	t	\N	Hayes.Kim51	2	2017
827	\N	t	\N	Schwartz.Carolyn13	2	2017
828	\N	t	\N	Bell.Mary50	2	2017
829	\N	t	\N	Barnes.Ruth27	2	2017
830	\N	t	\N	Valenzuela.Sydnee91	2	2017
831	\N	t	\N	Sweeney.Mercedes15	2	2017
832	\N	t	\N	Rose.Andrew30	2	2017
833	\N	t	\N	Obrien.Iris93	2	2017
834	\N	t	\N	Albert.Kylan57	2	2017
835	\N	t	\N	Mcintyre.Veda6	2	2017
836	\N	t	\N	Mendez.Barry62	2	2017
837	\N	t	\N	Giles.Carissa92	2	2017
838	\N	t	\N	Hull.Armando46	2	2017
839	\N	t	\N	Griffith.Kristen63	2	2017
840	\N	t	\N	Walton.Thaddeus29	2	2017
841	\N	t	\N	Ortega.Gwendolyn97	2	2017
842	\N	t	\N	Lang.Ivana14	2	2017
843	\N	t	\N	Brady.Rina10	2	2017
844	\N	t	\N	Reed.Gregory100	2	2017
845	\N	t	\N	Roman.Camille22	2	2017
846	\N	t	\N	Mcintyre.Roth95	2	2017
847	\N	t	\N	Roy.Stewart30	2	2017
848	\N	t	\N	Hunter.Rhoda8	2	2017
849	\N	t	\N	Stanley.Cameran48	2	2017
850	\N	t	\N	Knox.Yoko92	2	2017
851	\N	t	\N	Allison.Phelan83	2	2017
852	\N	t	\N	Kent.Donna54	2	2017
853	\N	t	\N	Moody.Gray92	2	2017
854	\N	t	\N	Mendez.Avram60	2	2017
855	\N	t	\N	Stevens.Chase10	2	2017
856	\N	t	\N	Deleon.Ursa16	2	2017
857	\N	t	\N	Raymond.Gary62	2	2017
858	\N	t	\N	Cole.Kermit6	2	2017
859	\N	t	\N	Morin.Abdul17	2	2017
860	\N	t	\N	Durham.Marny28	2	2017
861	\N	t	\N	Henson.Benjamin34	2	2017
862	\N	t	\N	Bridges.Tucker7	2	2017
863	\N	t	\N	Mitchell.Xyla20	2	2017
864	\N	t	\N	Chan.Nomlanga48	2	2017
865	\N	t	\N	Nelson.Xena38	2	2017
866	\N	t	\N	Tillman.Rajah56	2	2017
867	\N	t	\N	Roth.Nolan16	2	2017
868	\N	t	\N	Rhodes.Lara22	2	2017
869	\N	t	\N	Keller.Minerva36	2	2017
870	\N	t	\N	Burke.Eugenia70	2	2017
871	\N	t	\N	Gilmore.Clinton33	2	2017
872	\N	t	\N	Turner.Amela17	2	2017
873	\N	t	\N	Levy.Cherokee62	2	2017
874	\N	t	\N	Yates.Olivia55	2	2017
875	\N	t	\N	Singleton.Brynne89	2	2017
876	\N	t	\N	Miles.Nicole92	2	2017
877	\N	t	\N	Petersen.Cairo68	2	2017
878	\N	t	\N	Mcfadden.Sharon10	2	2017
879	\N	t	\N	Atkins.Judah32	2	2017
880	\N	t	\N	Dunn.Montana12	2	2017
881	\N	t	\N	Daugherty.Fallon98	2	2017
882	\N	t	\N	Farmer.Dora53	2	2017
883	\N	t	\N	Moon.Emerald95	2	2017
884	\N	t	\N	Michael.Hiroko23	2	2017
885	\N	t	\N	Collins.Darius81	2	2017
886	\N	t	\N	Garrett.Zeph49	2	2017
887	\N	t	\N	Colon.Ursa10	2	2017
888	\N	t	\N	Estes.Jarrod4	2	2017
889	\N	t	\N	Hobbs.Karen39	2	2017
890	\N	t	\N	Jacobs.Callie84	2	2017
891	\N	t	\N	Jackson.Dahlia87	2	2017
892	\N	t	\N	Stevenson.Madaline67	2	2017
893	\N	t	\N	Kennedy.Alice96	2	2017
894	\N	t	\N	Jordan.Roanna91	2	2017
895	\N	t	\N	Lawson.Asher8	2	2017
896	\N	t	\N	Curry.Cailin95	2	2017
897	\N	t	\N	Booker.Imelda6	2	2017
898	\N	t	\N	Contreras.Kirsten46	2	2017
899	\N	t	\N	Burgess.Warren34	2	2017
900	\N	t	\N	Downs.Steel2	2	2017
901	\N	t	\N	Benjamin.Jessica87	2	2017
902	\N	t	\N	Harper.Jonas23	2	2017
903	\N	t	\N	Walls.Christopher5	2	2017
904	\N	t	\N	Skinner.Ruby31	2	2017
905	\N	t	\N	Graham.Phelan12	2	2017
906	\N	t	\N	Mckee.Emery64	2	2017
907	\N	t	\N	Cole.Lillith48	2	2017
908	\N	t	\N	Wagner.Hayden86	2	2017
909	\N	t	\N	Noel.Yuli88	2	2017
910	\N	t	\N	Jackson.Shelly76	2	2017
911	\N	t	\N	Gamble.Hoyt29	2	2017
912	\N	t	\N	Scott.Mira46	2	2017
913	\N	t	\N	Sykes.Eliana60	2	2017
914	\N	t	\N	Macias.Irene77	2	2017
915	\N	t	\N	Romero.Margaret4	2	2017
916	\N	t	\N	Newton.Logan47	2	2017
917	\N	t	\N	Dawson.Jasper77	2	2017
918	\N	t	\N	Bray.Mallory49	2	2017
919	\N	t	\N	Barron.Lewis19	2	2017
920	\N	t	\N	Carney.Tanya48	2	2017
921	\N	t	\N	Nolan.Lani42	2	2017
922	\N	t	\N	Hansen.Candace3	2	2017
923	\N	t	\N	Horn.Emery41	2	2017
924	\N	t	\N	Collier.Ashely24	2	2017
925	\N	t	\N	Barton.Michelle11	2	2017
926	\N	t	\N	Allen.James4	2	2017
927	\N	t	\N	Hoffman.Clark45	2	2017
928	\N	t	\N	Shields.Emi97	2	2017
929	\N	t	\N	Holden.Martena56	2	2017
930	\N	t	\N	Trevino.Remedios97	2	2017
931	\N	t	\N	Aguilar.Jeremy92	2	2017
932	\N	t	\N	Ortega.Abbot37	2	2017
933	\N	t	\N	Villarreal.Hyacinth58	2	2017
934	\N	t	\N	Gibson.Ferris81	2	2017
935	\N	t	\N	Castillo.Indigo58	2	2017
936	\N	t	\N	Schroeder.Kermit67	2	2017
937	\N	t	\N	Jacobson.Kelsie21	2	2017
938	\N	t	\N	Howard.Cooper71	2	2017
939	\N	t	\N	Burton.Wylie56	2	2017
940	\N	t	\N	Gaines.Drake14	2	2017
941	\N	t	\N	Carpenter.Ahmed11	2	2017
942	\N	t	\N	Richardson.Aquila57	2	2017
943	\N	t	\N	Mcdowell.Celeste67	2	2017
944	\N	t	\N	Lowery.Celeste58	2	2017
945	\N	t	\N	Petty.Ferdinand76	2	2017
946	\N	t	\N	Hernandez.Phyllis11	2	2017
947	\N	t	\N	Mcleod.Clinton15	2	2017
948	\N	t	\N	Hayes.Hyacinth38	2	2017
949	\N	t	\N	Mcknight.Kyle46	2	2017
950	\N	t	\N	Walsh.Tiger42	2	2017
951	\N	t	\N	Finch.Ross78	2	2017
952	\N	t	\N	Ingram.Leo88	2	2017
953	\N	t	\N	Hudson.Aileen4	2	2017
954	\N	t	\N	Mullins.Willa79	2	2017
955	\N	t	\N	Sweet.Quamar7	2	2017
956	\N	t	\N	Dejesus.Kyle72	2	2017
957	\N	t	\N	Whitehead.Maggie96	2	2017
958	\N	t	\N	Solomon.Jemima13	2	2017
959	\N	t	\N	Grimes.Marvin9	2	2017
960	\N	t	\N	Garner.Echo30	2	2017
961	\N	t	\N	Sellers.Mira68	2	2017
962	\N	t	\N	Nichols.Colton17	2	2017
963	\N	t	\N	Blanchard.Felix40	2	2017
964	\N	t	\N	Powell.Quintessa88	2	2017
965	\N	t	\N	Guthrie.Bernard47	2	2017
966	\N	t	\N	Hart.Calista7	2	2017
967	\N	t	\N	Swanson.Oliver20	2	2017
968	\N	t	\N	Myers.Duncan11	2	2017
969	\N	t	\N	Boone.Jamal86	2	2017
970	\N	t	\N	Wynn.Lionel64	2	2017
971	\N	t	\N	Dickerson.Natalie18	2	2017
972	\N	t	\N	Martin.Channing22	2	2017
973	\N	t	\N	Miller.Zephania48	2	2017
974	\N	t	\N	Leon.Evangeline61	2	2017
975	\N	t	\N	Bridges.Serena88	2	2017
976	\N	t	\N	Cross.Kimberley4	2	2017
977	\N	t	\N	Andrews.Jenna22	2	2017
978	\N	t	\N	Snider.Nehru79	2	2017
979	\N	t	\N	Roth.Kyle3	2	2017
980	\N	t	\N	Rodgers.Moses15	2	2017
981	\N	t	\N	Christian.Rhona26	2	2017
982	\N	t	\N	Perry.Tara71	2	2017
983	\N	t	\N	Atkins.Yvette30	2	2017
984	\N	t	\N	Estes.Gemma55	2	2017
985	\N	t	\N	Fernandez.Chaim55	2	2017
986	\N	t	\N	Castaneda.Riley8	2	2017
987	\N	t	\N	Day.Felicia2	2	2017
988	\N	t	\N	Collins.Holly20	2	2017
989	\N	t	\N	Frye.Maggie98	2	2017
990	\N	t	\N	Osborne.Georgia12	2	2017
991	\N	t	\N	Harper.Lance100	2	2017
992	\N	t	\N	Bowman.Naomi94	2	2017
993	\N	t	\N	Pittman.Lydia91	2	2017
994	\N	t	\N	Franco.Keegan61	2	2017
995	\N	t	\N	Crosby.Julian52	2	2017
996	\N	t	\N	Pratt.Regina12	2	2017
997	\N	t	\N	Alston.Dominic65	2	2017
998	\N	t	\N	Madden.Duncan12	2	2017
999	\N	t	\N	Head.Isaiah78	2	2017
1000	\N	t	\N	Hayden.Gretchen22	2	2017
1001	\N	t	null      	Gibbs.Lance11	2	2017
1002	\N	t	null      	Suarez.Martina50	2	2017
1003	\N	t	null      	Stevenson.Oren10	2	2017
1004	\N	t	null      	Rogers.Nora79	2	2017
1005	\N	t	null      	Lowe.Kristen68	2	2017
1006	\N	t	null      	Deleon.Hollee41	2	2017
1007	\N	t	null      	Watkins.Echo23	2	2017
1008	\N	t	null      	Richardson.Mollie88	2	2017
1009	\N	t	null      	Hewitt.Dolan87	2	2017
1010	\N	t	null      	Huffman.Felicia60	2	2017
1011	\N	t	null      	Moran.Chiquita100	2	2017
1012	\N	t	null      	Fitzpatrick.Holmes75	2	2017
1013	\N	t	null      	Webster.Amity84	2	2017
1014	\N	t	null      	Roman.Kieran63	2	2017
1015	\N	t	null      	Wolfe.Curran44	2	2017
1016	\N	t	null      	Ramsey.Yvette25	2	2017
1017	\N	t	null      	Carney.Noble15	2	2017
1018	\N	t	null      	Hudson.Thor22	2	2017
1019	\N	t	null      	David.Joshua39	2	2017
1020	\N	t	null      	Hamilton.Herrod37	2	2017
1021	\N	t	null      	Dale.Leroy26	2	2017
1022	\N	t	null      	Whitley.Heidi25	2	2017
1023	\N	t	null      	Stark.Cody92	2	2017
1024	\N	t	null      	Ryan.Grace96	2	2017
1025	\N	t	null      	Stanton.Fay51	2	2017
1026	\N	t	null      	Lamb.Lydia34	2	2017
1027	\N	f	null      	Sloan.Elliott92	2	2017
1028	\N	f	null      	Beard.Dacey17	2	2017
1029	\N	f	null      	Turner.Emily41	2	2017
1030	\N	f	null      	Martinez.Quentin83	2	2017
1031	\N	f	null      	Vaughn.Francesca36	2	2017
1032	\N	f	null      	Higgins.Gannon55	2	2017
1033	\N	f	null      	Park.Iliana41	2	2017
1034	\N	f	null      	Daniel.Brandon11	2	2017
1035	\N	f	null      	Reed.Cora15	2	2017
1036	\N	f	null      	Green.Robin52	2	2017
1037	\N	f	null      	Poole.Alisa1	2	2017
1038	\N	t	null      	Castro.Yuri6	2	2017
1039	\N	t	null      	Horne.Hollee43	2	2017
1040	\N	t	null      	Sampson.Rooney97	2	2017
1041	\N	t	null      	Atkins.Winifred10	2	2017
1042	\N	t	null      	Joseph.Keegan13	2	2017
1043	\N	t	null      	Marsh.Jorden96	2	2017
1044	\N	t	null      	Bennett.Mary57	2	2017
1045	\N	t	null      	Rowland.Adele41	2	2017
1046	\N	t	null      	Forbes.David77	2	2017
1047	\N	t	null      	Meyer.Michael57	2	2017
1048	\N	t	null      	Donaldson.Dillon18	2	2017
1049	\N	f	null      	Klein.Yael79	2	2017
1050	\N	f	null      	Gould.Ferris72	2	2017
1051	\N	f	null      	Vasquez.Kaseem21	2	2017
1052	\N	f	null      	Oconnor.Fritz50	2	2017
1053	\N	f	null      	Hardin.Evan67	2	2017
1054	\N	f	null      	Weaver.Janna59	2	2017
1055	\N	f	null      	Hoover.Raya40	2	2017
1056	\N	f	null      	Casey.Kendall70	2	2017
1057	\N	f	null      	Guy.Clare17	2	2017
1058	\N	f	null      	Graham.Gillian83	2	2017
1059	\N	f	null      	Oliver.Venus52	2	2017
1060	\N	t	null      	Buckner.Heather43	2	2017
1061	\N	t	null      	Warren.Hyacinth69	2	2017
1062	\N	t	null      	Daniel.Quamar92	2	2017
1063	\N	t	null      	Good.Shaine54	2	2017
1064	\N	t	null      	Schultz.Maite82	2	2017
1065	\N	t	null      	Benjamin.Allistair71	2	2017
1066	\N	t	null      	Barber.Shannon83	2	2017
1067	\N	t	null      	Mcgee.Boris66	2	2017
1068	\N	t	null      	Combs.Libby96	2	2017
1069	\N	t	null      	Middleton.Aretha35	2	2017
1070	\N	t	null      	Farmer.Isaiah3	2	2017
1071	\N	t	null      	Mejia.Montana71	2	2017
1072	\N	t	null      	Velazquez.Shelly91	2	2017
1073	\N	t	null      	Albert.Dorothy22	2	2017
1074	\N	t	null      	Tucker.Lucian78	2	2017
1075	\N	t	null      	Mays.Zelenia2	2	2017
1076	\N	f	null      	Mcknight.Dorothy30	2	2017
1077	\N	f	null      	Odonnell.Deacon8	2	2017
1078	\N	f	null      	Compton.Demetria66	2	2017
1079	\N	f	null      	Vang.Anjolie13	2	2017
1080	\N	f	null      	Burke.Martha6	2	2017
1081	\N	f	null      	Reyes.Harding37	2	2017
1082	\N	f	null      	Pena.Hayes97	2	2017
1083	\N	f	null      	Grimes.Gray62	2	2017
1084	\N	f	null      	Velez.Bertha40	2	2017
1085	\N	f	null      	Gould.Darrel85	2	2017
1086	\N	f	null      	Fernandez.Deborah38	2	2017
1087	\N	f	null      	Conrad.Idola55	2	2017
1088	\N	f	null      	Moon.Harding14	2	2017
1089	\N	f	null      	James.Denton32	2	2017
1090	\N	f	null      	Roberts.Stephen1	2	2017
1091	\N	f	null      	Robbins.Erica16	2	2017
1092	\N	f	null      	Rodriguez.Stone40	2	2017
1093	\N	f	null      	Finley.Shelly100	2	2017
1094	\N	f	null      	Abbott.Owen53	2	2017
1095	\N	t	null      	Curtis.Michael78	2	2017
1096	\N	t	null      	Waller.Jena96	2	2017
1097	\N	t	null      	Salazar.Coby19	2	2017
1098	\N	t	null      	Schwartz.Megan66	2	2017
1099	\N	t	null      	Ryan.Aladdin11	2	2017
1100	\N	t	null      	Mclaughlin.Austin97	2	2017
1101	\N	t	null      	Chase.Chaim30	2	2017
1102	\N	t	null      	Woods.Kennan17	2	2017
1103	\N	t	null      	Phelps.Illana89	2	2017
1104	\N	t	null      	Cooley.Talon70	2	2017
1105	\N	t	null      	Mann.Brian16	2	2017
1106	\N	t	null      	Gilmore.Alden89	2	2017
1107	\N	t	null      	Wells.Vincent91	2	2017
1108	\N	t	null      	Beck.Sybil86	2	2017
1109	\N	t	null      	Douglas.Davis20	2	2017
1110	\N	t	null      	Rivera.Kelsie6	2	2017
1111	\N	t	null      	Fernandez.Colton64	2	2017
1112	\N	f	null      	Barber.Yael97	2	2017
1113	\N	f	null      	Gilmore.Porter80	2	2017
1114	\N	f	null      	Townsend.Leah8	2	2017
1115	\N	f	null      	Davis.Jordan9	2	2017
1116	\N	f	null      	Kemp.Wynter61	2	2017
1117	\N	f	null      	Stuart.Juliet6	2	2017
1118	\N	f	null      	Gonzales.Indigo58	2	2017
1119	\N	f	null      	Kidd.Alma42	2	2017
1120	\N	f	null      	Christian.Xyla72	2	2017
1121	\N	f	null      	Snyder.India67	2	2017
1122	\N	f	null      	Short.Laith32	2	2017
1123	\N	f	null      	Haynes.Lilah97	2	2017
1124	\N	f	null      	Dejesus.Bevis5	2	2017
1125	\N	f	null      	Bonner.Martin82	2	2017
1126	\N	f	null      	Roman.Shana89	2	2017
1127	\N	f	null      	Paul.Griffith99	2	2017
1128	\N	f	null      	Smith.Julian76	2	2017
1129	\N	f	null      	Roach.Nyssa62	2	2017
1130	\N	t	null      	Reeves.Merritt36	2	2017
1131	\N	t	null      	Irwin.Porter90	2	2017
1132	\N	t	null      	Santos.Brett11	2	2017
1133	\N	t	null      	Doyle.Whoopi68	2	2017
1134	\N	t	null      	Castro.Sean47	2	2017
1135	\N	t	null      	Davidson.Meghan49	2	2017
1136	\N	t	null      	Byers.Bert51	2	2017
1137	\N	t	null      	Rowe.Adrian64	2	2017
1138	\N	t	null      	Horne.Porter57	2	2017
1139	\N	t	null      	Snow.Brett59	2	2017
1140	\N	t	null      	May.Dorothy63	2	2017
1141	\N	t	null      	Dunlap.Irma4	2	2017
1142	\N	t	null      	Howe.Raven27	2	2017
1143	\N	t	null      	Ferguson.Jael67	2	2017
1144	\N	t	null      	Donaldson.Eric52	2	2017
1145	\N	t	null      	Schmidt.Mufutau78	2	2017
1146	\N	t	null      	Harrington.Peter98	2	2017
1147	\N	t	null      	Gillespie.Uta93	2	2017
1148	\N	t	null      	Davenport.Louis2	2	2017
1149	\N	t	null      	Guy.Bernard63	2	2017
1150	\N	t	null      	May.Zenaida90	2	2017
1151	\N	t	null      	Jensen.Judith77	2	2017
1152	\N	f	null      	Reyes.Scarlett68	2	2017
1153	\N	f	null      	Oneal.Channing81	2	2017
1154	\N	f	null      	Nunez.Madeline78	2	2017
1155	\N	f	null      	Hopkins.Barbara4	2	2017
1156	\N	f	null      	Carrillo.Hedley46	2	2017
1157	\N	f	null      	Farrell.Samuel79	2	2017
1158	\N	f	null      	Rowland.Kevyn66	2	2017
1159	\N	f	null      	Carey.Madonna75	2	2017
1160	\N	f	null      	Sosa.Sasha51	2	2017
1161	\N	f	null      	Andrews.Shaeleigh9	2	2017
1162	\N	f	null      	Mccormick.Guinevere28	2	2017
1163	\N	f	null      	Logan.Wing49	2	2017
1164	\N	f	null      	Gamble.Chastity15	2	2017
1165	\N	f	null      	Burton.Carly6	2	2017
1166	\N	f	null      	Mcintosh.Roary89	2	2017
1167	\N	t	null      	Duncan.Berk75	2	2017
1168	\N	t	null      	Compton.May41	2	2017
1169	\N	t	null      	Chen.Kelsey73	2	2017
1170	\N	t	null      	Clark.Neville89	2	2017
1171	\N	t	null      	Boyd.Daquan50	2	2017
1172	\N	t	null      	Roberson.Mari59	2	2017
1173	\N	t	null      	Hendricks.Wilma48	2	2017
1174	\N	t	null      	Howell.Kitra87	2	2017
1175	\N	t	null      	Perkins.Merrill87	2	2017
1176	\N	t	null      	Christensen.Constance90	2	2017
1177	\N	t	null      	Mendoza.Christopher100	2	2017
1178	\N	t	null      	Peters.Cherokee71	2	2017
1179	\N	t	null      	Kaufman.Ciara5	2	2017
1180	\N	t	null      	Moody.Hall39	2	2017
1181	\N	f	null      	Gross.Adena8	2	2017
1182	\N	f	null      	Joyce.Kareem51	2	2017
1183	\N	f	null      	Guy.Grant10	2	2017
1184	\N	f	null      	Albert.Ina45	2	2017
1185	\N	t	null      	Mcclain.Elliott76	2	2017
1186	\N	t	null      	Rutledge.Teagan33	2	2017
1187	\N	t	null      	Ramos.Jamal78	2	2017
1188	\N	t	null      	Barrett.Echo100	2	2017
1189	\N	t	null      	Glass.Aristotle86	2	2017
1190	\N	t	null      	Herring.Adele60	2	2017
1191	\N	t	null      	Rich.Adrienne97	2	2017
1192	\N	t	null      	Rivers.Ingrid95	2	2017
1193	\N	t	null      	Mcmillan.Mariko69	2	2017
1194	\N	t	null      	Carson.Herrod88	2	2017
1195	\N	t	null      	Lewis.Wayne43	2	2017
1196	\N	t	null      	Dunlap.Harper2	2	2017
1197	\N	t	null      	Bird.Branden18	2	2017
1198	\N	t	null      	Garcia.Reed1	2	2017
1199	\N	t	null      	Mcguire.Mia1	2	2017
1200	\N	t	null      	Short.Nathan42	2	2017
1201	\N	\N	\N	arri.kurniawan	2	2017
\.


--
-- Name: pendaftaran_id_seq; Type: SEQUENCE SET; Schema: sirima; Owner: arri.kurniawan
--

SELECT pg_catalog.setval('pendaftaran_id_seq', 1, false);


--
-- Data for Name: pendaftaran_prodi; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pendaftaran_prodi (id_pendaftaran, kode_prodi, status_lulus) FROM stdin;
201	85	f
201	6	f
202	77	f
202	14	f
203	47	f
203	85	f
204	69	f
204	79	f
205	21	f
205	86	f
206	59	f
206	40	f
207	58	f
207	60	f
208	27	f
208	54	f
209	81	f
209	15	f
210	16	f
210	18	f
211	53	f
211	52	f
212	55	f
212	18	f
213	63	f
213	49	f
214	85	f
214	80	f
215	72	f
215	12	f
216	70	f
216	5	f
217	31	f
217	40	f
218	53	f
218	16	f
219	42	f
219	39	f
220	78	f
220	23	f
221	42	f
221	73	f
222	70	f
222	54	f
223	57	f
223	92	f
224	12	f
224	6	f
225	89	f
225	79	f
226	84	f
226	82	f
227	2	f
227	52	f
228	29	f
228	78	f
229	63	f
229	2	f
230	20	f
230	78	f
231	14	f
231	55	f
232	43	f
232	29	f
233	17	f
233	43	f
234	47	f
235	44	f
235	45	f
236	88	f
236	24	f
237	74	f
237	35	f
238	32	f
239	38	f
239	3	f
240	61	f
240	66	f
241	81	f
241	37	f
242	1	f
242	85	f
243	40	f
243	31	f
244	84	f
244	31	f
245	59	f
245	72	f
246	16	f
246	77	f
247	71	f
247	1	f
248	4	f
248	34	f
249	24	f
249	20	f
250	13	f
250	51	f
251	36	f
251	46	f
252	27	f
252	67	f
253	90	f
253	46	f
254	85	f
254	26	f
255	73	f
255	43	f
256	40	f
256	60	f
257	49	f
257	17	f
258	48	f
258	27	f
259	74	f
259	56	f
260	53	f
260	57	f
261	52	f
261	16	f
262	41	f
262	28	f
263	92	f
263	11	f
264	57	f
264	69	f
265	36	f
265	72	f
266	14	f
266	85	f
267	71	f
267	56	f
268	33	f
268	26	f
269	58	f
269	92	f
270	92	f
270	31	f
271	91	f
271	61	f
272	90	f
272	79	f
273	78	f
273	23	f
274	41	f
274	51	f
275	6	f
275	61	f
276	25	f
276	72	f
277	75	f
277	90	f
278	54	f
278	48	f
279	62	f
279	15	f
280	28	f
280	2	f
281	50	f
281	86	f
282	5	f
282	52	f
283	7	f
283	40	f
284	62	f
284	52	f
285	5	f
285	57	f
86	12	f
87	34	f
87	2	f
88	31	f
88	52	f
89	34	f
89	82	f
90	26	f
90	20	f
91	59	f
91	80	f
92	13	f
92	48	f
93	17	f
286	45	f
286	85	f
287	51	f
287	54	f
288	46	f
288	76	f
289	15	f
289	92	f
290	54	f
290	30	f
291	70	f
291	26	f
292	15	f
292	25	f
293	40	f
293	46	f
294	64	f
294	21	f
295	69	f
295	74	f
296	31	f
296	17	f
297	52	f
297	40	f
298	13	f
298	32	f
299	21	f
299	37	f
300	53	f
300	15	f
161	17	f
301	2	f
301	70	f
302	64	f
302	3	f
303	42	f
303	28	f
304	13	f
304	47	f
305	18	f
305	22	f
306	21	f
167	14	f
306	4	f
307	56	f
307	50	f
308	3	f
308	28	f
309	33	f
309	91	f
310	19	f
310	61	f
311	89	f
311	43	f
312	42	f
312	3	f
174	20	f
313	19	f
313	44	f
314	32	f
314	42	f
315	86	f
315	15	f
316	6	f
316	74	f
317	68	f
317	25	f
318	28	f
318	87	f
94	65	f
94	73	f
95	40	f
95	49	f
96	37	f
96	27	f
97	54	f
98	28	f
98	64	f
99	3	f
99	57	f
100	40	t
100	89	f
101	4	f
101	15	t
102	3	f
102	19	t
103	14	t
104	2	f
104	16	t
105	1	f
105	14	t
106	4	t
106	13	f
107	4	f
107	17	t
108	2	f
109	4	f
109	20	t
110	4	f
110	18	t
111	2	f
111	15	t
112	2	t
112	16	f
113	4	f
113	16	t
114	13	t
115	2	f
115	15	t
116	1	f
116	19	t
117	1	f
117	18	t
118	4	t
118	13	f
119	1	f
120	1	f
120	19	t
121	1	f
121	18	t
122	1	f
122	20	t
123	2	f
123	13	t
124	2	t
124	20	f
125	15	t
126	4	f
126	20	t
127	3	f
127	16	t
128	2	f
128	19	t
129	3	f
129	17	t
130	4	t
131	2	f
131	17	t
132	2	f
132	19	t
133	1	f
133	15	t
134	1	f
134	13	t
135	2	f
135	18	t
136	14	f
137	2	f
137	18	t
138	4	f
138	19	t
139	1	f
139	17	t
140	4	f
140	14	t
141	4	f
142	4	t
142	16	f
143	3	f
143	19	t
144	2	f
144	15	t
145	1	f
145	19	t
146	3	f
146	20	t
147	15	t
148	4	t
148	14	f
149	4	f
149	14	t
150	4	f
150	16	t
151	3	f
151	19	t
1	6	t
1	41	f
2	47	f
2	1	t
3	79	f
3	15	t
4	44	f
4	57	t
5	55	f
5	46	t
6	24	f
6	75	t
7	63	t
7	21	f
8	73	f
8	68	t
9	67	f
9	12	t
10	7	f
10	41	t
11	39	f
11	12	t
12	34	f
12	2	t
13	31	t
13	52	f
14	34	f
14	82	t
15	26	f
15	20	t
16	59	f
16	80	t
17	13	f
17	48	t
18	17	f
18	54	t
19	65	t
19	73	f
20	40	f
20	49	t
21	37	f
21	27	t
22	54	f
22	65	t
23	28	f
23	64	t
24	3	f
24	57	t
25	40	t
25	89	f
26	6	f
26	41	t
27	47	f
27	1	t
28	79	f
28	15	t
29	44	f
29	57	t
30	55	f
30	46	t
31	24	t
31	75	f
32	63	f
32	21	t
33	73	f
33	68	t
34	67	f
34	12	t
35	7	f
35	41	t
36	39	f
36	12	t
37	34	t
37	2	f
38	31	f
38	52	t
39	34	f
39	82	t
40	26	f
40	20	t
41	59	f
41	80	t
42	13	f
42	48	t
43	17	t
43	54	f
44	65	f
44	73	t
45	40	f
45	49	t
46	37	f
46	27	t
47	54	f
47	65	t
48	28	f
48	64	t
49	3	t
49	57	f
50	40	f
50	89	t
51	6	f
51	41	t
52	47	f
52	1	t
53	79	f
53	15	t
54	44	f
54	57	t
55	55	t
55	46	f
56	24	f
56	75	t
57	63	f
57	21	t
58	73	f
58	68	t
59	67	f
59	12	t
60	7	f
60	41	t
61	39	t
61	12	f
62	34	t
62	2	t
63	31	f
63	52	f
64	34	t
64	82	f
65	26	t
65	20	f
66	59	t
66	80	f
67	13	t
67	48	f
68	17	t
68	54	t
69	65	f
69	73	f
70	40	t
70	49	f
71	37	t
71	27	f
72	54	t
72	65	f
73	28	t
73	64	f
74	3	t
74	57	f
75	40	t
75	89	t
76	6	f
76	41	f
77	47	t
77	1	f
78	79	t
186	16	f
187	2	f
187	14	f
188	3	f
188	13	f
189	2	f
189	17	f
190	18	f
191	2	f
191	17	f
192	4	f
192	14	f
193	1	f
193	16	f
194	2	f
194	18	f
195	4	f
196	1	f
196	15	f
197	1	f
197	17	f
198	3	f
198	17	f
199	1	f
199	15	f
200	2	f
200	16	f
78	15	f
79	44	t
79	57	f
80	55	t
80	46	f
81	24	f
81	75	f
82	63	f
82	21	f
83	73	f
83	68	f
84	67	f
84	12	f
85	7	f
85	41	f
86	39	f
93	54	f
97	65	f
103	3	f
108	15	t
114	1	f
119	17	t
125	2	f
130	17	f
136	3	t
141	14	t
147	3	f
152	2	f
152	15	t
153	1	f
153	19	t
154	3	t
154	20	f
155	3	f
155	15	t
156	4	f
156	16	t
157	1	f
157	14	t
158	2	f
158	20	t
159	4	f
159	14	t
160	4	t
160	17	f
161	3	t
319	16	f
162	1	f
162	19	f
163	1	t
163	19	f
164	4	t
164	13	f
165	4	t
165	19	f
166	4	t
166	17	f
167	1	t
319	29	f
168	2	f
168	13	f
169	2	t
169	13	f
170	4	t
170	20	f
171	1	t
171	19	f
172	4	t
172	18	f
173	4	t
173	14	f
174	3	t
320	27	f
175	1	f
175	18	f
176	4	t
176	18	f
177	1	t
177	16	f
178	1	t
178	16	f
179	2	t
179	19	f
180	1	t
180	18	f
181	1	f
181	20	f
182	1	f
182	16	f
183	4	f
183	20	f
184	1	f
184	14	f
185	2	f
185	18	f
186	1	f
190	1	f
195	20	f
320	29	f
321	39	f
321	8	f
322	76	f
322	75	f
323	41	f
323	84	f
324	34	f
324	53	f
325	20	f
325	64	f
326	23	f
326	9	f
327	41	f
327	86	f
328	61	f
328	56	f
329	71	f
329	34	f
330	92	f
330	81	f
331	51	f
331	55	f
332	52	f
332	32	f
333	17	f
333	25	f
334	30	f
334	12	f
335	39	f
335	81	f
336	60	f
336	26	f
337	1	f
337	18	f
338	12	f
338	86	f
339	45	f
339	10	f
340	31	f
340	63	f
341	27	f
341	30	f
342	92	f
343	21	f
343	31	f
344	2	f
344	56	f
345	60	f
345	31	f
346	92	f
346	38	f
347	65	f
347	89	f
348	33	f
348	37	f
349	26	f
349	92	f
350	5	f
350	68	f
351	84	f
351	46	f
352	5	f
352	14	f
353	55	f
353	92	f
354	30	f
354	68	f
355	48	f
355	41	f
356	17	f
356	66	f
357	80	f
357	24	f
358	40	f
358	1	f
359	67	f
359	78	f
360	45	f
360	43	f
361	34	f
361	63	f
362	51	f
362	9	f
363	25	f
363	44	f
364	60	f
364	73	f
365	3	f
365	21	f
366	21	f
366	83	f
367	18	f
367	11	f
368	43	f
368	57	f
369	75	f
369	65	f
370	69	f
370	16	f
371	17	f
371	70	f
372	87	f
372	35	f
373	56	f
373	70	f
374	53	f
374	41	f
375	43	f
375	69	f
376	24	f
376	70	f
377	19	f
377	43	f
378	15	f
378	85	f
379	6	f
379	51	f
380	91	f
380	13	f
381	12	f
381	66	f
382	44	f
382	14	f
383	48	f
383	56	f
384	49	f
384	71	f
385	7	f
385	79	f
386	25	f
386	68	f
387	52	f
387	39	f
388	3	f
388	8	f
389	74	f
389	81	f
390	67	f
390	1	f
391	74	f
391	83	f
392	77	f
392	90	f
393	65	f
393	34	f
394	72	f
394	15	f
395	3	f
395	49	f
396	4	f
396	81	f
397	73	f
397	58	f
398	25	f
398	77	f
399	5	f
399	27	f
400	54	f
400	20	f
401	45	f
401	7	f
402	86	f
402	85	f
403	65	f
403	29	f
404	4	f
404	86	f
405	47	f
405	86	f
406	43	f
406	45	f
407	88	f
407	54	f
408	76	f
408	35	f
409	28	f
409	85	f
410	64	f
410	7	f
411	17	f
411	81	f
412	21	f
412	25	f
413	37	f
413	10	f
414	62	f
414	79	f
415	26	f
415	2	f
416	9	f
416	70	f
417	54	f
417	76	f
418	43	f
418	36	f
419	1	f
419	53	f
420	90	f
420	64	f
421	12	f
421	4	f
422	65	f
422	85	f
423	75	f
423	36	f
424	25	f
425	58	f
425	43	f
426	35	f
426	53	f
427	11	f
427	66	f
428	66	f
428	17	f
429	51	f
429	80	f
430	37	f
430	14	f
431	43	f
431	57	f
432	60	f
432	67	f
433	79	f
433	76	f
434	23	f
434	53	f
435	79	f
435	7	f
436	85	f
436	84	f
437	60	f
437	55	f
438	53	f
438	83	f
439	17	f
439	10	f
440	78	f
440	88	f
441	17	f
441	52	f
442	91	f
443	65	f
443	71	f
444	76	f
444	44	f
445	24	f
445	12	f
446	37	f
446	43	f
447	20	f
447	28	f
448	9	f
448	87	f
449	61	f
450	80	f
450	10	f
451	66	f
451	38	f
452	44	f
452	65	f
453	92	f
453	1	f
454	81	f
454	52	f
455	16	f
455	84	f
456	21	f
456	89	f
457	58	f
457	8	f
458	40	f
458	11	f
459	49	f
459	21	f
460	59	f
460	63	f
461	76	f
461	92	f
462	90	f
462	36	f
463	35	f
463	40	f
464	65	f
464	36	f
465	22	f
465	4	f
466	43	f
466	63	f
467	35	f
467	80	f
468	43	f
468	67	f
469	20	f
469	73	f
470	5	f
470	10	f
471	59	f
471	36	f
472	1	f
472	14	f
473	16	f
473	67	f
474	53	f
474	4	f
475	23	f
475	33	f
476	32	f
476	35	f
477	35	f
477	57	f
478	16	f
478	78	f
479	19	f
479	36	f
480	72	f
480	11	f
481	61	f
481	30	f
482	48	f
482	15	f
483	67	f
483	73	f
484	31	f
484	38	f
485	40	f
485	75	f
486	70	f
486	85	f
487	14	f
487	83	f
488	45	f
488	61	f
489	80	f
489	27	f
490	3	f
490	54	f
491	42	f
491	3	f
492	15	f
492	31	f
493	7	f
493	72	f
494	13	f
494	42	f
495	31	f
495	71	f
496	5	f
496	22	f
497	28	f
497	67	f
498	52	f
498	29	f
499	66	f
499	24	f
500	90	f
500	80	f
501	23	f
501	74	f
502	75	f
502	73	f
503	75	f
503	74	f
504	17	f
504	12	f
505	31	f
505	70	f
506	53	f
506	30	f
507	65	f
507	45	f
508	58	f
508	39	f
509	54	f
509	80	f
510	32	f
510	46	f
511	41	f
511	72	f
512	73	f
512	54	f
513	46	f
513	4	f
514	12	f
514	7	f
515	92	f
515	48	f
516	30	f
516	18	f
517	28	f
517	36	f
518	19	f
518	91	f
519	29	f
519	35	f
520	63	f
520	84	f
521	86	f
521	7	f
522	64	f
522	71	f
523	3	f
523	5	f
524	37	f
524	91	f
525	81	f
525	54	f
526	19	f
526	39	f
527	7	f
527	76	f
528	16	f
528	3	f
529	41	f
529	40	f
530	30	f
530	57	f
531	50	f
531	45	f
532	28	f
532	3	f
533	45	f
533	58	f
534	67	f
534	1	f
535	82	f
535	29	f
536	84	f
536	18	f
537	66	f
537	32	f
538	39	f
538	12	f
539	73	f
539	13	f
540	13	f
540	51	f
541	62	f
541	44	f
542	47	f
542	63	f
543	85	f
543	68	f
544	51	f
544	65	f
545	46	f
545	92	f
546	86	f
546	87	f
547	3	f
547	65	f
548	47	f
548	7	f
549	88	f
549	21	f
550	22	f
550	43	f
551	87	f
551	53	f
552	55	f
552	23	f
553	15	f
553	39	f
554	47	f
554	88	f
555	17	f
555	23	f
556	44	f
556	47	f
557	57	f
557	75	f
558	64	f
558	5	f
559	63	f
559	78	f
560	49	f
560	23	f
561	84	f
561	54	f
562	82	f
562	59	f
563	84	f
563	27	f
564	17	f
564	73	f
565	85	f
565	76	f
566	79	f
566	81	f
567	3	f
567	88	f
568	31	f
568	57	f
569	33	f
569	68	f
570	29	f
570	18	f
571	73	f
571	13	f
572	10	f
572	85	f
573	26	f
573	5	f
574	39	f
574	5	f
575	8	f
575	63	f
576	90	f
576	54	f
577	48	f
578	69	f
578	63	f
579	38	f
579	37	f
580	82	f
580	31	f
581	13	f
581	65	f
582	26	f
582	90	f
583	30	f
583	27	f
584	46	f
584	83	f
585	85	f
585	42	f
586	69	f
586	73	f
587	92	f
587	1	f
588	38	f
588	35	f
589	89	f
589	75	f
590	77	f
590	64	f
591	40	f
591	15	f
592	38	f
592	28	f
593	25	f
593	71	f
594	37	f
594	85	f
595	16	f
595	8	f
596	67	f
596	8	f
597	13	f
597	20	f
598	43	f
598	57	f
599	56	f
599	32	f
600	8	f
600	32	f
601	92	f
601	26	f
602	52	f
602	64	f
603	62	f
603	84	f
604	21	f
604	86	f
605	14	f
605	33	f
606	69	f
606	87	f
607	19	f
607	81	f
608	16	f
608	65	f
609	11	f
609	84	f
610	67	f
610	65	f
611	1	f
611	4	f
612	56	f
612	81	f
613	32	f
613	52	f
614	73	f
614	82	f
615	44	f
615	56	f
616	21	f
616	28	f
617	49	f
617	70	f
618	16	f
618	39	f
619	12	f
619	92	f
620	34	f
620	38	f
621	80	f
621	44	f
622	44	f
622	11	f
623	47	f
623	38	f
624	62	f
624	19	f
625	37	f
625	78	f
626	63	f
626	59	f
627	81	f
627	19	f
628	57	f
628	38	f
629	4	f
629	56	f
630	69	f
630	7	f
631	58	f
631	19	f
632	11	f
632	18	f
633	55	f
633	15	f
634	20	f
634	42	f
635	66	f
635	53	f
636	80	f
636	20	f
637	58	f
637	34	f
638	31	f
638	50	f
639	18	f
639	31	f
640	73	f
640	63	f
641	42	f
641	37	f
642	32	f
642	36	f
643	44	f
643	8	f
644	40	f
644	56	f
645	88	f
645	37	f
646	64	f
646	50	f
647	75	f
647	37	f
648	89	f
648	70	f
649	22	f
649	6	f
650	19	f
650	74	f
651	85	f
651	7	f
652	11	f
652	43	f
653	23	f
653	62	f
654	56	f
654	75	f
655	87	f
655	86	f
656	12	f
656	63	f
657	84	f
657	32	f
658	78	f
658	8	f
659	89	f
659	70	f
660	32	f
660	62	f
661	16	f
661	79	f
662	82	f
662	81	f
663	22	f
663	76	f
664	89	f
664	47	f
665	6	f
665	7	f
666	73	f
666	92	f
667	37	f
667	28	f
668	83	f
668	42	f
669	28	f
669	73	f
670	73	f
670	22	f
671	41	f
671	28	f
672	76	f
672	67	f
673	57	f
673	51	f
674	46	f
674	80	f
675	82	f
675	63	f
676	49	f
676	21	f
677	54	f
677	83	f
678	89	f
678	67	f
679	21	f
679	74	f
680	54	f
680	32	f
681	51	f
681	52	f
682	13	f
682	3	f
683	55	f
683	82	f
684	67	f
684	63	f
685	18	f
685	80	f
686	56	f
686	33	f
687	29	f
687	61	f
688	49	f
688	61	f
689	91	f
689	17	f
690	91	f
690	37	f
691	63	f
691	80	f
692	18	f
692	88	f
693	61	f
693	41	f
694	88	f
694	9	f
695	75	f
695	76	f
696	22	f
696	83	f
697	8	f
697	33	f
698	32	f
698	34	f
699	17	f
699	84	f
700	30	f
700	83	f
701	8	f
701	45	f
702	26	f
702	80	f
703	4	f
703	12	f
704	13	f
704	77	f
705	15	f
705	19	f
706	75	f
706	80	f
707	69	f
707	79	f
708	47	f
708	39	f
709	44	f
709	40	f
710	79	f
710	50	f
711	73	f
711	74	f
712	32	f
712	72	f
713	69	f
713	92	f
714	49	f
714	60	f
715	5	f
715	66	f
716	22	f
716	43	f
717	13	f
717	17	f
718	67	f
718	21	f
719	5	f
719	1	f
720	71	f
720	44	f
721	87	f
721	34	f
722	18	f
722	32	f
723	18	f
723	15	f
724	78	f
724	83	f
725	7	f
725	58	f
726	20	f
726	61	f
727	57	f
727	80	f
728	44	f
728	74	f
729	69	f
729	62	f
730	59	f
730	72	f
731	36	f
731	78	f
732	37	f
732	70	f
733	19	f
733	32	f
734	52	f
734	88	f
735	61	f
735	58	f
736	78	f
736	49	f
737	9	f
737	59	f
738	92	f
738	90	f
739	16	f
739	49	f
740	85	f
740	83	f
741	9	f
741	57	f
742	85	f
742	88	f
743	41	f
743	75	f
744	74	f
744	13	f
745	39	f
745	53	f
746	42	f
746	29	f
747	64	f
747	36	f
748	71	f
749	65	f
749	43	f
750	56	f
750	84	f
751	13	f
751	33	f
752	77	f
752	38	f
753	6	f
753	62	f
754	72	f
754	29	f
755	86	f
755	7	f
756	57	f
756	46	f
757	9	f
757	54	f
758	31	f
758	91	f
759	24	f
759	65	f
760	76	f
760	71	f
761	54	f
761	51	f
762	47	f
762	51	f
763	76	f
763	20	f
764	15	f
764	24	f
765	4	f
765	77	f
766	52	f
766	1	f
767	33	f
767	78	f
768	10	f
768	83	f
769	26	f
769	61	f
770	6	f
770	48	f
771	10	f
771	53	f
772	42	f
772	21	f
773	57	f
773	86	f
774	58	f
774	29	f
775	59	f
775	64	f
776	24	f
776	40	f
777	32	f
777	3	f
778	77	f
778	21	f
779	41	f
779	49	f
780	12	f
780	25	f
781	45	f
781	44	f
782	90	f
782	12	f
783	44	f
783	80	f
784	82	f
784	86	f
785	35	f
785	75	f
786	85	f
786	74	f
787	44	f
787	62	f
788	73	f
788	82	f
789	51	f
789	24	f
790	9	f
790	81	f
791	24	f
791	29	f
792	27	f
792	91	f
793	41	f
793	38	f
794	23	f
794	4	f
795	71	f
795	68	f
796	58	f
796	70	f
797	32	f
797	6	f
798	61	f
798	66	f
799	17	f
799	71	f
800	32	f
800	84	f
801	57	f
801	62	f
802	11	f
802	69	f
803	48	f
803	21	f
804	57	f
804	54	f
805	83	f
805	82	f
806	1	f
806	84	f
807	30	f
807	69	f
808	83	f
808	27	f
809	61	f
809	39	f
810	35	f
810	38	f
811	20	f
811	36	f
812	11	f
812	91	f
813	28	f
813	30	f
814	10	f
814	26	f
815	54	f
815	69	f
816	22	f
816	15	f
817	26	f
817	41	f
818	31	f
818	21	f
819	86	f
819	47	f
820	19	f
820	83	f
821	36	f
821	40	f
822	44	f
822	91	f
823	7	f
823	20	f
824	23	f
824	33	f
825	91	f
825	72	f
826	5	f
826	91	f
827	43	f
827	76	f
828	11	f
828	1	f
829	11	f
829	32	f
830	65	f
830	63	f
831	67	f
831	18	f
832	33	f
832	60	f
833	69	f
833	41	f
834	25	f
834	88	f
835	8	f
835	78	f
836	12	f
836	20	f
837	2	f
837	66	f
838	84	f
838	31	f
839	40	f
839	68	f
840	91	f
840	44	f
841	86	f
841	42	f
842	59	f
842	87	f
843	21	f
843	68	f
844	13	f
844	69	f
845	31	f
845	77	f
846	42	f
846	2	f
847	35	f
847	72	f
848	17	f
848	75	f
849	31	f
849	21	f
850	88	f
850	19	f
851	12	f
851	7	f
852	8	f
852	77	f
853	59	f
853	81	f
854	78	f
854	16	f
855	78	f
855	45	f
856	90	f
856	9	f
857	87	f
857	82	f
858	21	f
859	27	f
859	36	f
860	71	f
860	51	f
861	43	f
861	83	f
862	62	f
862	63	f
863	21	f
863	44	f
864	7	f
864	90	f
865	92	f
865	81	f
866	60	f
866	69	f
867	46	f
867	74	f
868	6	f
868	53	f
869	89	f
869	75	f
870	42	f
870	15	f
871	15	f
871	61	f
872	22	f
872	48	f
873	33	f
873	55	f
874	84	f
874	71	f
875	61	f
875	70	f
876	15	f
876	5	f
877	69	f
877	31	f
878	26	f
878	51	f
879	21	f
879	75	f
880	19	f
880	81	f
881	20	f
881	48	f
882	74	f
882	68	f
883	90	f
883	16	f
884	20	f
884	78	f
885	15	f
885	75	f
886	40	f
886	91	f
887	71	f
887	40	f
888	50	f
888	41	f
889	47	f
889	85	f
890	66	f
890	63	f
891	48	f
891	25	f
892	69	f
892	87	f
893	27	f
893	74	f
894	82	f
894	41	f
895	42	f
895	61	f
896	54	f
896	77	f
897	91	f
897	9	f
898	5	f
898	19	f
899	76	f
899	39	f
900	4	f
900	18	f
901	54	f
901	25	f
902	77	f
902	52	f
903	3	f
903	75	f
904	44	f
904	70	f
905	38	f
905	1	f
906	71	f
906	31	f
907	58	f
907	24	f
908	47	f
908	79	f
909	31	f
909	1	f
910	91	f
910	23	f
911	6	f
911	13	f
912	6	f
912	23	f
913	44	f
913	58	f
914	31	f
914	56	f
915	50	f
915	75	f
916	43	f
916	63	f
917	8	f
917	10	f
918	60	f
918	36	f
919	92	f
919	63	f
920	64	f
920	5	f
921	24	f
921	52	f
922	35	f
922	9	f
923	52	f
923	22	f
924	6	f
924	22	f
925	46	f
925	38	f
926	9	f
926	15	f
927	29	f
927	58	f
928	61	f
928	49	f
929	89	f
929	90	f
930	91	f
930	14	f
931	43	f
931	83	f
932	24	f
932	46	f
933	31	f
933	61	f
934	40	f
934	80	f
935	41	f
935	65	f
936	63	f
936	66	f
937	24	f
937	67	f
938	10	f
938	74	f
939	44	f
939	92	f
940	52	f
940	34	f
941	37	f
941	87	f
942	55	f
942	39	f
943	67	f
943	82	f
944	2	f
944	34	f
945	7	f
945	76	f
946	5	f
946	10	f
947	56	f
947	15	f
948	26	f
948	64	f
949	64	f
949	34	f
950	1	f
950	28	f
951	31	f
951	17	f
952	33	f
952	57	f
953	89	f
953	35	f
954	45	f
954	31	f
955	36	f
955	78	f
956	49	f
956	70	f
957	27	f
957	48	f
958	25	f
958	44	f
959	69	f
959	32	f
960	56	f
960	23	f
961	82	f
961	14	f
962	16	f
962	46	f
963	77	f
963	71	f
964	19	f
964	91	f
965	14	f
965	4	f
966	27	f
966	36	f
967	90	f
967	51	f
968	45	f
968	69	f
969	47	f
969	12	f
970	31	f
970	22	f
971	38	f
971	40	f
972	7	f
972	53	f
973	54	f
973	3	f
974	86	f
974	26	f
975	53	f
975	40	f
976	54	f
976	18	f
977	26	f
977	40	f
978	47	f
978	63	f
979	9	f
979	6	f
980	38	f
980	1	f
981	50	f
981	26	f
982	52	f
982	65	f
983	62	f
983	17	f
984	76	f
984	92	f
985	82	f
985	52	f
986	4	f
986	6	f
987	45	f
987	10	f
988	52	f
988	84	f
989	38	f
989	79	f
990	75	f
990	25	f
991	69	f
991	81	f
992	52	f
992	88	f
993	45	f
993	62	f
994	58	f
994	37	f
995	89	f
995	21	f
996	39	f
996	56	f
997	32	f
997	70	f
998	54	f
998	68	f
999	31	f
999	63	f
1000	33	f
1000	36	f
1001	169	f
1002	148	f
1003	144	f
1004	181	f
1005	132	f
1006	140	f
1007	181	f
1008	184	f
1009	121	f
1010	126	f
1011	178	f
1012	150	f
1013	141	f
1014	165	f
1015	175	f
1016	147	f
1017	180	f
1018	183	f
1019	181	f
1020	162	f
1021	147	f
1022	158	f
1023	126	f
1024	132	f
1025	165	f
1026	122	f
1027	171	f
1028	134	f
1029	171	f
1030	140	f
1031	147	f
1032	182	f
1033	161	f
1034	145	f
1035	181	f
1036	125	f
1037	119	f
1038	128	f
1039	125	f
1040	180	f
1041	141	f
1042	153	f
1043	148	f
1044	139	f
1045	125	f
1046	180	f
1047	178	f
1048	127	f
1049	147	f
1050	144	f
1051	155	f
1052	126	f
1053	166	f
1054	164	f
1055	137	f
1056	180	f
1057	128	f
1058	169	f
1059	132	f
1060	150	f
1061	141	f
1062	138	f
1063	152	f
1064	171	f
1065	168	f
1066	173	f
1067	124	f
1068	171	f
1069	165	f
1070	140	f
1071	129	f
1072	174	f
1073	141	f
1074	121	f
1075	125	f
1076	142	f
1077	141	f
1078	119	f
1079	169	f
1080	183	f
1081	120	f
1082	121	f
1083	174	f
1084	159	f
1085	168	f
1086	147	f
1087	175	f
1088	121	f
1089	125	f
1090	178	f
1091	180	f
1092	162	f
1093	158	f
1094	155	f
1095	143	f
1096	167	f
1097	144	f
1098	151	f
1099	139	f
1100	162	f
1101	173	f
1102	178	f
1103	157	f
1104	164	f
1105	127	f
1106	143	f
1107	143	f
1108	177	f
1109	152	f
1110	147	f
1111	128	f
1112	129	f
1113	124	f
1114	131	f
1115	131	f
1116	161	f
1117	150	f
1118	154	f
1119	176	f
1120	140	f
1121	122	f
1122	167	f
1123	154	f
1124	144	f
1125	134	f
1126	132	f
1127	127	f
1128	141	f
1129	126	f
1130	139	f
1131	151	f
1132	176	f
1133	163	f
1134	133	f
1135	144	f
1136	175	f
1137	168	f
1138	163	f
1139	120	f
1140	164	f
1141	130	f
1142	146	f
1143	159	f
1144	175	f
1145	163	f
1146	146	f
1147	132	f
1148	157	f
1149	159	f
1150	177	f
1151	189	f
1152	202	f
1153	207	f
1154	212	f
1155	189	f
1156	219	f
1157	207	f
1158	185	f
1159	219	f
1160	209	f
1161	185	f
1162	196	f
1163	213	f
1164	220	f
1165	193	f
1166	185	f
1167	191	f
1168	215	f
1169	211	f
1170	192	f
1171	185	f
1172	199	f
1173	189	f
1174	210	f
1175	199	f
1176	214	f
1177	208	f
1178	200	f
1179	207	f
1180	210	f
1181	198	f
1182	206	f
1183	220	f
1184	213	f
1185	185	f
1186	215	f
1187	199	f
1188	204	f
1189	193	f
1190	212	f
1191	215	f
1192	219	f
1193	193	f
1194	201	f
1195	202	f
1196	195	f
1197	200	f
1198	212	f
1199	207	f
1200	190	f
1201	1	f
1201	23	f
1201	39	f
\.


--
-- Data for Name: pendaftaran_semas; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pendaftaran_semas (id_pendaftaran, status_hadir, nilai_ujian, no_kartu_ujian, lokasi_kota, lokasi_tempat) FROM stdin;
201	\N	\N	3046735673	Depok	Kampus UI Depok
202	\N	\N	3046735674	Jakarta Pusat	Kampus UI Salemba
203	\N	\N	3046735675	Jakarta Pusat	Gedung Serbaguna Jakpus
204	\N	\N	3046735676	Jakarta Timur	Gedung Serbaguna Jaktim
205	\N	\N	3046735677	Jakarta Selatan	Gedung Serbaguna Jaksel
206	\N	\N	3046735678	Depok	Gedung Serbaguna Depok
207	\N	\N	3046735679	Bekasi	Gedung Serbaguna Bekasi
208	\N	\N	3046735680	Tangerang	Gedung Serbaguna Tangerang
209	\N	\N	3046735681	Tangerang Selatan	Gedung Serbaguna Tangsel
210	\N	\N	3046735682	Bogor	Gedung Serbaguna Bogor
211	\N	\N	3046735683	Bandung	Gedung Serbaguna Bandung
212	\N	\N	3046735684	Jogjakarta	Gedung Serbaguna Jogjakarta
213	\N	\N	3046735685	Surabaya	Gedung Serbaguna Surabaya
214	\N	\N	3046735686	Makasar	Gedung Serbaguna Makasar
215	\N	\N	3046735687	Medan	Gedung Serbaguna Medan
216	\N	\N	3046735688	Padang	Gedung Serbaguna Padang
217	\N	\N	3046735689	Palembang	Gedung Serbaguna Palembang
218	\N	\N	3046735690	Depok	Kampus UI Depok
219	\N	\N	3046735691	Jakarta Pusat	Kampus UI Salemba
220	\N	\N	3046735692	Jakarta Pusat	Gedung Serbaguna Jakpus
221	\N	\N	3046735693	Jakarta Timur	Gedung Serbaguna Jaktim
222	\N	\N	3046735694	Jakarta Selatan	Gedung Serbaguna Jaksel
223	\N	\N	3046735695	Depok	Gedung Serbaguna Depok
224	\N	\N	3046735696	Bekasi	Gedung Serbaguna Bekasi
225	\N	\N	3046735697	Tangerang	Gedung Serbaguna Tangerang
226	\N	\N	3046735698	Tangerang Selatan	Gedung Serbaguna Tangsel
227	\N	\N	3046735699	Bogor	Gedung Serbaguna Bogor
228	\N	\N	3046735700	Bandung	Gedung Serbaguna Bandung
229	\N	\N	3046735701	Jogjakarta	Gedung Serbaguna Jogjakarta
230	\N	\N	3046735702	Surabaya	Gedung Serbaguna Surabaya
231	\N	\N	3046735703	Makasar	Gedung Serbaguna Makasar
232	\N	\N	3046735704	Medan	Gedung Serbaguna Medan
233	\N	\N	3046735705	Padang	Gedung Serbaguna Padang
234	\N	\N	3046735706	Palembang	Gedung Serbaguna Palembang
235	\N	\N	3046735707	Depok	Kampus UI Depok
236	\N	\N	3046735708	Jakarta Pusat	Kampus UI Salemba
237	\N	\N	3046735709	Jakarta Pusat	Gedung Serbaguna Jakpus
238	\N	\N	3046735710	Jakarta Timur	Gedung Serbaguna Jaktim
239	\N	\N	3046735711	Jakarta Selatan	Gedung Serbaguna Jaksel
240	\N	\N	3046735712	Depok	Gedung Serbaguna Depok
241	\N	\N	3046735713	Bekasi	Gedung Serbaguna Bekasi
242	\N	\N	3046735714	Tangerang	Gedung Serbaguna Tangerang
243	\N	\N	3046735715	Tangerang Selatan	Gedung Serbaguna Tangsel
244	\N	\N	3046735716	Bogor	Gedung Serbaguna Bogor
245	\N	\N	3046735717	Bandung	Gedung Serbaguna Bandung
246	\N	\N	3046735718	Jogjakarta	Gedung Serbaguna Jogjakarta
247	\N	\N	3046735719	Surabaya	Gedung Serbaguna Surabaya
248	\N	\N	3046735720	Makasar	Gedung Serbaguna Makasar
249	\N	\N	3046735721	Medan	Gedung Serbaguna Medan
250	\N	\N	3046735722	Padang	Gedung Serbaguna Padang
251	\N	\N	3046735723	Palembang	Gedung Serbaguna Palembang
252	\N	\N	3046735724	Depok	Kampus UI Depok
253	\N	\N	3046735725	Jakarta Pusat	Kampus UI Salemba
254	\N	\N	3046735726	Jakarta Pusat	Gedung Serbaguna Jakpus
255	\N	\N	3046735727	Jakarta Timur	Gedung Serbaguna Jaktim
256	\N	\N	3046735728	Jakarta Selatan	Gedung Serbaguna Jaksel
257	\N	\N	3046735729	Depok	Gedung Serbaguna Depok
258	\N	\N	3046735730	Bekasi	Gedung Serbaguna Bekasi
259	\N	\N	3046735731	Tangerang	Gedung Serbaguna Tangerang
260	\N	\N	3046735732	Tangerang Selatan	Gedung Serbaguna Tangsel
261	\N	\N	3046735733	Bogor	Gedung Serbaguna Bogor
262	\N	\N	3046735734	Bandung	Gedung Serbaguna Bandung
263	\N	\N	3046735735	Jogjakarta	Gedung Serbaguna Jogjakarta
264	\N	\N	3046735736	Surabaya	Gedung Serbaguna Surabaya
265	\N	\N	3046735737	Makasar	Gedung Serbaguna Makasar
266	\N	\N	3046735738	Medan	Gedung Serbaguna Medan
267	\N	\N	3046735739	Padang	Gedung Serbaguna Padang
268	\N	\N	3046735740	Palembang	Gedung Serbaguna Palembang
269	\N	\N	3046735741	Depok	Kampus UI Depok
270	\N	\N	3046735742	Jakarta Pusat	Kampus UI Salemba
271	\N	\N	3046735743	Jakarta Pusat	Gedung Serbaguna Jakpus
272	\N	\N	3046735744	Jakarta Timur	Gedung Serbaguna Jaktim
273	\N	\N	3046735745	Jakarta Selatan	Gedung Serbaguna Jaksel
274	\N	\N	3046735746	Depok	Gedung Serbaguna Depok
275	\N	\N	3046735747	Bekasi	Gedung Serbaguna Bekasi
276	\N	\N	3046735748	Tangerang	Gedung Serbaguna Tangerang
277	\N	\N	3046735749	Tangerang Selatan	Gedung Serbaguna Tangsel
278	\N	\N	3046735750	Bogor	Gedung Serbaguna Bogor
279	\N	\N	3046735751	Bandung	Gedung Serbaguna Bandung
280	\N	\N	3046735752	Jogjakarta	Gedung Serbaguna Jogjakarta
281	\N	\N	3046735753	Surabaya	Gedung Serbaguna Surabaya
282	\N	\N	3046735754	Makasar	Gedung Serbaguna Makasar
283	\N	\N	3046735755	Medan	Gedung Serbaguna Medan
284	\N	\N	3046735756	Padang	Gedung Serbaguna Padang
285	\N	\N	3046735757	Palembang	Gedung Serbaguna Palembang
286	\N	\N	3046735758	Depok	Kampus UI Depok
287	\N	\N	3046735759	Jakarta Pusat	Kampus UI Salemba
288	\N	\N	3046735760	Jakarta Pusat	Gedung Serbaguna Jakpus
289	\N	\N	3046735761	Jakarta Timur	Gedung Serbaguna Jaktim
290	\N	\N	3046735762	Jakarta Selatan	Gedung Serbaguna Jaksel
291	\N	\N	3046735763	Depok	Gedung Serbaguna Depok
292	\N	\N	3046735764	Bekasi	Gedung Serbaguna Bekasi
293	\N	\N	3046735765	Tangerang	Gedung Serbaguna Tangerang
294	\N	\N	3046735766	Tangerang Selatan	Gedung Serbaguna Tangsel
295	\N	\N	3046735767	Bogor	Gedung Serbaguna Bogor
296	\N	\N	3046735768	Bandung	Gedung Serbaguna Bandung
297	\N	\N	3046735769	Jogjakarta	Gedung Serbaguna Jogjakarta
298	\N	\N	3046735770	Surabaya	Gedung Serbaguna Surabaya
299	\N	\N	3046735771	Makasar	Gedung Serbaguna Makasar
300	\N	\N	3046735772	Medan	Gedung Serbaguna Medan
301	\N	\N	3046735773	Padang	Gedung Serbaguna Padang
302	\N	\N	3046735774	Palembang	Gedung Serbaguna Palembang
303	\N	\N	3046735775	Depok	Kampus UI Depok
304	\N	\N	3046735776	Jakarta Pusat	Kampus UI Salemba
305	\N	\N	3046735777	Jakarta Pusat	Gedung Serbaguna Jakpus
306	\N	\N	3046735778	Jakarta Timur	Gedung Serbaguna Jaktim
307	\N	\N	3046735779	Jakarta Selatan	Gedung Serbaguna Jaksel
308	\N	\N	3046735780	Depok	Gedung Serbaguna Depok
309	\N	\N	3046735781	Bekasi	Gedung Serbaguna Bekasi
310	\N	\N	3046735782	Tangerang	Gedung Serbaguna Tangerang
311	\N	\N	3046735783	Tangerang Selatan	Gedung Serbaguna Tangsel
312	\N	\N	3046735784	Bogor	Gedung Serbaguna Bogor
313	\N	\N	3046735785	Bandung	Gedung Serbaguna Bandung
314	\N	\N	3046735786	Jogjakarta	Gedung Serbaguna Jogjakarta
315	\N	\N	3046735787	Surabaya	Gedung Serbaguna Surabaya
316	\N	\N	3046735788	Makasar	Gedung Serbaguna Makasar
317	\N	\N	3046735789	Medan	Gedung Serbaguna Medan
318	\N	\N	3046735790	Padang	Gedung Serbaguna Padang
319	\N	\N	3046735791	Palembang	Gedung Serbaguna Palembang
320	\N	\N	3046735792	Depok	Kampus UI Depok
321	\N	\N	3046735793	Jakarta Pusat	Kampus UI Salemba
322	\N	\N	3046735794	Jakarta Pusat	Gedung Serbaguna Jakpus
323	\N	\N	3046735795	Jakarta Timur	Gedung Serbaguna Jaktim
324	\N	\N	3046735796	Jakarta Selatan	Gedung Serbaguna Jaksel
325	\N	\N	3046735797	Depok	Gedung Serbaguna Depok
326	\N	\N	3046735798	Bekasi	Gedung Serbaguna Bekasi
327	\N	\N	3046735799	Tangerang	Gedung Serbaguna Tangerang
328	\N	\N	3046735800	Tangerang Selatan	Gedung Serbaguna Tangsel
329	\N	\N	3046735801	Bogor	Gedung Serbaguna Bogor
330	\N	\N	3046735802	Bandung	Gedung Serbaguna Bandung
331	\N	\N	3046735803	Jogjakarta	Gedung Serbaguna Jogjakarta
332	\N	\N	3046735804	Surabaya	Gedung Serbaguna Surabaya
333	\N	\N	3046735805	Makasar	Gedung Serbaguna Makasar
334	\N	\N	3046735806	Medan	Gedung Serbaguna Medan
335	\N	\N	3046735807	Padang	Gedung Serbaguna Padang
336	\N	\N	3046735808	Palembang	Gedung Serbaguna Palembang
337	\N	\N	3046735809	Depok	Kampus UI Depok
338	\N	\N	3046735810	Jakarta Pusat	Kampus UI Salemba
339	\N	\N	3046735811	Jakarta Pusat	Gedung Serbaguna Jakpus
340	\N	\N	3046735812	Jakarta Timur	Gedung Serbaguna Jaktim
341	\N	\N	3046735813	Jakarta Selatan	Gedung Serbaguna Jaksel
342	\N	\N	3046735814	Depok	Gedung Serbaguna Depok
343	\N	\N	3046735815	Bekasi	Gedung Serbaguna Bekasi
344	\N	\N	3046735816	Tangerang	Gedung Serbaguna Tangerang
345	\N	\N	3046735817	Tangerang Selatan	Gedung Serbaguna Tangsel
346	\N	\N	3046735818	Bogor	Gedung Serbaguna Bogor
347	\N	\N	3046735819	Bandung	Gedung Serbaguna Bandung
348	\N	\N	3046735820	Jogjakarta	Gedung Serbaguna Jogjakarta
349	\N	\N	3046735821	Surabaya	Gedung Serbaguna Surabaya
350	\N	\N	3046735822	Makasar	Gedung Serbaguna Makasar
351	\N	\N	3046735823	Medan	Gedung Serbaguna Medan
352	\N	\N	3046735824	Padang	Gedung Serbaguna Padang
353	\N	\N	3046735825	Palembang	Gedung Serbaguna Palembang
354	\N	\N	3046735826	Depok	Kampus UI Depok
355	\N	\N	3046735827	Jakarta Pusat	Kampus UI Salemba
356	\N	\N	3046735828	Jakarta Pusat	Gedung Serbaguna Jakpus
357	\N	\N	3046735829	Jakarta Timur	Gedung Serbaguna Jaktim
358	\N	\N	3046735830	Jakarta Selatan	Gedung Serbaguna Jaksel
359	\N	\N	3046735831	Depok	Gedung Serbaguna Depok
360	\N	\N	3046735832	Bekasi	Gedung Serbaguna Bekasi
361	\N	\N	3046735833	Tangerang	Gedung Serbaguna Tangerang
362	\N	\N	3046735834	Tangerang Selatan	Gedung Serbaguna Tangsel
363	\N	\N	3046735835	Bogor	Gedung Serbaguna Bogor
364	\N	\N	3046735836	Bandung	Gedung Serbaguna Bandung
365	\N	\N	3046735837	Jogjakarta	Gedung Serbaguna Jogjakarta
366	\N	\N	3046735838	Surabaya	Gedung Serbaguna Surabaya
367	\N	\N	3046735839	Makasar	Gedung Serbaguna Makasar
368	\N	\N	3046735840	Medan	Gedung Serbaguna Medan
369	\N	\N	3046735841	Padang	Gedung Serbaguna Padang
370	\N	\N	3046735842	Palembang	Gedung Serbaguna Palembang
371	\N	\N	3046735843	Depok	Kampus UI Depok
372	\N	\N	3046735844	Jakarta Pusat	Kampus UI Salemba
373	\N	\N	3046735845	Jakarta Pusat	Gedung Serbaguna Jakpus
374	\N	\N	3046735846	Jakarta Timur	Gedung Serbaguna Jaktim
375	\N	\N	3046735847	Jakarta Selatan	Gedung Serbaguna Jaksel
376	\N	\N	3046735848	Depok	Gedung Serbaguna Depok
377	\N	\N	3046735849	Bekasi	Gedung Serbaguna Bekasi
378	\N	\N	3046735850	Tangerang	Gedung Serbaguna Tangerang
379	\N	\N	3046735851	Tangerang Selatan	Gedung Serbaguna Tangsel
380	\N	\N	3046735852	Bogor	Gedung Serbaguna Bogor
381	\N	\N	3046735853	Bandung	Gedung Serbaguna Bandung
382	\N	\N	3046735854	Jogjakarta	Gedung Serbaguna Jogjakarta
383	\N	\N	3046735855	Surabaya	Gedung Serbaguna Surabaya
384	\N	\N	3046735856	Makasar	Gedung Serbaguna Makasar
385	\N	\N	3046735857	Medan	Gedung Serbaguna Medan
386	\N	\N	3046735858	Padang	Gedung Serbaguna Padang
387	\N	\N	3046735859	Palembang	Gedung Serbaguna Palembang
388	\N	\N	3046735860	Depok	Kampus UI Depok
389	\N	\N	3046735861	Jakarta Pusat	Kampus UI Salemba
390	\N	\N	3046735862	Jakarta Pusat	Gedung Serbaguna Jakpus
391	\N	\N	3046735863	Jakarta Timur	Gedung Serbaguna Jaktim
392	\N	\N	3046735864	Jakarta Selatan	Gedung Serbaguna Jaksel
393	\N	\N	3046735865	Depok	Gedung Serbaguna Depok
394	\N	\N	3046735866	Bekasi	Gedung Serbaguna Bekasi
395	\N	\N	3046735867	Tangerang	Gedung Serbaguna Tangerang
396	\N	\N	3046735868	Tangerang Selatan	Gedung Serbaguna Tangsel
397	\N	\N	3046735869	Bogor	Gedung Serbaguna Bogor
398	\N	\N	3046735870	Bandung	Gedung Serbaguna Bandung
399	\N	\N	3046735871	Jogjakarta	Gedung Serbaguna Jogjakarta
400	\N	\N	3046735872	Surabaya	Gedung Serbaguna Surabaya
401	\N	\N	3046735873	Makasar	Gedung Serbaguna Makasar
402	\N	\N	3046735874	Medan	Gedung Serbaguna Medan
403	\N	\N	3046735875	Padang	Gedung Serbaguna Padang
404	\N	\N	3046735876	Palembang	Gedung Serbaguna Palembang
405	\N	\N	3046735877	Depok	Kampus UI Depok
406	\N	\N	3046735878	Jakarta Pusat	Kampus UI Salemba
407	\N	\N	3046735879	Jakarta Pusat	Gedung Serbaguna Jakpus
408	\N	\N	3046735880	Jakarta Timur	Gedung Serbaguna Jaktim
409	\N	\N	3046735881	Jakarta Selatan	Gedung Serbaguna Jaksel
410	\N	\N	3046735882	Depok	Gedung Serbaguna Depok
411	\N	\N	3046735883	Bekasi	Gedung Serbaguna Bekasi
412	\N	\N	3046735884	Tangerang	Gedung Serbaguna Tangerang
413	\N	\N	3046735885	Tangerang Selatan	Gedung Serbaguna Tangsel
414	\N	\N	3046735886	Bogor	Gedung Serbaguna Bogor
415	\N	\N	3046735887	Bandung	Gedung Serbaguna Bandung
416	\N	\N	3046735888	Jogjakarta	Gedung Serbaguna Jogjakarta
417	\N	\N	3046735889	Surabaya	Gedung Serbaguna Surabaya
418	\N	\N	3046735890	Makasar	Gedung Serbaguna Makasar
419	\N	\N	3046735891	Medan	Gedung Serbaguna Medan
420	\N	\N	3046735892	Padang	Gedung Serbaguna Padang
421	\N	\N	3046735893	Palembang	Gedung Serbaguna Palembang
422	\N	\N	3046735894	Depok	Kampus UI Depok
423	\N	\N	3046735895	Jakarta Pusat	Kampus UI Salemba
424	\N	\N	3046735896	Jakarta Pusat	Gedung Serbaguna Jakpus
425	\N	\N	3046735897	Jakarta Timur	Gedung Serbaguna Jaktim
426	\N	\N	3046735898	Jakarta Selatan	Gedung Serbaguna Jaksel
427	\N	\N	3046735899	Depok	Gedung Serbaguna Depok
428	\N	\N	3046735900	Bekasi	Gedung Serbaguna Bekasi
429	\N	\N	3046735901	Tangerang	Gedung Serbaguna Tangerang
430	\N	\N	3046735902	Tangerang Selatan	Gedung Serbaguna Tangsel
431	\N	\N	3046735903	Bogor	Gedung Serbaguna Bogor
432	\N	\N	3046735904	Bandung	Gedung Serbaguna Bandung
433	\N	\N	3046735905	Jogjakarta	Gedung Serbaguna Jogjakarta
434	\N	\N	3046735906	Surabaya	Gedung Serbaguna Surabaya
435	\N	\N	3046735907	Makasar	Gedung Serbaguna Makasar
436	\N	\N	3046735908	Medan	Gedung Serbaguna Medan
437	\N	\N	3046735909	Padang	Gedung Serbaguna Padang
438	\N	\N	3046735910	Palembang	Gedung Serbaguna Palembang
439	\N	\N	3046735911	Depok	Kampus UI Depok
440	\N	\N	3046735912	Jakarta Pusat	Kampus UI Salemba
441	\N	\N	3046735913	Jakarta Pusat	Gedung Serbaguna Jakpus
442	\N	\N	3046735914	Jakarta Timur	Gedung Serbaguna Jaktim
443	\N	\N	3046735915	Jakarta Selatan	Gedung Serbaguna Jaksel
444	\N	\N	3046735916	Depok	Gedung Serbaguna Depok
445	\N	\N	3046735917	Bekasi	Gedung Serbaguna Bekasi
446	\N	\N	3046735918	Tangerang	Gedung Serbaguna Tangerang
447	\N	\N	3046735919	Tangerang Selatan	Gedung Serbaguna Tangsel
448	\N	\N	3046735920	Bogor	Gedung Serbaguna Bogor
449	\N	\N	3046735921	Bandung	Gedung Serbaguna Bandung
450	\N	\N	3046735922	Jogjakarta	Gedung Serbaguna Jogjakarta
451	\N	\N	3046735923	Surabaya	Gedung Serbaguna Surabaya
452	\N	\N	3046735924	Makasar	Gedung Serbaguna Makasar
453	\N	\N	3046735925	Medan	Gedung Serbaguna Medan
454	\N	\N	3046735926	Padang	Gedung Serbaguna Padang
455	\N	\N	3046735927	Palembang	Gedung Serbaguna Palembang
456	\N	\N	3046735928	Depok	Kampus UI Depok
457	\N	\N	3046735929	Jakarta Pusat	Kampus UI Salemba
458	\N	\N	3046735930	Jakarta Pusat	Gedung Serbaguna Jakpus
459	\N	\N	3046735931	Jakarta Timur	Gedung Serbaguna Jaktim
460	\N	\N	3046735932	Jakarta Selatan	Gedung Serbaguna Jaksel
461	\N	\N	3046735933	Depok	Gedung Serbaguna Depok
462	\N	\N	3046735934	Bekasi	Gedung Serbaguna Bekasi
463	\N	\N	3046735935	Tangerang	Gedung Serbaguna Tangerang
464	\N	\N	3046735936	Tangerang Selatan	Gedung Serbaguna Tangsel
465	\N	\N	3046735937	Bogor	Gedung Serbaguna Bogor
466	\N	\N	3046735938	Bandung	Gedung Serbaguna Bandung
467	\N	\N	3046735939	Jogjakarta	Gedung Serbaguna Jogjakarta
468	\N	\N	3046735940	Surabaya	Gedung Serbaguna Surabaya
469	\N	\N	3046735941	Makasar	Gedung Serbaguna Makasar
470	\N	\N	3046735942	Medan	Gedung Serbaguna Medan
471	\N	\N	3046735943	Padang	Gedung Serbaguna Padang
472	\N	\N	3046735944	Palembang	Gedung Serbaguna Palembang
473	\N	\N	3046735945	Depok	Kampus UI Depok
474	\N	\N	3046735946	Jakarta Pusat	Kampus UI Salemba
475	\N	\N	3046735947	Jakarta Pusat	Gedung Serbaguna Jakpus
476	\N	\N	3046735948	Jakarta Timur	Gedung Serbaguna Jaktim
477	\N	\N	3046735949	Jakarta Selatan	Gedung Serbaguna Jaksel
478	\N	\N	3046735950	Depok	Gedung Serbaguna Depok
479	\N	\N	3046735951	Bekasi	Gedung Serbaguna Bekasi
480	\N	\N	3046735952	Tangerang	Gedung Serbaguna Tangerang
481	\N	\N	3046735953	Tangerang Selatan	Gedung Serbaguna Tangsel
482	\N	\N	3046735954	Bogor	Gedung Serbaguna Bogor
483	\N	\N	3046735955	Bandung	Gedung Serbaguna Bandung
484	\N	\N	3046735956	Jogjakarta	Gedung Serbaguna Jogjakarta
485	\N	\N	3046735957	Surabaya	Gedung Serbaguna Surabaya
486	\N	\N	3046735958	Makasar	Gedung Serbaguna Makasar
487	\N	\N	3046735959	Medan	Gedung Serbaguna Medan
488	\N	\N	3046735960	Padang	Gedung Serbaguna Padang
489	\N	\N	3046735961	Palembang	Gedung Serbaguna Palembang
490	\N	\N	3046735962	Depok	Kampus UI Depok
491	\N	\N	3046735963	Jakarta Pusat	Kampus UI Salemba
492	\N	\N	3046735964	Jakarta Pusat	Gedung Serbaguna Jakpus
493	\N	\N	3046735965	Jakarta Timur	Gedung Serbaguna Jaktim
494	\N	\N	3046735966	Jakarta Selatan	Gedung Serbaguna Jaksel
495	\N	\N	3046735967	Depok	Gedung Serbaguna Depok
496	\N	\N	3046735968	Bekasi	Gedung Serbaguna Bekasi
497	\N	\N	3046735969	Tangerang	Gedung Serbaguna Tangerang
498	\N	\N	3046735970	Tangerang Selatan	Gedung Serbaguna Tangsel
499	\N	\N	3046735971	Bogor	Gedung Serbaguna Bogor
500	\N	\N	3046735972	Bandung	Gedung Serbaguna Bandung
501	\N	\N	3046735973	Jogjakarta	Gedung Serbaguna Jogjakarta
502	\N	\N	3046735974	Surabaya	Gedung Serbaguna Surabaya
503	\N	\N	3046735975	Makasar	Gedung Serbaguna Makasar
504	\N	\N	3046735976	Medan	Gedung Serbaguna Medan
505	\N	\N	3046735977	Padang	Gedung Serbaguna Padang
506	\N	\N	3046735978	Palembang	Gedung Serbaguna Palembang
507	\N	\N	3046735979	Depok	Kampus UI Depok
508	\N	\N	3046735980	Jakarta Pusat	Kampus UI Salemba
509	\N	\N	3046735981	Jakarta Pusat	Gedung Serbaguna Jakpus
510	\N	\N	3046735982	Jakarta Timur	Gedung Serbaguna Jaktim
511	\N	\N	3046735983	Jakarta Selatan	Gedung Serbaguna Jaksel
512	\N	\N	3046735984	Depok	Gedung Serbaguna Depok
513	\N	\N	3046735985	Bekasi	Gedung Serbaguna Bekasi
514	\N	\N	3046735986	Tangerang	Gedung Serbaguna Tangerang
515	\N	\N	3046735987	Tangerang Selatan	Gedung Serbaguna Tangsel
516	\N	\N	3046735988	Bogor	Gedung Serbaguna Bogor
517	\N	\N	3046735989	Bandung	Gedung Serbaguna Bandung
518	\N	\N	3046735990	Jogjakarta	Gedung Serbaguna Jogjakarta
519	\N	\N	3046735991	Surabaya	Gedung Serbaguna Surabaya
520	\N	\N	3046735992	Makasar	Gedung Serbaguna Makasar
521	\N	\N	3046735993	Medan	Gedung Serbaguna Medan
522	\N	\N	3046735994	Padang	Gedung Serbaguna Padang
523	\N	\N	3046735995	Palembang	Gedung Serbaguna Palembang
524	\N	\N	3046735996	Depok	Kampus UI Depok
525	\N	\N	3046735997	Jakarta Pusat	Kampus UI Salemba
526	\N	\N	3046735998	Jakarta Pusat	Gedung Serbaguna Jakpus
527	\N	\N	3046735999	Jakarta Timur	Gedung Serbaguna Jaktim
528	\N	\N	3046736000	Jakarta Selatan	Gedung Serbaguna Jaksel
529	\N	\N	3046736001	Depok	Gedung Serbaguna Depok
530	\N	\N	3046736002	Bekasi	Gedung Serbaguna Bekasi
531	\N	\N	3046736003	Tangerang	Gedung Serbaguna Tangerang
532	\N	\N	3046736004	Tangerang Selatan	Gedung Serbaguna Tangsel
533	\N	\N	3046736005	Bogor	Gedung Serbaguna Bogor
534	\N	\N	3046736006	Bandung	Gedung Serbaguna Bandung
535	\N	\N	3046736007	Jogjakarta	Gedung Serbaguna Jogjakarta
536	\N	\N	3046736008	Surabaya	Gedung Serbaguna Surabaya
537	\N	\N	3046736009	Makasar	Gedung Serbaguna Makasar
538	\N	\N	3046736010	Medan	Gedung Serbaguna Medan
539	\N	\N	3046736011	Padang	Gedung Serbaguna Padang
540	\N	\N	3046736012	Palembang	Gedung Serbaguna Palembang
541	\N	\N	3046736013	Depok	Kampus UI Depok
542	\N	\N	3046736014	Jakarta Pusat	Kampus UI Salemba
543	\N	\N	3046736015	Jakarta Pusat	Gedung Serbaguna Jakpus
544	\N	\N	3046736016	Jakarta Timur	Gedung Serbaguna Jaktim
545	\N	\N	3046736017	Jakarta Selatan	Gedung Serbaguna Jaksel
546	\N	\N	3046736018	Depok	Gedung Serbaguna Depok
547	\N	\N	3046736019	Bekasi	Gedung Serbaguna Bekasi
548	\N	\N	3046736020	Tangerang	Gedung Serbaguna Tangerang
549	\N	\N	3046736021	Tangerang Selatan	Gedung Serbaguna Tangsel
550	\N	\N	3046736022	Bogor	Gedung Serbaguna Bogor
551	\N	\N	3046736023	Bandung	Gedung Serbaguna Bandung
552	\N	\N	3046736024	Jogjakarta	Gedung Serbaguna Jogjakarta
553	\N	\N	3046736025	Surabaya	Gedung Serbaguna Surabaya
554	\N	\N	3046736026	Makasar	Gedung Serbaguna Makasar
555	\N	\N	3046736027	Medan	Gedung Serbaguna Medan
556	\N	\N	3046736028	Padang	Gedung Serbaguna Padang
557	\N	\N	3046736029	Palembang	Gedung Serbaguna Palembang
558	\N	\N	3046736030	Depok	Kampus UI Depok
559	\N	\N	3046736031	Jakarta Pusat	Kampus UI Salemba
560	\N	\N	3046736032	Jakarta Pusat	Gedung Serbaguna Jakpus
561	\N	\N	3046736033	Jakarta Timur	Gedung Serbaguna Jaktim
562	\N	\N	3046736034	Jakarta Selatan	Gedung Serbaguna Jaksel
563	\N	\N	3046736035	Depok	Gedung Serbaguna Depok
564	\N	\N	3046736036	Bekasi	Gedung Serbaguna Bekasi
565	\N	\N	3046736037	Tangerang	Gedung Serbaguna Tangerang
566	\N	\N	3046736038	Tangerang Selatan	Gedung Serbaguna Tangsel
567	\N	\N	3046736039	Bogor	Gedung Serbaguna Bogor
568	\N	\N	3046736040	Bandung	Gedung Serbaguna Bandung
569	\N	\N	3046736041	Jogjakarta	Gedung Serbaguna Jogjakarta
570	\N	\N	3046736042	Surabaya	Gedung Serbaguna Surabaya
571	\N	\N	3046736043	Makasar	Gedung Serbaguna Makasar
572	\N	\N	3046736044	Medan	Gedung Serbaguna Medan
573	\N	\N	3046736045	Padang	Gedung Serbaguna Padang
574	\N	\N	3046736046	Palembang	Gedung Serbaguna Palembang
575	\N	\N	3046736047	Depok	Kampus UI Depok
576	\N	\N	3046736048	Jakarta Pusat	Kampus UI Salemba
577	\N	\N	3046736049	Jakarta Pusat	Gedung Serbaguna Jakpus
578	\N	\N	3046736050	Jakarta Timur	Gedung Serbaguna Jaktim
579	\N	\N	3046736051	Jakarta Selatan	Gedung Serbaguna Jaksel
580	\N	\N	3046736052	Depok	Gedung Serbaguna Depok
581	\N	\N	3046736053	Bekasi	Gedung Serbaguna Bekasi
582	\N	\N	3046736054	Tangerang	Gedung Serbaguna Tangerang
583	\N	\N	3046736055	Tangerang Selatan	Gedung Serbaguna Tangsel
584	\N	\N	3046736056	Bogor	Gedung Serbaguna Bogor
585	\N	\N	3046736057	Bandung	Gedung Serbaguna Bandung
586	\N	\N	3046736058	Jogjakarta	Gedung Serbaguna Jogjakarta
587	\N	\N	3046736059	Surabaya	Gedung Serbaguna Surabaya
588	\N	\N	3046736060	Makasar	Gedung Serbaguna Makasar
589	\N	\N	3046736061	Medan	Gedung Serbaguna Medan
590	\N	\N	3046736062	Padang	Gedung Serbaguna Padang
591	\N	\N	3046736063	Palembang	Gedung Serbaguna Palembang
592	\N	\N	3046736064	Depok	Kampus UI Depok
593	\N	\N	3046736065	Jakarta Pusat	Kampus UI Salemba
594	\N	\N	3046736066	Jakarta Pusat	Gedung Serbaguna Jakpus
595	\N	\N	3046736067	Jakarta Timur	Gedung Serbaguna Jaktim
596	\N	\N	3046736068	Jakarta Selatan	Gedung Serbaguna Jaksel
597	\N	\N	3046736069	Depok	Gedung Serbaguna Depok
598	\N	\N	3046736070	Bekasi	Gedung Serbaguna Bekasi
599	\N	\N	3046736071	Tangerang	Gedung Serbaguna Tangerang
600	\N	\N	3046736072	Tangerang Selatan	Gedung Serbaguna Tangsel
601	\N	\N	3046736073	Bogor	Gedung Serbaguna Bogor
602	\N	\N	3046736074	Bandung	Gedung Serbaguna Bandung
603	\N	\N	3046736075	Jogjakarta	Gedung Serbaguna Jogjakarta
604	\N	\N	3046736076	Surabaya	Gedung Serbaguna Surabaya
605	\N	\N	3046736077	Makasar	Gedung Serbaguna Makasar
606	\N	\N	3046736078	Medan	Gedung Serbaguna Medan
607	\N	\N	3046736079	Padang	Gedung Serbaguna Padang
608	\N	\N	3046736080	Palembang	Gedung Serbaguna Palembang
609	\N	\N	3046736081	Depok	Kampus UI Depok
610	\N	\N	3046736082	Jakarta Pusat	Kampus UI Salemba
611	\N	\N	3046736083	Jakarta Pusat	Gedung Serbaguna Jakpus
612	\N	\N	3046736084	Jakarta Timur	Gedung Serbaguna Jaktim
613	\N	\N	3046736085	Jakarta Selatan	Gedung Serbaguna Jaksel
614	\N	\N	3046736086	Depok	Gedung Serbaguna Depok
615	\N	\N	3046736087	Bekasi	Gedung Serbaguna Bekasi
616	\N	\N	3046736088	Tangerang	Gedung Serbaguna Tangerang
617	\N	\N	3046736089	Tangerang Selatan	Gedung Serbaguna Tangsel
618	\N	\N	3046736090	Bogor	Gedung Serbaguna Bogor
619	\N	\N	3046736091	Bandung	Gedung Serbaguna Bandung
620	\N	\N	3046736092	Jogjakarta	Gedung Serbaguna Jogjakarta
621	\N	\N	3046736093	Surabaya	Gedung Serbaguna Surabaya
622	\N	\N	3046736094	Makasar	Gedung Serbaguna Makasar
623	\N	\N	3046736095	Medan	Gedung Serbaguna Medan
624	\N	\N	3046736096	Padang	Gedung Serbaguna Padang
625	\N	\N	3046736097	Palembang	Gedung Serbaguna Palembang
626	\N	\N	3046736098	Depok	Kampus UI Depok
627	\N	\N	3046736099	Jakarta Pusat	Kampus UI Salemba
628	\N	\N	3046736100	Jakarta Pusat	Gedung Serbaguna Jakpus
629	\N	\N	3046736101	Jakarta Timur	Gedung Serbaguna Jaktim
630	\N	\N	3046736102	Jakarta Selatan	Gedung Serbaguna Jaksel
631	\N	\N	3046736103	Depok	Gedung Serbaguna Depok
632	\N	\N	3046736104	Bekasi	Gedung Serbaguna Bekasi
633	\N	\N	3046736105	Tangerang	Gedung Serbaguna Tangerang
634	\N	\N	3046736106	Tangerang Selatan	Gedung Serbaguna Tangsel
635	\N	\N	3046736107	Bogor	Gedung Serbaguna Bogor
636	\N	\N	3046736108	Bandung	Gedung Serbaguna Bandung
637	\N	\N	3046736109	Jogjakarta	Gedung Serbaguna Jogjakarta
638	\N	\N	3046736110	Surabaya	Gedung Serbaguna Surabaya
639	\N	\N	3046736111	Makasar	Gedung Serbaguna Makasar
640	\N	\N	3046736112	Medan	Gedung Serbaguna Medan
641	\N	\N	3046736113	Padang	Gedung Serbaguna Padang
642	\N	\N	3046736114	Palembang	Gedung Serbaguna Palembang
643	\N	\N	3046736115	Depok	Kampus UI Depok
644	\N	\N	3046736116	Jakarta Pusat	Kampus UI Salemba
645	\N	\N	3046736117	Jakarta Pusat	Gedung Serbaguna Jakpus
646	\N	\N	3046736118	Jakarta Timur	Gedung Serbaguna Jaktim
647	\N	\N	3046736119	Jakarta Selatan	Gedung Serbaguna Jaksel
648	\N	\N	3046736120	Depok	Gedung Serbaguna Depok
649	\N	\N	3046736121	Bekasi	Gedung Serbaguna Bekasi
650	\N	\N	3046736122	Tangerang	Gedung Serbaguna Tangerang
651	\N	\N	3046736123	Tangerang Selatan	Gedung Serbaguna Tangsel
652	\N	\N	3046736124	Bogor	Gedung Serbaguna Bogor
653	\N	\N	3046736125	Bandung	Gedung Serbaguna Bandung
654	\N	\N	3046736126	Jogjakarta	Gedung Serbaguna Jogjakarta
655	\N	\N	3046736127	Surabaya	Gedung Serbaguna Surabaya
656	\N	\N	3046736128	Makasar	Gedung Serbaguna Makasar
657	\N	\N	3046736129	Medan	Gedung Serbaguna Medan
658	\N	\N	3046736130	Padang	Gedung Serbaguna Padang
659	\N	\N	3046736131	Palembang	Gedung Serbaguna Palembang
660	\N	\N	3046736132	Depok	Kampus UI Depok
661	\N	\N	3046736133	Jakarta Pusat	Kampus UI Salemba
662	\N	\N	3046736134	Jakarta Pusat	Gedung Serbaguna Jakpus
663	\N	\N	3046736135	Jakarta Timur	Gedung Serbaguna Jaktim
664	\N	\N	3046736136	Jakarta Selatan	Gedung Serbaguna Jaksel
665	\N	\N	3046736137	Depok	Gedung Serbaguna Depok
666	\N	\N	3046736138	Bekasi	Gedung Serbaguna Bekasi
667	\N	\N	3046736139	Tangerang	Gedung Serbaguna Tangerang
668	\N	\N	3046736140	Tangerang Selatan	Gedung Serbaguna Tangsel
669	\N	\N	3046736141	Bogor	Gedung Serbaguna Bogor
670	\N	\N	3046736142	Bandung	Gedung Serbaguna Bandung
671	\N	\N	3046736143	Jogjakarta	Gedung Serbaguna Jogjakarta
672	\N	\N	3046736144	Surabaya	Gedung Serbaguna Surabaya
673	\N	\N	3046736145	Makasar	Gedung Serbaguna Makasar
674	\N	\N	3046736146	Medan	Gedung Serbaguna Medan
675	\N	\N	3046736147	Padang	Gedung Serbaguna Padang
676	\N	\N	3046736148	Palembang	Gedung Serbaguna Palembang
677	\N	\N	3046736149	Depok	Kampus UI Depok
678	\N	\N	3046736150	Jakarta Pusat	Kampus UI Salemba
679	\N	\N	3046736151	Jakarta Pusat	Gedung Serbaguna Jakpus
680	\N	\N	3046736152	Jakarta Timur	Gedung Serbaguna Jaktim
681	\N	\N	3046736153	Jakarta Selatan	Gedung Serbaguna Jaksel
682	\N	\N	3046736154	Depok	Gedung Serbaguna Depok
683	\N	\N	3046736155	Bekasi	Gedung Serbaguna Bekasi
684	\N	\N	3046736156	Tangerang	Gedung Serbaguna Tangerang
685	\N	\N	3046736157	Tangerang Selatan	Gedung Serbaguna Tangsel
686	\N	\N	3046736158	Bogor	Gedung Serbaguna Bogor
687	\N	\N	3046736159	Bandung	Gedung Serbaguna Bandung
688	\N	\N	3046736160	Jogjakarta	Gedung Serbaguna Jogjakarta
689	\N	\N	3046736161	Surabaya	Gedung Serbaguna Surabaya
690	\N	\N	3046736162	Makasar	Gedung Serbaguna Makasar
691	\N	\N	3046736163	Medan	Gedung Serbaguna Medan
692	\N	\N	3046736164	Padang	Gedung Serbaguna Padang
693	\N	\N	3046736165	Palembang	Gedung Serbaguna Palembang
694	\N	\N	3046736166	Depok	Kampus UI Depok
695	\N	\N	3046736167	Jakarta Pusat	Kampus UI Salemba
696	\N	\N	3046736168	Jakarta Pusat	Gedung Serbaguna Jakpus
697	\N	\N	3046736169	Jakarta Timur	Gedung Serbaguna Jaktim
698	\N	\N	3046736170	Jakarta Selatan	Gedung Serbaguna Jaksel
699	\N	\N	3046736171	Depok	Gedung Serbaguna Depok
700	\N	\N	3046736172	Bekasi	Gedung Serbaguna Bekasi
701	\N	\N	3046736173	Tangerang	Gedung Serbaguna Tangerang
702	\N	\N	3046736174	Tangerang Selatan	Gedung Serbaguna Tangsel
703	\N	\N	3046736175	Bogor	Gedung Serbaguna Bogor
704	\N	\N	3046736176	Bandung	Gedung Serbaguna Bandung
705	\N	\N	3046736177	Jogjakarta	Gedung Serbaguna Jogjakarta
706	\N	\N	3046736178	Surabaya	Gedung Serbaguna Surabaya
707	\N	\N	3046736179	Makasar	Gedung Serbaguna Makasar
708	\N	\N	3046736180	Medan	Gedung Serbaguna Medan
709	\N	\N	3046736181	Padang	Gedung Serbaguna Padang
710	\N	\N	3046736182	Palembang	Gedung Serbaguna Palembang
711	\N	\N	3046736183	Depok	Kampus UI Depok
712	\N	\N	3046736184	Jakarta Pusat	Kampus UI Salemba
713	\N	\N	3046736185	Jakarta Pusat	Gedung Serbaguna Jakpus
714	\N	\N	3046736186	Jakarta Timur	Gedung Serbaguna Jaktim
715	\N	\N	3046736187	Jakarta Selatan	Gedung Serbaguna Jaksel
716	\N	\N	3046736188	Depok	Gedung Serbaguna Depok
717	\N	\N	3046736189	Bekasi	Gedung Serbaguna Bekasi
718	\N	\N	3046736190	Tangerang	Gedung Serbaguna Tangerang
719	\N	\N	3046736191	Tangerang Selatan	Gedung Serbaguna Tangsel
720	\N	\N	3046736192	Bogor	Gedung Serbaguna Bogor
721	\N	\N	3046736193	Bandung	Gedung Serbaguna Bandung
722	\N	\N	3046736194	Jogjakarta	Gedung Serbaguna Jogjakarta
723	\N	\N	3046736195	Surabaya	Gedung Serbaguna Surabaya
724	\N	\N	3046736196	Makasar	Gedung Serbaguna Makasar
725	\N	\N	3046736197	Medan	Gedung Serbaguna Medan
726	\N	\N	3046736198	Padang	Gedung Serbaguna Padang
727	\N	\N	3046736199	Palembang	Gedung Serbaguna Palembang
728	\N	\N	3046736200	Depok	Kampus UI Depok
729	\N	\N	3046736201	Jakarta Pusat	Kampus UI Salemba
730	\N	\N	3046736202	Jakarta Pusat	Gedung Serbaguna Jakpus
731	\N	\N	3046736203	Jakarta Timur	Gedung Serbaguna Jaktim
732	\N	\N	3046736204	Jakarta Selatan	Gedung Serbaguna Jaksel
733	\N	\N	3046736205	Depok	Gedung Serbaguna Depok
734	\N	\N	3046736206	Bekasi	Gedung Serbaguna Bekasi
735	\N	\N	3046736207	Tangerang	Gedung Serbaguna Tangerang
736	\N	\N	3046736208	Tangerang Selatan	Gedung Serbaguna Tangsel
737	\N	\N	3046736209	Bogor	Gedung Serbaguna Bogor
738	\N	\N	3046736210	Bandung	Gedung Serbaguna Bandung
739	\N	\N	3046736211	Jogjakarta	Gedung Serbaguna Jogjakarta
740	\N	\N	3046736212	Surabaya	Gedung Serbaguna Surabaya
741	\N	\N	3046736213	Makasar	Gedung Serbaguna Makasar
742	\N	\N	3046736214	Medan	Gedung Serbaguna Medan
743	\N	\N	3046736215	Padang	Gedung Serbaguna Padang
744	\N	\N	3046736216	Palembang	Gedung Serbaguna Palembang
745	\N	\N	3046736217	Depok	Kampus UI Depok
746	\N	\N	3046736218	Jakarta Pusat	Kampus UI Salemba
747	\N	\N	3046736219	Jakarta Pusat	Gedung Serbaguna Jakpus
748	\N	\N	3046736220	Jakarta Timur	Gedung Serbaguna Jaktim
749	\N	\N	3046736221	Jakarta Selatan	Gedung Serbaguna Jaksel
750	\N	\N	3046736222	Depok	Gedung Serbaguna Depok
751	\N	\N	3046736223	Bekasi	Gedung Serbaguna Bekasi
752	\N	\N	3046736224	Tangerang	Gedung Serbaguna Tangerang
753	\N	\N	3046736225	Tangerang Selatan	Gedung Serbaguna Tangsel
754	\N	\N	3046736226	Bogor	Gedung Serbaguna Bogor
755	\N	\N	3046736227	Bandung	Gedung Serbaguna Bandung
756	\N	\N	3046736228	Jogjakarta	Gedung Serbaguna Jogjakarta
757	\N	\N	3046736229	Surabaya	Gedung Serbaguna Surabaya
758	\N	\N	3046736230	Makasar	Gedung Serbaguna Makasar
759	\N	\N	3046736231	Medan	Gedung Serbaguna Medan
760	\N	\N	3046736232	Padang	Gedung Serbaguna Padang
761	\N	\N	3046736233	Palembang	Gedung Serbaguna Palembang
762	\N	\N	3046736234	Depok	Kampus UI Depok
763	\N	\N	3046736235	Jakarta Pusat	Kampus UI Salemba
764	\N	\N	3046736236	Jakarta Pusat	Gedung Serbaguna Jakpus
765	\N	\N	3046736237	Jakarta Timur	Gedung Serbaguna Jaktim
766	\N	\N	3046736238	Jakarta Selatan	Gedung Serbaguna Jaksel
767	\N	\N	3046736239	Depok	Gedung Serbaguna Depok
768	\N	\N	3046736240	Bekasi	Gedung Serbaguna Bekasi
769	\N	\N	3046736241	Tangerang	Gedung Serbaguna Tangerang
770	\N	\N	3046736242	Tangerang Selatan	Gedung Serbaguna Tangsel
771	\N	\N	3046736243	Bogor	Gedung Serbaguna Bogor
772	\N	\N	3046736244	Bandung	Gedung Serbaguna Bandung
773	\N	\N	3046736245	Jogjakarta	Gedung Serbaguna Jogjakarta
774	\N	\N	3046736246	Surabaya	Gedung Serbaguna Surabaya
775	\N	\N	3046736247	Makasar	Gedung Serbaguna Makasar
776	\N	\N	3046736248	Medan	Gedung Serbaguna Medan
777	\N	\N	3046736249	Padang	Gedung Serbaguna Padang
778	\N	\N	3046736250	Palembang	Gedung Serbaguna Palembang
779	\N	\N	3046736251	Depok	Kampus UI Depok
780	\N	\N	3046736252	Jakarta Pusat	Kampus UI Salemba
781	\N	\N	3046736253	Jakarta Pusat	Gedung Serbaguna Jakpus
782	\N	\N	3046736254	Jakarta Timur	Gedung Serbaguna Jaktim
783	\N	\N	3046736255	Jakarta Selatan	Gedung Serbaguna Jaksel
784	\N	\N	3046736256	Depok	Gedung Serbaguna Depok
785	\N	\N	3046736257	Bekasi	Gedung Serbaguna Bekasi
786	\N	\N	3046736258	Tangerang	Gedung Serbaguna Tangerang
787	\N	\N	3046736259	Tangerang Selatan	Gedung Serbaguna Tangsel
788	\N	\N	3046736260	Bogor	Gedung Serbaguna Bogor
789	\N	\N	3046736261	Bandung	Gedung Serbaguna Bandung
790	\N	\N	3046736262	Jogjakarta	Gedung Serbaguna Jogjakarta
791	\N	\N	3046736263	Surabaya	Gedung Serbaguna Surabaya
792	\N	\N	3046736264	Makasar	Gedung Serbaguna Makasar
793	\N	\N	3046736265	Medan	Gedung Serbaguna Medan
794	\N	\N	3046736266	Padang	Gedung Serbaguna Padang
795	\N	\N	3046736267	Palembang	Gedung Serbaguna Palembang
796	\N	\N	3046736268	Depok	Kampus UI Depok
797	\N	\N	3046736269	Jakarta Pusat	Kampus UI Salemba
798	\N	\N	3046736270	Jakarta Pusat	Gedung Serbaguna Jakpus
799	\N	\N	3046736271	Jakarta Timur	Gedung Serbaguna Jaktim
800	\N	\N	3046736272	Jakarta Selatan	Gedung Serbaguna Jaksel
801	\N	\N	3046736273	Depok	Gedung Serbaguna Depok
802	\N	\N	3046736274	Bekasi	Gedung Serbaguna Bekasi
803	\N	\N	3046736275	Tangerang	Gedung Serbaguna Tangerang
804	\N	\N	3046736276	Tangerang Selatan	Gedung Serbaguna Tangsel
805	\N	\N	3046736277	Bogor	Gedung Serbaguna Bogor
806	\N	\N	3046736278	Bandung	Gedung Serbaguna Bandung
807	\N	\N	3046736279	Jogjakarta	Gedung Serbaguna Jogjakarta
808	\N	\N	3046736280	Surabaya	Gedung Serbaguna Surabaya
809	\N	\N	3046736281	Makasar	Gedung Serbaguna Makasar
810	\N	\N	3046736282	Medan	Gedung Serbaguna Medan
811	\N	\N	3046736283	Padang	Gedung Serbaguna Padang
812	\N	\N	3046736284	Palembang	Gedung Serbaguna Palembang
813	\N	\N	3046736285	Depok	Kampus UI Depok
814	\N	\N	3046736286	Jakarta Pusat	Kampus UI Salemba
815	\N	\N	3046736287	Jakarta Pusat	Gedung Serbaguna Jakpus
816	\N	\N	3046736288	Jakarta Timur	Gedung Serbaguna Jaktim
817	\N	\N	3046736289	Jakarta Selatan	Gedung Serbaguna Jaksel
818	\N	\N	3046736290	Depok	Gedung Serbaguna Depok
819	\N	\N	3046736291	Bekasi	Gedung Serbaguna Bekasi
820	\N	\N	3046736292	Tangerang	Gedung Serbaguna Tangerang
821	\N	\N	3046736293	Tangerang Selatan	Gedung Serbaguna Tangsel
822	\N	\N	3046736294	Bogor	Gedung Serbaguna Bogor
823	\N	\N	3046736295	Bandung	Gedung Serbaguna Bandung
824	\N	\N	3046736296	Jogjakarta	Gedung Serbaguna Jogjakarta
825	\N	\N	3046736297	Surabaya	Gedung Serbaguna Surabaya
826	\N	\N	3046736298	Makasar	Gedung Serbaguna Makasar
827	\N	\N	3046736299	Medan	Gedung Serbaguna Medan
828	\N	\N	3046736300	Padang	Gedung Serbaguna Padang
829	\N	\N	3046736301	Palembang	Gedung Serbaguna Palembang
830	\N	\N	3046736302	Depok	Kampus UI Depok
831	\N	\N	3046736303	Jakarta Pusat	Kampus UI Salemba
832	\N	\N	3046736304	Jakarta Pusat	Gedung Serbaguna Jakpus
833	\N	\N	3046736305	Jakarta Timur	Gedung Serbaguna Jaktim
834	\N	\N	3046736306	Jakarta Selatan	Gedung Serbaguna Jaksel
835	\N	\N	3046736307	Depok	Gedung Serbaguna Depok
836	\N	\N	3046736308	Bekasi	Gedung Serbaguna Bekasi
837	\N	\N	3046736309	Tangerang	Gedung Serbaguna Tangerang
838	\N	\N	3046736310	Tangerang Selatan	Gedung Serbaguna Tangsel
839	\N	\N	3046736311	Bogor	Gedung Serbaguna Bogor
840	\N	\N	3046736312	Bandung	Gedung Serbaguna Bandung
841	\N	\N	3046736313	Jogjakarta	Gedung Serbaguna Jogjakarta
842	\N	\N	3046736314	Surabaya	Gedung Serbaguna Surabaya
843	\N	\N	3046736315	Makasar	Gedung Serbaguna Makasar
844	\N	\N	3046736316	Medan	Gedung Serbaguna Medan
845	\N	\N	3046736317	Padang	Gedung Serbaguna Padang
846	\N	\N	3046736318	Palembang	Gedung Serbaguna Palembang
847	\N	\N	3046736319	Depok	Kampus UI Depok
848	\N	\N	3046736320	Jakarta Pusat	Kampus UI Salemba
849	\N	\N	3046736321	Jakarta Pusat	Gedung Serbaguna Jakpus
850	\N	\N	3046736322	Jakarta Timur	Gedung Serbaguna Jaktim
851	\N	\N	3046736323	Jakarta Selatan	Gedung Serbaguna Jaksel
852	\N	\N	3046736324	Depok	Gedung Serbaguna Depok
853	\N	\N	3046736325	Bekasi	Gedung Serbaguna Bekasi
854	\N	\N	3046736326	Tangerang	Gedung Serbaguna Tangerang
855	\N	\N	3046736327	Tangerang Selatan	Gedung Serbaguna Tangsel
856	\N	\N	3046736328	Bogor	Gedung Serbaguna Bogor
857	\N	\N	3046736329	Bandung	Gedung Serbaguna Bandung
858	\N	\N	3046736330	Jogjakarta	Gedung Serbaguna Jogjakarta
859	\N	\N	3046736331	Surabaya	Gedung Serbaguna Surabaya
860	\N	\N	3046736332	Makasar	Gedung Serbaguna Makasar
861	\N	\N	3046736333	Medan	Gedung Serbaguna Medan
862	\N	\N	3046736334	Padang	Gedung Serbaguna Padang
863	\N	\N	3046736335	Palembang	Gedung Serbaguna Palembang
864	\N	\N	3046736336	Depok	Kampus UI Depok
865	\N	\N	3046736337	Jakarta Pusat	Kampus UI Salemba
866	\N	\N	3046736338	Jakarta Pusat	Gedung Serbaguna Jakpus
867	\N	\N	3046736339	Jakarta Timur	Gedung Serbaguna Jaktim
868	\N	\N	3046736340	Jakarta Selatan	Gedung Serbaguna Jaksel
869	\N	\N	3046736341	Depok	Gedung Serbaguna Depok
870	\N	\N	3046736342	Bekasi	Gedung Serbaguna Bekasi
871	\N	\N	3046736343	Tangerang	Gedung Serbaguna Tangerang
872	\N	\N	3046736344	Tangerang Selatan	Gedung Serbaguna Tangsel
873	\N	\N	3046736345	Bogor	Gedung Serbaguna Bogor
874	\N	\N	3046736346	Bandung	Gedung Serbaguna Bandung
875	\N	\N	3046736347	Jogjakarta	Gedung Serbaguna Jogjakarta
876	\N	\N	3046736348	Surabaya	Gedung Serbaguna Surabaya
877	\N	\N	3046736349	Makasar	Gedung Serbaguna Makasar
878	\N	\N	3046736350	Medan	Gedung Serbaguna Medan
879	\N	\N	3046736351	Padang	Gedung Serbaguna Padang
880	\N	\N	3046736352	Palembang	Gedung Serbaguna Palembang
881	\N	\N	3046736353	Depok	Kampus UI Depok
882	\N	\N	3046736354	Jakarta Pusat	Kampus UI Salemba
883	\N	\N	3046736355	Jakarta Pusat	Gedung Serbaguna Jakpus
884	\N	\N	3046736356	Jakarta Timur	Gedung Serbaguna Jaktim
885	\N	\N	3046736357	Jakarta Selatan	Gedung Serbaguna Jaksel
886	\N	\N	3046736358	Depok	Gedung Serbaguna Depok
887	\N	\N	3046736359	Bekasi	Gedung Serbaguna Bekasi
888	\N	\N	3046736360	Tangerang	Gedung Serbaguna Tangerang
889	\N	\N	3046736361	Tangerang Selatan	Gedung Serbaguna Tangsel
890	\N	\N	3046736362	Bogor	Gedung Serbaguna Bogor
891	\N	\N	3046736363	Bandung	Gedung Serbaguna Bandung
892	\N	\N	3046736364	Jogjakarta	Gedung Serbaguna Jogjakarta
893	\N	\N	3046736365	Surabaya	Gedung Serbaguna Surabaya
894	\N	\N	3046736366	Makasar	Gedung Serbaguna Makasar
895	\N	\N	3046736367	Medan	Gedung Serbaguna Medan
896	\N	\N	3046736368	Padang	Gedung Serbaguna Padang
897	\N	\N	3046736369	Palembang	Gedung Serbaguna Palembang
898	\N	\N	3046736370	Depok	Kampus UI Depok
899	\N	\N	3046736371	Jakarta Pusat	Kampus UI Salemba
900	\N	\N	3046736372	Jakarta Pusat	Gedung Serbaguna Jakpus
901	\N	\N	3046736373	Jakarta Timur	Gedung Serbaguna Jaktim
902	\N	\N	3046736374	Jakarta Selatan	Gedung Serbaguna Jaksel
903	\N	\N	3046736375	Depok	Gedung Serbaguna Depok
904	\N	\N	3046736376	Bekasi	Gedung Serbaguna Bekasi
905	\N	\N	3046736377	Tangerang	Gedung Serbaguna Tangerang
906	\N	\N	3046736378	Tangerang Selatan	Gedung Serbaguna Tangsel
907	\N	\N	3046736379	Bogor	Gedung Serbaguna Bogor
908	\N	\N	3046736380	Bandung	Gedung Serbaguna Bandung
909	\N	\N	3046736381	Jogjakarta	Gedung Serbaguna Jogjakarta
910	\N	\N	3046736382	Surabaya	Gedung Serbaguna Surabaya
911	\N	\N	3046736383	Makasar	Gedung Serbaguna Makasar
912	\N	\N	3046736384	Medan	Gedung Serbaguna Medan
913	\N	\N	3046736385	Padang	Gedung Serbaguna Padang
914	\N	\N	3046736386	Palembang	Gedung Serbaguna Palembang
915	\N	\N	3046736387	Depok	Kampus UI Depok
916	\N	\N	3046736388	Jakarta Pusat	Kampus UI Salemba
917	\N	\N	3046736389	Jakarta Pusat	Gedung Serbaguna Jakpus
918	\N	\N	3046736390	Jakarta Timur	Gedung Serbaguna Jaktim
919	\N	\N	3046736391	Jakarta Selatan	Gedung Serbaguna Jaksel
920	\N	\N	3046736392	Depok	Gedung Serbaguna Depok
921	\N	\N	3046736393	Bekasi	Gedung Serbaguna Bekasi
922	\N	\N	3046736394	Tangerang	Gedung Serbaguna Tangerang
923	\N	\N	3046736395	Tangerang Selatan	Gedung Serbaguna Tangsel
924	\N	\N	3046736396	Bogor	Gedung Serbaguna Bogor
925	\N	\N	3046736397	Bandung	Gedung Serbaguna Bandung
926	\N	\N	3046736398	Jogjakarta	Gedung Serbaguna Jogjakarta
927	\N	\N	3046736399	Surabaya	Gedung Serbaguna Surabaya
928	\N	\N	3046736400	Makasar	Gedung Serbaguna Makasar
929	\N	\N	3046736401	Medan	Gedung Serbaguna Medan
930	\N	\N	3046736402	Padang	Gedung Serbaguna Padang
931	\N	\N	3046736403	Palembang	Gedung Serbaguna Palembang
932	\N	\N	3046736404	Depok	Kampus UI Depok
933	\N	\N	3046736405	Jakarta Pusat	Kampus UI Salemba
934	\N	\N	3046736406	Jakarta Pusat	Gedung Serbaguna Jakpus
935	\N	\N	3046736407	Jakarta Timur	Gedung Serbaguna Jaktim
936	\N	\N	3046736408	Jakarta Selatan	Gedung Serbaguna Jaksel
937	\N	\N	3046736409	Depok	Gedung Serbaguna Depok
938	\N	\N	3046736410	Bekasi	Gedung Serbaguna Bekasi
939	\N	\N	3046736411	Tangerang	Gedung Serbaguna Tangerang
940	\N	\N	3046736412	Tangerang Selatan	Gedung Serbaguna Tangsel
941	\N	\N	3046736413	Bogor	Gedung Serbaguna Bogor
942	\N	\N	3046736414	Bandung	Gedung Serbaguna Bandung
943	\N	\N	3046736415	Jogjakarta	Gedung Serbaguna Jogjakarta
944	\N	\N	3046736416	Surabaya	Gedung Serbaguna Surabaya
945	\N	\N	3046736417	Makasar	Gedung Serbaguna Makasar
946	\N	\N	3046736418	Medan	Gedung Serbaguna Medan
947	\N	\N	3046736419	Padang	Gedung Serbaguna Padang
948	\N	\N	3046736420	Palembang	Gedung Serbaguna Palembang
949	\N	\N	3046736421	Depok	Kampus UI Depok
950	\N	\N	3046736422	Jakarta Pusat	Kampus UI Salemba
951	\N	\N	3046736423	Jakarta Pusat	Gedung Serbaguna Jakpus
952	\N	\N	3046736424	Jakarta Timur	Gedung Serbaguna Jaktim
953	\N	\N	3046736425	Jakarta Selatan	Gedung Serbaguna Jaksel
954	\N	\N	3046736426	Depok	Gedung Serbaguna Depok
955	\N	\N	3046736427	Bekasi	Gedung Serbaguna Bekasi
956	\N	\N	3046736428	Tangerang	Gedung Serbaguna Tangerang
957	\N	\N	3046736429	Tangerang Selatan	Gedung Serbaguna Tangsel
958	\N	\N	3046736430	Bogor	Gedung Serbaguna Bogor
959	\N	\N	3046736431	Bandung	Gedung Serbaguna Bandung
960	\N	\N	3046736432	Jogjakarta	Gedung Serbaguna Jogjakarta
961	\N	\N	3046736433	Surabaya	Gedung Serbaguna Surabaya
962	\N	\N	3046736434	Makasar	Gedung Serbaguna Makasar
963	\N	\N	3046736435	Medan	Gedung Serbaguna Medan
964	\N	\N	3046736436	Padang	Gedung Serbaguna Padang
965	\N	\N	3046736437	Palembang	Gedung Serbaguna Palembang
966	\N	\N	3046736438	Depok	Kampus UI Depok
967	\N	\N	3046736439	Jakarta Pusat	Kampus UI Salemba
968	\N	\N	3046736440	Jakarta Pusat	Gedung Serbaguna Jakpus
969	\N	\N	3046736441	Jakarta Timur	Gedung Serbaguna Jaktim
970	\N	\N	3046736442	Jakarta Selatan	Gedung Serbaguna Jaksel
971	\N	\N	3046736443	Depok	Gedung Serbaguna Depok
972	\N	\N	3046736444	Bekasi	Gedung Serbaguna Bekasi
973	\N	\N	3046736445	Tangerang	Gedung Serbaguna Tangerang
974	\N	\N	3046736446	Tangerang Selatan	Gedung Serbaguna Tangsel
975	\N	\N	3046736447	Bogor	Gedung Serbaguna Bogor
976	\N	\N	3046736448	Bandung	Gedung Serbaguna Bandung
977	\N	\N	3046736449	Jogjakarta	Gedung Serbaguna Jogjakarta
978	\N	\N	3046736450	Surabaya	Gedung Serbaguna Surabaya
979	\N	\N	3046736451	Makasar	Gedung Serbaguna Makasar
980	\N	\N	3046736452	Medan	Gedung Serbaguna Medan
981	\N	\N	3046736453	Padang	Gedung Serbaguna Padang
982	\N	\N	3046736454	Palembang	Gedung Serbaguna Palembang
983	\N	\N	3046736455	Depok	Kampus UI Depok
984	\N	\N	3046736456	Jakarta Pusat	Kampus UI Salemba
985	\N	\N	3046736457	Jakarta Pusat	Gedung Serbaguna Jakpus
986	\N	\N	3046736458	Jakarta Timur	Gedung Serbaguna Jaktim
987	\N	\N	3046736459	Jakarta Selatan	Gedung Serbaguna Jaksel
988	\N	\N	3046736460	Depok	Gedung Serbaguna Depok
989	\N	\N	3046736461	Bekasi	Gedung Serbaguna Bekasi
990	\N	\N	3046736462	Tangerang	Gedung Serbaguna Tangerang
991	\N	\N	3046736463	Tangerang Selatan	Gedung Serbaguna Tangsel
992	\N	\N	3046736464	Bogor	Gedung Serbaguna Bogor
993	\N	\N	3046736465	Bandung	Gedung Serbaguna Bandung
994	\N	\N	3046736466	Jogjakarta	Gedung Serbaguna Jogjakarta
995	\N	\N	3046736467	Surabaya	Gedung Serbaguna Surabaya
996	\N	\N	3046736468	Makasar	Gedung Serbaguna Makasar
997	\N	\N	3046736469	Medan	Gedung Serbaguna Medan
998	\N	\N	3046736470	Padang	Gedung Serbaguna Padang
999	\N	\N	3046736471	Palembang	Gedung Serbaguna Palembang
1000	\N	\N	3046736472	Depok	Kampus UI Depok
1201	\N	\N	1720001002	Depok	Kampus UI Depok
1001	\N	\N	3046736473	Jakarta Pusat	Kampus UI Salemba
1002	\N	\N	3046736474	Jakarta Pusat	Gedung Serbaguna Jakpus
1003	\N	\N	3046736475	Jakarta Timur	Gedung Serbaguna Jaktim
1004	\N	\N	3046736476	Jakarta Selatan	Gedung Serbaguna Jaksel
1005	\N	\N	3046736477	Depok	Gedung Serbaguna Depok
1006	\N	\N	3046736478	Bekasi	Gedung Serbaguna Bekasi
1007	\N	\N	3046736479	Tangerang	Gedung Serbaguna Tangerang
1008	\N	\N	3046736480	Tangerang Selatan	Gedung Serbaguna Tangsel
1009	\N	\N	3046736481	Bogor	Gedung Serbaguna Bogor
1010	\N	\N	3046736482	Bandung	Gedung Serbaguna Bandung
1011	\N	\N	3046736483	Jogjakarta	Gedung Serbaguna Jogjakarta
1012	\N	\N	3046736484	Surabaya	Gedung Serbaguna Surabaya
1013	\N	\N	3046736485	Makasar	Gedung Serbaguna Makasar
1014	\N	\N	3046736486	Medan	Gedung Serbaguna Medan
1015	\N	\N	3046736487	Padang	Gedung Serbaguna Padang
1016	\N	\N	3046736488	Palembang	Gedung Serbaguna Palembang
1017	\N	\N	3046736489	Depok	Kampus UI Depok
1018	\N	\N	3046736490	Jakarta Pusat	Kampus UI Salemba
1019	\N	\N	3046736491	Jakarta Pusat	Gedung Serbaguna Jakpus
1020	\N	\N	3046736492	Jakarta Timur	Gedung Serbaguna Jaktim
1021	\N	\N	3046736493	Jakarta Selatan	Gedung Serbaguna Jaksel
1022	\N	\N	3046736494	Depok	Gedung Serbaguna Depok
1023	\N	\N	3046736495	Bekasi	Gedung Serbaguna Bekasi
1024	\N	\N	3046736496	Tangerang	Gedung Serbaguna Tangerang
1025	\N	\N	3046736497	Tangerang Selatan	Gedung Serbaguna Tangsel
1026	\N	\N	3046736498	Bogor	Gedung Serbaguna Bogor
1027	\N	\N	3046736499	Bandung	Gedung Serbaguna Bandung
1028	\N	\N	3046736500	Jogjakarta	Gedung Serbaguna Jogjakarta
1029	\N	\N	3046736501	Surabaya	Gedung Serbaguna Surabaya
1030	\N	\N	3046736502	Makasar	Gedung Serbaguna Makasar
1031	\N	\N	3046736503	Medan	Gedung Serbaguna Medan
1032	\N	\N	3046736504	Padang	Gedung Serbaguna Padang
1033	\N	\N	3046736505	Palembang	Gedung Serbaguna Palembang
1034	\N	\N	3046736506	Depok	Kampus UI Depok
1035	\N	\N	3046736507	Jakarta Pusat	Kampus UI Salemba
1036	\N	\N	3046736508	Jakarta Pusat	Gedung Serbaguna Jakpus
1037	\N	\N	3046736509	Jakarta Timur	Gedung Serbaguna Jaktim
1038	\N	\N	3046736510	Jakarta Selatan	Gedung Serbaguna Jaksel
1039	\N	\N	3046736511	Depok	Gedung Serbaguna Depok
1040	\N	\N	3046736512	Bekasi	Gedung Serbaguna Bekasi
1041	\N	\N	3046736513	Tangerang	Gedung Serbaguna Tangerang
1042	\N	\N	3046736514	Tangerang Selatan	Gedung Serbaguna Tangsel
1043	\N	\N	3046736515	Bogor	Gedung Serbaguna Bogor
1044	\N	\N	3046736516	Bandung	Gedung Serbaguna Bandung
1045	\N	\N	3046736517	Jogjakarta	Gedung Serbaguna Jogjakarta
1046	\N	\N	3046736518	Surabaya	Gedung Serbaguna Surabaya
1047	\N	\N	3046736519	Makasar	Gedung Serbaguna Makasar
1048	\N	\N	3046736520	Medan	Gedung Serbaguna Medan
1049	\N	\N	3046736521	Padang	Gedung Serbaguna Padang
1050	\N	\N	3046736522	Palembang	Gedung Serbaguna Palembang
1051	\N	\N	3046736523	Depok	Kampus UI Depok
1052	\N	\N	3046736524	Jakarta Pusat	Kampus UI Salemba
1053	\N	\N	3046736525	Jakarta Pusat	Gedung Serbaguna Jakpus
1054	\N	\N	3046736526	Jakarta Timur	Gedung Serbaguna Jaktim
1055	\N	\N	3046736527	Jakarta Selatan	Gedung Serbaguna Jaksel
1056	\N	\N	3046736528	Depok	Gedung Serbaguna Depok
1057	\N	\N	3046736529	Bekasi	Gedung Serbaguna Bekasi
1058	\N	\N	3046736530	Tangerang	Gedung Serbaguna Tangerang
1059	\N	\N	3046736531	Tangerang Selatan	Gedung Serbaguna Tangsel
1060	\N	\N	3046736532	Bogor	Gedung Serbaguna Bogor
1061	\N	\N	3046736533	Bandung	Gedung Serbaguna Bandung
1062	\N	\N	3046736534	Jogjakarta	Gedung Serbaguna Jogjakarta
1063	\N	\N	3046736535	Surabaya	Gedung Serbaguna Surabaya
1064	\N	\N	3046736536	Makasar	Gedung Serbaguna Makasar
1065	\N	\N	3046736537	Medan	Gedung Serbaguna Medan
1066	\N	\N	3046736538	Padang	Gedung Serbaguna Padang
1067	\N	\N	3046736539	Palembang	Gedung Serbaguna Palembang
1068	\N	\N	3046736540	Depok	Kampus UI Depok
1069	\N	\N	3046736541	Jakarta Pusat	Kampus UI Salemba
1070	\N	\N	3046736542	Jakarta Pusat	Gedung Serbaguna Jakpus
1071	\N	\N	3046736543	Jakarta Timur	Gedung Serbaguna Jaktim
1072	\N	\N	3046736544	Jakarta Selatan	Gedung Serbaguna Jaksel
1073	\N	\N	3046736545	Depok	Gedung Serbaguna Depok
1074	\N	\N	3046736546	Bekasi	Gedung Serbaguna Bekasi
1075	\N	\N	3046736547	Tangerang	Gedung Serbaguna Tangerang
1076	\N	\N	3046736548	Tangerang Selatan	Gedung Serbaguna Tangsel
1077	\N	\N	3046736549	Bogor	Gedung Serbaguna Bogor
1078	\N	\N	3046736550	Bandung	Gedung Serbaguna Bandung
1079	\N	\N	3046736551	Jogjakarta	Gedung Serbaguna Jogjakarta
1080	\N	\N	3046736552	Surabaya	Gedung Serbaguna Surabaya
1081	\N	\N	3046736553	Makasar	Gedung Serbaguna Makasar
1082	\N	\N	3046736554	Medan	Gedung Serbaguna Medan
1083	\N	\N	3046736555	Padang	Gedung Serbaguna Padang
1084	\N	\N	3046736556	Palembang	Gedung Serbaguna Palembang
1085	\N	\N	3046736557	Depok	Kampus UI Depok
1086	\N	\N	3046736558	Jakarta Pusat	Kampus UI Salemba
1087	\N	\N	3046736559	Jakarta Pusat	Gedung Serbaguna Jakpus
1088	\N	\N	3046736560	Jakarta Timur	Gedung Serbaguna Jaktim
1089	\N	\N	3046736561	Jakarta Selatan	Gedung Serbaguna Jaksel
1090	\N	\N	3046736562	Depok	Gedung Serbaguna Depok
1091	\N	\N	3046736563	Bekasi	Gedung Serbaguna Bekasi
1092	\N	\N	3046736564	Tangerang	Gedung Serbaguna Tangerang
1093	\N	\N	3046736565	Tangerang Selatan	Gedung Serbaguna Tangsel
1094	\N	\N	3046736566	Bogor	Gedung Serbaguna Bogor
1095	\N	\N	3046736567	Bandung	Gedung Serbaguna Bandung
1096	\N	\N	3046736568	Jogjakarta	Gedung Serbaguna Jogjakarta
1097	\N	\N	3046736569	Surabaya	Gedung Serbaguna Surabaya
1098	\N	\N	3046736570	Makasar	Gedung Serbaguna Makasar
1099	\N	\N	3046736571	Medan	Gedung Serbaguna Medan
1100	\N	\N	3046736572	Padang	Gedung Serbaguna Padang
1101	\N	\N	3046736573	Palembang	Gedung Serbaguna Palembang
1102	\N	\N	3046736574	Depok	Kampus UI Depok
1103	\N	\N	3046736575	Jakarta Pusat	Kampus UI Salemba
1104	\N	\N	3046736576	Jakarta Pusat	Gedung Serbaguna Jakpus
1105	\N	\N	3046736577	Jakarta Timur	Gedung Serbaguna Jaktim
1106	\N	\N	3046736578	Jakarta Selatan	Gedung Serbaguna Jaksel
1107	\N	\N	3046736579	Depok	Gedung Serbaguna Depok
1108	\N	\N	3046736580	Bekasi	Gedung Serbaguna Bekasi
1109	\N	\N	3046736581	Tangerang	Gedung Serbaguna Tangerang
1110	\N	\N	3046736582	Tangerang Selatan	Gedung Serbaguna Tangsel
1111	\N	\N	3046736583	Bogor	Gedung Serbaguna Bogor
1112	\N	\N	3046736584	Bandung	Gedung Serbaguna Bandung
1113	\N	\N	3046736585	Jogjakarta	Gedung Serbaguna Jogjakarta
1114	\N	\N	3046736586	Surabaya	Gedung Serbaguna Surabaya
1115	\N	\N	3046736587	Makasar	Gedung Serbaguna Makasar
1116	\N	\N	3046736588	Medan	Gedung Serbaguna Medan
1117	\N	\N	3046736589	Padang	Gedung Serbaguna Padang
1118	\N	\N	3046736590	Palembang	Gedung Serbaguna Palembang
1119	\N	\N	3046736591	Depok	Kampus UI Depok
1120	\N	\N	3046736592	Jakarta Pusat	Kampus UI Salemba
1121	\N	\N	3046736593	Jakarta Pusat	Gedung Serbaguna Jakpus
1122	\N	\N	3046736594	Jakarta Timur	Gedung Serbaguna Jaktim
1123	\N	\N	3046736595	Jakarta Selatan	Gedung Serbaguna Jaksel
1124	\N	\N	3046736596	Depok	Gedung Serbaguna Depok
1125	\N	\N	3046736597	Bekasi	Gedung Serbaguna Bekasi
1126	\N	\N	3046736598	Tangerang	Gedung Serbaguna Tangerang
1127	\N	\N	3046736599	Tangerang Selatan	Gedung Serbaguna Tangsel
1128	\N	\N	3046736600	Bogor	Gedung Serbaguna Bogor
1129	\N	\N	3046736601	Bandung	Gedung Serbaguna Bandung
1130	\N	\N	3046736602	Jogjakarta	Gedung Serbaguna Jogjakarta
1131	\N	\N	3046736603	Surabaya	Gedung Serbaguna Surabaya
1132	\N	\N	3046736604	Makasar	Gedung Serbaguna Makasar
1133	\N	\N	3046736605	Medan	Gedung Serbaguna Medan
1134	\N	\N	3046736606	Padang	Gedung Serbaguna Padang
1135	\N	\N	3046736607	Palembang	Gedung Serbaguna Palembang
1136	\N	\N	3046736608	Depok	Kampus UI Depok
1137	\N	\N	3046736609	Jakarta Pusat	Kampus UI Salemba
1138	\N	\N	3046736610	Jakarta Pusat	Gedung Serbaguna Jakpus
1139	\N	\N	3046736611	Jakarta Timur	Gedung Serbaguna Jaktim
1140	\N	\N	3046736612	Jakarta Selatan	Gedung Serbaguna Jaksel
1141	\N	\N	3046736613	Depok	Gedung Serbaguna Depok
1142	\N	\N	3046736614	Bekasi	Gedung Serbaguna Bekasi
1143	\N	\N	3046736615	Tangerang	Gedung Serbaguna Tangerang
1144	\N	\N	3046736616	Tangerang Selatan	Gedung Serbaguna Tangsel
1145	\N	\N	3046736617	Bogor	Gedung Serbaguna Bogor
1146	\N	\N	3046736618	Bandung	Gedung Serbaguna Bandung
1147	\N	\N	3046736619	Jogjakarta	Gedung Serbaguna Jogjakarta
1148	\N	\N	3046736620	Surabaya	Gedung Serbaguna Surabaya
1149	\N	\N	3046736621	Makasar	Gedung Serbaguna Makasar
1150	\N	\N	3046736622	Medan	Gedung Serbaguna Medan
1151	\N	\N	3046736623	Padang	Gedung Serbaguna Padang
1152	\N	\N	3046736624	Palembang	Gedung Serbaguna Palembang
1153	\N	\N	3046736625	Depok	Kampus UI Depok
1154	\N	\N	3046736626	Jakarta Pusat	Kampus UI Salemba
1155	\N	\N	3046736627	Jakarta Pusat	Gedung Serbaguna Jakpus
1156	\N	\N	3046736628	Jakarta Timur	Gedung Serbaguna Jaktim
1157	\N	\N	3046736629	Jakarta Selatan	Gedung Serbaguna Jaksel
1158	\N	\N	3046736630	Depok	Gedung Serbaguna Depok
1159	\N	\N	3046736631	Bekasi	Gedung Serbaguna Bekasi
1160	\N	\N	3046736632	Tangerang	Gedung Serbaguna Tangerang
1161	\N	\N	3046736633	Tangerang Selatan	Gedung Serbaguna Tangsel
1162	\N	\N	3046736634	Bogor	Gedung Serbaguna Bogor
1163	\N	\N	3046736635	Bandung	Gedung Serbaguna Bandung
1164	\N	\N	3046736636	Jogjakarta	Gedung Serbaguna Jogjakarta
1165	\N	\N	3046736637	Surabaya	Gedung Serbaguna Surabaya
1166	\N	\N	3046736638	Makasar	Gedung Serbaguna Makasar
1167	\N	\N	3046736639	Medan	Gedung Serbaguna Medan
1168	\N	\N	3046736640	Padang	Gedung Serbaguna Padang
1169	\N	\N	3046736641	Palembang	Gedung Serbaguna Palembang
1170	\N	\N	3046736642	Depok	Kampus UI Depok
1171	\N	\N	3046736643	Jakarta Pusat	Kampus UI Salemba
1172	\N	\N	3046736644	Jakarta Pusat	Gedung Serbaguna Jakpus
1173	\N	\N	3046736645	Jakarta Timur	Gedung Serbaguna Jaktim
1174	\N	\N	3046736646	Jakarta Selatan	Gedung Serbaguna Jaksel
1175	\N	\N	3046736647	Depok	Gedung Serbaguna Depok
1176	\N	\N	3046736648	Bekasi	Gedung Serbaguna Bekasi
1177	\N	\N	3046736649	Tangerang	Gedung Serbaguna Tangerang
1178	\N	\N	3046736650	Tangerang Selatan	Gedung Serbaguna Tangsel
1179	\N	\N	3046736651	Bogor	Gedung Serbaguna Bogor
1180	\N	\N	3046736652	Bandung	Gedung Serbaguna Bandung
1181	\N	\N	3046736653	Jogjakarta	Gedung Serbaguna Jogjakarta
1182	\N	\N	3046736654	Surabaya	Gedung Serbaguna Surabaya
1183	\N	\N	3046736655	Makasar	Gedung Serbaguna Makasar
1184	\N	\N	3046736656	Medan	Gedung Serbaguna Medan
1185	\N	\N	3046736657	Padang	Gedung Serbaguna Padang
1186	\N	\N	3046736658	Palembang	Gedung Serbaguna Palembang
1187	\N	\N	3046736659	Depok	Kampus UI Depok
1188	\N	\N	3046736660	Jakarta Pusat	Kampus UI Salemba
1189	\N	\N	3046736661	Jakarta Pusat	Gedung Serbaguna Jakpus
1190	\N	\N	3046736662	Jakarta Timur	Gedung Serbaguna Jaktim
1191	\N	\N	3046736663	Jakarta Selatan	Gedung Serbaguna Jaksel
1192	\N	\N	3046736664	Depok	Gedung Serbaguna Depok
1193	\N	\N	3046736665	Bekasi	Gedung Serbaguna Bekasi
1194	\N	\N	3046736666	Tangerang	Gedung Serbaguna Tangerang
1195	\N	\N	3046736667	Tangerang Selatan	Gedung Serbaguna Tangsel
1196	\N	\N	3046736668	Bogor	Gedung Serbaguna Bogor
1197	\N	\N	3046736669	Bandung	Gedung Serbaguna Bandung
1198	\N	\N	3046736670	Jogjakarta	Gedung Serbaguna Jogjakarta
1199	\N	\N	3046736671	Surabaya	Gedung Serbaguna Surabaya
1200	\N	\N	3046736672	Makasar	Gedung Serbaguna Makasar
\.


--
-- Data for Name: pendaftaran_semas_pascasarjana; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pendaftaran_semas_pascasarjana (id_pendaftaran, nilai_tpa, nilai_toefl, jenjang_terakhir, asal_univ, alamat_univ, prodi_terakhir, nilai_ipk, no_ijazah, tgl_lulus, jenjang, nama_rekomender, prop_penelitian) FROM stdin;
1001	638	842	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Ilmu Perpustakaan	3.83	SKS79156387176	2007-08-16	S2	Victoria	penelitian_124324.pdf
1002	635	835	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sastara Belanda	3.85	SKS79156387177	2007-08-17	S2	Addison	penelitian_124325.pdf
1003	699	840	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Biologi	3.79	SKS79156387178	2007-08-31	S2	Uriah	penelitian_124326.pdf
1004	651	774	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Kimia	3.98	SKS79156387179	2007-09-12	S2	Steven	penelitian_124327.pdf
1005	691	759	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Arsitektur	3.96	SKS79156387180	2007-09-25	S2	Sacha	penelitian_124328.pdf
1006	652	835	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Arsitektur	3.90	SKS79156387181	2007-09-06	S2	Justin	penelitian_124329.pdf
1007	607	827	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Ilmu Administrasi	3.99	SKS79156387182	2007-08-21	S2	Michelle	penelitian_124330.pdf
1008	689	810	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Teknik Mesin	3.80	SKS79156387183	2007-09-16	S2	Peter	penelitian_124331.pdf
1009	682	809	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Sastra Korea	3.79	SKS79156387184	2007-09-18	S2	Steven	penelitian_124332.pdf
1010	680	824	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Geografi	3.98	SKS79156387185	2007-09-01	S2	Beck	penelitian_124333.pdf
1011	617	814	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Akutansi	3.92	SKS79156387186	2007-08-26	S2	Olivia	penelitian_124334.pdf
1012	606	774	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Sastara Belanda	3.84	SKS79156387187	2007-08-06	S2	Ivan	penelitian_124335.pdf
1013	628	791	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Teknik Sipil	3.83	SKS79156387188	2007-09-01	S2	Bruno	penelitian_124336.pdf
1014	632	761	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Teknik Industri	3.78	SKS79156387189	2007-08-07	S2	Maile	penelitian_124337.pdf
1015	646	771	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Ilmu Ekonomi	3.90	SKS79156387190	2007-09-02	S2	Olivia	penelitian_124338.pdf
1016	671	791	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Ilmu Ekonomi	3.97	SKS79156387191	2007-08-21	S2	Sacha	penelitian_124339.pdf
1017	696	779	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Komputer	3.87	SKS79156387192	2007-09-17	S2	Maile	penelitian_124340.pdf
1018	650	764	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Ilmu Hukum	3.99	SKS79156387193	2007-09-10	S2	Mason	penelitian_124341.pdf
1019	663	795	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Teknik Mesin	3.85	SKS79156387194	2007-08-08	S2	Barclay	penelitian_124342.pdf
1020	601	777	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sastra Arab	3.98	SKS79156387195	2007-09-11	S2	Coby	penelitian_124343.pdf
1021	660	772	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Matematika	3.99	SKS79156387196	2007-09-21	S2	Steven	penelitian_124344.pdf
1022	669	824	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Ilmu Komputer	3.97	SKS79156387197	2007-08-17	S2	Mason	penelitian_124345.pdf
1023	675	850	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Sastra Korea	3.91	SKS79156387198	2007-09-19	S2	Stewart	penelitian_124346.pdf
1024	629	846	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Matematika	3.84	SKS79156387199	2007-09-22	S2	Hedley	penelitian_124347.pdf
1025	617	811	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Teknik Industri	3.82	SKS79156387200	2007-09-26	S2	Malachi	penelitian_124348.pdf
1026	459	574	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Ilmu politik	3.60	SKS79156387201	2007-09-02	S2	Marny	penelitian_124349.pdf
1027	477	583	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Sastra Indonesia	3.51	SKS79156387202	2007-08-19	S2	Hanna	penelitian_124350.pdf
1028	414	518	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Ilmu Ekonomi	3.45	SKS79156387203	2007-08-30	S2	Juliet	penelitian_124351.pdf
1029	418	522	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Sastra Indonesia	3.50	SKS79156387204	2007-09-30	S2	Idona	penelitian_124352.pdf
1030	484	587	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Fisika	3.52	SKS79156387205	2007-09-21	S2	Marah	penelitian_124353.pdf
1031	480	587	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Kedokteran	3.48	SKS79156387206	2007-09-12	S2	Jane	penelitian_124354.pdf
1032	423	579	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Ilmu Komputer	3.60	SKS79156387207	2007-09-30	S2	Harriet	penelitian_124355.pdf
1033	458	515	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Geografi	3.45	SKS79156387208	2007-08-06	S2	Josephine	penelitian_124356.pdf
1034	416	507	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Ilmu Perpustakaan	3.52	SKS79156387209	2007-08-21	S2	Dora	penelitian_124357.pdf
1035	433	540	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Komputer	3.53	SKS79156387210	2007-09-24	S2	Quemby	penelitian_124358.pdf
1036	416	559	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Ilmu Hukum	3.49	SKS79156387211	2007-08-31	S2	Porter	penelitian_124359.pdf
1037	458	587	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Ilmu Perpustakaan	3.48	SKS79156387212	2007-08-27	S2	Wilma	penelitian_124360.pdf
1038	407	574	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Kimia	3.57	SKS79156387213	2007-09-25	S2	Tarik	penelitian_124361.pdf
1039	452	547	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Ilmu Komputer	3.55	SKS79156387214	2007-08-13	S2	Upton	penelitian_124362.pdf
1040	445	575	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Geografi	3.49	SKS79156387215	2007-09-01	S2	Kieran	penelitian_124363.pdf
1041	423	570	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Sastra Inggris	3.45	SKS79156387216	2007-08-14	S2	Penelope	penelitian_124364.pdf
1042	479	582	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Sastra Korea	3.40	SKS79156387217	2007-09-12	S2	Carolyn	penelitian_124365.pdf
1043	482	543	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Kimia	3.60	SKS79156387218	2007-09-06	S2	Nasim	penelitian_124366.pdf
1044	448	515	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Sastra Jepang	3.43	SKS79156387219	2007-09-17	S2	Mason	penelitian_124367.pdf
1045	445	592	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Ilmu Administrasi	3.56	SKS79156387220	2007-09-08	S2	Quentin	penelitian_124368.pdf
1046	467	532	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Teknik Mesin	3.54	SKS79156387221	2007-08-12	S2	Penelope	penelitian_124369.pdf
1047	473	529	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Ilmu Administrasi	3.53	SKS79156387222	2007-09-26	S2	Mia	penelitian_124370.pdf
1048	473	573	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Arsitektur	3.51	SKS79156387223	2007-09-16	S2	Ayanna	penelitian_124371.pdf
1049	462	565	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Teknik Mesin	3.48	SKS79156387224	2007-09-11	S2	Justina	penelitian_124372.pdf
1050	456	532	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Kimia	3.41	SKS79156387225	2007-09-26	S2	Olivia	penelitian_124373.pdf
1051	430	526	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Sistem Informasi	3.45	SKS79156387226	2007-08-05	S2	Cheryl	penelitian_124374.pdf
1052	456	566	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Teknik Sipil	3.52	SKS79156387227	2007-08-05	S2	Kadeem	penelitian_124375.pdf
1053	485	506	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Fisika	3.41	SKS79156387228	2007-09-18	S2	Mia	penelitian_124376.pdf
1054	420	540	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Sastra Perancis	3.43	SKS79156387229	2007-08-27	S2	Yvonne	penelitian_124377.pdf
1055	463	541	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Sipil	3.48	SKS79156387230	2007-08-01	S2	Penelope	penelitian_124378.pdf
1056	420	579	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Teknik Mesin	3.56	SKS79156387231	2007-09-28	S2	Karen	penelitian_124379.pdf
1057	402	534	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Sistem Informasi	3.46	SKS79156387232	2007-08-22	S2	Phillip	penelitian_124380.pdf
1058	500	577	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Teknik Kimia	3.59	SKS79156387233	2007-08-21	S2	Bruno	penelitian_124381.pdf
1059	426	526	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Sastra Perancis	3.60	SKS79156387234	2007-08-24	S2	Dara	penelitian_124382.pdf
1060	473	591	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Kimia	3.51	SKS79156387235	2007-09-15	S2	Walter	penelitian_124383.pdf
1061	421	528	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Ilmu Komputer	3.43	SKS79156387236	2007-09-02	S2	Richard	penelitian_124384.pdf
1062	448	596	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Sipil	3.57	SKS79156387237	2007-09-17	S2	Lionel	penelitian_124385.pdf
1063	478	583	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Ilmu Hukum	3.48	SKS79156387238	2007-08-20	S2	Xaviera	penelitian_124386.pdf
1064	436	545	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Teknik Elektro	3.41	SKS79156387239	2007-08-31	S2	Caldwell	penelitian_124387.pdf
1065	419	598	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Ilmu Administrasi	3.57	SKS79156387240	2007-08-21	S2	Dara	penelitian_124388.pdf
1066	487	539	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Sastara Belanda	3.55	SKS79156387241	2007-09-15	S2	Emma	penelitian_124389.pdf
1067	496	552	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Kimia	3.48	SKS79156387242	2007-08-05	S2	Victoria	penelitian_124390.pdf
1068	409	529	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Sastra Indonesia	3.43	SKS79156387243	2007-09-05	S2	Roth	penelitian_124391.pdf
1069	437	593	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Matematika	3.52	SKS79156387244	2007-09-16	S2	Peter	penelitian_124392.pdf
1070	457	512	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Teknik Kimia	3.43	SKS79156387245	2007-08-09	S2	Emma	penelitian_124393.pdf
1071	466	547	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Psikologi	3.40	SKS79156387246	2007-08-09	S2	Richard	penelitian_124394.pdf
1072	499	594	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Teknik Kimia	3.43	SKS79156387247	2007-09-13	S2	Dara	penelitian_124395.pdf
1073	415	519	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Sastra Inggris	3.46	SKS79156387248	2007-09-17	S2	Raven	penelitian_124396.pdf
1074	447	539	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Sastra Indonesia	3.52	SKS79156387249	2007-08-15	S2	Karen	penelitian_124397.pdf
1075	459	522	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Teknik Mesin	3.42	SKS79156387250	2007-09-16	S2	Peter	penelitian_124398.pdf
1076	429	529	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Ilmu Hukum	3.55	SKS79156387251	2007-09-17	S2	Victoria	penelitian_124399.pdf
1077	462	556	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Sastra Inggris	3.40	SKS79156387252	2007-08-20	S2	Kyra	penelitian_124400.pdf
1078	420	562	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Sastra Indonesia	3.57	SKS79156387253	2007-08-14	S2	Idona	penelitian_124401.pdf
1079	407	527	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Teknik Sipil	3.58	SKS79156387254	2007-08-20	S2	Harper	penelitian_124402.pdf
1080	461	587	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Fisika	3.45	SKS79156387255	2007-09-05	S2	Jack	penelitian_124403.pdf
1081	464	512	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Teknik Komputer	3.52	SKS79156387256	2007-09-23	S2	Kyra	penelitian_124404.pdf
1082	428	581	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Teknik Elektro	3.41	SKS79156387257	2007-08-06	S2	Josephine	penelitian_124405.pdf
1083	473	576	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Sastra Arab	3.56	SKS79156387258	2007-09-19	S2	Tad	penelitian_124406.pdf
1084	433	599	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Ilmu Komputer	3.51	SKS79156387259	2007-09-03	S2	Lionel	penelitian_124407.pdf
1085	470	557	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Ilmu Komputer	3.58	SKS79156387260	2007-08-12	S2	Tad	penelitian_124408.pdf
1086	407	561	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Sistem Informasi	3.46	SKS79156387261	2007-09-24	S2	Tarik	penelitian_124409.pdf
1087	447	600	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Fisika	3.56	SKS79156387262	2007-09-16	S2	Nasim	penelitian_124410.pdf
1088	416	566	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Ilmu Komputer	3.54	SKS79156387263	2007-09-18	S2	Michelle	penelitian_124411.pdf
1089	439	580	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Kedokteran	3.40	SKS79156387264	2007-09-08	S2	Lacey	penelitian_124412.pdf
1090	444	592	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Teknik Industri	3.53	SKS79156387265	2007-08-14	S2	Kyle	penelitian_124413.pdf
1091	487	552	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Sistem Informasi	3.48	SKS79156387266	2007-08-28	S2	Liberty	penelitian_124414.pdf
1092	412	504	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Elektro	3.50	SKS79156387267	2007-08-24	S2	Tarik	penelitian_124415.pdf
1093	499	543	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Akutansi	3.50	SKS79156387268	2007-09-26	S2	Walter	penelitian_124416.pdf
1094	402	524	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Akutansi	3.56	SKS79156387269	2007-08-14	S2	Ivan	penelitian_124417.pdf
1095	438	592	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Teknik Sipil	3.52	SKS79156387270	2007-09-05	S2	Dillon	penelitian_124418.pdf
1096	414	566	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Teknik Elektro	3.40	SKS79156387271	2007-08-17	S2	Ruby	penelitian_124419.pdf
1097	412	508	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Ilmu politik	3.47	SKS79156387272	2007-08-13	S2	Addison	penelitian_124420.pdf
1098	451	532	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Sastra Indonesia	3.49	SKS79156387273	2007-09-09	S2	Steven	penelitian_124421.pdf
1099	460	548	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Teknik Sipil	3.44	SKS79156387274	2007-08-28	S2	Sacha	penelitian_124422.pdf
1100	482	565	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Fisika	3.58	SKS79156387275	2007-08-08	S2	Quentin	penelitian_124423.pdf
1101	444	509	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Kedokteran	3.54	SKS79156387276	2007-09-09	S2	Richard	penelitian_124424.pdf
1102	483	538	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Sastra Inggris	3.59	SKS79156387277	2007-08-09	S2	Quemby	penelitian_124425.pdf
1103	431	529	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sistem Informasi	3.43	SKS79156387278	2007-09-09	S2	Harriet	penelitian_124426.pdf
1104	464	509	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Teknik Kimia	3.57	SKS79156387279	2007-09-25	S2	Ivan	penelitian_124427.pdf
1105	494	517	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Teknik Kimia	3.40	SKS79156387280	2007-08-29	S2	Carolyn	penelitian_124428.pdf
1106	489	505	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Ilmu Perpustakaan	3.52	SKS79156387281	2007-09-01	S2	Quentin	penelitian_124429.pdf
1107	468	565	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Psikologi	3.43	SKS79156387282	2007-08-31	S2	Beck	penelitian_124430.pdf
1108	400	547	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Ilmu politik	3.42	SKS79156387283	2007-09-04	S2	Anthony	penelitian_124431.pdf
1109	453	562	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Matematika	3.51	SKS79156387284	2007-08-19	S2	Tamekah	penelitian_124432.pdf
1110	497	506	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Sastra Perancis	3.40	SKS79156387285	2007-08-16	S2	Kieran	penelitian_124433.pdf
1111	400	570	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Sastara Belanda	3.56	SKS79156387286	2007-08-11	S2	Mia	penelitian_124434.pdf
1112	459	509	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Ilmu Komputer	3.49	SKS79156387287	2007-08-01	S2	Phillip	penelitian_124435.pdf
1113	417	588	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Ilmu politik	3.42	SKS79156387288	2007-08-06	S2	Bell	penelitian_124436.pdf
1114	483	585	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sastra Jepang	3.55	SKS79156387289	2007-09-18	S2	Lacey	penelitian_124437.pdf
1115	400	548	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Ilmu Perpustakaan	3.52	SKS79156387290	2007-09-27	S2	Stewart	penelitian_124438.pdf
1116	459	524	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Komputer	3.55	SKS79156387291	2007-10-01	S2	Lionel	penelitian_124439.pdf
1117	409	594	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sastra Arab	3.48	SKS79156387292	2007-08-15	S2	Jane	penelitian_124440.pdf
1118	485	540	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Elektro	3.42	SKS79156387293	2007-09-17	S2	Kadeem	penelitian_124441.pdf
1119	463	500	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sastra Jerman	3.57	SKS79156387294	2007-08-15	S2	Juliet	penelitian_124442.pdf
1120	455	569	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Teknik Mesin	3.59	SKS79156387295	2007-09-22	S2	Hanna	penelitian_124443.pdf
1121	454	598	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Teknik Industri	3.59	SKS79156387296	2007-09-13	S2	Jackson	penelitian_124444.pdf
1122	463	502	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Teknik Mesin	3.44	SKS79156387297	2007-08-30	S2	Anthony	penelitian_124445.pdf
1123	448	557	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Fisika	3.57	SKS79156387298	2007-09-19	S2	Steven	penelitian_124446.pdf
1124	443	580	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Matematika	3.43	SKS79156387299	2007-09-09	S2	Beck	penelitian_124447.pdf
1125	454	560	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Kedokteran	3.42	SKS79156387300	2007-09-26	S2	Walter	penelitian_124448.pdf
1126	438	593	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Sastra Perancis	3.40	SKS79156387301	2007-08-20	S2	Kyra	penelitian_124449.pdf
1127	498	555	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Psikologi	3.52	SKS79156387302	2007-09-06	S2	Upton	penelitian_124450.pdf
1128	407	553	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Teknik Mesin	3.43	SKS79156387303	2007-08-11	S2	Norman	penelitian_124451.pdf
1129	477	548	S1	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sistem Informasi	3.42	SKS79156387304	2007-08-19	S2	Idona	penelitian_124452.pdf
1130	420	573	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Ilmu Hukum	3.49	SKS79156387305	2007-08-12	S2	Hanna	penelitian_124453.pdf
1131	489	592	S1	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Akutansi	3.50	SKS79156387306	2007-08-27	S2	Ann	penelitian_124454.pdf
1132	431	575	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Sastra Arab	3.53	SKS79156387307	2007-08-26	S2	Maile	penelitian_124455.pdf
1133	480	502	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Ilmu politik	3.57	SKS79156387308	2007-09-07	S2	Dieter	penelitian_124456.pdf
1134	429	570	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Fisika	3.50	SKS79156387309	2007-08-23	S2	Olivia	penelitian_124457.pdf
1135	424	576	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Ilmu Komputer	3.43	SKS79156387310	2007-08-12	S2	Cheryl	penelitian_124458.pdf
1136	401	557	S1	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Teknik Sipil	3.59	SKS79156387311	2007-10-01	S2	Barclay	penelitian_124459.pdf
1137	437	558	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Kimia	3.44	SKS79156387312	2007-08-27	S2	Ivan	penelitian_124460.pdf
1138	412	583	S1	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Ilmu Administrasi	3.41	SKS79156387313	2007-09-19	S2	Justin	penelitian_124461.pdf
1139	449	569	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Ilmu Administrasi	3.41	SKS79156387314	2007-09-14	S2	Ann	penelitian_124462.pdf
1140	499	582	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Kimia	3.42	SKS79156387315	2007-09-18	S2	Harriet	penelitian_124463.pdf
1141	438	555	S1	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Sastra Jerman	3.44	SKS79156387316	2007-08-19	S2	Beck	penelitian_124464.pdf
1142	498	526	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Kedokteran	3.49	SKS79156387317	2007-08-19	S2	Justina	penelitian_124465.pdf
1143	414	521	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Ilmu Administrasi	3.48	SKS79156387318	2007-09-20	S2	Yvonne	penelitian_124466.pdf
1144	419	510	S1	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Psikologi	3.51	SKS79156387319	2007-08-01	S2	Quemby	penelitian_124467.pdf
1145	477	593	S1	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Sastra Perancis	3.53	SKS79156387320	2007-08-15	S2	Whilemina	penelitian_124468.pdf
1146	486	572	S1	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Sastra Indonesia	3.46	SKS79156387321	2007-08-02	S2	Lacey	penelitian_124469.pdf
1147	424	529	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Fisika	3.54	SKS79156387322	2007-09-29	S2	Jane	penelitian_124470.pdf
1148	448	550	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Kimia	3.59	SKS79156387323	2007-08-25	S2	Tarik	penelitian_124471.pdf
1149	471	536	S1	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Teknik Elektro	3.45	SKS79156387324	2007-09-13	S2	Kadeem	penelitian_124472.pdf
1150	431	511	S1	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Mesin	3.43	SKS79156387325	2007-09-25	S2	Richard	penelitian_124473.pdf
1151	466	546	S2	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Sastara Belanda	3.50	SKS79156387326	2007-10-01	S3	Jackson	penelitian_124474.pdf
1152	413	586	S2	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Sastra Korea	3.42	SKS79156387327	2007-09-06	S3	Justina	penelitian_124475.pdf
1153	453	523	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Sastara Belanda	3.48	SKS79156387328	2007-08-25	S3	Michelle	penelitian_124476.pdf
1154	431	574	S2	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Ilmu Perpustakaan	3.41	SKS79156387329	2007-08-29	S3	Hedley	penelitian_124477.pdf
1155	475	516	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Fisika	3.41	SKS79156387330	2007-09-24	S3	Idona	penelitian_124478.pdf
1156	422	512	S2	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Teknik Sipil	3.59	SKS79156387331	2007-09-12	S3	Ivan	penelitian_124479.pdf
1157	489	545	S2	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Sastra Korea	3.40	SKS79156387332	2007-09-14	S3	Anthony	penelitian_124480.pdf
1158	453	546	S2	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Teknik Sipil	3.52	SKS79156387333	2007-09-27	S3	Addison	penelitian_124481.pdf
1159	490	578	S2	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Ilmu Administrasi	3.46	SKS79156387334	2007-09-07	S3	Caldwell	penelitian_124482.pdf
1160	466	509	S2	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Kedokteran	3.56	SKS79156387335	2007-09-04	S3	Hanna	penelitian_124483.pdf
1161	457	544	S2	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Ilmu politik	3.44	SKS79156387336	2007-09-14	S3	Kyle	penelitian_124484.pdf
1162	435	528	S2	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Kimia	3.51	SKS79156387337	2007-08-15	S3	Peter	penelitian_124485.pdf
1163	427	569	S2	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Ilmu Komputer	3.48	SKS79156387338	2007-09-07	S3	Idona	penelitian_124486.pdf
1164	455	522	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Kimia	3.58	SKS79156387339	2007-08-29	S3	Bruno	penelitian_124487.pdf
1165	478	509	S2	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Sastra Arab	3.50	SKS79156387340	2007-09-07	S3	Dillon	penelitian_124488.pdf
1166	494	543	S2	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Sastra Inggris	3.42	SKS79156387341	2007-08-14	S3	Dillon	penelitian_124489.pdf
1167	487	575	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Sastara Belanda	3.52	SKS79156387342	2007-09-18	S3	Marny	penelitian_124490.pdf
1168	461	532	S2	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Sistem Informasi	3.43	SKS79156387343	2007-08-28	S3	Marah	penelitian_124491.pdf
1169	431	549	S2	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Teknik Sipil	3.58	SKS79156387344	2007-08-27	S3	Carly	penelitian_124492.pdf
1170	400	541	S2	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Sastra Korea	3.44	SKS79156387345	2007-09-08	S3	Caldwell	penelitian_124493.pdf
1171	497	547	S2	Universitas Sriwijaya	Jl. Kramat Raya No. 17 A, Palembang	Sastra Arab	3.42	SKS79156387346	2007-08-29	S3	Dara	penelitian_124494.pdf
1172	423	577	S2	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Fisika	3.45	SKS79156387347	2007-09-23	S3	Wilma	penelitian_124495.pdf
1173	476	579	S2	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Sastra Indonesia	3.56	SKS79156387348	2007-09-08	S3	Barclay	penelitian_124496.pdf
1174	442	502	S2	Universitas Gunadarma	Jl. Landas Pacu Timur, Depok	Ilmu politik	3.54	SKS79156387349	2007-09-26	S3	Violet	penelitian_124497.pdf
1175	402	569	S2	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Teknik Industri	3.47	SKS79156387350	2007-09-05	S3	Ruby	penelitian_124498.pdf
1176	485	508	S2	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Ilmu Administrasi	3.49	SKS79156387351	2007-09-30	S3	Kai	penelitian_124499.pdf
1177	490	590	S2	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Teknik Sipil	3.44	SKS79156387352	2007-08-09	S3	Marah	penelitian_124500.pdf
1178	497	599	S2	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Sastra Jepang	3.42	SKS79156387353	2007-09-13	S3	Seth	penelitian_124501.pdf
1179	428	554	S2	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Teknik Kimia	3.48	SKS79156387354	2007-08-02	S3	Porter	penelitian_124502.pdf
1180	475	524	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Teknik Kimia	3.51	SKS79156387355	2007-09-17	S3	Victoria	penelitian_124503.pdf
1181	464	525	S2	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Psikologi	3.55	SKS79156387356	2007-09-11	S3	Justin	penelitian_124504.pdf
1182	449	592	S2	Universitas Indonesia	Jl. Cempaka Putih Tengah I / 1, Depok	Sastra Arab	3.53	SKS79156387357	2007-09-16	S3	Addison	penelitian_124505.pdf
1183	444	565	S2	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sastra Korea	3.55	SKS79156387358	2007-08-25	S3	Walter	penelitian_124506.pdf
1184	443	543	S2	Universitas Padjadjaran	Jl. Kyai Caringin No. 7, Bandung	Arsitektur	3.43	SKS79156387359	2007-08-13	S3	Dieter	penelitian_124507.pdf
1185	495	593	S2	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Sastra Inggris	3.57	SKS79156387360	2007-08-09	S3	Emma	penelitian_124508.pdf
1186	624	785	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Teknik Kimia	3.96	SKS79156387361	2007-08-23	S3	Walter	penelitian_124509.pdf
1187	667	792	S2	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Fisika	3.77	SKS79156387362	2007-09-05	S3	Caldwell	penelitian_124510.pdf
1188	644	819	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Ilmu Komputer	3.84	SKS79156387363	2007-09-18	S3	Tamekah	penelitian_124511.pdf
1189	648	809	S2	Universitas Mulawarman	Jl. Raden Saleh No. 40 , Samarinda	Ilmu Komputer	3.77	SKS79156387364	2007-09-02	S3	Richard	penelitian_124512.pdf
1190	621	792	S2	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Ilmu Hukum	3.94	SKS79156387365	2007-09-28	S3	Quemby	penelitian_124513.pdf
1191	607	777	S2	Universitas Brawijaya	Jl. HOS Cokroaminoto No. 31 - 33, Surabaya	Sastra Arab	3.79	SKS79156387366	2007-08-08	S3	McKenzie	penelitian_124514.pdf
1192	600	832	S2	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Teknik Komputer	3.79	SKS79156387367	2007-08-24	S3	Roth	penelitian_124515.pdf
1193	699	819	S2	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Ilmu Administrasi	3.91	SKS79156387368	2007-09-09	S3	Gisela	penelitian_124516.pdf
1194	644	849	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Fisika	3.92	SKS79156387369	2007-09-20	S3	Quentin	penelitian_124517.pdf
1195	620	759	S2	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Psikologi	3.86	SKS79156387370	2007-09-25	S3	Marny	penelitian_124518.pdf
1196	684	757	S2	Universitas Diponegoro	Jl. Diponegoro No. 71, Semarang	Ilmu Administrasi	3.75	SKS79156387371	2007-08-29	S3	Bruno	penelitian_124519.pdf
1197	651	835	S2	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Akutansi	3.75	SKS79156387372	2007-09-14	S3	Ivan	penelitian_124520.pdf
1198	627	751	S2	Institut Teknologi Bandung	Jl. Kali Pasir  No. 9, Bandung	Sastra Inggris	3.82	SKS79156387373	2007-08-21	S3	Walter	penelitian_124521.pdf
1199	674	827	S2	Universitas Gadjah Mada	Jl. Achmad Yani No. 2, By Pass, Yogyakarta	Sastara Belanda	3.78	SKS79156387374	2007-08-01	S3	Peter	penelitian_124522.pdf
1200	642	850	S2	Institut Teknologi Surabaya	Jl. Raya Mangga Besar Raya 137 / 139, Surabaya	Sastra Inggris	3.86	SKS79156387375	2007-08-06	S3	Carly	penelitian_124523.pdf
\.


--
-- Data for Name: pendaftaran_semas_sarjana; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pendaftaran_semas_sarjana (id_pendaftaran, asal_sekolah, jenis_sma, alamat_sekolah, nisn, tgl_lulus, nilai_uan) FROM stdin;
201	SMK Negeri 16 Bandung	Teknik Komputer	Jl. Kali Pasir  No. 9, Bandung	9945675351	2017-05-15	37.64
202	SMA Negeri 18 Bandung	IPS	Jl. Raya Mangga Besar Raya 137 / 139, Bandung	9945675352	2017-05-15	38.66
203	SMA Negeri 17 Bogor	IPA	Jl. Diponegoro No. 71, Bogor	9945675353	2017-05-15	37.66
204	SMK Negeri 18 Medan	Multimedia	Jl. Kramat Raya No. 17 A, Medan	9945675354	2017-05-15	37.52
205	SMK Negeri 06 Jakarta Selatan	Multimedia	Jl. Kramat Raya No. 128, Jakarta Selatan	9945675355	2017-05-15	37.39
206	SMK Negeri 01 Bogor	Teknik Komputer	Jl. Salemba Raya No. 41, Bogor	9945675356	2017-05-15	37.82
207	SMA Negeri 14 Makasar	IPS	Jl. Salemba Tengah 26 - 28, Makasar	9945675357	2017-05-15	38.08
208	SMA Negeri 09 Garut	IPA	Jl. Dr. Abdul Rachman Saleh 24, Garut	9945675358	2017-05-15	37.98
209	SMK Negeri 15 Bali 	Teknik Komputer	Jl. Bendungan Hilir No. 17, Bali 	9945675359	2017-05-15	38.10
210	SMK Negeri 11 Bali 	Analisa Kimia	Jl. Rawamangun No. 47, Bali 	9945675360	2017-05-15	37.95
211	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675361	2017-05-15	38.51
212	SMK Negeri 16 Papua	Multimedia	Jl. Kesehatan No. 9, Papua	9945675362	2017-05-15	38.72
213	SMA Negeri 12 Aceh	IPS	Jl. Kaji No. 40, Aceh	9945675363	2017-05-15	37.85
214	SMK Negeri 08 Bali 	Multimedia	Jl. Sawo No. 58 - 60, Bali 	9945675364	2017-05-15	38.49
215	SMA Negeri 14 Semarang	IPA	Jl. Sumur Batu Raya Blok A3 No. 13, Semarang	9945675365	2017-05-15	37.45
216	SMK Negeri 01 Aceh	Teknik Komputer	Jl. Gereja Theresia No. 22, Aceh	9945675366	2017-05-15	35.83
217	SMA Negeri 12 Makasar	IPA	Jl. Teuku Cik Ditiro No. 28, Makasar	9945675367	2017-05-15	35.54
218	SMA Negeri 15 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675368	2017-05-15	35.14
219	SMA Negeri 03 Palembang	IPS	Jl. Teuku Cik Ditiro No. 46  M, Palembang	9945675369	2017-05-15	34.93
220	SMK Negeri 19 Maluku	Analisa Kimia	Jl. Proklamasi  No. 43 , Maluku	9945675370	2017-05-15	34.69
221	SMK Negeri 06 Balikpapan	Teknik Komputer	Jl. Tambak No. 18, Balikpapan	9945675371	2017-05-15	34.66
222	SMK Negeri 13 Papua	Teknik Otomasi	Jl. Salemba Raya, Papua	9945675372	2017-05-15	35.89
223	SMA Negeri 17 Bogor	IPA	Jl. Salemba I  No. 13, Bogor	9945675373	2017-05-15	34.78
224	SMK Negeri 11 Depok	Teknik Komputer	Jl. Jenderal Sudirman Kavling 86, Depok	9945675374	2017-05-15	36.29
225	SMK Negeri 07 Banten	Multimedia	Jl. Tipar Cakung No. 5, Banten	9945675375	2017-05-15	34.97
226	SMA Negeri 19 Maluku	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Maluku	9945675376	2017-05-15	36.42
227	SMK Negeri 08 Palembang	Teknik Mesin	Jl. Bukit Gading Raya Kav. II, Palembang	9945675377	2017-05-15	36.11
228	SMA Negeri 04 Aceh	IPA	Jl. Deli No. 4  Tanjung Priok, Aceh	9945675378	2017-05-15	35.80
229	SMA Negeri 12 Banten	IPS	Jl. Kramat Jaya, Tanjung Priok, Banten	9945675379	2017-05-15	35.92
230	SMK Negeri 13 Depok	Teknik Otomasi	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Depok	9945675380	2017-05-15	34.09
231	SMA Negeri 15 Lombok	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Lombok	9945675381	2017-05-15	36.09
232	SMK Negeri 04 Depok	Analisa Kimia	Jl. Pluit Raya No. 2, Depok	9945675382	2017-05-15	35.41
233	SMA Negeri 09 Depok	IPA	Jl. Raya Pluit Selatan No. 2, Depok	9945675383	2017-05-15	35.61
234	SMA Negeri 17 Jakarta Utara	IPA	Jl Sungai Bambu  No. 5, Jakarta Utara	9945675384	2017-05-15	34.50
235	SMK Negeri 03 Garut	Teknik Mesin	Jl. Agung Utara Raya Blok A No. 1, Garut	9945675385	2017-05-15	35.62
236	SMA Negeri 01 Bali 	IPS	Jl. Danau Sunter Utara Raya No. 1, Bali 	9945675386	2017-05-15	35.38
237	SMK Negeri 16 Depok	Teknik Mesin	Jl. Enggano No. 10, Depok	9945675387	2017-05-15	34.62
238	SMK Negeri 19 Papua	Teknik Mesin	Jl. Tawes No. 18-20 , Papua	9945675388	2017-05-15	34.09
239	SMA Negeri 18 Bogor	IPS	Pluit Mas I Blok A No. 2A - 5A, Bogor	9945675389	2017-05-15	36.25
240	SMA Negeri 16 Maluku	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Maluku	9945675390	2017-05-15	34.55
241	SMK Negeri 02 Balikpapan	Teknik Otomasi	Jl. Baru Sunter Permai Raya, Balikpapan	9945675391	2017-05-15	35.67
242	SMA Negeri 06 Palembang	IPS	Jl. Ganggeng Raya No.9, Palembang	9945675392	2017-05-15	35.93
243	SMA Negeri 11 Palembang	IPA	Jl. Siak J-5 No. 14, Palembang	9945675393	2017-05-15	34.06
244	SMA Negeri 17 Papua	IPA	Jl. Danau Agung 2 Blok E 3 No. 28-30, Papua	9945675394	2017-05-15	34.03
245	SMA Negeri 07 Balikpapan	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Balikpapan	9945675395	2017-05-15	36.29
246	SMK Negeri 02 Jakarta Selatan	Teknik Otomasi	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675396	2017-05-15	36.05
247	SMA Negeri 11 Garut	IPA	Jl. Daan Mogot No. 34, Garut	9945675397	2017-05-15	35.81
248	SMK Negeri 02 Bontang	Teknik Otomasi	Jl. Kyai Tapa No. 1, Bontang	9945675398	2017-05-15	36.42
249	SMA Negeri 19 Jakarta Selatan	IPS	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Selatan	9945675399	2017-05-15	35.19
250	SMA Negeri 17 Makasar	IPS	Jl. Raya Pejuangan Kav. 8, Makasar	9945675400	2017-05-15	35.11
251	SMK Negeri 19 Medan	Multimedia	Jl. Kedoya Raya / Al-Kamal No. 2, Medan	9945675401	2017-05-15	34.16
252	SMA Negeri 05 Surabaya	IPA	Jl. Panjang Arteri 26, Surabaya	9945675402	2017-05-15	36.03
253	SMK Negeri 18 Makasar	Multimedia	Jl. Raya Kebayoran Lama No. 64 , Makasar	9945675403	2017-05-15	35.50
254	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Puri Indah Raya  Blok S-2, Balikpapan	9945675404	2017-05-15	34.05
255	SMA Negeri 14 Bontang	IPA	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675405	2017-05-15	34.64
256	SMK Negeri 15 Makasar	Teknik Otomasi	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675406	2017-05-15	35.49
257	SMA Negeri 18 Bali 	IPS	Jl. Raya kamal Outer Ring Road, Bali 	9945675407	2017-05-15	34.53
258	SMA Negeri 15 Semarang	IPA	Jl. Prof. Dr. Latumeten No. 1, Semarang	9945675408	2017-05-15	34.19
259	SMA Negeri 12 Jakarta Utara	IPS	Jl. Duri Raya No. 22, Jakarta Utara	9945675409	2017-05-15	34.54
260	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Letjen S. Parman Kav. 84-86, Balikpapan	9945675410	2017-05-15	35.78
261	SMK Negeri 02 Makasar	Teknik Mesin	Jl. LetJen S. Parman Kav. 87, Slipi, Makasar	9945675411	2017-05-15	34.39
262	SMA Negeri 07 Jakarta Utara	IPS	Jl. LetJen S. Parman Kav. 87, Jakarta Utara	9945675412	2017-05-15	35.42
263	SMA Negeri 14 Jakarta Utara	IPA	Jl. Tanah Sereal VII / 9, Jakarta Utara	9945675413	2017-05-15	35.14
264	SMA Negeri 01 Balikpapan	IPS	Jl. Kyai Tapa No. , Balikpapan	9945675414	2017-05-15	36.44
265	SMA Negeri 11 Garut	IPS	Jl. Anggrek No. 2 B, Garut	9945675415	2017-05-15	36.12
266	SMA Negeri 14 Bandung	IPS	Jl. Pesanggrahan No. 1, Bandung	9945675416	2017-05-15	36.31
267	SMA Negeri 18 Papua	IPA	Jl. RS Fatmawati No. 80 - 82, Papua	9945675417	2017-05-15	35.76
268	SMA Negeri 07 Medan	IPA	Jl. RS. Fatmawati, Medan	9945675418	2017-05-15	35.12
269	SMA Negeri 19 Surabaya	IPA	Jl. Lebak Bulus 1, Surabaya	9945675419	2017-05-15	35.77
270	SMK Negeri 14 Bali 	Analisa Kimia	Jl. RS Fatmawati No. 74 , Bali 	9945675420	2017-05-15	34.56
271	SMK Negeri 16 Aceh	Teknik Mesin	Jl. Warung Silah No. 1, Aceh	9945675421	2017-05-15	34.03
272	SMK Negeri 02 Depok	Teknik Otomasi	Jl. Sirsak No. 21, Depok	9945675422	2017-05-15	34.05
273	SMK Negeri 15 Aceh	Multimedia	Jl. Kyai Maja No. 43, Aceh	9945675423	2017-05-15	36.18
274	SMK Negeri 06 Garut	Teknik Mesin	Jl. Gandaria I / 20, Garut	9945675424	2017-05-15	35.97
275	SMK Negeri 05 Balikpapan	Teknik Komputer	Jl. Gandaria Tengah II No. 6 - 14, Balikpapan	9945675425	2017-05-15	34.76
276	SMA Negeri 14 Bandung	IPA	Jl. Metro Duta Kav. UE,  Pondok Indah, Bandung	9945675426	2017-05-15	35.31
277	SMA Negeri 07 Maluku	IPS	Jl. Ciputat Raya No. 40, Maluku	9945675427	2017-05-15	35.80
278	SMA Negeri 19 Depok	IPS	Jl. Warung Buncit Raya No. 15, Depok	9945675428	2017-05-15	35.97
279	SMK Negeri 11 Garut	Teknik Otomasi	Jl. Raya Cilandak  KKO, Garut	9945675429	2017-05-15	35.71
280	SMK Negeri 02 Papua	Teknik Komputer	Jl. Siaga Raya Kav. 4 - 8, Papua	9945675430	2017-05-15	36.17
281	SMK Negeri 05 Surabaya	Multimedia	Jl. R. C. Veteran No. 178, Surabaya	9945675431	2017-05-15	34.61
282	SMK Negeri 19 Bontang	Teknik Komputer	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Bontang	9945675432	2017-05-15	36.09
283	SMA Negeri 09 Makasar	IPA	Jl. Jend. Sudirman Kav. 49 , Makasar	9945675433	2017-05-15	35.19
284	SMA Negeri 04 Bogor	IPS	Jl. Jenderal Gatot Subroto Kav. 59, Bogor	9945675434	2017-05-15	34.86
285	SMK Negeri 05 Surabaya	Multimedia	Jl. Sultan Agung No. 67, Surabaya	9945675435	2017-05-15	36.00
286	SMA Negeri 12 Jakarta Utara	IPA	Jl. MT. Haryono No. 8, Jakarta Utara	9945675436	2017-05-15	36.44
287	SMA Negeri 07 Makasar	IPA	Jl. Raya Pasar Minggu No. 3 A, Makasar	9945675437	2017-05-15	35.89
288	SMA Negeri 11 Jakarta Utara	IPA	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Jakarta Utara	9945675438	2017-05-15	34.24
289	SMA Negeri 14 Jakarta Selatan	IPS	Jl. Mohamad Kahfi Raya 1, Jakarta Selatan	9945675439	2017-05-15	35.68
290	SMK Negeri 07 Banten	Teknik Mesin	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Banten	9945675440	2017-05-15	34.47
291	SMA Negeri 07 Balikpapan	IPA	Jl. Bina Warga RT. 009 / RW. 07, Kalibata, Balikpapan	9945675441	2017-05-15	34.21
292	SMA Negeri 05 Surabaya	IPS	Jl. Taman Brawijaya No. 1, Surabaya	9945675442	2017-05-15	35.06
293	SMK Negeri 04 Banten	Teknik Komputer	Jl. Panglima Polim I  No. 34, Banten	9945675443	2017-05-15	34.84
294	SMK Negeri 14 Surabaya	Analisa Kimia	Jl. Dharmawangsa Raya No. 13  Blok P II, Surabaya	9945675444	2017-05-15	34.32
295	SMA Negeri 16 Papua	IPA	Jl. Ciranjang  II No. 20-22, Papua	9945675445	2017-05-15	36.19
296	SMK Negeri 05 Papua	Teknik Komputer	Jl. Senayan No. 26, Papua	9945675446	2017-05-15	36.42
297	SMK Negeri 15 Banten	Multimedia	Jl. Ciledug Raya No. 94 - 96, Banten	9945675447	2017-05-15	35.20
298	SMK Negeri 07 Papua	Multimedia	Jl. Ciputat Raya No. 5, Papua	9945675448	2017-05-15	35.40
299	SMA Negeri 14 Bogor	IPS	Jl. Duren Tiga Raya No. 20, Bogor	9945675449	2017-05-15	35.55
300	SMK Negeri 04 Medan	Multimedia	Jl. Duren Tiga Raya No. 5, Medan	9945675450	2017-05-15	34.24
301	SMK Negeri 11 Jakarta Utara	Multimedia	Jl. H. Rohimin No. 30, Jakarta Utara	9945675451	2017-05-15	35.77
302	SMA Negeri 06 Semarang	IPA	Jl. Ampera Raya No. 34, Semarang	9945675452	2017-05-15	34.78
303	SMK Negeri 09 Semarang	Analisa Kimia	Jl. Garnisun No. 2 - 3, Semarang	9945675453	2017-05-15	34.64
304	SMA Negeri 14 Bandung	IPS	Jl. HR. Rasuna Said, Kuningan, Bandung	9945675454	2017-05-15	35.01
305	SMK Negeri 08 Jakarta Selatan	Multimedia	Jl. Dr. Saharjo No. 120, Jakarta Selatan	9945675455	2017-05-15	35.80
306	SMK Negeri 14 Depok	Multimedia	Jl. Bintaro Permai Raya No. 3, Depok	9945675456	2017-05-15	36.44
307	SMK Negeri 05 Aceh	Multimedia	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Aceh	9945675457	2017-05-15	34.29
308	SMK Negeri 19 Bali 	Analisa Kimia	Jl. Raya Bogor KM. 22 No. 44, Bali 	9945675458	2017-05-15	36.03
309	SMK Negeri 18 Makasar	Teknik Mesin	Jl. Pahlawan Revolusi No. 47, Makasar	9945675459	2017-05-15	35.47
310	SMK Negeri 06 Papua	Teknik Otomasi	Jl. Raya Pondok Kopi, Papua	9945675460	2017-05-15	36.37
311	SMK Negeri 05 Aceh	Teknik Komputer	Jl. Mahoni, Pasar Rebo, Cijantung II , Aceh	9945675461	2017-05-15	35.45
312	SMK Negeri 04 Jakarta Utara	Teknik Otomasi	Jl. Raya Bekasi Timur 170 C, Jakarta Utara	9945675462	2017-05-15	34.44
313	SMA Negeri 13 Bandung	IPS	Jl. Raya Jatinegara Timur No. 85 - 87, Bandung	9945675463	2017-05-15	34.84
314	SMA Negeri 11 Bandung	IPA	Jl. Merpati No. 2, Bandung	9945675464	2017-05-15	36.22
315	SMA Negeri 16 Papua	IPA	Jl. Dewi Sartika III No. 200, Papua	9945675465	2017-05-15	34.58
316	SMA Negeri 05 Maluku	IPS	Jl. Raya Bogor, Maluku	9945675466	2017-05-15	35.08
317	SMK Negeri 15 Jakarta Utara	Multimedia	Jl. RS Polri, Jakarta Utara	9945675467	2017-05-15	34.92
318	SMA Negeri 04 Depok	IPS	Jl. Mayjen Sutoyo No. 2, Depok	9945675468	2017-05-15	34.36
319	SMK Negeri 11 Makasar	Teknik Komputer	Jl. Tarum Barat - Kalimalang, Makasar	9945675469	2017-05-15	35.42
320	SMA Negeri 12 Surabaya	IPS	Jl. Raya Pondok Gede No. 4, Surabaya	9945675470	2017-05-15	36.35
321	SMA Negeri 08 Garut	IPA	Jl. Letjen T. B. Simatupang No. 30, Garut	9945675471	2017-05-15	36.44
322	SMA Negeri 12 Palembang	IPA	Jl. Pemuda, Palembang	9945675472	2017-05-15	34.24
323	SMK Negeri 02 Semarang	Teknik Mesin	Jl. Kayu Putih Raya, Semarang	9945675473	2017-05-15	34.51
324	SMA Negeri 16 Maluku	IPA	Jl. Pulomas Barat VI No. 20, Maluku	9945675474	2017-05-15	36.18
325	SMK Negeri 12 Maluku	Teknik Mesin	Jl. Pulomas Timur K. No.2, Maluku	9945675475	2017-05-15	35.04
326	SMA Negeri 01 Maluku	IPA	Jl. Persahabatan Raya , Maluku	9945675476	2017-05-15	35.86
327	SMA Negeri 09 Semarang	IPS	Jl. Perintis Kemerdekaan Kav. 149, Semarang	9945675477	2017-05-15	34.53
328	SMA Negeri 08 Medan	IPA	Jl. Balai Pustaka Baru No. 19, Medan	9945675478	2017-05-15	36.50
329	SMA Negeri 06 Lombok	IPS	Jl. Pahlawan Komarudin Raya No. 5, Lombok	9945675479	2017-05-15	36.21
330	SMA Negeri 01 Lombok	IPA	Jl. LapanganTembak No. 75, Lombok	9945675480	2017-05-15	34.93
331	SMA Negeri 13 Jakarta Selatan	IPS	Jl. Duren Sawit Baru No. 2, Jakarta Selatan	9945675481	2017-05-15	36.23
332	SMA Negeri 19 Palembang	IPS	Jl. Raden Inten, Palembang	9945675482	2017-05-15	34.47
333	SMK Negeri 01 Banten	Teknik Komputer	Jl. Bunga Rampai X - Perumnas Klender, Banten	9945675483	2017-05-15	34.47
334	SMK Negeri 19 Banten	Teknik Mesin	Jl. Pahlawan Revolusi No. 100, Banten	9945675484	2017-05-15	35.90
335	SMK Negeri 05 Banten	Multimedia	Jl. Basuki Rachmat  No. 31, Banten	9945675485	2017-05-15	34.15
336	SMK Negeri 05 Jakarta Selatan	Teknik Komputer	Jl. Taman Malaka Selatan No. 6, Jakarta Selatan	9945675486	2017-05-15	34.51
337	SMA Negeri 09 Depok	IPS	Jl. Jatinegara Barat No. 126 , Depok	9945675487	2017-05-15	34.12
338	SMA Negeri 02 Jakarta Utara	IPS	JL. Duren Sawit Raya Blok K.3 No.1, Jakarta Utara	9945675488	2017-05-15	36.23
339	SMA Negeri 05 Jakarta Utara	IPS	Jl. Raya Bogor  Km. 19  No. 3.a, Jakarta Utara	9945675489	2017-05-15	36.47
340	SMA Negeri 01 Medan	IPS	Jl. TB Simatupang No. 71 Jak-Tim, Medan	9945675490	2017-05-15	34.94
341	SMA Negeri 15 Makasar	IPA	Jl. H. Ten, Makasar	9945675491	2017-05-15	35.78
342	SMK Negeri 13 Bandung	Analisa Kimia	Jl. Balai Pustaka Raya No. 29-31, Bandung	9945675492	2017-05-15	34.03
343	SMK Negeri 17 Bogor	Analisa Kimia	Jl. Pemuda No. 80  RT.001 RW.08, Bogor	9945675493	2017-05-15	34.84
344	SMK Negeri 02 Bogor	Multimedia	Jl. Diponegoro No. 71, Bogor	9945675494	2017-05-15	35.98
345	SMA Negeri 16 Surabaya	IPS	Jl. Kramat Raya No. 17 A, Surabaya	9945675495	2017-05-15	35.93
346	SMK Negeri 14 Jakarta Utara	Teknik Komputer	Jl. Kramat Raya No. 128, Jakarta Utara	9945675496	2017-05-15	34.30
347	SMA Negeri 02 Banten	IPS	Jl. Salemba Raya No. 41, Banten	9945675497	2017-05-15	34.08
348	SMK Negeri 08 Depok	Analisa Kimia	Jl. Salemba Tengah 26 - 28, Depok	9945675498	2017-05-15	36.50
349	SMA Negeri 09 Jakarta Utara	IPA	Jl. Dr. Abdul Rachman Saleh 24, Jakarta Utara	9945675499	2017-05-15	35.35
350	SMA Negeri 18 Bogor	IPA	Jl. Bendungan Hilir No. 17, Bogor	9945675500	2017-05-15	36.12
351	SMA Negeri 18 Surabaya	IPS	Jl. Rawamangun No. 47, Surabaya	9945675501	2017-05-15	35.15
352	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675502	2017-05-15	36.14
353	SMA Negeri 04 Banten	IPS	Jl. Kesehatan No. 9, Banten	9945675503	2017-05-15	36.43
354	SMA Negeri 14 Papua	IPS	Jl. Kaji No. 40, Papua	9945675504	2017-05-15	35.84
355	SMA Negeri 06 Aceh	IPS	Jl. Sawo No. 58 - 60, Aceh	9945675505	2017-05-15	34.00
356	SMK Negeri 14 Bontang	Analisa Kimia	Jl. Sumur Batu Raya Blok A3 No. 13, Bontang	9945675506	2017-05-15	36.01
357	SMK Negeri 09 Bali 	Teknik Komputer	Jl. Gereja Theresia No. 22, Bali 	9945675507	2017-05-15	34.50
358	SMK Negeri 17 Jakarta Selatan	Teknik Mesin	Jl. Teuku Cik Ditiro No. 28, Jakarta Selatan	9945675508	2017-05-15	36.38
359	SMA Negeri 03 Maluku	IPA	Jl. Teuku Cik Ditiro No. 41, Maluku	9945675509	2017-05-15	35.65
360	SMA Negeri 09 Balikpapan	IPS	Jl. Kyai Maja No. 43, Balikpapan	9945675510	2017-05-15	35.42
361	SMK Negeri 17 Bontang	Multimedia	Jl. Gandaria I / 20, Bontang	9945675511	2017-05-15	34.98
362	SMK Negeri 05 Aceh	Multimedia	Jl. Gandaria Tengah II No. 6 - 14, Aceh	9945675512	2017-05-15	36.02
363	SMK Negeri 09 Balikpapan	Teknik Mesin	Jl. Metro Duta Kav. UE,  Pondok Indah, Balikpapan	9945675513	2017-05-15	34.40
364	SMK Negeri 15 Jakarta Selatan	Teknik Komputer	Jl. Ciputat Raya No. 40, Jakarta Selatan	9945675514	2017-05-15	35.87
365	SMK Negeri 04 Maluku	Teknik Mesin	Jl. Warung Buncit Raya No. 15, Maluku	9945675515	2017-05-15	35.50
366	SMK Negeri 12 Semarang	Teknik Otomasi	Jl. Raya Cilandak  KKO, Semarang	9945675516	2017-05-15	36.25
367	SMK Negeri 17 Palembang	Analisa Kimia	Jl. Siaga Raya Kav. 4 - 8, Palembang	9945675517	2017-05-15	35.79
368	SMK Negeri 17 Banten	Multimedia	Jl. R. C. Veteran No. 178, Banten	9945675518	2017-05-15	34.49
369	SMK Negeri 08 Depok	Analisa Kimia	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Depok	9945675519	2017-05-15	35.15
370	SMA Negeri 13 Bogor	IPA	Jl. Jend. Sudirman Kav. 49 , Bogor	9945675520	2017-05-15	35.57
371	SMK Negeri 08 Surabaya	Teknik Mesin	Jl. Jenderal Gatot Subroto Kav. 59, Surabaya	9945675521	2017-05-15	34.54
372	SMA Negeri 16 Bali 	IPA	Jl. Sultan Agung No. 67, Bali 	9945675522	2017-05-15	36.36
373	SMA Negeri 15 Palembang	IPA	Jl. MT. Haryono No. 8, Palembang	9945675523	2017-05-15	34.00
374	SMK Negeri 01 Lombok	Analisa Kimia	Jl. Raya Pasar Minggu No. 3 A, Lombok	9945675524	2017-05-15	36.12
375	SMK Negeri 01 Bogor	Teknik Mesin	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Bogor	9945675525	2017-05-15	35.40
376	SMK Negeri 08 Semarang	Teknik Mesin	Jl. Mohamad Kahfi Raya 1, Semarang	9945675526	2017-05-15	36.48
377	SMA Negeri 03 Aceh	IPS	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Aceh	9945675527	2017-05-15	35.36
378	SMA Negeri 13 Bontang	IPA	Jl. Teuku Cik Ditiro No. 28, Bontang	9945675528	2017-05-15	35.48
379	SMA Negeri 14 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675529	2017-05-15	34.51
380	SMK Negeri 02 Bogor	Teknik Komputer	Jl. Teuku Cik Ditiro No. 46  M, Bogor	9945675530	2017-05-15	34.61
381	SMA Negeri 11 Semarang	IPS	Jl. Proklamasi  No. 43 , Semarang	9945675531	2017-05-15	35.84
382	SMA Negeri 02 Maluku	IPS	Jl. Tambak No. 18, Maluku	9945675532	2017-05-15	35.31
383	SMK Negeri 14 Medan	Teknik Otomasi	Jl. Salemba Raya, Medan	9945675533	2017-05-15	35.75
384	SMK Negeri 19 Bali 	Teknik Otomasi	Jl. Salemba I  No. 13, Bali 	9945675534	2017-05-15	35.77
385	SMK Negeri 15 Makasar	Multimedia	Jl. Jenderal Sudirman Kavling 86, Makasar	9945675535	2017-05-15	34.17
386	SMK Negeri 13 Garut	Multimedia	Jl. Tipar Cakung No. 5, Garut	9945675536	2017-05-15	34.69
387	SMA Negeri 11 Palembang	IPA	Jl. Boulevard Timur Raya RT. 006 / 02, Palembang	9945675537	2017-05-15	35.10
388	SMK Negeri 01 Bandung	Teknik Otomasi	Jl. Bukit Gading Raya Kav. II, Bandung	9945675538	2017-05-15	34.74
389	SMK Negeri 06 Palembang	Teknik Otomasi	Jl. Deli No. 4  Tanjung Priok, Palembang	9945675539	2017-05-15	35.39
390	SMA Negeri 13 Jakarta Utara	IPA	Jl. Kramat Jaya, Tanjung Priok, Jakarta Utara	9945675540	2017-05-15	35.55
391	SMK Negeri 03 Lombok	Teknik Komputer	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Lombok	9945675541	2017-05-15	34.29
392	SMA Negeri 12 Bogor	IPS	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Bogor	9945675542	2017-05-15	36.01
393	SMK Negeri 11 Palembang	Teknik Otomasi	Jl. Pluit Raya No. 2, Palembang	9945675543	2017-05-15	35.96
394	SMA Negeri 19 Surabaya	IPA	Jl. Raya Pluit Selatan No. 2, Surabaya	9945675544	2017-05-15	36.43
395	SMA Negeri 03 Bontang	IPA	Jl. Cempaka Putih Tengah I / 1, Bontang	9945675545	2017-05-15	34.11
396	SMK Negeri 07 Aceh	Teknik Otomasi	Jl. Achmad Yani No. 2, By Pass, Aceh	9945675546	2017-05-15	34.09
397	SMA Negeri 13 Jakarta Selatan	IPS	Jl. Kyai Caringin No. 7, Jakarta Selatan	9945675547	2017-05-15	34.22
398	SMK Negeri 06 Semarang	Teknik Mesin	Jl. Landas Pacu Timur, Semarang	9945675548	2017-05-15	34.00
399	SMA Negeri 15 Bali 	IPA	Jl. Raden Saleh No. 40 , Bali 	9945675549	2017-05-15	35.89
400	SMA Negeri 07 Depok	IPA	Jl. HOS Cokroaminoto No. 31 - 33, Depok	9945675550	2017-05-15	35.65
401	SMK Negeri 19 Semarang	Teknik Komputer	Jl. Kali Pasir  No. 9, Semarang	9945675551	2017-05-15	34.99
402	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Raya Mangga Besar Raya 137 / 139, Balikpapan	9945675552	2017-05-15	34.40
403	SMK Negeri 05 Depok	Teknik Mesin	Jl. Diponegoro No. 71, Depok	9945675553	2017-05-15	34.99
404	SMK Negeri 14 Balikpapan	Teknik Otomasi	Jl. Kramat Raya No. 17 A, Balikpapan	9945675554	2017-05-15	35.96
405	SMK Negeri 09 Papua	Teknik Otomasi	Jl. Kramat Raya No. 128, Papua	9945675555	2017-05-15	38.88
406	SMK Negeri 16 Medan	Multimedia	Jl. Salemba Raya No. 41, Medan	9945675556	2017-05-15	37.37
407	SMA Negeri 12 Lombok	IPS	Jl. Salemba Tengah 26 - 28, Lombok	9945675557	2017-05-15	38.30
408	SMK Negeri 06 Bandung	Teknik Otomasi	Jl. Dr. Abdul Rachman Saleh 24, Bandung	9945675558	2017-05-15	37.55
409	SMK Negeri 01 Bogor	Teknik Mesin	Jl. Bendungan Hilir No. 17, Bogor	9945675559	2017-05-15	37.39
410	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Rawamangun No. 47, Balikpapan	9945675560	2017-05-15	37.48
411	SMA Negeri 12 Bontang	IPS	Jl. Budi Kemuliaan No. 25 , Bontang	9945675561	2017-05-15	37.44
412	SMK Negeri 11 Jakarta Selatan	Multimedia	Jl. Kesehatan No. 9, Jakarta Selatan	9945675562	2017-05-15	38.24
413	SMA Negeri 02 Medan	IPS	Jl. Kaji No. 40, Medan	9945675563	2017-05-15	37.80
414	SMK Negeri 03 Garut	Analisa Kimia	Jl. Sawo No. 58 - 60, Garut	9945675564	2017-05-15	37.33
415	SMK Negeri 11 Lombok	Teknik Komputer	Jl. Sumur Batu Raya Blok A3 No. 13, Lombok	9945675565	2017-05-15	37.86
416	SMA Negeri 18 Depok	IPA	Jl. Gereja Theresia No. 22, Depok	9945675566	2017-05-15	38.66
417	SMK Negeri 06 Jakarta Utara	Teknik Mesin	Jl. Teuku Cik Ditiro No. 28, Jakarta Utara	9945675567	2017-05-15	38.99
418	SMK Negeri 03 Lombok	Teknik Mesin	Jl. Teuku Cik Ditiro No. 41, Lombok	9945675568	2017-05-15	37.73
419	SMK Negeri 14 Bali 	Multimedia	Jl. Teuku Cik Ditiro No. 46  M, Bali 	9945675569	2017-05-15	37.94
420	SMK Negeri 09 Makasar	Analisa Kimia	Jl. Proklamasi  No. 43 , Makasar	9945675570	2017-05-15	38.51
421	SMA Negeri 15 Jakarta Selatan	IPS	Jl. Tambak No. 18, Jakarta Selatan	9945675571	2017-05-15	38.03
422	SMK Negeri 15 Bogor	Multimedia	Jl. Salemba Raya, Bogor	9945675572	2017-05-15	37.37
423	SMK Negeri 04 Depok	Analisa Kimia	Jl. Salemba I  No. 13, Depok	9945675573	2017-05-15	38.69
424	SMK Negeri 14 Garut	Teknik Otomasi	Jl. Jenderal Sudirman Kavling 86, Garut	9945675574	2017-05-15	38.02
425	SMA Negeri 19 Balikpapan	IPS	Jl. Tipar Cakung No. 5, Balikpapan	9945675575	2017-05-15	37.95
426	SMA Negeri 02 Papua	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Papua	9945675576	2017-05-15	37.23
427	SMK Negeri 13 Surabaya	Multimedia	Jl. Bukit Gading Raya Kav. II, Surabaya	9945675577	2017-05-15	37.56
428	SMK Negeri 18 Makasar	Teknik Komputer	Jl. Deli No. 4  Tanjung Priok, Makasar	9945675578	2017-05-15	37.02
429	SMK Negeri 05 Makasar	Teknik Otomasi	Jl. Kramat Jaya, Tanjung Priok, Makasar	9945675579	2017-05-15	38.27
430	SMK Negeri 17 Papua	Analisa Kimia	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Papua	9945675580	2017-05-15	37.81
431	SMA Negeri 11 Bali 	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Bali 	9945675581	2017-05-15	38.51
432	SMK Negeri 05 Banten	Multimedia	Jl. Pluit Raya No. 2, Banten	9945675582	2017-05-15	38.03
433	SMA Negeri 07 Medan	IPS	Jl. Raya Pluit Selatan No. 2, Medan	9945675583	2017-05-15	38.53
434	SMA Negeri 16 Makasar	IPA	Jl Sungai Bambu  No. 5, Makasar	9945675584	2017-05-15	37.10
435	SMA Negeri 15 Jakarta Selatan	IPS	Jl. Agung Utara Raya Blok A No. 1, Jakarta Selatan	9945675585	2017-05-15	38.38
436	SMK Negeri 06 Aceh	Multimedia	Jl. Danau Sunter Utara Raya No. 1, Aceh	9945675586	2017-05-15	38.19
437	SMK Negeri 07 Maluku	Teknik Mesin	Jl. Enggano No. 10, Maluku	9945675587	2017-05-15	38.49
438	SMK Negeri 13 Aceh	Multimedia	Jl. Tawes No. 18-20 , Aceh	9945675588	2017-05-15	38.62
439	SMA Negeri 19 Garut	IPA	Pluit Mas I Blok A No. 2A - 5A, Garut	9945675589	2017-05-15	37.84
440	SMA Negeri 09 Garut	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Garut	9945675590	2017-05-15	37.77
441	SMK Negeri 14 Semarang	Teknik Mesin	Jl. Baru Sunter Permai Raya, Semarang	9945675591	2017-05-15	38.96
442	SMK Negeri 06 Semarang	Teknik Mesin	Jl. Ganggeng Raya No.9, Semarang	9945675592	2017-05-15	38.02
443	SMK Negeri 06 Maluku	Teknik Otomasi	Jl. Siak J-5 No. 14, Maluku	9945675593	2017-05-15	37.93
444	SMA Negeri 17 Bali 	IPS	Jl. Danau Agung 2 Blok E 3 No. 28-30, Bali 	9945675594	2017-05-15	38.64
445	SMA Negeri 04 Papua	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Papua	9945675595	2017-05-15	37.08
446	SMA Negeri 16 Jakarta Selatan	IPS	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675596	2017-05-15	38.71
447	SMA Negeri 01 Palembang	IPA	Jl. Daan Mogot No. 34, Palembang	9945675597	2017-05-15	37.34
448	SMK Negeri 14 Aceh	Teknik Mesin	Jl. Kyai Tapa No. 1, Aceh	9945675598	2017-05-15	37.41
449	SMA Negeri 08 Jakarta Utara	IPA	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Utara	9945675599	2017-05-15	37.72
450	SMA Negeri 09 Depok	IPA	Jl. Raya Pejuangan Kav. 8, Depok	9945675600	2017-05-15	38.55
451	SMK Negeri 11 Banten	Teknik Komputer	Jl. Kedoya Raya / Al-Kamal No. 2, Banten	9945675601	2017-05-15	37.72
452	SMK Negeri 16 Bandung	Teknik Komputer	Jl. Panjang Arteri 26, Bandung	9945675602	2017-05-15	38.60
453	SMK Negeri 04 Bogor	Teknik Otomasi	Jl. Raya Kebayoran Lama No. 64 , Bogor	9945675603	2017-05-15	38.74
454	SMA Negeri 12 Bali 	IPA	Jl. Puri Indah Raya  Blok S-2, Bali 	9945675604	2017-05-15	37.65
455	SMK Negeri 06 Bontang	Multimedia	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675605	2017-05-15	37.20
456	SMA Negeri 09 Makasar	IPS	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675606	2017-05-15	38.13
457	SMA Negeri 11 Bontang	IPA	Jl. Raya kamal Outer Ring Road, Bontang	9945675607	2017-05-15	37.83
458	SMK Negeri 13 Bontang	Analisa Kimia	Jl. Prof. Dr. Latumeten No. 1, Bontang	9945675608	2017-05-15	37.82
459	SMA Negeri 05 Jakarta Selatan	IPA	Jl. Duri Raya No. 22, Jakarta Selatan	9945675609	2017-05-15	37.96
460	SMK Negeri 17 Banten	Teknik Otomasi	Jl. Letjen S. Parman Kav. 84-86, Banten	9945675610	2017-05-15	38.67
461	SMA Negeri 13 Banten	IPS	Jl. LetJen S. Parman Kav. 87, Slipi, Banten	9945675611	2017-05-15	37.82
462	SMA Negeri 17 Maluku	IPS	Jl. LetJen S. Parman Kav. 87, Maluku	9945675612	2017-05-15	37.71
463	SMK Negeri 03 Bali 	Analisa Kimia	Jl. Tanah Sereal VII / 9, Bali 	9945675613	2017-05-15	38.88
464	SMA Negeri 06 Makasar	IPS	Jl. Kyai Tapa No. , Makasar	9945675614	2017-05-15	37.24
465	SMA Negeri 19 Bogor	IPA	Jl. Anggrek No. 2 B, Bogor	9945675615	2017-05-15	37.34
466	SMA Negeri 11 Depok	IPS	Jl. Pesanggrahan No. 1, Depok	9945675616	2017-05-15	37.17
467	SMA Negeri 04 Depok	IPA	Jl. RS Fatmawati No. 80 - 82, Depok	9945675617	2017-05-15	38.77
468	SMK Negeri 07 Balikpapan	Teknik Mesin	Jl. RS. Fatmawati, Balikpapan	9945675618	2017-05-15	37.30
469	SMA Negeri 06 Banten	IPA	Jl. Lebak Bulus 1, Banten	9945675619	2017-05-15	37.98
470	SMK Negeri 18 Lombok	Multimedia	Jl. RS Fatmawati No. 74 , Lombok	9945675620	2017-05-15	38.00
471	SMA Negeri 07 Banten	IPS	Jl. Warung Silah No. 1, Banten	9945675621	2017-05-15	37.05
472	SMA Negeri 14 Balikpapan	IPS	Jl. Sirsak No. 21, Balikpapan	9945675622	2017-05-15	37.86
473	SMK Negeri 11 Medan	Teknik Mesin	Jl. Kyai Maja No. 43, Medan	9945675623	2017-05-15	38.00
474	SMK Negeri 19 Surabaya	Teknik Mesin	Jl. Gandaria I / 20, Surabaya	9945675624	2017-05-15	37.88
475	SMA Negeri 07 Bandung	IPA	Jl. Gandaria Tengah II No. 6 - 14, Bandung	9945675625	2017-05-15	37.99
476	SMK Negeri 16 Bogor	Multimedia	Jl. Metro Duta Kav. UE,  Pondok Indah, Bogor	9945675626	2017-05-15	37.17
477	SMA Negeri 05 Bontang	IPS	Jl. Ciputat Raya No. 40, Bontang	9945675627	2017-05-15	38.72
478	SMK Negeri 12 Bontang	Analisa Kimia	Jl. Warung Buncit Raya No. 15, Bontang	9945675628	2017-05-15	37.89
479	SMK Negeri 03 Bandung	Multimedia	Jl. Raya Cilandak  KKO, Bandung	9945675629	2017-05-15	38.47
480	SMK Negeri 06 Balikpapan	Teknik Komputer	Jl. Siaga Raya Kav. 4 - 8, Balikpapan	9945675630	2017-05-15	37.55
481	SMA Negeri 17 Bogor	IPS	Jl. R. C. Veteran No. 178, Bogor	9945675631	2017-05-15	38.00
482	SMK Negeri 01 Bontang	Teknik Otomasi	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Bontang	9945675632	2017-05-15	37.49
483	SMA Negeri 18 Bandung	IPA	Jl. Jend. Sudirman Kav. 49 , Bandung	9945675633	2017-05-15	38.94
484	SMK Negeri 02 Makasar	Teknik Otomasi	Jl. Jenderal Gatot Subroto Kav. 59, Makasar	9945675634	2017-05-15	38.67
485	SMK Negeri 13 Balikpapan	Teknik Komputer	Jl. Sultan Agung No. 67, Balikpapan	9945675635	2017-05-15	38.87
486	SMA Negeri 05 Jakarta Selatan	IPA	Jl. MT. Haryono No. 8, Jakarta Selatan	9945675636	2017-05-15	37.07
487	SMA Negeri 09 Garut	IPS	Jl. Raya Pasar Minggu No. 3 A, Garut	9945675637	2017-05-15	38.16
488	SMK Negeri 18 Surabaya	Multimedia	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Surabaya	9945675638	2017-05-15	37.49
489	SMA Negeri 03 Medan	IPS	Jl. Mohamad Kahfi Raya 1, Medan	9945675639	2017-05-15	37.63
490	SMK Negeri 18 Palembang	Teknik Mesin	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Palembang	9945675640	2017-05-15	38.24
491	SMA Negeri 01 Bogor	IPA	Jl. Bina Warga RT. 009 / RW. 07, Kalibata, Bogor	9945675641	2017-05-15	37.96
492	SMA Negeri 07 Garut	IPA	Jl. Taman Brawijaya No. 1, Garut	9945675642	2017-05-15	37.83
493	SMK Negeri 09 Banten	Teknik Mesin	Jl. Taman Brawijaya No. 2, Banten	9945675643	2017-05-15	37.08
494	SMA Negeri 09 Depok	IPA	Jl. Taman Brawijaya No. 3, Depok	9945675644	2017-05-15	38.25
495	SMA Negeri 09 Garut	IPA	Jl. Dr. Abdul Rachman Saleh 24, Garut	9945675358	2017-05-15	37.98
496	SMK Negeri 15 Bali 	Teknik Komputer	Jl. Bendungan Hilir No. 17, Bali 	9945675359	2017-05-15	38.10
497	SMK Negeri 11 Bali 	Analisa Kimia	Jl. Rawamangun No. 47, Bali 	9945675360	2017-05-15	37.95
498	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675361	2017-05-15	38.51
499	SMK Negeri 16 Papua	Multimedia	Jl. Kesehatan No. 9, Papua	9945675362	2017-05-15	38.72
500	SMA Negeri 12 Aceh	IPS	Jl. Kaji No. 40, Aceh	9945675363	2017-05-15	37.85
501	SMK Negeri 08 Bali 	Multimedia	Jl. Sawo No. 58 - 60, Bali 	9945675364	2017-05-15	38.49
502	SMA Negeri 14 Semarang	IPA	Jl. Sumur Batu Raya Blok A3 No. 13, Semarang	9945675365	2017-05-15	37.45
503	SMK Negeri 01 Aceh	Teknik Komputer	Jl. Gereja Theresia No. 22, Aceh	9945675366	2017-05-15	35.83
504	SMA Negeri 12 Makasar	IPA	Jl. Teuku Cik Ditiro No. 28, Makasar	9945675367	2017-05-15	35.54
505	SMA Negeri 15 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675368	2017-05-15	35.14
506	SMA Negeri 03 Palembang	IPS	Jl. Teuku Cik Ditiro No. 46  M, Palembang	9945675369	2017-05-15	34.93
507	SMK Negeri 19 Maluku	Analisa Kimia	Jl. Proklamasi  No. 43 , Maluku	9945675370	2017-05-15	34.69
508	SMK Negeri 06 Balikpapan	Teknik Komputer	Jl. Tambak No. 18, Balikpapan	9945675371	2017-05-15	34.66
509	SMK Negeri 13 Papua	Teknik Otomasi	Jl. Salemba Raya, Papua	9945675372	2017-05-15	35.89
510	SMA Negeri 17 Bogor	IPA	Jl. Salemba I  No. 13, Bogor	9945675373	2017-05-15	34.78
511	SMK Negeri 11 Depok	Teknik Komputer	Jl. Jenderal Sudirman Kavling 86, Depok	9945675374	2017-05-15	36.29
512	SMK Negeri 07 Banten	Multimedia	Jl. Tipar Cakung No. 5, Banten	9945675375	2017-05-15	34.97
513	SMA Negeri 19 Maluku	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Maluku	9945675376	2017-05-15	36.42
514	SMK Negeri 08 Palembang	Teknik Mesin	Jl. Bukit Gading Raya Kav. II, Palembang	9945675377	2017-05-15	36.11
515	SMA Negeri 04 Aceh	IPA	Jl. Deli No. 4  Tanjung Priok, Aceh	9945675378	2017-05-15	35.80
516	SMA Negeri 12 Banten	IPS	Jl. Kramat Jaya, Tanjung Priok, Banten	9945675379	2017-05-15	35.92
517	SMK Negeri 13 Depok	Teknik Otomasi	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Depok	9945675380	2017-05-15	34.09
518	SMA Negeri 15 Lombok	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Lombok	9945675381	2017-05-15	36.09
519	SMK Negeri 04 Depok	Analisa Kimia	Jl. Pluit Raya No. 2, Depok	9945675382	2017-05-15	35.41
520	SMA Negeri 09 Depok	IPA	Jl. Raya Pluit Selatan No. 2, Depok	9945675383	2017-05-15	35.61
521	SMA Negeri 17 Jakarta Utara	IPA	Jl Sungai Bambu  No. 5, Jakarta Utara	9945675384	2017-05-15	34.50
522	SMK Negeri 03 Garut	Teknik Mesin	Jl. Agung Utara Raya Blok A No. 1, Garut	9945675385	2017-05-15	35.62
523	SMA Negeri 01 Bali 	IPS	Jl. Danau Sunter Utara Raya No. 1, Bali 	9945675386	2017-05-15	35.38
524	SMK Negeri 16 Depok	Teknik Mesin	Jl. Enggano No. 10, Depok	9945675387	2017-05-15	34.62
525	SMK Negeri 19 Papua	Teknik Mesin	Jl. Tawes No. 18-20 , Papua	9945675388	2017-05-15	34.09
526	SMA Negeri 18 Bogor	IPS	Pluit Mas I Blok A No. 2A - 5A, Bogor	9945675389	2017-05-15	36.25
527	SMA Negeri 16 Maluku	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Maluku	9945675390	2017-05-15	34.55
528	SMK Negeri 02 Balikpapan	Teknik Otomasi	Jl. Baru Sunter Permai Raya, Balikpapan	9945675391	2017-05-15	35.67
529	SMA Negeri 06 Palembang	IPS	Jl. Ganggeng Raya No.9, Palembang	9945675392	2017-05-15	35.93
530	SMA Negeri 11 Palembang	IPA	Jl. Siak J-5 No. 14, Palembang	9945675393	2017-05-15	34.06
531	SMA Negeri 17 Papua	IPA	Jl. Danau Agung 2 Blok E 3 No. 28-30, Papua	9945675394	2017-05-15	34.03
532	SMA Negeri 07 Balikpapan	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Balikpapan	9945675395	2017-05-15	36.29
533	SMK Negeri 02 Jakarta Selatan	Teknik Otomasi	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675396	2017-05-15	36.05
534	SMA Negeri 11 Garut	IPA	Jl. Daan Mogot No. 34, Garut	9945675397	2017-05-15	35.81
535	SMK Negeri 02 Bontang	Teknik Otomasi	Jl. Kyai Tapa No. 1, Bontang	9945675398	2017-05-15	36.42
536	SMA Negeri 19 Jakarta Selatan	IPS	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Selatan	9945675399	2017-05-15	35.19
537	SMA Negeri 17 Makasar	IPS	Jl. Raya Pejuangan Kav. 8, Makasar	9945675400	2017-05-15	35.11
538	SMK Negeri 19 Medan	Multimedia	Jl. Kedoya Raya / Al-Kamal No. 2, Medan	9945675401	2017-05-15	34.16
539	SMA Negeri 05 Surabaya	IPA	Jl. Panjang Arteri 26, Surabaya	9945675402	2017-05-15	36.03
540	SMK Negeri 18 Makasar	Multimedia	Jl. Raya Kebayoran Lama No. 64 , Makasar	9945675403	2017-05-15	35.50
541	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Puri Indah Raya  Blok S-2, Balikpapan	9945675404	2017-05-15	34.05
542	SMA Negeri 14 Bontang	IPA	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675405	2017-05-15	34.64
543	SMK Negeri 15 Makasar	Teknik Otomasi	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675406	2017-05-15	35.49
544	SMA Negeri 18 Bali 	IPS	Jl. Raya kamal Outer Ring Road, Bali 	9945675407	2017-05-15	34.53
545	SMA Negeri 15 Semarang	IPA	Jl. Prof. Dr. Latumeten No. 1, Semarang	9945675408	2017-05-15	34.19
546	SMA Negeri 12 Jakarta Utara	IPS	Jl. Duri Raya No. 22, Jakarta Utara	9945675409	2017-05-15	34.54
547	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Letjen S. Parman Kav. 84-86, Balikpapan	9945675410	2017-05-15	35.78
548	SMK Negeri 02 Makasar	Teknik Mesin	Jl. LetJen S. Parman Kav. 87, Slipi, Makasar	9945675411	2017-05-15	34.39
549	SMA Negeri 07 Jakarta Utara	IPS	Jl. LetJen S. Parman Kav. 87, Jakarta Utara	9945675412	2017-05-15	35.42
550	SMA Negeri 14 Jakarta Utara	IPA	Jl. Tanah Sereal VII / 9, Jakarta Utara	9945675413	2017-05-15	35.14
551	SMA Negeri 01 Balikpapan	IPS	Jl. Kyai Tapa No. , Balikpapan	9945675414	2017-05-15	36.44
552	SMA Negeri 11 Garut	IPS	Jl. Anggrek No. 2 B, Garut	9945675415	2017-05-15	36.12
553	SMA Negeri 14 Bandung	IPS	Jl. Pesanggrahan No. 1, Bandung	9945675416	2017-05-15	36.31
554	SMA Negeri 18 Papua	IPA	Jl. RS Fatmawati No. 80 - 82, Papua	9945675417	2017-05-15	35.76
555	SMA Negeri 07 Medan	IPA	Jl. RS. Fatmawati, Medan	9945675418	2017-05-15	35.12
556	SMA Negeri 19 Surabaya	IPA	Jl. Lebak Bulus 1, Surabaya	9945675419	2017-05-15	35.77
557	SMK Negeri 14 Bali 	Analisa Kimia	Jl. RS Fatmawati No. 74 , Bali 	9945675420	2017-05-15	34.56
558	SMK Negeri 16 Aceh	Teknik Mesin	Jl. Warung Silah No. 1, Aceh	9945675421	2017-05-15	34.03
559	SMK Negeri 02 Depok	Teknik Otomasi	Jl. Sirsak No. 21, Depok	9945675422	2017-05-15	34.05
560	SMK Negeri 15 Aceh	Multimedia	Jl. Kyai Maja No. 43, Aceh	9945675423	2017-05-15	36.18
561	SMK Negeri 06 Garut	Teknik Mesin	Jl. Gandaria I / 20, Garut	9945675424	2017-05-15	35.97
562	SMK Negeri 05 Balikpapan	Teknik Komputer	Jl. Gandaria Tengah II No. 6 - 14, Balikpapan	9945675425	2017-05-15	34.76
563	SMA Negeri 14 Bandung	IPA	Jl. Metro Duta Kav. UE,  Pondok Indah, Bandung	9945675426	2017-05-15	35.31
564	SMA Negeri 07 Maluku	IPS	Jl. Ciputat Raya No. 40, Maluku	9945675427	2017-05-15	35.80
565	SMA Negeri 19 Depok	IPS	Jl. Warung Buncit Raya No. 15, Depok	9945675428	2017-05-15	35.97
566	SMK Negeri 11 Garut	Teknik Otomasi	Jl. Raya Cilandak  KKO, Garut	9945675429	2017-05-15	35.71
567	SMK Negeri 02 Papua	Teknik Komputer	Jl. Siaga Raya Kav. 4 - 8, Papua	9945675430	2017-05-15	36.17
568	SMK Negeri 05 Surabaya	Multimedia	Jl. R. C. Veteran No. 178, Surabaya	9945675431	2017-05-15	34.61
569	SMK Negeri 19 Bontang	Teknik Komputer	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Bontang	9945675432	2017-05-15	36.09
570	SMA Negeri 09 Makasar	IPA	Jl. Jend. Sudirman Kav. 49 , Makasar	9945675433	2017-05-15	35.19
571	SMA Negeri 04 Bogor	IPS	Jl. Jenderal Gatot Subroto Kav. 59, Bogor	9945675434	2017-05-15	34.86
572	SMK Negeri 05 Surabaya	Multimedia	Jl. Sultan Agung No. 67, Surabaya	9945675435	2017-05-15	36.00
573	SMA Negeri 12 Jakarta Utara	IPA	Jl. MT. Haryono No. 8, Jakarta Utara	9945675436	2017-05-15	36.44
574	SMA Negeri 07 Makasar	IPA	Jl. Raya Pasar Minggu No. 3 A, Makasar	9945675437	2017-05-15	35.89
575	SMA Negeri 11 Jakarta Utara	IPA	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Jakarta Utara	9945675438	2017-05-15	34.24
576	SMA Negeri 14 Jakarta Selatan	IPS	Jl. Mohamad Kahfi Raya 1, Jakarta Selatan	9945675439	2017-05-15	35.68
577	SMK Negeri 07 Banten	Teknik Mesin	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Banten	9945675440	2017-05-15	34.47
578	SMA Negeri 07 Balikpapan	IPA	Jl. Bina Warga RT. 009 / RW. 07, Kalibata, Balikpapan	9945675441	2017-05-15	34.21
579	SMA Negeri 05 Surabaya	IPS	Jl. Taman Brawijaya No. 1, Surabaya	9945675442	2017-05-15	35.06
580	SMK Negeri 04 Banten	Teknik Komputer	Jl. Panglima Polim I  No. 34, Banten	9945675443	2017-05-15	34.84
581	SMK Negeri 14 Surabaya	Analisa Kimia	Jl. Dharmawangsa Raya No. 13  Blok P II, Surabaya	9945675444	2017-05-15	34.32
582	SMA Negeri 16 Papua	IPA	Jl. Ciranjang  II No. 20-22, Papua	9945675445	2017-05-15	36.19
583	SMK Negeri 05 Papua	Teknik Komputer	Jl. Senayan No. 26, Papua	9945675446	2017-05-15	36.42
584	SMK Negeri 15 Banten	Multimedia	Jl. Ciledug Raya No. 94 - 96, Banten	9945675447	2017-05-15	35.20
585	SMK Negeri 07 Papua	Multimedia	Jl. Ciputat Raya No. 5, Papua	9945675448	2017-05-15	35.40
586	SMA Negeri 14 Bogor	IPS	Jl. Duren Tiga Raya No. 20, Bogor	9945675449	2017-05-15	35.55
587	SMK Negeri 04 Medan	Multimedia	Jl. Duren Tiga Raya No. 5, Medan	9945675450	2017-05-15	34.24
588	SMK Negeri 11 Jakarta Utara	Multimedia	Jl. H. Rohimin No. 30, Jakarta Utara	9945675451	2017-05-15	35.77
589	SMA Negeri 06 Semarang	IPA	Jl. Ampera Raya No. 34, Semarang	9945675452	2017-05-15	34.78
590	SMK Negeri 09 Semarang	Analisa Kimia	Jl. Garnisun No. 2 - 3, Semarang	9945675453	2017-05-15	34.64
591	SMA Negeri 14 Bandung	IPS	Jl. HR. Rasuna Said, Kuningan, Bandung	9945675454	2017-05-15	35.01
592	SMK Negeri 08 Jakarta Selatan	Multimedia	Jl. Dr. Saharjo No. 120, Jakarta Selatan	9945675455	2017-05-15	35.80
593	SMK Negeri 14 Depok	Multimedia	Jl. Bintaro Permai Raya No. 3, Depok	9945675456	2017-05-15	36.44
594	SMK Negeri 05 Aceh	Multimedia	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Aceh	9945675457	2017-05-15	34.29
595	SMK Negeri 19 Bali 	Analisa Kimia	Jl. Raya Bogor KM. 22 No. 44, Bali 	9945675458	2017-05-15	36.03
596	SMK Negeri 18 Makasar	Teknik Mesin	Jl. Pahlawan Revolusi No. 47, Makasar	9945675459	2017-05-15	35.47
597	SMK Negeri 06 Papua	Teknik Otomasi	Jl. Raya Pondok Kopi, Papua	9945675460	2017-05-15	36.37
598	SMK Negeri 05 Aceh	Teknik Komputer	Jl. Mahoni, Pasar Rebo, Cijantung II , Aceh	9945675461	2017-05-15	35.45
599	SMK Negeri 04 Jakarta Utara	Teknik Otomasi	Jl. Raya Bekasi Timur 170 C, Jakarta Utara	9945675462	2017-05-15	34.44
600	SMA Negeri 13 Bandung	IPS	Jl. Raya Jatinegara Timur No. 85 - 87, Bandung	9945675463	2017-05-15	34.84
601	SMA Negeri 11 Bandung	IPA	Jl. Merpati No. 2, Bandung	9945675464	2017-05-15	36.22
602	SMA Negeri 16 Papua	IPA	Jl. Dewi Sartika III No. 200, Papua	9945675465	2017-05-15	34.58
603	SMA Negeri 05 Maluku	IPS	Jl. Raya Bogor, Maluku	9945675466	2017-05-15	35.08
604	SMK Negeri 15 Jakarta Utara	Multimedia	Jl. RS Polri, Jakarta Utara	9945675467	2017-05-15	34.92
605	SMA Negeri 04 Depok	IPS	Jl. Mayjen Sutoyo No. 2, Depok	9945675468	2017-05-15	34.36
606	SMK Negeri 11 Makasar	Teknik Komputer	Jl. Tarum Barat - Kalimalang, Makasar	9945675469	2017-05-15	35.42
607	SMA Negeri 12 Surabaya	IPS	Jl. Raya Pondok Gede No. 4, Surabaya	9945675470	2017-05-15	36.35
608	SMA Negeri 08 Garut	IPA	Jl. Letjen T. B. Simatupang No. 30, Garut	9945675471	2017-05-15	36.44
609	SMA Negeri 12 Palembang	IPA	Jl. Pemuda, Palembang	9945675472	2017-05-15	34.24
610	SMK Negeri 02 Semarang	Teknik Mesin	Jl. Kayu Putih Raya, Semarang	9945675473	2017-05-15	34.51
611	SMA Negeri 16 Maluku	IPA	Jl. Pulomas Barat VI No. 20, Maluku	9945675474	2017-05-15	36.18
612	SMK Negeri 12 Maluku	Teknik Mesin	Jl. Pulomas Timur K. No.2, Maluku	9945675475	2017-05-15	35.04
613	SMA Negeri 01 Maluku	IPA	Jl. Persahabatan Raya , Maluku	9945675476	2017-05-15	35.86
614	SMA Negeri 09 Semarang	IPS	Jl. Perintis Kemerdekaan Kav. 149, Semarang	9945675477	2017-05-15	34.53
615	SMA Negeri 08 Medan	IPA	Jl. Balai Pustaka Baru No. 19, Medan	9945675478	2017-05-15	36.50
616	SMA Negeri 06 Lombok	IPS	Jl. Pahlawan Komarudin Raya No. 5, Lombok	9945675479	2017-05-15	36.21
617	SMA Negeri 01 Lombok	IPA	Jl. LapanganTembak No. 75, Lombok	9945675480	2017-05-15	34.93
618	SMA Negeri 13 Jakarta Selatan	IPS	Jl. Duren Sawit Baru No. 2, Jakarta Selatan	9945675481	2017-05-15	36.23
619	SMA Negeri 19 Palembang	IPS	Jl. Raden Inten, Palembang	9945675482	2017-05-15	34.47
620	SMK Negeri 01 Banten	Teknik Komputer	Jl. Bunga Rampai X - Perumnas Klender, Banten	9945675483	2017-05-15	34.47
621	SMK Negeri 19 Banten	Teknik Mesin	Jl. Pahlawan Revolusi No. 100, Banten	9945675484	2017-05-15	35.90
622	SMK Negeri 05 Banten	Multimedia	Jl. Basuki Rachmat  No. 31, Banten	9945675485	2017-05-15	34.15
623	SMK Negeri 05 Jakarta Selatan	Teknik Komputer	Jl. Taman Malaka Selatan No. 6, Jakarta Selatan	9945675486	2017-05-15	34.51
624	SMA Negeri 09 Depok	IPS	Jl. Jatinegara Barat No. 126 , Depok	9945675487	2017-05-15	34.12
625	SMA Negeri 02 Jakarta Utara	IPS	JL. Duren Sawit Raya Blok K.3 No.1, Jakarta Utara	9945675488	2017-05-15	36.23
626	SMA Negeri 05 Jakarta Utara	IPS	Jl. Raya Bogor  Km. 19  No. 3.a, Jakarta Utara	9945675489	2017-05-15	36.47
627	SMA Negeri 01 Medan	IPS	Jl. TB Simatupang No. 71 Jak-Tim, Medan	9945675490	2017-05-15	34.94
628	SMA Negeri 15 Makasar	IPA	Jl. H. Ten, Makasar	9945675491	2017-05-15	35.78
629	SMK Negeri 13 Bandung	Analisa Kimia	Jl. Balai Pustaka Raya No. 29-31, Bandung	9945675492	2017-05-15	34.03
630	SMK Negeri 17 Bogor	Analisa Kimia	Jl. Pemuda No. 80  RT.001 RW.08, Bogor	9945675493	2017-05-15	34.84
631	SMK Negeri 02 Bogor	Multimedia	Jl. Diponegoro No. 71, Bogor	9945675494	2017-05-15	35.98
632	SMA Negeri 16 Surabaya	IPS	Jl. Kramat Raya No. 17 A, Surabaya	9945675495	2017-05-15	35.93
633	SMK Negeri 14 Jakarta Utara	Teknik Komputer	Jl. Kramat Raya No. 128, Jakarta Utara	9945675496	2017-05-15	34.30
634	SMA Negeri 02 Banten	IPS	Jl. Salemba Raya No. 41, Banten	9945675497	2017-05-15	34.08
635	SMK Negeri 08 Depok	Analisa Kimia	Jl. Salemba Tengah 26 - 28, Depok	9945675498	2017-05-15	36.50
636	SMA Negeri 09 Jakarta Utara	IPA	Jl. Dr. Abdul Rachman Saleh 24, Jakarta Utara	9945675499	2017-05-15	35.35
637	SMA Negeri 18 Bogor	IPA	Jl. Bendungan Hilir No. 17, Bogor	9945675500	2017-05-15	36.12
638	SMA Negeri 18 Surabaya	IPS	Jl. Rawamangun No. 47, Surabaya	9945675501	2017-05-15	35.15
639	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675502	2017-05-15	36.14
640	SMA Negeri 04 Banten	IPS	Jl. Kesehatan No. 9, Banten	9945675503	2017-05-15	36.43
641	SMA Negeri 14 Papua	IPS	Jl. Kaji No. 40, Papua	9945675504	2017-05-15	35.84
642	SMA Negeri 06 Aceh	IPS	Jl. Sawo No. 58 - 60, Aceh	9945675505	2017-05-15	34.00
643	SMK Negeri 14 Bontang	Analisa Kimia	Jl. Sumur Batu Raya Blok A3 No. 13, Bontang	9945675506	2017-05-15	36.01
644	SMK Negeri 09 Bali 	Teknik Komputer	Jl. Gereja Theresia No. 22, Bali 	9945675507	2017-05-15	34.50
645	SMK Negeri 17 Jakarta Selatan	Teknik Mesin	Jl. Teuku Cik Ditiro No. 28, Jakarta Selatan	9945675508	2017-05-15	36.38
646	SMA Negeri 03 Maluku	IPA	Jl. Teuku Cik Ditiro No. 41, Maluku	9945675509	2017-05-15	35.65
647	SMA Negeri 09 Balikpapan	IPS	Jl. Kyai Maja No. 43, Balikpapan	9945675510	2017-05-15	35.42
648	SMK Negeri 17 Bontang	Multimedia	Jl. Gandaria I / 20, Bontang	9945675511	2017-05-15	34.98
649	SMK Negeri 05 Aceh	Multimedia	Jl. Gandaria Tengah II No. 6 - 14, Aceh	9945675512	2017-05-15	36.02
650	SMK Negeri 09 Balikpapan	Teknik Mesin	Jl. Metro Duta Kav. UE,  Pondok Indah, Balikpapan	9945675513	2017-05-15	34.40
651	SMK Negeri 15 Jakarta Selatan	Teknik Komputer	Jl. Ciputat Raya No. 40, Jakarta Selatan	9945675514	2017-05-15	35.87
652	SMK Negeri 04 Maluku	Teknik Mesin	Jl. Warung Buncit Raya No. 15, Maluku	9945675515	2017-05-15	35.50
653	SMK Negeri 12 Semarang	Teknik Otomasi	Jl. Raya Cilandak  KKO, Semarang	9945675516	2017-05-15	36.25
654	SMK Negeri 17 Palembang	Analisa Kimia	Jl. Siaga Raya Kav. 4 - 8, Palembang	9945675517	2017-05-15	35.79
655	SMK Negeri 17 Banten	Multimedia	Jl. R. C. Veteran No. 178, Banten	9945675518	2017-05-15	34.49
656	SMK Negeri 08 Depok	Analisa Kimia	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Depok	9945675519	2017-05-15	35.15
657	SMA Negeri 13 Bogor	IPA	Jl. Jend. Sudirman Kav. 49 , Bogor	9945675520	2017-05-15	35.57
658	SMK Negeri 08 Surabaya	Teknik Mesin	Jl. Jenderal Gatot Subroto Kav. 59, Surabaya	9945675521	2017-05-15	34.54
659	SMA Negeri 16 Bali 	IPA	Jl. Sultan Agung No. 67, Bali 	9945675522	2017-05-15	36.36
660	SMA Negeri 15 Palembang	IPA	Jl. MT. Haryono No. 8, Palembang	9945675523	2017-05-15	34.00
661	SMK Negeri 01 Lombok	Analisa Kimia	Jl. Raya Pasar Minggu No. 3 A, Lombok	9945675524	2017-05-15	36.12
662	SMK Negeri 01 Bogor	Teknik Mesin	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Bogor	9945675525	2017-05-15	35.40
663	SMK Negeri 08 Semarang	Teknik Mesin	Jl. Mohamad Kahfi Raya 1, Semarang	9945675526	2017-05-15	36.48
664	SMA Negeri 03 Aceh	IPS	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Aceh	9945675527	2017-05-15	35.36
665	SMA Negeri 13 Bontang	IPA	Jl. Teuku Cik Ditiro No. 28, Bontang	9945675528	2017-05-15	35.48
666	SMA Negeri 14 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675529	2017-05-15	34.51
667	SMK Negeri 02 Bogor	Teknik Komputer	Jl. Teuku Cik Ditiro No. 46  M, Bogor	9945675530	2017-05-15	34.61
668	SMA Negeri 11 Semarang	IPS	Jl. Proklamasi  No. 43 , Semarang	9945675531	2017-05-15	35.84
669	SMA Negeri 02 Maluku	IPS	Jl. Tambak No. 18, Maluku	9945675532	2017-05-15	35.31
670	SMK Negeri 14 Medan	Teknik Otomasi	Jl. Salemba Raya, Medan	9945675533	2017-05-15	35.75
671	SMK Negeri 19 Bali 	Teknik Otomasi	Jl. Salemba I  No. 13, Bali 	9945675534	2017-05-15	35.77
672	SMK Negeri 15 Makasar	Multimedia	Jl. Jenderal Sudirman Kavling 86, Makasar	9945675535	2017-05-15	34.17
673	SMK Negeri 13 Garut	Multimedia	Jl. Tipar Cakung No. 5, Garut	9945675536	2017-05-15	34.69
674	SMA Negeri 11 Palembang	IPA	Jl. Boulevard Timur Raya RT. 006 / 02, Palembang	9945675537	2017-05-15	35.10
675	SMK Negeri 01 Bandung	Teknik Otomasi	Jl. Bukit Gading Raya Kav. II, Bandung	9945675538	2017-05-15	34.74
676	SMK Negeri 06 Palembang	Teknik Otomasi	Jl. Deli No. 4  Tanjung Priok, Palembang	9945675539	2017-05-15	35.39
677	SMA Negeri 13 Jakarta Utara	IPA	Jl. Kramat Jaya, Tanjung Priok, Jakarta Utara	9945675540	2017-05-15	35.55
678	SMK Negeri 03 Lombok	Teknik Komputer	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Lombok	9945675541	2017-05-15	34.29
679	SMA Negeri 12 Bogor	IPS	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Bogor	9945675542	2017-05-15	36.01
680	SMK Negeri 11 Palembang	Teknik Otomasi	Jl. Pluit Raya No. 2, Palembang	9945675543	2017-05-15	35.96
681	SMA Negeri 19 Surabaya	IPA	Jl. Raya Pluit Selatan No. 2, Surabaya	9945675544	2017-05-15	36.43
682	SMA Negeri 03 Bontang	IPA	Jl. Cempaka Putih Tengah I / 1, Bontang	9945675545	2017-05-15	34.11
683	SMK Negeri 07 Aceh	Teknik Otomasi	Jl. Achmad Yani No. 2, By Pass, Aceh	9945675546	2017-05-15	34.09
684	SMA Negeri 13 Jakarta Selatan	IPS	Jl. Kyai Caringin No. 7, Jakarta Selatan	9945675547	2017-05-15	34.22
685	SMK Negeri 06 Semarang	Teknik Mesin	Jl. Landas Pacu Timur, Semarang	9945675548	2017-05-15	34.00
686	SMA Negeri 15 Bali 	IPA	Jl. Raden Saleh No. 40 , Bali 	9945675549	2017-05-15	35.89
687	SMA Negeri 07 Depok	IPA	Jl. HOS Cokroaminoto No. 31 - 33, Depok	9945675550	2017-05-15	35.65
688	SMK Negeri 19 Semarang	Teknik Komputer	Jl. Kali Pasir  No. 9, Semarang	9945675551	2017-05-15	34.99
689	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Raya Mangga Besar Raya 137 / 139, Balikpapan	9945675552	2017-05-15	34.40
690	SMK Negeri 05 Depok	Teknik Mesin	Jl. Diponegoro No. 71, Depok	9945675553	2017-05-15	34.99
691	SMK Negeri 14 Balikpapan	Teknik Otomasi	Jl. Kramat Raya No. 17 A, Balikpapan	9945675554	2017-05-15	35.96
692	SMK Negeri 09 Papua	Teknik Otomasi	Jl. Kramat Raya No. 128, Papua	9945675555	2017-05-15	38.88
693	SMK Negeri 16 Medan	Multimedia	Jl. Salemba Raya No. 41, Medan	9945675556	2017-05-15	37.37
694	SMA Negeri 12 Lombok	IPS	Jl. Salemba Tengah 26 - 28, Lombok	9945675557	2017-05-15	38.30
695	SMK Negeri 06 Bandung	Teknik Otomasi	Jl. Dr. Abdul Rachman Saleh 24, Bandung	9945675558	2017-05-15	37.55
696	SMK Negeri 01 Bogor	Teknik Mesin	Jl. Bendungan Hilir No. 17, Bogor	9945675559	2017-05-15	37.39
697	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Rawamangun No. 47, Balikpapan	9945675560	2017-05-15	37.48
698	SMA Negeri 12 Bontang	IPS	Jl. Budi Kemuliaan No. 25 , Bontang	9945675561	2017-05-15	37.44
699	SMK Negeri 11 Jakarta Selatan	Multimedia	Jl. Kesehatan No. 9, Jakarta Selatan	9945675562	2017-05-15	38.24
700	SMA Negeri 02 Medan	IPS	Jl. Kaji No. 40, Medan	9945675563	2017-05-15	37.80
701	SMK Negeri 03 Garut	Analisa Kimia	Jl. Sawo No. 58 - 60, Garut	9945675564	2017-05-15	37.33
702	SMK Negeri 11 Lombok	Teknik Komputer	Jl. Sumur Batu Raya Blok A3 No. 13, Lombok	9945675565	2017-05-15	37.86
703	SMA Negeri 18 Depok	IPA	Jl. Gereja Theresia No. 22, Depok	9945675566	2017-05-15	38.66
704	SMK Negeri 06 Jakarta Utara	Teknik Mesin	Jl. Teuku Cik Ditiro No. 28, Jakarta Utara	9945675567	2017-05-15	38.99
705	SMK Negeri 03 Lombok	Teknik Mesin	Jl. Teuku Cik Ditiro No. 41, Lombok	9945675568	2017-05-15	37.73
706	SMK Negeri 14 Bali 	Multimedia	Jl. Teuku Cik Ditiro No. 46  M, Bali 	9945675569	2017-05-15	37.94
707	SMK Negeri 09 Makasar	Analisa Kimia	Jl. Proklamasi  No. 43 , Makasar	9945675570	2017-05-15	38.51
708	SMA Negeri 15 Jakarta Selatan	IPS	Jl. Tambak No. 18, Jakarta Selatan	9945675571	2017-05-15	38.03
709	SMK Negeri 15 Bogor	Multimedia	Jl. Salemba Raya, Bogor	9945675572	2017-05-15	37.37
710	SMK Negeri 04 Depok	Analisa Kimia	Jl. Salemba I  No. 13, Depok	9945675573	2017-05-15	38.69
711	SMK Negeri 14 Garut	Teknik Otomasi	Jl. Jenderal Sudirman Kavling 86, Garut	9945675574	2017-05-15	38.02
712	SMA Negeri 19 Balikpapan	IPS	Jl. Tipar Cakung No. 5, Balikpapan	9945675575	2017-05-15	37.95
713	SMA Negeri 02 Papua	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Papua	9945675576	2017-05-15	37.23
714	SMK Negeri 13 Surabaya	Multimedia	Jl. Bukit Gading Raya Kav. II, Surabaya	9945675577	2017-05-15	37.56
715	SMK Negeri 18 Makasar	Teknik Komputer	Jl. Deli No. 4  Tanjung Priok, Makasar	9945675578	2017-05-15	37.02
716	SMK Negeri 05 Makasar	Teknik Otomasi	Jl. Kramat Jaya, Tanjung Priok, Makasar	9945675579	2017-05-15	38.27
717	SMK Negeri 17 Papua	Analisa Kimia	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Papua	9945675580	2017-05-15	37.81
718	SMA Negeri 11 Bali 	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Bali 	9945675581	2017-05-15	38.51
719	SMK Negeri 05 Banten	Multimedia	Jl. Pluit Raya No. 2, Banten	9945675582	2017-05-15	38.03
720	SMA Negeri 07 Medan	IPS	Jl. Raya Pluit Selatan No. 2, Medan	9945675583	2017-05-15	38.53
721	SMA Negeri 16 Makasar	IPA	Jl Sungai Bambu  No. 5, Makasar	9945675584	2017-05-15	37.10
722	SMA Negeri 15 Jakarta Selatan	IPS	Jl. Agung Utara Raya Blok A No. 1, Jakarta Selatan	9945675585	2017-05-15	38.38
723	SMK Negeri 06 Aceh	Multimedia	Jl. Danau Sunter Utara Raya No. 1, Aceh	9945675586	2017-05-15	38.19
724	SMK Negeri 07 Maluku	Teknik Mesin	Jl. Enggano No. 10, Maluku	9945675587	2017-05-15	38.49
725	SMK Negeri 13 Aceh	Multimedia	Jl. Tawes No. 18-20 , Aceh	9945675588	2017-05-15	38.62
726	SMA Negeri 19 Garut	IPA	Pluit Mas I Blok A No. 2A - 5A, Garut	9945675589	2017-05-15	37.84
727	SMA Negeri 09 Garut	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Garut	9945675590	2017-05-15	37.77
728	SMK Negeri 14 Semarang	Teknik Mesin	Jl. Baru Sunter Permai Raya, Semarang	9945675591	2017-05-15	38.96
729	SMK Negeri 06 Semarang	Teknik Mesin	Jl. Ganggeng Raya No.9, Semarang	9945675592	2017-05-15	38.02
730	SMK Negeri 06 Maluku	Teknik Otomasi	Jl. Siak J-5 No. 14, Maluku	9945675593	2017-05-15	37.93
731	SMA Negeri 17 Bali 	IPS	Jl. Danau Agung 2 Blok E 3 No. 28-30, Bali 	9945675594	2017-05-15	38.64
732	SMA Negeri 04 Papua	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Papua	9945675595	2017-05-15	37.08
733	SMA Negeri 16 Jakarta Selatan	IPS	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675596	2017-05-15	38.71
734	SMA Negeri 01 Palembang	IPA	Jl. Daan Mogot No. 34, Palembang	9945675597	2017-05-15	37.34
735	SMK Negeri 14 Aceh	Teknik Mesin	Jl. Kyai Tapa No. 1, Aceh	9945675598	2017-05-15	37.41
736	SMA Negeri 08 Jakarta Utara	IPA	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Utara	9945675599	2017-05-15	37.72
737	SMA Negeri 09 Depok	IPA	Jl. Raya Pejuangan Kav. 8, Depok	9945675600	2017-05-15	38.55
738	SMK Negeri 11 Banten	Teknik Komputer	Jl. Kedoya Raya / Al-Kamal No. 2, Banten	9945675601	2017-05-15	37.72
739	SMK Negeri 16 Bandung	Teknik Komputer	Jl. Panjang Arteri 26, Bandung	9945675602	2017-05-15	38.60
740	SMK Negeri 04 Bogor	Teknik Otomasi	Jl. Raya Kebayoran Lama No. 64 , Bogor	9945675603	2017-05-15	38.74
741	SMA Negeri 12 Bali 	IPA	Jl. Puri Indah Raya  Blok S-2, Bali 	9945675604	2017-05-15	37.65
742	SMK Negeri 06 Bontang	Multimedia	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675605	2017-05-15	37.20
743	SMA Negeri 09 Makasar	IPS	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675606	2017-05-15	38.13
744	SMA Negeri 11 Bontang	IPA	Jl. Raya kamal Outer Ring Road, Bontang	9945675607	2017-05-15	37.83
745	SMK Negeri 13 Bontang	Analisa Kimia	Jl. Prof. Dr. Latumeten No. 1, Bontang	9945675608	2017-05-15	37.82
746	SMA Negeri 05 Jakarta Selatan	IPA	Jl. Duri Raya No. 22, Jakarta Selatan	9945675609	2017-05-15	37.96
747	SMK Negeri 17 Banten	Teknik Otomasi	Jl. Letjen S. Parman Kav. 84-86, Banten	9945675610	2017-05-15	38.67
748	SMA Negeri 13 Banten	IPS	Jl. LetJen S. Parman Kav. 87, Slipi, Banten	9945675611	2017-05-15	37.82
749	SMA Negeri 17 Maluku	IPS	Jl. LetJen S. Parman Kav. 87, Maluku	9945675612	2017-05-15	37.71
750	SMK Negeri 03 Bali 	Analisa Kimia	Jl. Tanah Sereal VII / 9, Bali 	9945675613	2017-05-15	38.88
751	SMA Negeri 06 Makasar	IPS	Jl. Kyai Tapa No. , Makasar	9945675614	2017-05-15	37.24
752	SMA Negeri 19 Bogor	IPA	Jl. Anggrek No. 2 B, Bogor	9945675615	2017-05-15	37.34
753	SMA Negeri 11 Depok	IPS	Jl. Pesanggrahan No. 1, Depok	9945675616	2017-05-15	37.17
754	SMA Negeri 04 Depok	IPA	Jl. RS Fatmawati No. 80 - 82, Depok	9945675617	2017-05-15	38.77
755	SMK Negeri 07 Balikpapan	Teknik Mesin	Jl. RS. Fatmawati, Balikpapan	9945675618	2017-05-15	37.30
756	SMA Negeri 06 Banten	IPA	Jl. Lebak Bulus 1, Banten	9945675619	2017-05-15	37.98
757	SMK Negeri 18 Lombok	Multimedia	Jl. RS Fatmawati No. 74 , Lombok	9945675620	2017-05-15	38.00
758	SMA Negeri 07 Banten	IPS	Jl. Warung Silah No. 1, Banten	9945675621	2017-05-15	37.05
759	SMA Negeri 14 Balikpapan	IPS	Jl. Sirsak No. 21, Balikpapan	9945675622	2017-05-15	37.86
760	SMK Negeri 11 Medan	Teknik Mesin	Jl. Kyai Maja No. 43, Medan	9945675623	2017-05-15	38.00
761	SMK Negeri 19 Surabaya	Teknik Mesin	Jl. Gandaria I / 20, Surabaya	9945675624	2017-05-15	37.88
762	SMK Negeri 01 Aceh	Teknik Komputer	Jl. Gereja Theresia No. 22, Aceh	9945675366	2017-05-15	35.83
763	SMA Negeri 12 Makasar	IPA	Jl. Teuku Cik Ditiro No. 28, Makasar	9945675367	2017-05-15	35.54
764	SMA Negeri 15 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675368	2017-05-15	35.14
765	SMA Negeri 03 Palembang	IPS	Jl. Teuku Cik Ditiro No. 46  M, Palembang	9945675369	2017-05-15	34.93
766	SMK Negeri 19 Maluku	Analisa Kimia	Jl. Proklamasi  No. 43 , Maluku	9945675370	2017-05-15	34.69
767	SMK Negeri 06 Balikpapan	Teknik Komputer	Jl. Tambak No. 18, Balikpapan	9945675371	2017-05-15	34.66
768	SMK Negeri 13 Papua	Teknik Otomasi	Jl. Salemba Raya, Papua	9945675372	2017-05-15	35.89
769	SMA Negeri 17 Bogor	IPA	Jl. Salemba I  No. 13, Bogor	9945675373	2017-05-15	34.78
770	SMK Negeri 11 Depok	Teknik Komputer	Jl. Jenderal Sudirman Kavling 86, Depok	9945675374	2017-05-15	36.29
771	SMK Negeri 07 Banten	Multimedia	Jl. Tipar Cakung No. 5, Banten	9945675375	2017-05-15	34.97
772	SMA Negeri 19 Maluku	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Maluku	9945675376	2017-05-15	36.42
773	SMK Negeri 08 Palembang	Teknik Mesin	Jl. Bukit Gading Raya Kav. II, Palembang	9945675377	2017-05-15	36.11
774	SMA Negeri 04 Aceh	IPA	Jl. Deli No. 4  Tanjung Priok, Aceh	9945675378	2017-05-15	35.80
775	SMA Negeri 12 Banten	IPS	Jl. Kramat Jaya, Tanjung Priok, Banten	9945675379	2017-05-15	35.92
776	SMK Negeri 13 Depok	Teknik Otomasi	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Depok	9945675380	2017-05-15	34.09
777	SMA Negeri 15 Lombok	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Lombok	9945675381	2017-05-15	36.09
778	SMK Negeri 04 Depok	Analisa Kimia	Jl. Pluit Raya No. 2, Depok	9945675382	2017-05-15	35.41
779	SMA Negeri 09 Depok	IPA	Jl. Raya Pluit Selatan No. 2, Depok	9945675383	2017-05-15	35.61
780	SMA Negeri 17 Jakarta Utara	IPA	Jl Sungai Bambu  No. 5, Jakarta Utara	9945675384	2017-05-15	34.50
781	SMK Negeri 03 Garut	Teknik Mesin	Jl. Agung Utara Raya Blok A No. 1, Garut	9945675385	2017-05-15	35.62
782	SMA Negeri 01 Bali 	IPS	Jl. Danau Sunter Utara Raya No. 1, Bali 	9945675386	2017-05-15	35.38
783	SMK Negeri 16 Depok	Teknik Mesin	Jl. Enggano No. 10, Depok	9945675387	2017-05-15	34.62
784	SMK Negeri 19 Papua	Teknik Mesin	Jl. Tawes No. 18-20 , Papua	9945675388	2017-05-15	34.09
785	SMA Negeri 18 Bogor	IPS	Pluit Mas I Blok A No. 2A - 5A, Bogor	9945675389	2017-05-15	36.25
786	SMA Negeri 16 Maluku	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Maluku	9945675390	2017-05-15	34.55
787	SMK Negeri 02 Balikpapan	Teknik Otomasi	Jl. Baru Sunter Permai Raya, Balikpapan	9945675391	2017-05-15	35.67
788	SMA Negeri 06 Palembang	IPS	Jl. Ganggeng Raya No.9, Palembang	9945675392	2017-05-15	35.93
789	SMA Negeri 11 Palembang	IPA	Jl. Siak J-5 No. 14, Palembang	9945675393	2017-05-15	34.06
790	SMA Negeri 17 Papua	IPA	Jl. Danau Agung 2 Blok E 3 No. 28-30, Papua	9945675394	2017-05-15	34.03
791	SMA Negeri 07 Balikpapan	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Balikpapan	9945675395	2017-05-15	36.29
792	SMK Negeri 02 Jakarta Selatan	Teknik Otomasi	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675396	2017-05-15	36.05
793	SMA Negeri 11 Garut	IPA	Jl. Daan Mogot No. 34, Garut	9945675397	2017-05-15	35.81
794	SMK Negeri 02 Bontang	Teknik Otomasi	Jl. Kyai Tapa No. 1, Bontang	9945675398	2017-05-15	36.42
795	SMA Negeri 19 Jakarta Selatan	IPS	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Selatan	9945675399	2017-05-15	35.19
796	SMA Negeri 17 Makasar	IPS	Jl. Raya Pejuangan Kav. 8, Makasar	9945675400	2017-05-15	35.11
797	SMK Negeri 19 Medan	Multimedia	Jl. Kedoya Raya / Al-Kamal No. 2, Medan	9945675401	2017-05-15	34.16
798	SMA Negeri 05 Surabaya	IPA	Jl. Panjang Arteri 26, Surabaya	9945675402	2017-05-15	36.03
799	SMK Negeri 18 Makasar	Multimedia	Jl. Raya Kebayoran Lama No. 64 , Makasar	9945675403	2017-05-15	35.50
800	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Puri Indah Raya  Blok S-2, Balikpapan	9945675404	2017-05-15	34.05
801	SMA Negeri 14 Bontang	IPA	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675405	2017-05-15	34.64
802	SMK Negeri 15 Makasar	Teknik Otomasi	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675406	2017-05-15	35.49
803	SMA Negeri 18 Bali 	IPS	Jl. Raya kamal Outer Ring Road, Bali 	9945675407	2017-05-15	34.53
804	SMA Negeri 15 Semarang	IPA	Jl. Prof. Dr. Latumeten No. 1, Semarang	9945675408	2017-05-15	34.19
805	SMA Negeri 12 Jakarta Utara	IPS	Jl. Duri Raya No. 22, Jakarta Utara	9945675409	2017-05-15	34.54
806	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Letjen S. Parman Kav. 84-86, Balikpapan	9945675410	2017-05-15	35.78
807	SMK Negeri 02 Makasar	Teknik Mesin	Jl. LetJen S. Parman Kav. 87, Slipi, Makasar	9945675411	2017-05-15	34.39
808	SMA Negeri 07 Jakarta Utara	IPS	Jl. LetJen S. Parman Kav. 87, Jakarta Utara	9945675412	2017-05-15	35.42
809	SMA Negeri 14 Jakarta Utara	IPA	Jl. Tanah Sereal VII / 9, Jakarta Utara	9945675413	2017-05-15	35.14
810	SMA Negeri 01 Balikpapan	IPS	Jl. Kyai Tapa No. , Balikpapan	9945675414	2017-05-15	36.44
811	SMA Negeri 11 Garut	IPS	Jl. Anggrek No. 2 B, Garut	9945675415	2017-05-15	36.12
812	SMA Negeri 14 Bandung	IPS	Jl. Pesanggrahan No. 1, Bandung	9945675416	2017-05-15	36.31
813	SMA Negeri 18 Papua	IPA	Jl. RS Fatmawati No. 80 - 82, Papua	9945675417	2017-05-15	35.76
814	SMA Negeri 07 Medan	IPA	Jl. RS. Fatmawati, Medan	9945675418	2017-05-15	35.12
815	SMA Negeri 19 Surabaya	IPA	Jl. Lebak Bulus 1, Surabaya	9945675419	2017-05-15	35.77
816	SMK Negeri 14 Bali 	Analisa Kimia	Jl. RS Fatmawati No. 74 , Bali 	9945675420	2017-05-15	34.56
817	SMK Negeri 16 Aceh	Teknik Mesin	Jl. Warung Silah No. 1, Aceh	9945675421	2017-05-15	34.03
818	SMK Negeri 02 Depok	Teknik Otomasi	Jl. Sirsak No. 21, Depok	9945675422	2017-05-15	34.05
819	SMK Negeri 15 Aceh	Multimedia	Jl. Kyai Maja No. 43, Aceh	9945675423	2017-05-15	36.18
820	SMK Negeri 06 Garut	Teknik Mesin	Jl. Gandaria I / 20, Garut	9945675424	2017-05-15	35.97
821	SMK Negeri 05 Balikpapan	Teknik Komputer	Jl. Gandaria Tengah II No. 6 - 14, Balikpapan	9945675425	2017-05-15	34.76
822	SMA Negeri 14 Bandung	IPA	Jl. Metro Duta Kav. UE,  Pondok Indah, Bandung	9945675426	2017-05-15	35.31
823	SMA Negeri 07 Maluku	IPS	Jl. Ciputat Raya No. 40, Maluku	9945675427	2017-05-15	35.80
824	SMA Negeri 19 Depok	IPS	Jl. Warung Buncit Raya No. 15, Depok	9945675428	2017-05-15	35.97
825	SMK Negeri 11 Garut	Teknik Otomasi	Jl. Raya Cilandak  KKO, Garut	9945675429	2017-05-15	35.71
826	SMK Negeri 02 Papua	Teknik Komputer	Jl. Siaga Raya Kav. 4 - 8, Papua	9945675430	2017-05-15	36.17
827	SMK Negeri 05 Surabaya	Multimedia	Jl. R. C. Veteran No. 178, Surabaya	9945675431	2017-05-15	34.61
828	SMK Negeri 19 Bontang	Teknik Komputer	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Bontang	9945675432	2017-05-15	36.09
829	SMA Negeri 09 Makasar	IPA	Jl. Jend. Sudirman Kav. 49 , Makasar	9945675433	2017-05-15	35.19
830	SMA Negeri 04 Bogor	IPS	Jl. Jenderal Gatot Subroto Kav. 59, Bogor	9945675434	2017-05-15	34.86
831	SMK Negeri 05 Surabaya	Multimedia	Jl. Sultan Agung No. 67, Surabaya	9945675435	2017-05-15	36.00
832	SMA Negeri 12 Jakarta Utara	IPA	Jl. MT. Haryono No. 8, Jakarta Utara	9945675436	2017-05-15	36.44
833	SMA Negeri 07 Makasar	IPA	Jl. Raya Pasar Minggu No. 3 A, Makasar	9945675437	2017-05-15	35.89
834	SMA Negeri 11 Jakarta Utara	IPA	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Jakarta Utara	9945675438	2017-05-15	34.24
835	SMA Negeri 14 Jakarta Selatan	IPS	Jl. Mohamad Kahfi Raya 1, Jakarta Selatan	9945675439	2017-05-15	35.68
836	SMK Negeri 07 Banten	Teknik Mesin	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Banten	9945675440	2017-05-15	34.47
837	SMA Negeri 07 Balikpapan	IPA	Jl. Bina Warga RT. 009 / RW. 07, Kalibata, Balikpapan	9945675441	2017-05-15	34.21
838	SMA Negeri 05 Surabaya	IPS	Jl. Taman Brawijaya No. 1, Surabaya	9945675442	2017-05-15	35.06
839	SMK Negeri 04 Banten	Teknik Komputer	Jl. Panglima Polim I  No. 34, Banten	9945675443	2017-05-15	34.84
840	SMK Negeri 14 Surabaya	Analisa Kimia	Jl. Dharmawangsa Raya No. 13  Blok P II, Surabaya	9945675444	2017-05-15	34.32
841	SMA Negeri 16 Papua	IPA	Jl. Ciranjang  II No. 20-22, Papua	9945675445	2017-05-15	36.19
842	SMK Negeri 05 Papua	Teknik Komputer	Jl. Senayan No. 26, Papua	9945675446	2017-05-15	36.42
843	SMK Negeri 15 Banten	Multimedia	Jl. Ciledug Raya No. 94 - 96, Banten	9945675447	2017-05-15	35.20
844	SMK Negeri 07 Papua	Multimedia	Jl. Ciputat Raya No. 5, Papua	9945675448	2017-05-15	35.40
845	SMA Negeri 14 Bogor	IPS	Jl. Duren Tiga Raya No. 20, Bogor	9945675449	2017-05-15	35.55
846	SMK Negeri 04 Medan	Multimedia	Jl. Duren Tiga Raya No. 5, Medan	9945675450	2017-05-15	34.24
847	SMK Negeri 11 Jakarta Utara	Multimedia	Jl. H. Rohimin No. 30, Jakarta Utara	9945675451	2017-05-15	35.77
848	SMA Negeri 06 Semarang	IPA	Jl. Ampera Raya No. 34, Semarang	9945675452	2017-05-15	34.78
849	SMK Negeri 09 Semarang	Analisa Kimia	Jl. Garnisun No. 2 - 3, Semarang	9945675453	2017-05-15	34.64
850	SMA Negeri 14 Bandung	IPS	Jl. HR. Rasuna Said, Kuningan, Bandung	9945675454	2017-05-15	35.01
851	SMK Negeri 08 Jakarta Selatan	Multimedia	Jl. Dr. Saharjo No. 120, Jakarta Selatan	9945675455	2017-05-15	35.80
852	SMK Negeri 14 Depok	Multimedia	Jl. Bintaro Permai Raya No. 3, Depok	9945675456	2017-05-15	36.44
853	SMK Negeri 05 Aceh	Multimedia	Jl. Bekasi Timur Raya KM. 18 No. 6 P. Gdg. , Aceh	9945675457	2017-05-15	34.29
854	SMK Negeri 19 Bali 	Analisa Kimia	Jl. Raya Bogor KM. 22 No. 44, Bali 	9945675458	2017-05-15	36.03
855	SMK Negeri 18 Makasar	Teknik Mesin	Jl. Pahlawan Revolusi No. 47, Makasar	9945675459	2017-05-15	35.47
856	SMK Negeri 06 Papua	Teknik Otomasi	Jl. Raya Pondok Kopi, Papua	9945675460	2017-05-15	36.37
857	SMK Negeri 05 Aceh	Teknik Komputer	Jl. Mahoni, Pasar Rebo, Cijantung II , Aceh	9945675461	2017-05-15	35.45
858	SMK Negeri 04 Jakarta Utara	Teknik Otomasi	Jl. Raya Bekasi Timur 170 C, Jakarta Utara	9945675462	2017-05-15	34.44
859	SMA Negeri 13 Bandung	IPS	Jl. Raya Jatinegara Timur No. 85 - 87, Bandung	9945675463	2017-05-15	34.84
860	SMA Negeri 11 Bandung	IPA	Jl. Merpati No. 2, Bandung	9945675464	2017-05-15	36.22
861	SMA Negeri 16 Papua	IPA	Jl. Dewi Sartika III No. 200, Papua	9945675465	2017-05-15	34.58
862	SMA Negeri 05 Maluku	IPS	Jl. Raya Bogor, Maluku	9945675466	2017-05-15	35.08
863	SMK Negeri 15 Jakarta Utara	Multimedia	Jl. RS Polri, Jakarta Utara	9945675467	2017-05-15	34.92
864	SMA Negeri 04 Depok	IPS	Jl. Mayjen Sutoyo No. 2, Depok	9945675468	2017-05-15	34.36
865	SMK Negeri 11 Makasar	Teknik Komputer	Jl. Tarum Barat - Kalimalang, Makasar	9945675469	2017-05-15	35.42
866	SMA Negeri 12 Surabaya	IPS	Jl. Raya Pondok Gede No. 4, Surabaya	9945675470	2017-05-15	36.35
867	SMA Negeri 08 Garut	IPA	Jl. Letjen T. B. Simatupang No. 30, Garut	9945675471	2017-05-15	36.44
868	SMA Negeri 12 Palembang	IPA	Jl. Pemuda, Palembang	9945675472	2017-05-15	34.24
869	SMK Negeri 02 Semarang	Teknik Mesin	Jl. Kayu Putih Raya, Semarang	9945675473	2017-05-15	34.51
870	SMA Negeri 16 Maluku	IPA	Jl. Pulomas Barat VI No. 20, Maluku	9945675474	2017-05-15	36.18
871	SMK Negeri 12 Maluku	Teknik Mesin	Jl. Pulomas Timur K. No.2, Maluku	9945675475	2017-05-15	35.04
872	SMA Negeri 01 Maluku	IPA	Jl. Persahabatan Raya , Maluku	9945675476	2017-05-15	35.86
873	SMA Negeri 09 Semarang	IPS	Jl. Perintis Kemerdekaan Kav. 149, Semarang	9945675477	2017-05-15	34.53
874	SMA Negeri 08 Medan	IPA	Jl. Balai Pustaka Baru No. 19, Medan	9945675478	2017-05-15	36.50
875	SMA Negeri 06 Lombok	IPS	Jl. Pahlawan Komarudin Raya No. 5, Lombok	9945675479	2017-05-15	36.21
876	SMA Negeri 01 Lombok	IPA	Jl. LapanganTembak No. 75, Lombok	9945675480	2017-05-15	34.93
877	SMA Negeri 13 Jakarta Selatan	IPS	Jl. Duren Sawit Baru No. 2, Jakarta Selatan	9945675481	2017-05-15	36.23
878	SMA Negeri 19 Palembang	IPS	Jl. Raden Inten, Palembang	9945675482	2017-05-15	34.47
879	SMK Negeri 01 Banten	Teknik Komputer	Jl. Bunga Rampai X - Perumnas Klender, Banten	9945675483	2017-05-15	34.47
880	SMK Negeri 19 Banten	Teknik Mesin	Jl. Pahlawan Revolusi No. 100, Banten	9945675484	2017-05-15	35.90
881	SMK Negeri 05 Banten	Multimedia	Jl. Basuki Rachmat  No. 31, Banten	9945675485	2017-05-15	34.15
882	SMK Negeri 05 Jakarta Selatan	Teknik Komputer	Jl. Taman Malaka Selatan No. 6, Jakarta Selatan	9945675486	2017-05-15	34.51
883	SMA Negeri 09 Depok	IPS	Jl. Jatinegara Barat No. 126 , Depok	9945675487	2017-05-15	34.12
884	SMA Negeri 02 Jakarta Utara	IPS	JL. Duren Sawit Raya Blok K.3 No.1, Jakarta Utara	9945675488	2017-05-15	36.23
885	SMA Negeri 05 Jakarta Utara	IPS	Jl. Raya Bogor  Km. 19  No. 3.a, Jakarta Utara	9945675489	2017-05-15	36.47
886	SMA Negeri 01 Medan	IPS	Jl. TB Simatupang No. 71 Jak-Tim, Medan	9945675490	2017-05-15	34.94
887	SMA Negeri 15 Makasar	IPA	Jl. H. Ten, Makasar	9945675491	2017-05-15	35.78
888	SMK Negeri 13 Bandung	Analisa Kimia	Jl. Balai Pustaka Raya No. 29-31, Bandung	9945675492	2017-05-15	34.03
889	SMK Negeri 17 Bogor	Analisa Kimia	Jl. Pemuda No. 80  RT.001 RW.08, Bogor	9945675493	2017-05-15	34.84
890	SMK Negeri 02 Bogor	Multimedia	Jl. Diponegoro No. 71, Bogor	9945675494	2017-05-15	35.98
891	SMA Negeri 16 Surabaya	IPS	Jl. Kramat Raya No. 17 A, Surabaya	9945675495	2017-05-15	35.93
892	SMK Negeri 14 Jakarta Utara	Teknik Komputer	Jl. Kramat Raya No. 128, Jakarta Utara	9945675496	2017-05-15	34.30
893	SMA Negeri 02 Banten	IPS	Jl. Salemba Raya No. 41, Banten	9945675497	2017-05-15	34.08
894	SMK Negeri 08 Depok	Analisa Kimia	Jl. Salemba Tengah 26 - 28, Depok	9945675498	2017-05-15	36.50
895	SMA Negeri 09 Jakarta Utara	IPA	Jl. Dr. Abdul Rachman Saleh 24, Jakarta Utara	9945675499	2017-05-15	35.35
896	SMA Negeri 18 Bogor	IPA	Jl. Bendungan Hilir No. 17, Bogor	9945675500	2017-05-15	36.12
897	SMA Negeri 18 Surabaya	IPS	Jl. Rawamangun No. 47, Surabaya	9945675501	2017-05-15	35.15
898	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675502	2017-05-15	36.14
899	SMA Negeri 04 Banten	IPS	Jl. Kesehatan No. 9, Banten	9945675503	2017-05-15	36.43
900	SMA Negeri 14 Papua	IPS	Jl. Kaji No. 40, Papua	9945675504	2017-05-15	35.84
901	SMA Negeri 06 Aceh	IPS	Jl. Sawo No. 58 - 60, Aceh	9945675505	2017-05-15	34.00
902	SMK Negeri 14 Bontang	Analisa Kimia	Jl. Sumur Batu Raya Blok A3 No. 13, Bontang	9945675506	2017-05-15	36.01
903	SMK Negeri 09 Bali 	Teknik Komputer	Jl. Gereja Theresia No. 22, Bali 	9945675507	2017-05-15	34.50
904	SMK Negeri 17 Jakarta Selatan	Teknik Mesin	Jl. Teuku Cik Ditiro No. 28, Jakarta Selatan	9945675508	2017-05-15	36.38
905	SMA Negeri 03 Maluku	IPA	Jl. Teuku Cik Ditiro No. 41, Maluku	9945675509	2017-05-15	35.65
906	SMA Negeri 09 Balikpapan	IPS	Jl. Kyai Maja No. 43, Balikpapan	9945675510	2017-05-15	35.42
907	SMK Negeri 17 Bontang	Multimedia	Jl. Gandaria I / 20, Bontang	9945675511	2017-05-15	34.98
908	SMK Negeri 05 Aceh	Multimedia	Jl. Gandaria Tengah II No. 6 - 14, Aceh	9945675512	2017-05-15	36.02
909	SMK Negeri 09 Balikpapan	Teknik Mesin	Jl. Metro Duta Kav. UE,  Pondok Indah, Balikpapan	9945675513	2017-05-15	34.40
910	SMK Negeri 15 Jakarta Selatan	Teknik Komputer	Jl. Ciputat Raya No. 40, Jakarta Selatan	9945675514	2017-05-15	35.87
911	SMK Negeri 04 Maluku	Teknik Mesin	Jl. Warung Buncit Raya No. 15, Maluku	9945675515	2017-05-15	35.50
912	SMK Negeri 12 Semarang	Teknik Otomasi	Jl. Raya Cilandak  KKO, Semarang	9945675516	2017-05-15	36.25
913	SMK Negeri 17 Palembang	Analisa Kimia	Jl. Siaga Raya Kav. 4 - 8, Palembang	9945675517	2017-05-15	35.79
914	SMK Negeri 17 Banten	Multimedia	Jl. R. C. Veteran No. 178, Banten	9945675518	2017-05-15	34.49
915	SMK Negeri 08 Depok	Analisa Kimia	Jl. HR. Rasuna Said Kav. C-21 Kuningan, Depok	9945675519	2017-05-15	35.15
916	SMA Negeri 13 Bogor	IPA	Jl. Jend. Sudirman Kav. 49 , Bogor	9945675520	2017-05-15	35.57
917	SMK Negeri 08 Surabaya	Teknik Mesin	Jl. Jenderal Gatot Subroto Kav. 59, Surabaya	9945675521	2017-05-15	34.54
918	SMA Negeri 16 Bali 	IPA	Jl. Sultan Agung No. 67, Bali 	9945675522	2017-05-15	36.36
919	SMA Negeri 15 Palembang	IPA	Jl. MT. Haryono No. 8, Palembang	9945675523	2017-05-15	34.00
920	SMK Negeri 01 Lombok	Analisa Kimia	Jl. Raya Pasar Minggu No. 3 A, Lombok	9945675524	2017-05-15	36.12
921	SMK Negeri 01 Bogor	Teknik Mesin	Jl. Warung Sila No.8 RT.006 / RW.04 Gudang Baru, Bogor	9945675525	2017-05-15	35.40
922	SMK Negeri 08 Semarang	Teknik Mesin	Jl. Mohamad Kahfi Raya 1, Semarang	9945675526	2017-05-15	36.48
923	SMA Negeri 03 Aceh	IPS	Jl. Jeruk Raya No. 15 RT. 0011 / RW. 01, Aceh	9945675527	2017-05-15	35.36
924	SMA Negeri 13 Bontang	IPA	Jl. Teuku Cik Ditiro No. 28, Bontang	9945675528	2017-05-15	35.48
925	SMA Negeri 14 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675529	2017-05-15	34.51
926	SMK Negeri 02 Bogor	Teknik Komputer	Jl. Teuku Cik Ditiro No. 46  M, Bogor	9945675530	2017-05-15	34.61
927	SMA Negeri 11 Semarang	IPS	Jl. Proklamasi  No. 43 , Semarang	9945675531	2017-05-15	35.84
928	SMA Negeri 02 Maluku	IPS	Jl. Tambak No. 18, Maluku	9945675532	2017-05-15	35.31
929	SMK Negeri 14 Medan	Teknik Otomasi	Jl. Salemba Raya, Medan	9945675533	2017-05-15	35.75
930	SMK Negeri 19 Bali 	Teknik Otomasi	Jl. Salemba I  No. 13, Bali 	9945675534	2017-05-15	35.77
931	SMK Negeri 15 Makasar	Multimedia	Jl. Jenderal Sudirman Kavling 86, Makasar	9945675535	2017-05-15	34.17
932	SMK Negeri 13 Garut	Multimedia	Jl. Tipar Cakung No. 5, Garut	9945675536	2017-05-15	34.69
933	SMA Negeri 11 Palembang	IPA	Jl. Boulevard Timur Raya RT. 006 / 02, Palembang	9945675537	2017-05-15	35.10
934	SMK Negeri 01 Bandung	Teknik Otomasi	Jl. Bukit Gading Raya Kav. II, Bandung	9945675538	2017-05-15	34.74
935	SMK Negeri 06 Palembang	Teknik Otomasi	Jl. Deli No. 4  Tanjung Priok, Palembang	9945675539	2017-05-15	35.39
936	SMA Negeri 13 Jakarta Utara	IPA	Jl. Kramat Jaya, Tanjung Priok, Jakarta Utara	9945675540	2017-05-15	35.55
937	SMK Negeri 03 Lombok	Teknik Komputer	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Lombok	9945675541	2017-05-15	34.29
938	SMA Negeri 12 Bogor	IPS	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Bogor	9945675542	2017-05-15	36.01
939	SMK Negeri 11 Palembang	Teknik Otomasi	Jl. Pluit Raya No. 2, Palembang	9945675543	2017-05-15	35.96
940	SMA Negeri 19 Surabaya	IPA	Jl. Raya Pluit Selatan No. 2, Surabaya	9945675544	2017-05-15	36.43
941	SMA Negeri 03 Bontang	IPA	Jl. Cempaka Putih Tengah I / 1, Bontang	9945675545	2017-05-15	34.11
942	SMK Negeri 07 Aceh	Teknik Otomasi	Jl. Achmad Yani No. 2, By Pass, Aceh	9945675546	2017-05-15	34.09
943	SMA Negeri 13 Jakarta Selatan	IPS	Jl. Kyai Caringin No. 7, Jakarta Selatan	9945675547	2017-05-15	34.22
944	SMK Negeri 06 Semarang	Teknik Mesin	Jl. Landas Pacu Timur, Semarang	9945675548	2017-05-15	34.00
945	SMA Negeri 15 Bali 	IPA	Jl. Raden Saleh No. 40 , Bali 	9945675549	2017-05-15	35.89
946	SMA Negeri 07 Depok	IPA	Jl. HOS Cokroaminoto No. 31 - 33, Depok	9945675550	2017-05-15	35.65
947	SMK Negeri 19 Semarang	Teknik Komputer	Jl. Kali Pasir  No. 9, Semarang	9945675551	2017-05-15	34.99
948	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Raya Mangga Besar Raya 137 / 139, Balikpapan	9945675552	2017-05-15	34.40
949	SMK Negeri 05 Depok	Teknik Mesin	Jl. Diponegoro No. 71, Depok	9945675553	2017-05-15	34.99
950	SMK Negeri 14 Balikpapan	Teknik Otomasi	Jl. Kramat Raya No. 17 A, Balikpapan	9945675554	2017-05-15	35.96
951	SMK Negeri 09 Papua	Teknik Otomasi	Jl. Kramat Raya No. 128, Papua	9945675555	2017-05-15	38.88
952	SMK Negeri 16 Medan	Multimedia	Jl. Salemba Raya No. 41, Medan	9945675556	2017-05-15	37.37
953	SMA Negeri 12 Lombok	IPS	Jl. Salemba Tengah 26 - 28, Lombok	9945675557	2017-05-15	38.30
954	SMK Negeri 06 Bandung	Teknik Otomasi	Jl. Dr. Abdul Rachman Saleh 24, Bandung	9945675558	2017-05-15	37.55
955	SMK Negeri 01 Bogor	Teknik Mesin	Jl. Bendungan Hilir No. 17, Bogor	9945675559	2017-05-15	37.39
956	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Rawamangun No. 47, Balikpapan	9945675560	2017-05-15	37.48
957	SMA Negeri 12 Bontang	IPS	Jl. Budi Kemuliaan No. 25 , Bontang	9945675561	2017-05-15	37.44
958	SMK Negeri 11 Jakarta Selatan	Multimedia	Jl. Kesehatan No. 9, Jakarta Selatan	9945675562	2017-05-15	38.24
959	SMA Negeri 02 Medan	IPS	Jl. Kaji No. 40, Medan	9945675563	2017-05-15	37.80
960	SMK Negeri 03 Garut	Analisa Kimia	Jl. Sawo No. 58 - 60, Garut	9945675564	2017-05-15	37.33
961	SMK Negeri 11 Lombok	Teknik Komputer	Jl. Sumur Batu Raya Blok A3 No. 13, Lombok	9945675565	2017-05-15	37.86
962	SMA Negeri 18 Depok	IPA	Jl. Gereja Theresia No. 22, Depok	9945675566	2017-05-15	38.66
963	SMK Negeri 06 Jakarta Utara	Teknik Mesin	Jl. Teuku Cik Ditiro No. 28, Jakarta Utara	9945675567	2017-05-15	38.99
964	SMK Negeri 03 Lombok	Teknik Mesin	Jl. Teuku Cik Ditiro No. 41, Lombok	9945675568	2017-05-15	37.73
965	SMK Negeri 14 Bali 	Multimedia	Jl. Teuku Cik Ditiro No. 46  M, Bali 	9945675569	2017-05-15	37.94
966	SMK Negeri 09 Makasar	Analisa Kimia	Jl. Proklamasi  No. 43 , Makasar	9945675570	2017-05-15	38.51
967	SMA Negeri 15 Jakarta Selatan	IPS	Jl. Tambak No. 18, Jakarta Selatan	9945675571	2017-05-15	38.03
968	SMK Negeri 15 Bogor	Multimedia	Jl. Salemba Raya, Bogor	9945675572	2017-05-15	37.37
969	SMK Negeri 04 Depok	Analisa Kimia	Jl. Salemba I  No. 13, Depok	9945675573	2017-05-15	38.69
970	SMK Negeri 14 Garut	Teknik Otomasi	Jl. Jenderal Sudirman Kavling 86, Garut	9945675574	2017-05-15	38.02
971	SMA Negeri 19 Balikpapan	IPS	Jl. Tipar Cakung No. 5, Balikpapan	9945675575	2017-05-15	37.95
972	SMA Negeri 02 Papua	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Papua	9945675576	2017-05-15	37.23
973	SMK Negeri 13 Surabaya	Multimedia	Jl. Bukit Gading Raya Kav. II, Surabaya	9945675577	2017-05-15	37.56
974	SMK Negeri 18 Makasar	Teknik Komputer	Jl. Deli No. 4  Tanjung Priok, Makasar	9945675578	2017-05-15	37.02
975	SMK Negeri 05 Makasar	Teknik Otomasi	Jl. Kramat Jaya, Tanjung Priok, Makasar	9945675579	2017-05-15	38.27
976	SMK Negeri 17 Papua	Analisa Kimia	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Papua	9945675580	2017-05-15	37.81
977	SMA Negeri 11 Bali 	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Bali 	9945675581	2017-05-15	38.51
978	SMK Negeri 05 Banten	Multimedia	Jl. Pluit Raya No. 2, Banten	9945675582	2017-05-15	38.03
979	SMA Negeri 07 Medan	IPS	Jl. Raya Pluit Selatan No. 2, Medan	9945675583	2017-05-15	38.53
980	SMA Negeri 16 Makasar	IPA	Jl Sungai Bambu  No. 5, Makasar	9945675584	2017-05-15	37.10
981	SMA Negeri 15 Jakarta Selatan	IPS	Jl. Agung Utara Raya Blok A No. 1, Jakarta Selatan	9945675585	2017-05-15	38.38
982	SMK Negeri 06 Aceh	Multimedia	Jl. Danau Sunter Utara Raya No. 1, Aceh	9945675586	2017-05-15	38.19
983	SMK Negeri 07 Maluku	Teknik Mesin	Jl. Enggano No. 10, Maluku	9945675587	2017-05-15	38.49
984	SMK Negeri 13 Aceh	Multimedia	Jl. Tawes No. 18-20 , Aceh	9945675588	2017-05-15	38.62
985	SMA Negeri 19 Garut	IPA	Pluit Mas I Blok A No. 2A - 5A, Garut	9945675589	2017-05-15	37.84
986	SMA Negeri 09 Garut	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Garut	9945675590	2017-05-15	37.77
987	SMK Negeri 14 Semarang	Teknik Mesin	Jl. Baru Sunter Permai Raya, Semarang	9945675591	2017-05-15	38.96
988	SMK Negeri 06 Semarang	Teknik Mesin	Jl. Ganggeng Raya No.9, Semarang	9945675592	2017-05-15	38.02
989	SMK Negeri 06 Maluku	Teknik Otomasi	Jl. Siak J-5 No. 14, Maluku	9945675593	2017-05-15	37.93
990	SMA Negeri 17 Bali 	IPS	Jl. Danau Agung 2 Blok E 3 No. 28-30, Bali 	9945675594	2017-05-15	38.64
991	SMA Negeri 04 Papua	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Papua	9945675595	2017-05-15	37.08
992	SMA Negeri 16 Jakarta Selatan	IPS	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675596	2017-05-15	38.71
993	SMA Negeri 01 Palembang	IPA	Jl. Daan Mogot No. 34, Palembang	9945675597	2017-05-15	37.34
994	SMK Negeri 14 Aceh	Teknik Mesin	Jl. Kyai Tapa No. 1, Aceh	9945675598	2017-05-15	37.41
995	SMA Negeri 08 Jakarta Utara	IPA	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Utara	9945675599	2017-05-15	37.72
996	SMA Negeri 09 Depok	IPA	Jl. Raya Pejuangan Kav. 8, Depok	9945675600	2017-05-15	38.55
997	SMK Negeri 11 Banten	Teknik Komputer	Jl. Kedoya Raya / Al-Kamal No. 2, Banten	9945675601	2017-05-15	37.72
998	SMK Negeri 16 Bandung	Teknik Komputer	Jl. Panjang Arteri 26, Bandung	9945675602	2017-05-15	38.60
999	SMK Negeri 04 Bogor	Teknik Otomasi	Jl. Raya Kebayoran Lama No. 64 , Bogor	9945675603	2017-05-15	38.74
1000	SMA Negeri 12 Bali 	IPA	Jl. Puri Indah Raya  Blok S-2, Bali 	9945675604	2017-05-15	37.65
1201	SMA Negeri 1 Garut	IPA	Jl. Merdeka No. 91, Garut	1231231211	2017-04-10	39.40
\.


--
-- Data for Name: pendaftaran_uui; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pendaftaran_uui (id_pendaftaran, rapot, surat_rekomendasi, asal_sekolah, jenis_sma, alamat_sekolah, nisn, tgl_lulus, nilai_uan) FROM stdin;
24	rapot_32590.pdf	rekomendasi_45344.pdf	SMA Negeri 15 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675368	2016-06-17	35.14
25	rapot_32591.pdf	rekomendasi_45345.pdf	SMA Negeri 03 Palembang	IPS	Jl. Teuku Cik Ditiro No. 46  M, Palembang	9945675369	2016-06-04	34.93
26	rapot_32592.pdf	rekomendasi_45346.pdf	SMK Negeri 19 Maluku	Analisa Kimia	Jl. Proklamasi  No. 43 , Maluku	9945675370	2016-07-01	34.69
27	rapot_32593.pdf	rekomendasi_45347.pdf	SMK Negeri 06 Balikpapan	Teknik Komputer	Jl. Tambak No. 18, Balikpapan	9945675371	2016-06-06	34.66
28	rapot_32594.pdf	rekomendasi_45348.pdf	SMK Negeri 13 Papua	Teknik Otomasi	Jl. Salemba Raya, Papua	9945675372	2016-07-29	35.89
29	rapot_32595.pdf	rekomendasi_45349.pdf	SMA Negeri 17 Bogor	IPA	Jl. Salemba I  No. 13, Bogor	9945675373	2016-06-17	34.78
30	rapot_32596.pdf	rekomendasi_45350.pdf	SMK Negeri 11 Depok	Teknik Komputer	Jl. Jenderal Sudirman Kavling 86, Depok	9945675374	2016-07-16	36.29
31	rapot_32597.pdf	rekomendasi_45351.pdf	SMK Negeri 07 Banten	Multimedia	Jl. Tipar Cakung No. 5, Banten	9945675375	2016-06-26	34.97
32	rapot_32598.pdf	rekomendasi_45352.pdf	SMA Negeri 19 Maluku	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Maluku	9945675376	2016-06-29	36.42
33	rapot_32599.pdf	rekomendasi_45353.pdf	SMK Negeri 08 Palembang	Teknik Mesin	Jl. Bukit Gading Raya Kav. II, Palembang	9945675377	2016-06-27	36.11
34	rapot_32600.pdf	rekomendasi_45354.pdf	SMA Negeri 04 Aceh	IPA	Jl. Deli No. 4  Tanjung Priok, Aceh	9945675378	2016-07-16	35.80
35	rapot_32601.pdf	rekomendasi_45355.pdf	SMA Negeri 12 Banten	IPS	Jl. Kramat Jaya, Tanjung Priok, Banten	9945675379	2016-06-30	35.92
36	rapot_32602.pdf	rekomendasi_45356.pdf	SMK Negeri 13 Depok	Teknik Otomasi	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Depok	9945675380	2016-07-30	34.09
37	rapot_32603.pdf	rekomendasi_45357.pdf	SMA Negeri 15 Lombok	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Lombok	9945675381	2016-07-16	36.09
38	rapot_32604.pdf	rekomendasi_45358.pdf	SMK Negeri 04 Depok	Analisa Kimia	Jl. Pluit Raya No. 2, Depok	9945675382	2016-07-29	35.41
39	rapot_32605.pdf	rekomendasi_45359.pdf	SMA Negeri 09 Depok	IPA	Jl. Raya Pluit Selatan No. 2, Depok	9945675383	2016-07-24	35.61
40	rapot_32606.pdf	rekomendasi_45360.pdf	SMA Negeri 17 Jakarta Utara	IPA	Jl Sungai Bambu  No. 5, Jakarta Utara	9945675384	2016-06-05	34.50
42	rapot_32608.pdf	rekomendasi_45362.pdf	SMA Negeri 01 Bali 	IPS	Jl. Danau Sunter Utara Raya No. 1, Bali 	9945675386	2016-07-13	35.38
43	rapot_32609.pdf	rekomendasi_45363.pdf	SMK Negeri 16 Depok	Teknik Mesin	Jl. Enggano No. 10, Depok	9945675387	2016-06-16	34.62
44	rapot_32610.pdf	rekomendasi_45364.pdf	SMK Negeri 19 Papua	Teknik Mesin	Jl. Tawes No. 18-20 , Papua	9945675388	2016-07-19	34.09
45	rapot_32611.pdf	rekomendasi_45365.pdf	SMA Negeri 18 Bogor	IPS	Pluit Mas I Blok A No. 2A - 5A, Bogor	9945675389	2016-06-28	36.25
46	rapot_32612.pdf	rekomendasi_45366.pdf	SMA Negeri 16 Maluku	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Maluku	9945675390	2016-06-05	34.55
47	rapot_32613.pdf	rekomendasi_45367.pdf	SMK Negeri 02 Balikpapan	Teknik Otomasi	Jl. Baru Sunter Permai Raya, Balikpapan	9945675391	2016-06-27	35.67
48	rapot_32614.pdf	rekomendasi_45368.pdf	SMA Negeri 06 Palembang	IPS	Jl. Ganggeng Raya No.9, Palembang	9945675392	2016-07-31	35.93
49	rapot_32615.pdf	rekomendasi_45369.pdf	SMA Negeri 11 Palembang	IPA	Jl. Siak J-5 No. 14, Palembang	9945675393	2016-07-07	34.06
50	rapot_32616.pdf	rekomendasi_45370.pdf	SMA Negeri 17 Papua	IPA	Jl. Danau Agung 2 Blok E 3 No. 28-30, Papua	9945675394	2016-07-14	34.03
1	rapot_32567.pdf	rekomendasi_45321.pdf	SMA Negeri 06 Bogor	IPS	Jl. Cempaka Putih Tengah I / 1, Bogor	9945675345	2016-06-15	37.08
2	rapot_32568.pdf	rekomendasi_45322.pdf	SMA Negeri 07 Bontang	IPA	Jl. Achmad Yani No. 2, By Pass, Bontang	9945675346	2016-06-19	38.29
3	rapot_32569.pdf	rekomendasi_45323.pdf	SMA Negeri 06 Papua	IPA	Jl. Kyai Caringin No. 7, Papua	9945675347	2016-07-01	37.48
4	rapot_32570.pdf	rekomendasi_45324.pdf	SMA Negeri 15 Banten	IPA	Jl. Landas Pacu Timur, Banten	9945675348	2016-06-30	38.16
5	rapot_32571.pdf	rekomendasi_45325.pdf	SMK Negeri 05 Surabaya	Analisa Kimia	Jl. Raden Saleh No. 40 , Surabaya	9945675349	2016-07-11	37.60
6	rapot_32572.pdf	rekomendasi_45326.pdf	SMA Negeri 12 Aceh	IPS	Jl. HOS Cokroaminoto No. 31 - 33, Aceh	9945675350	2016-07-31	38.67
7	rapot_32573.pdf	rekomendasi_45327.pdf	SMK Negeri 16 Bandung	Teknik Komputer	Jl. Kali Pasir  No. 9, Bandung	9945675351	2016-07-27	37.64
8	rapot_32574.pdf	rekomendasi_45328.pdf	SMA Negeri 18 Bandung	IPS	Jl. Raya Mangga Besar Raya 137 / 139, Bandung	9945675352	2016-07-11	38.66
9	rapot_32575.pdf	rekomendasi_45329.pdf	SMA Negeri 17 Bogor	IPA	Jl. Diponegoro No. 71, Bogor	9945675353	2016-07-22	37.66
10	rapot_32576.pdf	rekomendasi_45330.pdf	SMK Negeri 18 Medan	Multimedia	Jl. Kramat Raya No. 17 A, Medan	9945675354	2016-07-30	37.52
11	rapot_32577.pdf	rekomendasi_45331.pdf	SMK Negeri 06 Jakarta Selatan	Multimedia	Jl. Kramat Raya No. 128, Jakarta Selatan	9945675355	2016-07-05	37.39
12	rapot_32578.pdf	rekomendasi_45332.pdf	SMK Negeri 01 Bogor	Teknik Komputer	Jl. Salemba Raya No. 41, Bogor	9945675356	2016-07-24	37.82
13	rapot_32579.pdf	rekomendasi_45333.pdf	SMA Negeri 14 Makasar	IPS	Jl. Salemba Tengah 26 - 28, Makasar	9945675357	2016-07-30	38.08
14	rapot_32580.pdf	rekomendasi_45334.pdf	SMA Negeri 09 Garut	IPA	Jl. Dr. Abdul Rachman Saleh 24, Garut	9945675358	2016-07-13	37.98
15	rapot_32581.pdf	rekomendasi_45335.pdf	SMK Negeri 15 Bali 	Teknik Komputer	Jl. Bendungan Hilir No. 17, Bali 	9945675359	2016-06-13	38.10
16	rapot_32582.pdf	rekomendasi_45336.pdf	SMK Negeri 11 Bali 	Analisa Kimia	Jl. Rawamangun No. 47, Bali 	9945675360	2016-06-30	37.95
17	rapot_32583.pdf	rekomendasi_45337.pdf	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675361	2016-07-02	38.51
18	rapot_32584.pdf	rekomendasi_45338.pdf	SMK Negeri 16 Papua	Multimedia	Jl. Kesehatan No. 9, Papua	9945675362	2016-07-08	38.72
19	rapot_32585.pdf	rekomendasi_45339.pdf	SMA Negeri 12 Aceh	IPS	Jl. Kaji No. 40, Aceh	9945675363	2016-07-14	37.85
20	rapot_32586.pdf	rekomendasi_45340.pdf	SMK Negeri 08 Bali 	Multimedia	Jl. Sawo No. 58 - 60, Bali 	9945675364	2016-07-30	38.49
21	rapot_32587.pdf	rekomendasi_45341.pdf	SMA Negeri 14 Semarang	IPA	Jl. Sumur Batu Raya Blok A3 No. 13, Semarang	9945675365	2016-06-26	37.45
23	rapot_32589.pdf	rekomendasi_45343.pdf	SMA Negeri 12 Makasar	IPA	Jl. Teuku Cik Ditiro No. 28, Makasar	9945675367	2016-06-06	35.54
53	rapot_32619.pdf	rekomendasi_45373.pdf	SMA Negeri 11 Garut	IPA	Jl. Daan Mogot No. 34, Garut	9945675397	2016-06-23	35.81
54	rapot_32620.pdf	rekomendasi_45374.pdf	SMK Negeri 02 Bontang	Teknik Otomasi	Jl. Kyai Tapa No. 1, Bontang	9945675398	2016-07-10	36.42
55	rapot_32621.pdf	rekomendasi_45375.pdf	SMA Negeri 19 Jakarta Selatan	IPS	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Selatan	9945675399	2016-07-22	35.19
56	rapot_32622.pdf	rekomendasi_45376.pdf	SMA Negeri 17 Makasar	IPS	Jl. Raya Pejuangan Kav. 8, Makasar	9945675400	2016-06-06	35.11
57	rapot_32623.pdf	rekomendasi_45377.pdf	SMK Negeri 19 Medan	Multimedia	Jl. Kedoya Raya / Al-Kamal No. 2, Medan	9945675401	2016-07-22	34.16
58	rapot_32624.pdf	rekomendasi_45378.pdf	SMA Negeri 05 Surabaya	IPA	Jl. Panjang Arteri 26, Surabaya	9945675402	2016-06-12	36.03
59	rapot_32625.pdf	rekomendasi_45379.pdf	SMK Negeri 18 Makasar	Multimedia	Jl. Raya Kebayoran Lama No. 64 , Makasar	9945675403	2016-07-31	35.50
60	rapot_32626.pdf	rekomendasi_45380.pdf	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Puri Indah Raya  Blok S-2, Balikpapan	9945675404	2016-07-23	34.05
61	rapot_32627.pdf	rekomendasi_45381.pdf	SMA Negeri 14 Bontang	IPA	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675405	2016-06-20	34.64
62	rapot_32628.pdf	rekomendasi_45382.pdf	SMK Negeri 15 Makasar	Teknik Otomasi	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675406	2016-07-31	35.49
63	rapot_32629.pdf	rekomendasi_45383.pdf	SMA Negeri 18 Bali 	IPS	Jl. Raya kamal Outer Ring Road, Bali 	9945675407	2016-06-05	34.53
64	rapot_32630.pdf	rekomendasi_45384.pdf	SMA Negeri 15 Semarang	IPA	Jl. Prof. Dr. Latumeten No. 1, Semarang	9945675408	2016-07-09	34.19
65	rapot_32631.pdf	rekomendasi_45385.pdf	SMA Negeri 12 Jakarta Utara	IPS	Jl. Duri Raya No. 22, Jakarta Utara	9945675409	2016-07-14	34.54
66	rapot_32632.pdf	rekomendasi_45386.pdf	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Letjen S. Parman Kav. 84-86, Balikpapan	9945675410	2016-06-27	35.78
67	rapot_32633.pdf	rekomendasi_45387.pdf	SMK Negeri 02 Makasar	Teknik Mesin	Jl. LetJen S. Parman Kav. 87, Slipi, Makasar	9945675411	2016-06-06	34.39
68	rapot_32634.pdf	rekomendasi_45388.pdf	SMA Negeri 07 Jakarta Utara	IPS	Jl. LetJen S. Parman Kav. 87, Jakarta Utara	9945675412	2016-06-20	35.42
69	rapot_32635.pdf	rekomendasi_45389.pdf	SMA Negeri 14 Jakarta Utara	IPA	Jl. Tanah Sereal VII / 9, Jakarta Utara	9945675413	2016-07-21	35.14
70	rapot_32636.pdf	rekomendasi_45390.pdf	SMA Negeri 01 Balikpapan	IPS	Jl. Kyai Tapa No. , Balikpapan	9945675414	2016-07-29	36.44
71	rapot_32637.pdf	rekomendasi_45391.pdf	SMA Negeri 11 Garut	IPS	Jl. Anggrek No. 2 B, Garut	9945675415	2016-07-30	36.12
72	rapot_32638.pdf	rekomendasi_45392.pdf	SMA Negeri 14 Bandung	IPS	Jl. Pesanggrahan No. 1, Bandung	9945675416	2016-06-09	36.31
73	rapot_32639.pdf	rekomendasi_45393.pdf	SMA Negeri 18 Papua	IPA	Jl. RS Fatmawati No. 80 - 82, Papua	9945675417	2016-06-15	35.76
74	rapot_32640.pdf	rekomendasi_45394.pdf	SMK Negeri 16 Bandung	Teknik Komputer	Jl. Kali Pasir  No. 9, Bandung	9945675351	2016-07-27	37.64
75	rapot_32641.pdf	rekomendasi_45395.pdf	SMA Negeri 18 Bandung	IPS	Jl. Raya Mangga Besar Raya 137 / 139, Bandung	9945675352	2016-07-11	38.66
76	rapot_32642.pdf	rekomendasi_45396.pdf	SMA Negeri 17 Bogor	IPA	Jl. Diponegoro No. 71, Bogor	9945675353	2016-07-22	37.66
77	rapot_32643.pdf	rekomendasi_45397.pdf	SMK Negeri 18 Medan	Multimedia	Jl. Kramat Raya No. 17 A, Medan	9945675354	2016-07-30	37.52
78	rapot_32644.pdf	rekomendasi_45398.pdf	SMK Negeri 06 Jakarta Selatan	Multimedia	Jl. Kramat Raya No. 128, Jakarta Selatan	9945675355	2016-07-05	37.39
79	rapot_32645.pdf	rekomendasi_45399.pdf	SMK Negeri 01 Bogor	Teknik Komputer	Jl. Salemba Raya No. 41, Bogor	9945675356	2016-07-24	37.82
80	rapot_32646.pdf	rekomendasi_45400.pdf	SMA Negeri 14 Makasar	IPS	Jl. Salemba Tengah 26 - 28, Makasar	9945675357	2016-07-30	38.08
81	rapot_32647.pdf	rekomendasi_45401.pdf	SMA Negeri 09 Garut	IPA	Jl. Dr. Abdul Rachman Saleh 24, Garut	9945675358	2016-07-13	37.98
82	rapot_32648.pdf	rekomendasi_45402.pdf	SMK Negeri 15 Bali 	Teknik Komputer	Jl. Bendungan Hilir No. 17, Bali 	9945675359	2016-06-13	38.10
83	rapot_32649.pdf	rekomendasi_45403.pdf	SMK Negeri 11 Bali 	Analisa Kimia	Jl. Rawamangun No. 47, Bali 	9945675360	2016-06-30	37.95
84	rapot_32650.pdf	rekomendasi_45404.pdf	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675361	2016-07-02	38.51
85	rapot_32651.pdf	rekomendasi_45405.pdf	SMK Negeri 16 Papua	Multimedia	Jl. Kesehatan No. 9, Papua	9945675362	2016-07-08	38.72
86	rapot_32652.pdf	rekomendasi_45406.pdf	SMA Negeri 12 Aceh	IPS	Jl. Kaji No. 40, Aceh	9945675363	2016-07-14	37.85
87	rapot_32653.pdf	rekomendasi_45407.pdf	SMK Negeri 08 Bali 	Multimedia	Jl. Sawo No. 58 - 60, Bali 	9945675364	2016-07-30	38.49
89	rapot_32655.pdf	rekomendasi_45409.pdf	SMK Negeri 01 Aceh	Teknik Komputer	Jl. Gereja Theresia No. 22, Aceh	9945675366	2016-06-06	35.83
90	rapot_32656.pdf	rekomendasi_45410.pdf	SMA Negeri 12 Makasar	IPA	Jl. Teuku Cik Ditiro No. 28, Makasar	9945675367	2016-06-06	35.54
91	rapot_32657.pdf	rekomendasi_45411.pdf	SMA Negeri 15 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675368	2016-06-17	35.14
92	rapot_32658.pdf	rekomendasi_45412.pdf	SMA Negeri 03 Palembang	IPS	Jl. Teuku Cik Ditiro No. 46  M, Palembang	9945675369	2016-06-04	34.93
93	rapot_32659.pdf	rekomendasi_45413.pdf	SMK Negeri 19 Maluku	Analisa Kimia	Jl. Proklamasi  No. 43 , Maluku	9945675370	2016-07-01	34.69
94	rapot_32660.pdf	rekomendasi_45414.pdf	SMK Negeri 06 Balikpapan	Teknik Komputer	Jl. Tambak No. 18, Balikpapan	9945675371	2016-06-06	34.66
95	rapot_32661.pdf	rekomendasi_45415.pdf	SMK Negeri 13 Papua	Teknik Otomasi	Jl. Salemba Raya, Papua	9945675372	2016-07-29	35.89
96	rapot_32662.pdf	rekomendasi_45416.pdf	SMA Negeri 17 Bogor	IPA	Jl. Salemba I  No. 13, Bogor	9945675373	2016-06-17	34.78
97	rapot_32663.pdf	rekomendasi_45417.pdf	SMK Negeri 11 Depok	Teknik Komputer	Jl. Jenderal Sudirman Kavling 86, Depok	9945675374	2016-07-16	36.29
98	rapot_32664.pdf	rekomendasi_45418.pdf	SMK Negeri 07 Banten	Multimedia	Jl. Tipar Cakung No. 5, Banten	9945675375	2016-06-26	34.97
99	rapot_32665.pdf	rekomendasi_45419.pdf	SMA Negeri 19 Maluku	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Maluku	9945675376	2016-06-29	36.42
52	rapot_32618.pdf	rekomendasi_45372.pdf	SMK Negeri 02 Jakarta Selatan	Teknik Otomasi	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675396	2016-06-27	36.05
102	rapot_32668.pdf	rekomendasi_45422.pdf	SMA Negeri 12 Banten	IPS	Jl. Kramat Jaya, Tanjung Priok, Banten	9945675379	2017-06-30	35.92
103	rapot_32669.pdf	rekomendasi_45423.pdf	SMK Negeri 13 Depok	Teknik Otomasi	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Depok	9945675380	2017-07-30	34.09
104	rapot_32670.pdf	rekomendasi_45424.pdf	SMA Negeri 15 Lombok	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Lombok	9945675381	2017-07-16	36.09
105	rapot_32671.pdf	rekomendasi_45425.pdf	SMK Negeri 04 Depok	Analisa Kimia	Jl. Pluit Raya No. 2, Depok	9945675382	2017-07-29	35.41
106	rapot_32672.pdf	rekomendasi_45426.pdf	SMA Negeri 09 Depok	IPA	Jl. Raya Pluit Selatan No. 2, Depok	9945675383	2017-07-24	35.61
107	rapot_32673.pdf	rekomendasi_45427.pdf	SMA Negeri 17 Jakarta Utara	IPA	Jl Sungai Bambu  No. 5, Jakarta Utara	9945675384	2017-06-05	34.50
108	rapot_32674.pdf	rekomendasi_45428.pdf	SMK Negeri 03 Garut	Teknik Mesin	Jl. Agung Utara Raya Blok A No. 1, Garut	9945675385	2017-06-26	35.62
109	rapot_32675.pdf	rekomendasi_45429.pdf	SMA Negeri 01 Bali 	IPS	Jl. Danau Sunter Utara Raya No. 1, Bali 	9945675386	2017-07-13	35.38
110	rapot_32676.pdf	rekomendasi_45430.pdf	SMK Negeri 16 Depok	Teknik Mesin	Jl. Enggano No. 10, Depok	9945675387	2017-06-16	34.62
111	rapot_32677.pdf	rekomendasi_45431.pdf	SMK Negeri 19 Papua	Teknik Mesin	Jl. Tawes No. 18-20 , Papua	9945675388	2017-07-19	34.09
112	rapot_32678.pdf	rekomendasi_45432.pdf	SMA Negeri 18 Bogor	IPS	Pluit Mas I Blok A No. 2A - 5A, Bogor	9945675389	2017-06-28	36.25
114	rapot_32680.pdf	rekomendasi_45434.pdf	SMK Negeri 02 Balikpapan	Teknik Otomasi	Jl. Baru Sunter Permai Raya, Balikpapan	9945675391	2017-06-27	35.67
115	rapot_32681.pdf	rekomendasi_45435.pdf	SMA Negeri 06 Palembang	IPS	Jl. Ganggeng Raya No.9, Palembang	9945675392	2017-07-31	35.93
116	rapot_32682.pdf	rekomendasi_45436.pdf	SMA Negeri 11 Palembang	IPA	Jl. Siak J-5 No. 14, Palembang	9945675393	2017-07-07	34.06
117	rapot_32683.pdf	rekomendasi_45437.pdf	SMA Negeri 17 Papua	IPA	Jl. Danau Agung 2 Blok E 3 No. 28-30, Papua	9945675394	2017-07-14	34.03
118	rapot_32684.pdf	rekomendasi_45438.pdf	SMA Negeri 07 Balikpapan	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Balikpapan	9945675395	2017-07-23	36.29
119	rapot_32685.pdf	rekomendasi_45439.pdf	SMK Negeri 02 Jakarta Selatan	Teknik Otomasi	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675396	2017-06-27	36.05
120	rapot_32686.pdf	rekomendasi_45440.pdf	SMA Negeri 11 Garut	IPA	Jl. Daan Mogot No. 34, Garut	9945675397	2017-06-23	35.81
121	rapot_32687.pdf	rekomendasi_45441.pdf	SMK Negeri 02 Bontang	Teknik Otomasi	Jl. Kyai Tapa No. 1, Bontang	9945675398	2017-07-10	36.42
122	rapot_32688.pdf	rekomendasi_45442.pdf	SMA Negeri 19 Jakarta Selatan	IPS	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Selatan	9945675399	2017-07-22	35.19
123	rapot_32689.pdf	rekomendasi_45443.pdf	SMA Negeri 17 Makasar	IPS	Jl. Raya Pejuangan Kav. 8, Makasar	9945675400	2017-06-06	35.11
124	rapot_32690.pdf	rekomendasi_45444.pdf	SMK Negeri 19 Medan	Multimedia	Jl. Kedoya Raya / Al-Kamal No. 2, Medan	9945675401	2017-07-22	34.16
125	rapot_32691.pdf	rekomendasi_45445.pdf	SMA Negeri 05 Surabaya	IPA	Jl. Panjang Arteri 26, Surabaya	9945675402	2017-06-12	36.03
126	rapot_32692.pdf	rekomendasi_45446.pdf	SMK Negeri 18 Makasar	Multimedia	Jl. Raya Kebayoran Lama No. 64 , Makasar	9945675403	2017-07-31	35.50
127	rapot_32693.pdf	rekomendasi_45447.pdf	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Puri Indah Raya  Blok S-2, Balikpapan	9945675404	2017-07-23	34.05
128	rapot_32694.pdf	rekomendasi_45448.pdf	SMA Negeri 14 Bontang	IPA	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675405	2017-06-20	34.64
129	rapot_32695.pdf	rekomendasi_45449.pdf	SMK Negeri 15 Makasar	Teknik Otomasi	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675406	2017-07-31	35.49
130	rapot_32696.pdf	rekomendasi_45450.pdf	SMA Negeri 18 Bali 	IPS	Jl. Raya kamal Outer Ring Road, Bali 	9945675407	2017-06-05	34.53
131	rapot_32697.pdf	rekomendasi_45451.pdf	SMA Negeri 15 Semarang	IPA	Jl. Prof. Dr. Latumeten No. 1, Semarang	9945675408	2017-07-09	34.19
132	rapot_32698.pdf	rekomendasi_45452.pdf	SMA Negeri 12 Jakarta Utara	IPS	Jl. Duri Raya No. 22, Jakarta Utara	9945675409	2017-07-14	34.54
133	rapot_32699.pdf	rekomendasi_45453.pdf	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Letjen S. Parman Kav. 84-86, Balikpapan	9945675410	2017-06-27	35.78
134	rapot_32700.pdf	rekomendasi_45454.pdf	SMK Negeri 02 Makasar	Teknik Mesin	Jl. LetJen S. Parman Kav. 87, Slipi, Makasar	9945675411	2017-06-06	34.39
135	rapot_32701.pdf	rekomendasi_45455.pdf	SMA Negeri 07 Jakarta Utara	IPS	Jl. LetJen S. Parman Kav. 87, Jakarta Utara	9945675412	2017-06-20	35.42
136	rapot_32702.pdf	rekomendasi_45456.pdf	SMA Negeri 14 Jakarta Utara	IPA	Jl. Tanah Sereal VII / 9, Jakarta Utara	9945675413	2017-07-21	35.14
137	rapot_32703.pdf	rekomendasi_45457.pdf	SMA Negeri 01 Balikpapan	IPS	Jl. Kyai Tapa No. , Balikpapan	9945675414	2017-07-29	36.44
138	rapot_32704.pdf	rekomendasi_45458.pdf	SMA Negeri 11 Garut	IPS	Jl. Anggrek No. 2 B, Garut	9945675415	2017-07-30	36.12
139	rapot_32705.pdf	rekomendasi_45459.pdf	SMA Negeri 14 Bandung	IPS	Jl. Pesanggrahan No. 1, Bandung	9945675416	2017-06-09	36.31
140	rapot_32706.pdf	rekomendasi_45460.pdf	SMA Negeri 18 Papua	IPA	Jl. RS Fatmawati No. 80 - 82, Papua	9945675417	2017-06-15	35.76
141	rapot_32707.pdf	rekomendasi_45461.pdf	SMA Negeri 09 Garut	IPA	Jl. Dr. Abdul Rachman Saleh 24, Garut	9945675358	2017-07-13	37.98
142	rapot_32708.pdf	rekomendasi_45462.pdf	SMK Negeri 15 Bali 	Teknik Komputer	Jl. Bendungan Hilir No. 17, Bali 	9945675359	2017-06-13	38.10
143	rapot_32709.pdf	rekomendasi_45463.pdf	SMK Negeri 11 Bali 	Analisa Kimia	Jl. Rawamangun No. 47, Bali 	9945675360	2017-06-30	37.95
144	rapot_32710.pdf	rekomendasi_45464.pdf	SMA Negeri 17 Balikpapan	IPS	Jl. Budi Kemuliaan No. 25 , Balikpapan	9945675361	2017-07-02	38.51
145	rapot_32711.pdf	rekomendasi_45465.pdf	SMK Negeri 16 Papua	Multimedia	Jl. Kesehatan No. 9, Papua	9945675362	2017-07-08	38.72
146	rapot_32712.pdf	rekomendasi_45466.pdf	SMA Negeri 12 Aceh	IPS	Jl. Kaji No. 40, Aceh	9945675363	2017-07-14	37.85
147	rapot_32713.pdf	rekomendasi_45467.pdf	SMK Negeri 08 Bali 	Multimedia	Jl. Sawo No. 58 - 60, Bali 	9945675364	2017-07-30	38.49
148	rapot_32714.pdf	rekomendasi_45468.pdf	SMA Negeri 14 Semarang	IPA	Jl. Sumur Batu Raya Blok A3 No. 13, Semarang	9945675365	2017-06-26	37.45
101	rapot_32667.pdf	rekomendasi_45421.pdf	SMA Negeri 04 Aceh	IPA	Jl. Deli No. 4  Tanjung Priok, Aceh	9945675378	2017-07-16	35.80
151	rapot_32717.pdf	rekomendasi_45471.pdf	SMA Negeri 15 Medan	IPA	Jl. Teuku Cik Ditiro No. 41, Medan	9945675368	2017-06-17	35.14
152	rapot_32718.pdf	rekomendasi_45472.pdf	SMA Negeri 03 Palembang	IPS	Jl. Teuku Cik Ditiro No. 46  M, Palembang	9945675369	2017-06-04	34.93
153	rapot_32719.pdf	rekomendasi_45473.pdf	SMK Negeri 19 Maluku	Analisa Kimia	Jl. Proklamasi  No. 43 , Maluku	9945675370	2017-07-01	34.69
154	rapot_32720.pdf	rekomendasi_45474.pdf	SMK Negeri 06 Balikpapan	Teknik Komputer	Jl. Tambak No. 18, Balikpapan	9945675371	2017-06-06	34.66
155	rapot_32721.pdf	rekomendasi_45475.pdf	SMK Negeri 13 Papua	Teknik Otomasi	Jl. Salemba Raya, Papua	9945675372	2017-07-29	35.89
156	rapot_32722.pdf	rekomendasi_45476.pdf	SMA Negeri 17 Bogor	IPA	Jl. Salemba I  No. 13, Bogor	9945675373	2017-06-17	34.78
158	rapot_32724.pdf	rekomendasi_45478.pdf	SMK Negeri 07 Banten	Multimedia	Jl. Tipar Cakung No. 5, Banten	9945675375	2017-06-26	34.97
159	rapot_32725.pdf	rekomendasi_45479.pdf	SMA Negeri 19 Maluku	IPS	Jl. Boulevard Timur Raya RT. 006 / 02, Maluku	9945675376	2017-06-29	36.42
160	rapot_32726.pdf	rekomendasi_45480.pdf	SMK Negeri 08 Palembang	Teknik Mesin	Jl. Bukit Gading Raya Kav. II, Palembang	9945675377	2017-06-27	36.11
161	rapot_32727.pdf	rekomendasi_45481.pdf	SMA Negeri 04 Aceh	IPA	Jl. Deli No. 4  Tanjung Priok, Aceh	9945675378	2017-07-16	35.80
162	rapot_32728.pdf	rekomendasi_45482.pdf	SMA Negeri 12 Banten	IPS	Jl. Kramat Jaya, Tanjung Priok, Banten	9945675379	2017-06-30	35.92
163	rapot_32729.pdf	rekomendasi_45483.pdf	SMK Negeri 13 Depok	Teknik Otomasi	Jl. Raya Plumpang Semper No. 19  RT.006 / RW.015, Depok	9945675380	2017-07-30	34.09
164	rapot_32730.pdf	rekomendasi_45484.pdf	SMA Negeri 15 Lombok	IPA	Jl. Pantai Indah Utara 3 Sek. Utr. Tmr Blok T, Lombok	9945675381	2017-07-16	36.09
165	rapot_32731.pdf	rekomendasi_45485.pdf	SMK Negeri 04 Depok	Analisa Kimia	Jl. Pluit Raya No. 2, Depok	9945675382	2017-07-29	35.41
166	rapot_32732.pdf	rekomendasi_45486.pdf	SMA Negeri 09 Depok	IPA	Jl. Raya Pluit Selatan No. 2, Depok	9945675383	2017-07-24	35.61
167	rapot_32733.pdf	rekomendasi_45487.pdf	SMA Negeri 17 Jakarta Utara	IPA	Jl Sungai Bambu  No. 5, Jakarta Utara	9945675384	2017-06-05	34.50
168	rapot_32734.pdf	rekomendasi_45488.pdf	SMK Negeri 03 Garut	Teknik Mesin	Jl. Agung Utara Raya Blok A No. 1, Garut	9945675385	2017-06-26	35.62
169	rapot_32735.pdf	rekomendasi_45489.pdf	SMA Negeri 01 Bali 	IPS	Jl. Danau Sunter Utara Raya No. 1, Bali 	9945675386	2017-07-13	35.38
170	rapot_32736.pdf	rekomendasi_45490.pdf	SMK Negeri 16 Depok	Teknik Mesin	Jl. Enggano No. 10, Depok	9945675387	2017-06-16	34.62
171	rapot_32737.pdf	rekomendasi_45491.pdf	SMK Negeri 19 Papua	Teknik Mesin	Jl. Tawes No. 18-20 , Papua	9945675388	2017-07-19	34.09
172	rapot_32738.pdf	rekomendasi_45492.pdf	SMA Negeri 18 Bogor	IPS	Pluit Mas I Blok A No. 2A - 5A, Bogor	9945675389	2017-06-28	36.25
173	rapot_32739.pdf	rekomendasi_45493.pdf	SMA Negeri 16 Maluku	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Maluku	9945675390	2017-06-05	34.55
174	rapot_32740.pdf	rekomendasi_45494.pdf	SMK Negeri 02 Balikpapan	Teknik Otomasi	Jl. Baru Sunter Permai Raya, Balikpapan	9945675391	2017-06-27	35.67
175	rapot_32741.pdf	rekomendasi_45495.pdf	SMA Negeri 06 Palembang	IPS	Jl. Ganggeng Raya No.9, Palembang	9945675392	2017-07-31	35.93
176	rapot_32742.pdf	rekomendasi_45496.pdf	SMA Negeri 11 Palembang	IPA	Jl. Siak J-5 No. 14, Palembang	9945675393	2017-07-07	34.06
177	rapot_32743.pdf	rekomendasi_45497.pdf	SMA Negeri 17 Papua	IPA	Jl. Danau Agung 2 Blok E 3 No. 28-30, Papua	9945675394	2017-07-14	34.03
178	rapot_32744.pdf	rekomendasi_45498.pdf	SMA Negeri 07 Balikpapan	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Balikpapan	9945675395	2017-07-23	36.29
179	rapot_32745.pdf	rekomendasi_45499.pdf	SMK Negeri 02 Jakarta Selatan	Teknik Otomasi	Jl. Cendrawasih No.1 Komp. Dep. Han, Mabes TNI  Slipi, Jakarta Selatan	9945675396	2017-06-27	36.05
180	rapot_32746.pdf	rekomendasi_45500.pdf	SMA Negeri 11 Garut	IPA	Jl. Daan Mogot No. 34, Garut	9945675397	2017-06-23	35.81
181	rapot_32747.pdf	rekomendasi_45501.pdf	SMK Negeri 02 Bontang	Teknik Otomasi	Jl. Kyai Tapa No. 1, Bontang	9945675398	2017-07-10	36.42
182	rapot_32748.pdf	rekomendasi_45502.pdf	SMA Negeri 19 Jakarta Selatan	IPS	Jl. Kintamani Raya No. 2, Kawasan Daan Mogot Baru, Jakarta Selatan	9945675399	2017-07-22	35.19
183	rapot_32749.pdf	rekomendasi_45503.pdf	SMA Negeri 17 Makasar	IPS	Jl. Raya Pejuangan Kav. 8, Makasar	9945675400	2017-06-06	35.11
184	rapot_32750.pdf	rekomendasi_45504.pdf	SMK Negeri 19 Medan	Multimedia	Jl. Kedoya Raya / Al-Kamal No. 2, Medan	9945675401	2017-07-22	34.16
185	rapot_32751.pdf	rekomendasi_45505.pdf	SMA Negeri 05 Surabaya	IPA	Jl. Panjang Arteri 26, Surabaya	9945675402	2017-06-12	36.03
186	rapot_32752.pdf	rekomendasi_45506.pdf	SMK Negeri 18 Makasar	Multimedia	Jl. Raya Kebayoran Lama No. 64 , Makasar	9945675403	2017-07-31	35.50
187	rapot_32753.pdf	rekomendasi_45507.pdf	SMK Negeri 04 Balikpapan	Analisa Kimia	Jl. Puri Indah Raya  Blok S-2, Balikpapan	9945675404	2017-07-23	34.05
188	rapot_32754.pdf	rekomendasi_45508.pdf	SMA Negeri 14 Bontang	IPA	Jl. Aip II K. S. Tubun No. 92-94, Bontang	9945675405	2017-06-20	34.64
189	rapot_32755.pdf	rekomendasi_45509.pdf	SMK Negeri 15 Makasar	Teknik Otomasi	Jl. Aipda K. S. Tubun No. 79, Makasar	9945675406	2017-07-31	35.49
190	rapot_32756.pdf	rekomendasi_45510.pdf	SMA Negeri 18 Bali 	IPS	Jl. Raya kamal Outer Ring Road, Bali 	9945675407	2017-06-05	34.53
191	rapot_32757.pdf	rekomendasi_45511.pdf	SMA Negeri 15 Semarang	IPA	Jl. Prof. Dr. Latumeten No. 1, Semarang	9945675408	2017-07-09	34.19
192	rapot_32758.pdf	rekomendasi_45512.pdf	SMA Negeri 12 Jakarta Utara	IPS	Jl. Duri Raya No. 22, Jakarta Utara	9945675409	2017-07-14	34.54
193	rapot_32759.pdf	rekomendasi_45513.pdf	SMK Negeri 14 Balikpapan	Analisa Kimia	Jl. Letjen S. Parman Kav. 84-86, Balikpapan	9945675410	2017-06-27	35.78
195	rapot_32761.pdf	rekomendasi_45515.pdf	SMA Negeri 07 Jakarta Utara	IPS	Jl. LetJen S. Parman Kav. 87, Jakarta Utara	9945675412	2017-06-20	35.42
196	rapot_32762.pdf	rekomendasi_45516.pdf	SMA Negeri 14 Jakarta Utara	IPA	Jl. Tanah Sereal VII / 9, Jakarta Utara	9945675413	2017-07-21	35.14
197	rapot_32763.pdf	rekomendasi_45517.pdf	SMA Negeri 01 Balikpapan	IPS	Jl. Kyai Tapa No. , Balikpapan	9945675414	2017-07-29	36.44
150	rapot_32716.pdf	rekomendasi_45470.pdf	SMA Negeri 12 Makasar	IPA	Jl. Teuku Cik Ditiro No. 28, Makasar	9945675367	2017-06-06	35.54
22	rapot_32588.pdf	rekomendasi_45342.pdf	SMK Negeri 01 Aceh	Teknik Komputer	Jl. Gereja Theresia No. 22, Aceh	9945675366	2016-06-06	35.83
41	rapot_32607.pdf	rekomendasi_45361.pdf	SMK Negeri 03 Garut	Teknik Mesin	Jl. Agung Utara Raya Blok A No. 1, Garut	9945675385	2016-06-26	35.62
51	rapot_32617.pdf	rekomendasi_45371.pdf	SMA Negeri 07 Balikpapan	IPS	Jl. Kamal Raya, Bumi Cengkareng Indah, Balikpapan	9945675395	2016-07-23	36.29
88	rapot_32654.pdf	rekomendasi_45408.pdf	SMA Negeri 14 Semarang	IPA	Jl. Sumur Batu Raya Blok A3 No. 13, Semarang	9945675365	2016-06-26	37.45
100	rapot_32666.pdf	rekomendasi_45420.pdf	SMK Negeri 08 Palembang	Teknik Mesin	Jl. Bukit Gading Raya Kav. II, Palembang	9945675377	2016-06-27	36.11
113	rapot_32679.pdf	rekomendasi_45433.pdf	SMA Negeri 16 Maluku	IPS	Mutiara Mediterania C/8 A, Jl. Raya Pluit Samudra I-A RT.0011 RW.05, Maluku	9945675390	2017-06-05	34.55
149	rapot_32715.pdf	rekomendasi_45469.pdf	SMK Negeri 01 Aceh	Teknik Komputer	Jl. Gereja Theresia No. 22, Aceh	9945675366	2017-06-06	35.83
157	rapot_32723.pdf	rekomendasi_45477.pdf	SMK Negeri 11 Depok	Teknik Komputer	Jl. Jenderal Sudirman Kavling 86, Depok	9945675374	2017-07-16	36.29
194	rapot_32760.pdf	rekomendasi_45514.pdf	SMK Negeri 02 Makasar	Teknik Mesin	Jl. LetJen S. Parman Kav. 87, Slipi, Makasar	9945675411	2017-06-06	34.39
198	rapot_32764.pdf	rekomendasi_45518.pdf	SMA Negeri 11 Garut	IPS	Jl. Anggrek No. 2 B, Garut	9945675415	2017-07-30	36.12
199	rapot_32765.pdf	rekomendasi_45519.pdf	SMA Negeri 14 Bandung	IPS	Jl. Pesanggrahan No. 1, Bandung	9945675416	2017-06-09	36.31
200	rapot_32766.pdf	rekomendasi_45520.pdf	SMA Negeri 18 Papua	IPA	Jl. RS Fatmawati No. 80 - 82, Papua	9945675417	2017-06-15	35.76
\.


--
-- Data for Name: penerimaan_prodi; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY penerimaan_prodi (nomor_periode, tahun_periode, kode_prodi, kuota, jumlah_pelamar, jumlah_diterima) FROM stdin;
1	2016	94	80	\N	\N
1	2016	95	50	\N	\N
1	2016	96	100	\N	\N
1	2016	97	50	\N	\N
1	2016	98	60	\N	\N
1	2016	99	20	\N	\N
1	2016	100	30	\N	\N
1	2016	101	80	\N	\N
1	2016	102	100	\N	\N
1	2016	103	40	\N	\N
1	2016	104	70	\N	\N
1	2016	105	20	\N	\N
1	2016	106	70	\N	\N
1	2016	107	90	\N	\N
1	2016	108	80	\N	\N
1	2016	109	50	\N	\N
1	2016	110	100	\N	\N
1	2016	111	40	\N	\N
1	2016	112	80	\N	\N
1	2016	113	90	\N	\N
1	2016	114	100	\N	\N
1	2016	115	30	\N	\N
1	2016	116	60	\N	\N
1	2016	117	90	\N	\N
1	2016	118	100	\N	\N
1	2016	119	20	\N	\N
1	2016	120	50	\N	\N
1	2016	121	30	\N	\N
1	2016	122	60	\N	\N
1	2016	123	80	\N	\N
1	2016	124	30	\N	\N
1	2016	125	30	\N	\N
1	2016	126	40	\N	\N
1	2016	127	100	\N	\N
1	2016	128	90	\N	\N
1	2016	129	30	\N	\N
1	2016	130	20	\N	\N
1	2016	131	50	\N	\N
1	2016	132	40	\N	\N
1	2016	133	70	\N	\N
1	2016	134	80	\N	\N
1	2016	135	90	\N	\N
1	2016	136	20	\N	\N
1	2016	137	60	\N	\N
1	2016	138	60	\N	\N
1	2016	139	80	\N	\N
1	2016	140	40	\N	\N
1	2016	141	20	\N	\N
1	2016	142	30	\N	\N
1	2016	143	20	\N	\N
1	2016	144	40	\N	\N
1	2016	145	40	\N	\N
1	2016	146	60	\N	\N
1	2016	147	20	\N	\N
1	2016	148	100	\N	\N
1	2016	149	90	\N	\N
1	2016	150	40	\N	\N
1	2016	151	80	\N	\N
1	2016	152	40	\N	\N
1	2016	153	40	\N	\N
1	2016	154	80	\N	\N
1	2016	155	40	\N	\N
1	2016	156	70	\N	\N
1	2016	157	70	\N	\N
1	2016	158	40	\N	\N
1	2016	159	40	\N	\N
1	2016	160	80	\N	\N
1	2016	161	30	\N	\N
1	2016	162	50	\N	\N
1	2016	163	40	\N	\N
1	2016	164	80	\N	\N
1	2016	165	80	\N	\N
1	2016	166	60	\N	\N
1	2016	167	60	\N	\N
1	2016	168	90	\N	\N
1	2016	169	30	\N	\N
1	2016	170	70	\N	\N
1	2016	171	80	\N	\N
1	2016	172	90	\N	\N
1	2016	173	80	\N	\N
1	2016	174	60	\N	\N
1	2016	175	60	\N	\N
1	2016	176	100	\N	\N
1	2016	177	30	\N	\N
1	2016	178	50	\N	\N
1	2016	179	50	\N	\N
1	2016	180	80	\N	\N
1	2016	181	90	\N	\N
1	2016	182	80	\N	\N
1	2016	183	20	\N	\N
1	2016	184	30	\N	\N
1	2016	185	60	\N	\N
1	2016	186	60	\N	\N
1	2016	187	70	\N	\N
1	2016	188	100	\N	\N
1	2016	189	60	\N	\N
1	2016	190	40	\N	\N
1	2016	191	90	\N	\N
1	2016	192	80	\N	\N
1	2016	193	20	\N	\N
1	2016	194	90	\N	\N
1	2016	195	60	\N	\N
1	2016	196	40	\N	\N
1	2016	197	50	\N	\N
1	2016	198	90	\N	\N
1	2016	199	40	\N	\N
1	2016	200	90	\N	\N
1	2016	201	40	\N	\N
1	2016	202	90	\N	\N
1	2016	203	60	\N	\N
1	2016	204	30	\N	\N
1	2016	205	80	\N	\N
1	2016	206	20	\N	\N
1	2016	207	80	\N	\N
1	2016	208	90	\N	\N
1	2016	209	40	\N	\N
1	2016	210	90	\N	\N
1	2016	211	40	\N	\N
1	2016	212	90	\N	\N
1	2016	213	50	\N	\N
1	2016	214	60	\N	\N
1	2016	215	50	\N	\N
1	2016	216	100	\N	\N
1	2016	217	30	\N	\N
1	2016	218	100	\N	\N
1	2016	219	90	\N	\N
1	2016	220	20	\N	\N
1	2016	221	90	\N	\N
2	2016	1	30	\N	\N
2	2016	2	40	\N	\N
2	2016	3	100	\N	\N
2	2016	4	70	\N	\N
2	2016	5	20	\N	\N
2	2016	6	90	\N	\N
2	2016	7	60	\N	\N
2	2016	8	20	\N	\N
2	2016	10	90	\N	\N
2	2016	12	20	\N	\N
2	2016	14	100	\N	\N
2	2016	16	50	\N	\N
2	2016	18	100	\N	\N
2	2016	20	70	\N	\N
2	2016	21	60	\N	\N
2	2016	22	50	\N	\N
2	2016	23	70	\N	\N
2	2016	25	90	\N	\N
2	2016	27	80	\N	\N
2	2016	29	20	\N	\N
2	2016	31	90	\N	\N
2	2016	33	70	\N	\N
2	2016	35	100	\N	\N
2	2016	37	60	\N	\N
2	2016	39	50	\N	\N
2	2016	41	70	\N	\N
2	2016	42	30	\N	\N
2	2016	43	40	\N	\N
2	2016	44	50	\N	\N
2	2016	45	70	\N	\N
2	2016	46	20	\N	\N
2	2016	48	80	\N	\N
2	2016	49	70	\N	\N
2	2016	50	80	\N	\N
2	2016	52	60	\N	\N
2	2016	53	90	\N	\N
2	2016	54	90	\N	\N
2	2016	56	60	\N	\N
2	2016	58	50	\N	\N
2	2016	59	90	\N	\N
2	2016	60	60	\N	\N
2	2016	62	20	\N	\N
2	2016	63	60	\N	\N
2	2016	65	90	\N	\N
2	2016	67	90	\N	\N
2	2016	68	80	\N	\N
2	2016	69	60	\N	\N
2	2016	71	90	\N	\N
2	2016	73	90	\N	\N
2	2016	75	90	\N	\N
2	2016	77	40	\N	\N
2	2016	78	20	\N	\N
2	2016	80	90	\N	\N
2	2016	81	50	\N	\N
2	2016	83	90	\N	\N
2	2016	84	100	\N	\N
2	2016	85	70	\N	\N
2	2016	86	30	\N	\N
2	2016	87	40	\N	\N
2	2016	88	100	\N	\N
2	2016	90	90	\N	\N
2	2016	92	20	\N	\N
2	2016	94	100	\N	\N
2	2016	95	30	\N	\N
2	2016	96	30	\N	\N
2	2016	97	50	\N	\N
2	2016	98	90	\N	\N
2	2016	99	20	\N	\N
2	2016	100	60	\N	\N
2	2016	101	90	\N	\N
2	2016	102	50	\N	\N
2	2016	103	90	\N	\N
2	2016	104	90	\N	\N
2	2016	105	80	\N	\N
2	2016	106	30	\N	\N
2	2016	107	90	\N	\N
2	2016	108	40	\N	\N
2	2016	109	70	\N	\N
2	2016	110	70	\N	\N
2	2016	111	90	\N	\N
2	2016	112	100	\N	\N
2	2016	113	80	\N	\N
2	2016	114	20	\N	\N
2	2016	115	20	\N	\N
2	2016	116	60	\N	\N
2	2016	117	20	\N	\N
2	2016	118	60	\N	\N
2	2016	119	80	\N	\N
2	2016	120	50	\N	\N
2	2016	121	90	\N	\N
2	2016	122	20	\N	\N
2	2016	123	50	\N	\N
2	2016	124	40	\N	\N
2	2016	125	40	\N	\N
2	2016	126	50	\N	\N
2	2016	127	40	\N	\N
2	2016	128	100	\N	\N
2	2016	129	70	\N	\N
2	2016	130	30	\N	\N
2	2016	131	20	\N	\N
2	2016	132	70	\N	\N
2	2016	133	90	\N	\N
2	2016	134	40	\N	\N
2	2016	135	30	\N	\N
2	2016	136	40	\N	\N
2	2016	137	20	\N	\N
2	2016	138	80	\N	\N
2	2016	139	20	\N	\N
2	2016	140	30	\N	\N
2	2016	141	60	\N	\N
2	2016	142	30	\N	\N
2	2016	143	20	\N	\N
2	2016	144	90	\N	\N
2	2016	145	90	\N	\N
2	2016	146	40	\N	\N
2	2016	147	40	\N	\N
2	2016	148	90	\N	\N
2	2016	149	30	\N	\N
2	2016	150	70	\N	\N
2	2016	151	40	\N	\N
2	2016	152	100	\N	\N
2	2016	153	60	\N	\N
2	2016	154	70	\N	\N
2	2016	155	100	\N	\N
2	2016	156	60	\N	\N
2	2016	157	70	\N	\N
2	2016	158	70	\N	\N
2	2016	159	70	\N	\N
2	2016	160	40	\N	\N
2	2016	161	20	\N	\N
2	2016	162	80	\N	\N
2	2016	163	40	\N	\N
2	2016	164	60	\N	\N
2	2016	165	20	\N	\N
2	2016	166	50	\N	\N
2	2016	167	30	\N	\N
2	2016	168	40	\N	\N
2	2016	169	40	\N	\N
2	2016	170	50	\N	\N
2	2016	171	60	\N	\N
2	2016	172	70	\N	\N
2	2016	173	90	\N	\N
2	2016	174	30	\N	\N
2	2016	175	20	\N	\N
2	2016	176	70	\N	\N
2	2016	177	100	\N	\N
2	2016	178	40	\N	\N
2	2016	179	50	\N	\N
2	2016	180	70	\N	\N
2	2016	181	50	\N	\N
2	2016	182	70	\N	\N
2	2016	183	90	\N	\N
2	2016	184	70	\N	\N
2	2016	185	40	\N	\N
2	2016	186	70	\N	\N
2	2016	187	50	\N	\N
2	2016	188	70	\N	\N
2	2016	189	30	\N	\N
2	2016	190	60	\N	\N
2	2016	191	40	\N	\N
2	2016	192	90	\N	\N
2	2016	193	20	\N	\N
2	2016	194	80	\N	\N
2	2016	195	60	\N	\N
2	2016	196	30	\N	\N
2	2016	197	20	\N	\N
2	2016	198	80	\N	\N
2	2016	199	50	\N	\N
2	2016	200	70	\N	\N
2	2016	201	50	\N	\N
2	2016	202	80	\N	\N
2	2016	203	90	\N	\N
2	2016	204	20	\N	\N
2	2016	205	70	\N	\N
2	2016	206	20	\N	\N
2	2016	207	70	\N	\N
2	2016	208	20	\N	\N
2	2016	209	80	\N	\N
2	2016	210	80	\N	\N
2	2016	211	60	\N	\N
2	2016	212	40	\N	\N
2	2016	213	30	\N	\N
2	2016	214	100	\N	\N
2	2016	215	100	\N	\N
2	2016	216	90	\N	\N
2	2016	217	50	\N	\N
2	2016	218	80	\N	\N
2	2016	219	30	\N	\N
2	2016	220	60	\N	\N
2	2016	221	100	\N	\N
3	2016	9	100	\N	\N
3	2016	11	70	\N	\N
3	2016	13	60	\N	\N
3	2016	15	30	\N	\N
3	2016	17	90	\N	\N
3	2016	19	30	\N	\N
3	2016	24	60	\N	\N
3	2016	26	70	\N	\N
3	2016	28	80	\N	\N
3	2016	30	80	\N	\N
3	2016	32	60	\N	\N
3	2016	34	100	\N	\N
3	2016	36	20	\N	\N
3	2016	38	90	\N	\N
3	2016	40	20	\N	\N
3	2016	47	100	\N	\N
3	2016	51	30	\N	\N
3	2016	55	50	\N	\N
3	2016	57	100	\N	\N
3	2016	61	100	\N	\N
3	2016	64	50	\N	\N
3	2016	66	50	\N	\N
3	2016	70	40	\N	\N
3	2016	72	30	\N	\N
3	2016	74	20	\N	\N
3	2016	76	40	\N	\N
3	2016	79	60	\N	\N
3	2016	82	80	\N	\N
3	2016	89	100	\N	\N
3	2016	91	70	\N	\N
3	2016	93	50	\N	\N
4	2016	94	20	\N	\N
4	2016	95	50	\N	\N
4	2016	96	20	\N	\N
4	2016	97	100	\N	\N
4	2016	98	80	\N	\N
4	2016	99	80	\N	\N
4	2016	100	30	\N	\N
4	2016	101	70	\N	\N
4	2016	102	100	\N	\N
4	2016	103	50	\N	\N
4	2016	104	40	\N	\N
4	2016	105	20	\N	\N
4	2016	106	20	\N	\N
4	2016	107	80	\N	\N
4	2016	108	50	\N	\N
4	2016	109	70	\N	\N
4	2016	110	80	\N	\N
4	2016	111	20	\N	\N
4	2016	112	80	\N	\N
4	2016	113	20	\N	\N
4	2016	114	70	\N	\N
4	2016	115	60	\N	\N
4	2016	116	20	\N	\N
4	2016	117	70	\N	\N
4	2016	118	20	\N	\N
4	2016	119	30	\N	\N
4	2016	120	90	\N	\N
4	2016	121	60	\N	\N
4	2016	122	60	\N	\N
4	2016	123	50	\N	\N
4	2016	124	50	\N	\N
4	2016	125	90	\N	\N
4	2016	126	20	\N	\N
4	2016	127	90	\N	\N
4	2016	128	90	\N	\N
4	2016	129	100	\N	\N
4	2016	130	20	\N	\N
4	2016	131	80	\N	\N
4	2016	132	50	\N	\N
4	2016	133	60	\N	\N
4	2016	134	30	\N	\N
4	2016	135	90	\N	\N
4	2016	136	20	\N	\N
4	2016	137	50	\N	\N
4	2016	138	100	\N	\N
4	2016	139	90	\N	\N
4	2016	140	70	\N	\N
4	2016	141	60	\N	\N
4	2016	142	20	\N	\N
4	2016	143	60	\N	\N
4	2016	144	40	\N	\N
4	2016	145	40	\N	\N
4	2016	146	40	\N	\N
4	2016	147	50	\N	\N
4	2016	148	30	\N	\N
4	2016	149	40	\N	\N
4	2016	150	80	\N	\N
4	2016	151	70	\N	\N
4	2016	152	60	\N	\N
4	2016	153	20	\N	\N
4	2016	154	60	\N	\N
4	2016	155	70	\N	\N
4	2016	156	70	\N	\N
4	2016	157	20	\N	\N
4	2016	158	40	\N	\N
4	2016	159	30	\N	\N
4	2016	160	40	\N	\N
4	2016	161	20	\N	\N
4	2016	162	40	\N	\N
4	2016	163	80	\N	\N
4	2016	164	60	\N	\N
4	2016	165	100	\N	\N
4	2016	166	80	\N	\N
4	2016	167	90	\N	\N
4	2016	168	100	\N	\N
4	2016	169	50	\N	\N
4	2016	170	70	\N	\N
4	2016	171	60	\N	\N
4	2016	172	80	\N	\N
4	2016	173	30	\N	\N
4	2016	174	80	\N	\N
4	2016	175	90	\N	\N
4	2016	176	70	\N	\N
4	2016	177	40	\N	\N
4	2016	178	100	\N	\N
4	2016	179	20	\N	\N
4	2016	180	50	\N	\N
4	2016	181	100	\N	\N
4	2016	182	60	\N	\N
4	2016	183	80	\N	\N
4	2016	184	30	\N	\N
4	2016	185	80	\N	\N
4	2016	186	70	\N	\N
4	2016	187	90	\N	\N
4	2016	188	40	\N	\N
4	2016	189	20	\N	\N
4	2016	190	80	\N	\N
4	2016	191	60	\N	\N
4	2016	192	30	\N	\N
4	2016	193	100	\N	\N
4	2016	194	60	\N	\N
4	2016	195	100	\N	\N
4	2016	196	70	\N	\N
4	2016	197	40	\N	\N
4	2016	198	30	\N	\N
4	2016	199	100	\N	\N
4	2016	200	70	\N	\N
4	2016	201	20	\N	\N
4	2016	202	80	\N	\N
4	2016	203	20	\N	\N
4	2016	204	30	\N	\N
4	2016	205	20	\N	\N
4	2016	206	90	\N	\N
4	2016	207	40	\N	\N
4	2016	208	70	\N	\N
4	2016	209	70	\N	\N
4	2016	210	80	\N	\N
4	2016	211	90	\N	\N
4	2016	212	100	\N	\N
4	2016	213	90	\N	\N
4	2016	214	20	\N	\N
4	2016	215	50	\N	\N
4	2016	216	60	\N	\N
4	2016	217	70	\N	\N
4	2016	218	20	\N	\N
4	2016	219	60	\N	\N
4	2016	220	30	\N	\N
4	2016	221	80	\N	\N
1	2017	94	70	\N	\N
1	2017	95	20	\N	\N
1	2017	96	50	\N	\N
1	2017	97	50	\N	\N
1	2017	98	80	\N	\N
1	2017	99	40	\N	\N
1	2017	100	60	\N	\N
1	2017	101	20	\N	\N
1	2017	102	30	\N	\N
1	2017	103	80	\N	\N
1	2017	104	20	\N	\N
1	2017	105	20	\N	\N
1	2017	106	20	\N	\N
1	2017	107	50	\N	\N
1	2017	108	60	\N	\N
1	2017	109	30	\N	\N
1	2017	110	70	\N	\N
1	2017	111	70	\N	\N
1	2017	112	20	\N	\N
1	2017	113	90	\N	\N
1	2017	114	30	\N	\N
1	2017	115	90	\N	\N
1	2017	116	70	\N	\N
1	2017	117	90	\N	\N
1	2017	118	100	\N	\N
1	2017	119	40	\N	\N
1	2017	120	40	\N	\N
1	2017	121	50	\N	\N
1	2017	122	70	\N	\N
1	2017	123	100	\N	\N
1	2017	124	100	\N	\N
1	2017	125	100	\N	\N
1	2017	126	60	\N	\N
1	2017	127	100	\N	\N
1	2017	128	20	\N	\N
1	2017	129	70	\N	\N
1	2017	130	100	\N	\N
1	2017	131	90	\N	\N
1	2017	132	20	\N	\N
1	2017	133	20	\N	\N
1	2017	134	30	\N	\N
1	2017	135	20	\N	\N
1	2017	136	30	\N	\N
1	2017	137	90	\N	\N
1	2017	138	30	\N	\N
1	2017	139	20	\N	\N
1	2017	140	90	\N	\N
1	2017	141	30	\N	\N
1	2017	142	20	\N	\N
1	2017	143	50	\N	\N
1	2017	144	30	\N	\N
1	2017	145	50	\N	\N
1	2017	146	50	\N	\N
1	2017	147	70	\N	\N
1	2017	148	80	\N	\N
1	2017	149	60	\N	\N
1	2017	150	50	\N	\N
1	2017	151	60	\N	\N
1	2017	152	30	\N	\N
1	2017	153	40	\N	\N
1	2017	154	70	\N	\N
1	2017	155	20	\N	\N
1	2017	156	40	\N	\N
1	2017	157	100	\N	\N
1	2017	158	50	\N	\N
1	2017	159	40	\N	\N
1	2017	160	40	\N	\N
1	2017	161	40	\N	\N
1	2017	162	30	\N	\N
1	2017	163	70	\N	\N
1	2017	164	80	\N	\N
1	2017	165	60	\N	\N
1	2017	166	50	\N	\N
1	2017	167	20	\N	\N
1	2017	168	50	\N	\N
1	2017	169	30	\N	\N
1	2017	170	80	\N	\N
1	2017	171	90	\N	\N
1	2017	172	50	\N	\N
1	2017	173	30	\N	\N
1	2017	174	70	\N	\N
1	2017	175	40	\N	\N
1	2017	176	70	\N	\N
1	2017	177	20	\N	\N
1	2017	178	60	\N	\N
1	2017	179	40	\N	\N
1	2017	180	20	\N	\N
1	2017	181	40	\N	\N
1	2017	182	20	\N	\N
1	2017	183	80	\N	\N
1	2017	184	80	\N	\N
1	2017	185	30	\N	\N
1	2017	186	90	\N	\N
1	2017	187	20	\N	\N
1	2017	188	20	\N	\N
1	2017	189	50	\N	\N
1	2017	190	40	\N	\N
1	2017	191	30	\N	\N
1	2017	192	70	\N	\N
1	2017	193	20	\N	\N
1	2017	194	90	\N	\N
1	2017	195	70	\N	\N
1	2017	196	100	\N	\N
1	2017	197	30	\N	\N
1	2017	198	100	\N	\N
1	2017	199	100	\N	\N
1	2017	200	40	\N	\N
1	2017	201	70	\N	\N
1	2017	202	60	\N	\N
1	2017	203	100	\N	\N
1	2017	204	60	\N	\N
1	2017	205	40	\N	\N
1	2017	206	60	\N	\N
1	2017	207	80	\N	\N
1	2017	208	50	\N	\N
1	2017	209	40	\N	\N
1	2017	210	90	\N	\N
1	2017	211	90	\N	\N
1	2017	212	70	\N	\N
1	2017	213	30	\N	\N
1	2017	214	80	\N	\N
1	2017	215	30	\N	\N
1	2017	216	50	\N	\N
1	2017	217	50	\N	\N
1	2017	218	70	\N	\N
1	2017	219	30	\N	\N
1	2017	220	30	\N	\N
1	2017	221	20	\N	\N
2	2017	94	50	\N	\N
2	2017	95	40	\N	\N
2	2017	96	60	\N	\N
2	2017	97	90	\N	\N
2	2017	98	20	\N	\N
2	2017	99	30	\N	\N
2	2017	100	20	\N	\N
2	2017	101	60	\N	\N
2	2017	102	20	\N	\N
2	2017	103	40	\N	\N
2	2017	104	20	\N	\N
2	2017	105	100	\N	\N
2	2017	106	40	\N	\N
2	2017	107	40	\N	\N
2	2017	108	30	\N	\N
2	2017	109	100	\N	\N
2	2017	110	50	\N	\N
2	2017	111	20	\N	\N
2	2017	112	70	\N	\N
2	2017	113	80	\N	\N
2	2017	114	70	\N	\N
2	2017	115	60	\N	\N
2	2017	116	100	\N	\N
2	2017	117	90	\N	\N
2	2017	118	70	\N	\N
2	2017	123	20	\N	\N
2	2017	135	40	\N	\N
2	2017	136	20	\N	\N
2	2017	149	100	\N	\N
2	2017	67	100	18	\N
2	2017	122	90	2	\N
2	2017	35	100	15	\N
2	2017	78	100	19	\N
2	2017	49	80	15	\N
2	2017	48	80	13	\N
2	2017	134	60	2	\N
2	2017	90	60	16	\N
2	2017	7	70	20	\N
2	2017	127	60	3	\N
2	2017	145	30	1	\N
2	2017	69	100	23	\N
2	2017	88	80	14	\N
2	2017	62	50	15	\N
2	2017	141	20	6	\N
2	2017	126	20	4	\N
2	2017	142	50	1	\N
2	2017	58	60	17	\N
2	2017	54	60	25	\N
2	2017	119	60	2	\N
2	2017	139	80	3	\N
2	2017	148	80	2	\N
2	2017	133	40	1	\N
2	2017	144	90	5	\N
2	2017	120	50	2	\N
2	2017	83	60	17	\N
2	2017	80	70	18	\N
2	2017	121	40	4	\N
2	2017	130	60	1	\N
2	2017	125	70	5	\N
2	2017	146	40	2	\N
2	2017	132	20	5	\N
2	2017	59	70	11	\N
2	2017	137	30	1	\N
2	2017	138	70	1	\N
2	2017	143	80	3	\N
2	2017	147	20	6	\N
2	2017	128	60	3	\N
2	2017	129	80	2	\N
2	2017	124	80	2	\N
2	2017	131	70	2	\N
2	2017	140	80	4	\N
2	2017	156	50	\N	\N
2	2017	160	30	\N	\N
2	2017	170	40	\N	\N
2	2017	172	90	\N	\N
2	2017	179	80	\N	\N
2	2017	186	20	\N	\N
2	2017	187	20	\N	\N
2	2017	188	30	\N	\N
2	2017	194	50	\N	\N
2	2017	197	80	\N	\N
2	2017	203	30	\N	\N
2	2017	205	20	\N	\N
2	2017	216	90	\N	\N
2	2017	217	20	\N	\N
2	2017	218	60	\N	\N
2	2017	221	90	\N	\N
1	2016	4	30	\N	\N
1	2016	5	10	\N	\N
1	2016	8	30	\N	\N
1	2016	10	20	\N	\N
1	2016	14	10	\N	\N
1	2016	16	20	\N	\N
1	2016	18	20	\N	\N
1	2016	22	20	\N	\N
1	2016	23	30	\N	\N
1	2016	25	10	\N	\N
1	2016	29	30	\N	\N
1	2016	33	20	\N	\N
1	2016	35	20	\N	\N
1	2016	42	30	\N	\N
1	2016	43	20	\N	\N
1	2016	45	30	\N	\N
1	2016	50	10	\N	\N
1	2016	53	10	\N	\N
1	2016	56	10	\N	\N
1	2016	58	10	\N	\N
1	2016	60	10	\N	\N
1	2016	62	30	\N	\N
1	2016	69	30	\N	\N
1	2016	71	30	\N	\N
1	2016	77	30	\N	\N
1	2016	78	20	\N	\N
1	2016	81	20	\N	\N
1	2016	83	10	\N	\N
1	2016	84	30	\N	\N
1	2016	85	30	\N	\N
1	2016	86	30	\N	\N
1	2016	87	10	\N	\N
1	2016	88	20	\N	\N
1	2016	90	10	\N	\N
1	2016	92	10	\N	\N
1	2017	5	20	\N	\N
1	2017	6	20	\N	\N
1	2017	7	30	\N	\N
1	2017	8	20	\N	\N
1	2017	10	20	\N	\N
1	2017	12	30	\N	\N
1	2017	21	30	\N	\N
1	2017	22	30	\N	\N
1	2017	23	10	\N	\N
1	2017	25	20	\N	\N
1	2017	27	30	\N	\N
1	2017	29	30	\N	\N
1	2017	31	20	\N	\N
1	2017	33	20	\N	\N
1	2017	35	20	\N	\N
2	2017	169	60	3	\N
1	2017	18	10	12	5
1	2017	1	10	31	6
2	2017	181	20	4	\N
2	2017	168	100	3	\N
1	2017	2	30	25	2
1	2017	4	20	29	7
2	2017	184	30	1	\N
2	2017	166	30	1	\N
1	2017	14	20	14	7
2	2017	185	80	5	\N
1	2017	20	10	12	5
1	2017	16	20	13	5
1	2017	3	20	15	2
2	2017	180	20	5	\N
2	2017	152	30	2	\N
2	2017	161	50	2	\N
2	2017	162	40	3	\N
2	2017	173	100	2	\N
2	2017	183	50	2	\N
2	2017	158	20	2	\N
2	2017	174	40	2	\N
2	2017	182	60	1	\N
2	2017	167	100	2	\N
2	2017	153	40	1	\N
2	2017	150	40	3	\N
2	2017	178	40	4	\N
2	2017	193	80	3	\N
2	2017	154	90	2	\N
2	2017	151	90	2	\N
2	2017	171	70	4	\N
2	2017	165	70	3	\N
2	2017	155	40	2	\N
2	2017	157	80	2	\N
2	2017	159	20	3	\N
2	2017	177	100	2	\N
2	2017	164	80	3	\N
2	2017	201	40	1	\N
2	2017	208	70	1	\N
2	2017	175	90	4	\N
2	2017	176	50	2	\N
2	2017	200	30	2	\N
2	2017	202	70	2	\N
2	2017	163	60	3	\N
2	2017	198	50	1	\N
2	2017	209	80	1	\N
2	2017	212	50	3	\N
2	2017	196	60	1	\N
2	2017	195	80	1	\N
2	2017	189	90	3	\N
2	2017	191	40	1	\N
2	2017	211	90	1	\N
2	2017	192	40	1	\N
2	2017	206	60	1	\N
2	2017	215	90	3	\N
2	2017	214	70	1	\N
2	2017	210	60	2	\N
2	2017	220	80	2	\N
2	2017	213	60	2	\N
2	2017	199	30	3	\N
2	2017	204	30	1	\N
2	2017	219	50	3	\N
2	2017	207	30	4	\N
2	2017	190	60	1	\N
1	2017	37	30	\N	\N
1	2017	39	10	\N	\N
1	2017	41	20	\N	\N
1	2017	42	10	\N	\N
1	2017	43	20	\N	\N
1	2017	44	30	\N	\N
1	2017	45	20	\N	\N
1	2017	46	30	\N	\N
1	2017	48	10	\N	\N
1	2017	49	30	\N	\N
1	2017	50	20	\N	\N
1	2017	52	20	\N	\N
1	2017	53	10	\N	\N
1	2017	54	30	\N	\N
1	2017	56	30	\N	\N
1	2017	58	30	\N	\N
1	2017	59	10	\N	\N
1	2017	60	20	\N	\N
1	2017	62	20	\N	\N
1	2017	63	10	\N	\N
1	2017	65	30	\N	\N
1	2017	67	20	\N	\N
1	2017	68	20	\N	\N
1	2017	69	20	\N	\N
1	2017	71	10	\N	\N
1	2017	73	10	\N	\N
1	2017	75	10	\N	\N
1	2017	77	20	\N	\N
1	2017	78	20	\N	\N
1	2017	80	10	\N	\N
1	2017	81	10	\N	\N
1	2017	83	10	\N	\N
1	2017	84	20	\N	\N
1	2017	85	10	\N	\N
1	2017	86	20	\N	\N
1	2017	87	10	\N	\N
1	2017	88	10	\N	\N
1	2017	90	10	\N	\N
1	2017	92	30	\N	\N
1	2016	54	10	8	\N
2	2017	10	80	13	\N
1	2016	65	10	8	\N
1	2016	3	30	4	\N
2	2017	84	20	20	\N
2	2017	75	20	22	\N
2	2017	25	90	16	\N
2	2017	81	60	19	\N
2	2017	52	90	24	\N
2	2017	45	90	17	\N
2	2017	37	20	18	\N
2	2017	21	20	26	\N
2	2017	29	40	15	\N
2	2017	43	30	24	\N
2	2017	56	50	19	\N
2	2017	68	100	11	\N
2	2017	41	90	18	\N
2	2017	31	30	30	\N
2	2017	63	50	25	\N
2	2017	33	50	15	\N
1	2016	6	20	4	\N
2	2017	1	60	20	\N
1	2016	1	30	4	\N
1	2016	44	20	4	\N
1	2016	46	20	4	\N
2	2017	23	90	16	\N
1	2016	75	10	4	\N
1	2016	63	30	4	\N
1	2016	21	30	4	\N
2	2017	39	50	17	\N
1	2016	68	10	4	\N
1	2016	67	10	4	\N
2	2017	20	80	16	\N
1	2016	7	10	4	\N
1	2016	41	10	8	\N
1	2016	39	10	4	\N
2	2017	87	50	12	\N
1	2016	12	20	8	\N
2	2017	2	40	9	\N
1	2016	2	10	4	\N
1	2016	31	10	4	\N
1	2016	52	20	4	\N
2	2017	5	20	19	\N
1	2016	20	30	4	\N
1	2016	59	30	4	\N
1	2016	80	20	4	\N
1	2016	48	30	4	\N
2	2017	85	100	23	\N
1	2016	73	10	8	\N
1	2016	49	30	4	\N
1	2016	37	20	4	\N
1	2016	27	20	4	\N
2	2017	42	60	17	\N
2	2017	44	70	25	\N
2	2017	16	40	18	\N
2	2017	46	30	15	\N
2	2017	77	50	14	\N
2	2017	71	40	18	\N
2	2017	14	40	12	\N
2	2017	27	70	15	\N
2	2017	12	70	18	\N
2	2017	22	20	14	\N
2	2017	3	40	18	\N
2	2017	86	60	18	\N
2	2017	53	20	19	\N
2	2017	18	40	17	\N
2	2017	73	20	19	\N
2	2017	50	100	9	\N
2	2017	65	20	19	\N
2	2017	8	50	14	\N
2	2017	92	100	24	\N
2	2017	4	80	16	\N
2	2017	60	30	11	\N
2	2017	6	100	16	\N
\.


--
-- Data for Name: pengawas; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY pengawas (nomor_induk, nama, no_telp, lokasi_kota, lokasi_tempat, lokasi_id) FROM stdin;
3482652437928350	Sri Lestari	085635425346	Depok	Kampus UI Depok	1
3482652437928351	Arwan Singgih	085223032704	Depok	Kampus UI Depok	2
3482652437928352	Kin Dhananjaya	085622833521	Depok	Kampus UI Depok	3
3482652437928353	Ruri Narendra	085335852492	Depok	Kampus UI Depok	4
3482652437928354	Tommy Wijaya	085235083381	Depok	Kampus UI Depok	5
3482652437928355	Antonio Ricardo	085228614030	Depok	Kampus UI Depok	6
3482652437928356	Arwin Wijanarko	085529652296	Depok	Kampus UI Depok	7
3482652437928357	Arief Wirayudha	085350943646	Depok	Kampus UI Depok	8
3482652437928358	Muhammad Mirza	085346792585	Depok	Kampus UI Depok	9
3482652437928359	Bagas Pratama	085629273045	Depok	Kampus UI Depok	10
3482652437928360	Dwiki Lalo	085635425316	Jakarta Pusat	Kampus UI Salemba	1
3482652437928361	Lendy Satriana	085223032714	Jakarta Pusat	Kampus UI Salemba	2
3482652437928362	Ismail Azis	085622833511	Jakarta Pusat	Kampus UI Salemba	3
3482652437928363	Gilang Prasojo	085335852412	Jakarta Pusat	Kampus UI Salemba	4
3482652437928364	Edy Sastra	085235083311	Jakarta Pusat	Kampus UI Salemba	5
3482652437928365	Farizi Widyasti	085228614010	Jakarta Pusat	Gedung Serbaguna Jakpus	1
3482652437928366	Mustafid Tobing	085529652216	Jakarta Pusat	Gedung Serbaguna Jakpus	2
3482652437928367	Ficky Tika	085350943616	Jakarta Timur	Gedung Serbaguna Jaktim	1
3482652437928368	Hudzaifah Ardiansyah	085346792515	Jakarta Timur	Gedung Serbaguna Jaktim	2
3482652437928369	Rifqi Sidharta	085629273015	Jakarta Selatan	Gedung Serbaguna Jaksel	1
3482652437928370	Syahid Audy	085635422316	Jakarta Selatan	Gedung Serbaguna Jaksel	2
3482652437928371	Daniel Fakhrul Gultom	085223032714	Depok	Gedung Serbaguna Depok	1
3482652437928372	Edwin Rahma	085622832511	Depok	Gedung Serbaguna Depok	2
3482652437928373	Ekka Agtrivia	085335852412	Bekasi	Gedung Serbaguna Bekasi	1
3482652437928374	Indra Ayudhani	085235082311	Bekasi	Gedung Serbaguna Bekasi	2
3482652437928375	Sebastian Widyasmoro	085228612010	Tangerang	Gedung Serbaguna Tangerang	1
3482652437928376	Devito Satria	085529652216	Tangerang	Gedung Serbaguna Tangerang	2
3482652437928377	Anas Aprisilya	085350942616	Tangerang Selatan	Gedung Serbaguna Tangsel	1
3482652437928378	Imam Fadhlir Febrianto	085346792515	Tangerang Selatan	Gedung Serbaguna Tangsel	2
3482652437928379	Rinno Randhika	085629272015	Bogor	Gedung Serbaguna Bogor	1
3482652437928380	June Candraditya	085633422316	Bogor	Gedung Serbaguna Bogor	2
3482652437928381	Saliha Raisid	085223032714	Bandung	Gedung Serbaguna Bandung	1
3482652437928382	Wike Naradhipa	085623832511	Bandung	Gedung Serbaguna Bandung	2
3482652437928383	Larasati Febriani	085333852412	Jogjakarta	Gedung Serbaguna Jogjakarta	1
3482652437928384	Nika Candrakasi Prahasti	085233082311	Jogjakarta	Gedung Serbaguna Jogjakarta	2
3482652437928385	Wiwied Aisyah	081633422316	Surabaya	Gedung Serbaguna Surabaya	1
3482652437928386	Karlina Ahugrah	081223032714	Surabaya	Gedung Serbaguna Surabaya	2
3482652437928387	Maharani Apriyanto	081623832511	Makasar	Gedung Serbaguna Makasar	1
3482652437928388	Yova Dewi	081333852412	Makasar	Gedung Serbaguna Makasar	2
3482652437928389	Hanindita Acbar	081233082311	Medan	Gedung Serbaguna Medan	1
3482652437928390	Nanda Dwira Mulyana	081223612010	Medan	Gedung Serbaguna Medan	2
3482652437928391	Disya Isnandri	081523652216	Padang	Gedung Serbaguna Padang	1
3482652437928392	Defara Hanny Paramitha	081353942616	Padang	Gedung Serbaguna Padang	2
3482652437928393	Shifa Wahyuni	081343792515	Palembang	Gedung Serbaguna Palembang	1
3482652437928394	Syifa Arieska	081623272015	Palembang	Gedung Serbaguna Palembang	2
\.


--
-- Data for Name: periode_penerimaan; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY periode_penerimaan (nomor, tahun, status_aktif) FROM stdin;
1	2016	f
2	2016	f
3	2016	f
4	2016	f
1	2017	f
2	2017	t
\.


--
-- Data for Name: program_studi; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY program_studi (kode, nama, jenis_kelas, nama_fakultas, jenjang) FROM stdin;
1	Pendidikan Dokter	Reguler	Kedokteran	S1
2	Pendidikan Dokter Gigi	Reguler	Kedokteran Gigi	S1
3	Kesehatan Masyarakat	Reguler	Kesehatan Masyarakat	S1
4	Gizi	Reguler	Kesehatan Masyarakat	S1
5	Kesehatan Lingkungan	Reguler	Kesehatan Masyarakat	S1
6	K3	Reguler	Kesehatan Masyarakat	S1
7	Ilmu Keperawatan	Reguler	Ilmu Keperawatan	S1
8	Farmasi	Reguler	Farmasi	S1
9	Farmasi	Paralel	Farmasi	S1
10	Matematika	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
11	Matematika	Paralel	Matematika dan Ilmu Pengetahuan Alam	S1
12	Fisika	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
13	Fisika	Paralel	Matematika dan Ilmu Pengetahuan Alam	S1
14	Kimia	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
15	Kimia	Paralel	Matematika dan Ilmu Pengetahuan Alam	S1
16	Biologi	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
17	Biologi	Paralel	Matematika dan Ilmu Pengetahuan Alam	S1
18	Geografi	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
19	Geografi	Paralel	Matematika dan Ilmu Pengetahuan Alam	S1
20	Geofisika	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
21	Geologi	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
22	Statistika	Reguler	Matematika dan Ilmu Pengetahuan Alam	S1
23	Ilmu Komputer	Reguler	Ilmu Komputer	S1
24	Ilmu Komputer	Paralel	Ilmu Komputer	S1
25	Sistem Informasi	Reguler	Ilmu Komputer	S1
26	Sistem Informasi	Paralel	Ilmu Komputer	S1
27	Teknik Sipil	Reguler	Teknik	S1
28	Teknik Sipil	Paralel	Teknik	S1
29	Teknik Mesin	Reguler	Teknik	S1
30	Teknik Mesin	Paralel	Teknik	S1
31	Teknik Elektro	Reguler	Teknik	S1
32	Teknik Elektro	Paralel	Teknik	S1
33	Teknik Metalurgi dan Material	Reguler	Teknik	S1
34	Teknik Metalurgi dan Material	Paralel	Teknik	S1
35	Arsitektur	Reguler	Teknik	S1
36	Arsitektur	Paralel	Teknik	S1
37	Teknik Kimia	Reguler	Teknik	S1
38	Teknik Kimia	Paralel	Teknik	S1
39	Teknik Industri	Reguler	Teknik	S1
40	Teknik Industri	Paralel	Teknik	S1
41	Teknik Perkapalan	Reguler	Teknik	S1
42	Teknik Lingkungan	Reguler	Teknik	S1
43	Teknik Komputer	Reguler	Teknik	S1
44	Arsitektur Interior	Reguler	Teknik	S1
45	Teknologi Bioproses	Reguler	Teknik	S1
46	Ilmu Hukum	Reguler	Hukum	S1
47	Ilmu Hukum	Paralel	Hukum	S1
48	Ilmu Ekonomi	Reguler	Ekonomi dan Bisnis	S1
49	Manajemen	Reguler	Ekonomi dan Bisnis	S1
50	Akuntansi	Reguler	Ekonomi dan Bisnis	S1
51	Akuntansi	Paralel	Ekonomi dan Bisnis	S1
52	Ilmu Ekonomi Islam	Reguler	Ekonomi dan Bisnis	S1
53	Bisnis Islam	Reguler	Ekonomi dan Bisnis	S1
54	Bahasa dan Kebudayaan Korea	Reguler	Ilmu Pengetahuan Budaya	S1
55	Bahasa dan Kebudayaan Korea	Paralel	Ilmu Pengetahuan Budaya	S1
56	Sastra Belanda	Reguler	Ilmu Pengetahuan Budaya	S1
57	Sastra Belanda	Paralel	Ilmu Pengetahuan Budaya	S1
58	Arkeologi	Reguler	Ilmu Pengetahuan Budaya	S1
59	Ilmu Filsafat	Reguler	Ilmu Pengetahuan Budaya	S1
60	Ilmu Perpustakaan	Reguler	Ilmu Pengetahuan Budaya	S1
61	Ilmu Perpustakaan	Paralel	Ilmu Pengetahuan Budaya	S1
62	Ilmu Sejarah	Reguler	Ilmu Pengetahuan Budaya	S1
63	Sastra Arab	Reguler	Ilmu Pengetahuan Budaya	S1
64	Sastra Arab	Paralel	Ilmu Pengetahuan Budaya	S1
65	Sastra Cina	Reguler	Ilmu Pengetahuan Budaya	S1
66	Sastra Cina	Paralel	Ilmu Pengetahuan Budaya	S1
67	Sastra Daerah/Jawa	Reguler	Ilmu Pengetahuan Budaya	S1
68	Sastra Indonesia	Reguler	Ilmu Pengetahuan Budaya	S1
69	Sastra Inggris	Reguler	Ilmu Pengetahuan Budaya	S1
70	Sastra Inggris	Paralel	Ilmu Pengetahuan Budaya	S1
71	Sastra Jepang	Reguler	Ilmu Pengetahuan Budaya	S1
72	Sastra Jepang	Paralel	Ilmu Pengetahuan Budaya	S1
73	Sastra Jerman	Reguler	Ilmu Pengetahuan Budaya	S1
74	Sastra Jerman	Paralel	Ilmu Pengetahuan Budaya	S1
75	Sastra Perancis	Reguler	Ilmu Pengetahuan Budaya	S1
76	Sastra Perancis	Paralel	Ilmu Pengetahuan Budaya	S1
77	Sastra Rusia	Reguler	Ilmu Pengetahuan Budaya	S1
78	Psikologi	Reguler	Psikologi	S1
79	Psikologi	Paralel	Psikologi	S1
80	Ilmu Politik	Reguler	Ilmu Sosial dan Ilmu Politik	S1
81	Ilmu Komunikasi	Reguler	Ilmu Sosial dan Ilmu Politik	S1
82	Ilmu Komunikasi	Paralel	Ilmu Sosial dan Ilmu Politik	S1
83	Sosiologi	Reguler	Ilmu Sosial dan Ilmu Politik	S1
84	Antropologi Sosial	Reguler	Ilmu Sosial dan Ilmu Politik	S1
85	Ilmu Hubungan Internasional	Reguler	Ilmu Sosial dan Ilmu Politik	S1
86	Ilmu Kesejahteraan Sosial	Reguler	Ilmu Sosial dan Ilmu Politik	S1
87	Kriminologi	Reguler	Ilmu Sosial dan Ilmu Politik	S1
88	Ilmu Administrasi Negara	Reguler	Ilmu Administrasi Negara	S1
89	Ilmu Administrasi Negara	Paralel	Ilmu Administrasi Negara	S1
90	Ilmu Administrasi Niaga	Reguler	Ilmu Administrasi Negara	S1
91	Ilmu Administrasi Niaga	Paralel	Ilmu Administrasi Negara	S1
92	Ilmu Administrasi Fiskal	Reguler	Ilmu Administrasi Negara	S1
93	Ilmu Administrasi Fiskal	Paralel	Ilmu Administrasi Negara	S1
94	Pendidikan Dokter	Internasional (Double Degree)	Kedokteran	S2
95	Teknik Sipil	Internasional (Single Degree)	Teknik	S2
96	Teknik Sipil	Internasional (Double Degree)	Teknik	S2
97	Teknik Mesin	Internasional (Single Degree)	Teknik	S2
98	Teknik Mesin	Internasional (Double Degree)	Teknik	S2
99	Teknik Elektro	Internasional (Single Degree)	Teknik	S2
100	Teknik Elektro	Internasional (Double Degree)	Teknik	S2
101	Arsitektur	Internasional (Single Degree)	Teknik	S2
102	Arsitektur	Internasional (Double Degree)	Teknik	S2
103	Teknik Metalurgi dan Material	Internasional (Single Degree)	Teknik	S2
104	Teknik Metalurgi dan Material	Internasional (Double Degree)	Teknik	S2
105	Teknik Kimia	Internasional (Single Degree)	Teknik	S2
106	Teknik Kimia	Internasional (Double Degree)	Teknik	S2
107	Teknik Industri	Internasional (Single Degree)	Teknik	S2
108	Ilmu Komputer	Internasional (Double Degree)	Ilmu Komputer	S2
109	Psikologi	Internasional (Double Degree)	Psikologi	S2
110	Ilmu Ekonomi	Internasional (Single Degree)	Ekonomi dan Bisnis	S2
111	Ilmu Ekonomi	Internasional (Double Degree)	Ekonomi dan Bisnis	S2
112	Manajemen	Internasional (Single Degree)	Ekonomi dan Bisnis	S2
113	Manajemen	Internasional (Double Degree)	Ekonomi dan Bisnis	S2
114	Akuntansi	Internasional (Single Degree)	Ekonomi dan Bisnis	S2
115	Akuntansi	Internasional (Double Degree)	Ekonomi dan Bisnis	S2
116	Ilmu Hukum	Internasional (Single Degree)	Ekonomi dan Bisnis	S2
117	Ilmu Hukum	Internasional (Double Degree)	Hukum	S2
118	Ilmu Komunikasi	Internasional (Double Degree)	Ilmu Sosial dan Ilmu Politik	S2
119	Ilmu Biomedik	Reguler	Kedokteran	S2
120	Ilmu Gizi	Reguler	Kedokteran	S2
121	Kedokteran Kerja	Reguler	Kedokteran	S2
122	Pendidikan Kedokteran	Reguler	Kedokteran	S2
123	Ilmu Kedokteran Gigi Dasar	Reguler	Kedokteran Gigi	S2
124	Ilmu Kedokteran Gigi Komunitas	Reguler	Kedokteran Gigi	S2
125	Ilmu Kesehatan Masyarakat	Reguler	Kesehatan Masyarakat	S2
126	Administrasi Rumah Sakit	Reguler	Kesehatan Masyarakat	S2
127	Epidemiologi	Reguler	Kesehatan Masyarakat	S2
128	Keselamatan & Kesehatan Kerja	Reguler	Kesehatan Masyarakat	S2
129	Ilmu Keperawatan	Reguler	Ilmu Keperawatan	S2
130	Matematika	Reguler	Matematika dan Ilmu Pengetahuan Alam	S2
131	Ilmu Fisika	Reguler	Matematika dan Ilmu Pengetahuan Alam	S2
132	Ilmu Kimia	Reguler	Matematika dan Ilmu Pengetahuan Alam	S2
133	Biologi	Reguler	Matematika dan Ilmu Pengetahuan Alam	S2
134	Ilmu Kelautan	Reguler	Matematika dan Ilmu Pengetahuan Alam	S2
135	Ilmu Geografi	Reguler	Matematika dan Ilmu Pengetahuan Alam	S2
136	Ilmu Bahan-bahan	Reguler	Matematika dan Ilmu Pengetahuan Alam	S2
137	Ilmu Kefarmasian	Reguler	Farmasi	S2
138	Herbal	Reguler	Farmasi	S2
139	Teknik Industri	Reguler	Teknik	S2
140	Teknik Sipil	Reguler	Teknik	S2
141	Teknik Mesin	Reguler	Teknik	S2
142	Teknik Elektro	Reguler	Teknik	S2
143	Teknik Metalurgi dan Material	Reguler	Teknik	S2
144	Arsitektur	Reguler	Teknik	S2
145	Teknik Kimia	Reguler	Teknik	S2
146	Teknologi Informasi	Reguler	Ilmu Komputer	S2
147	Ilmu Komputer	Reguler	Ilmu Komputer	S2
148	Ilmu Ekonomi	Reguler	Ekonomi dan Bisnis	S2
149	Perencanaan dan Kebijakan Publik (MPKP)	Reguler	Ekonomi dan Bisnis	S2
150	Ilmu Manajemen	Reguler	Ekonomi dan Bisnis	S2
151	Magister Manajemen	Reguler	Ekonomi dan Bisnis	S2
152	Ilmu Akuntansi	Reguler	Ekonomi dan Bisnis	S2
153	Magister Akuntansi	Reguler	Ekonomi dan Bisnis	S2
154	Ekonomi Kependudukan dan Ketenagakerjaan	Reguler	Ekonomi dan Bisnis	S2
155	Arkeologi	Reguler	Ilmu Pengetahuan Budaya	S2
156	Ilmu Filsafat	Reguler	Ilmu Pengetahuan Budaya	S2
157	Ilmu Perpustakaan	Reguler	Ilmu Pengetahuan Budaya	S2
158	Ilmu Linguistik	Reguler	Ilmu Pengetahuan Budaya	S2
159	Ilmu Susastra (Sastra)	Reguler	Ilmu Pengetahuan Budaya	S2
160	Ilmu Sejarah	Reguler	Ilmu Pengetahuan Budaya	S2
161	Kajian Asia Tenggara	Reguler	Ilmu Pengetahuan Budaya	S2
162	Ilmu Psikologi	Reguler	Psikologi	S2
163	Psikologi Profesi	Reguler	Psikologi	S2
164	Psikologi Terapan	Reguler	Psikologi	S2
165	Ilmu Hukum	Reguler	Hukum	S2
166	Kenotariatan	Reguler	Hukum	S2
167	Ilmu Komunikasi	Reguler	Ilmu Sosial dan Ilmu Politik	S2
168	Ilmu Politik	Reguler	Ilmu Sosial dan Ilmu Politik	S2
169	Sosiologi	Reguler	Ilmu Sosial dan Ilmu Politik	S2
170	Kriminologi	Reguler	Ilmu Sosial dan Ilmu Politik	S2
171	Ilmu Kesehatan Sosial	Reguler	Ilmu Sosial dan Ilmu Politik	S2
172	Antropologi	Reguler	Ilmu Sosial dan Ilmu Politik	S2
173	Ilmu Hubungan Internasional	Reguler	Ilmu Sosial dan Ilmu Politik	S2
174	Ilmu Administrasi	Reguler	Ilmu Administrasi	S2
175	Kajian Ilmu Kepolisian	Reguler	Sekolah Kajian Stratejik & Global	S2
176	Kajian Ketahanan Nasional	Reguler	Sekolah Kajian Stratejik & Global	S2
177	Kajian Wilayah Amerika	Reguler	Sekolah Kajian Stratejik & Global	S2
178	Kajian Wilayah Eropa	Reguler	Sekolah Kajian Stratejik & Global	S2
179	Kajian Wilayah Jepang	Reguler	Sekolah Kajian Stratejik & Global	S2
180	Kajian Wilayah Timur Tengah Islam	Reguler	Sekolah Kajian Stratejik & Global	S2
181	Kajian Pengembangan Perkotaan	Reguler	Sekolah Kajian Stratejik & Global	S2
182	Kajian Gender	Reguler	Sekolah Kajian Stratejik & Global	S2
183	Kajian Terorisme	Reguler	Sekolah Kajian Stratejik & Global	S2
184	Kajian Ilmu Lingkungan	Reguler	Sekolah Ilmu Lingkungan	S2
185	Ilmu Biomedik	Reguler	Kedokteran	S3
186	Ilmu Gizi	Reguler	Kedokteran	S3
187	Ilmu Kedokteran	Reguler	Kedokteran	S3
188	Ilmu Kedokteran Gigi	Reguler	Kedokteran Gigi	S3
189	Ilmu Kesehatan Masyarakat	Reguler	Kesehatan Masyarakat	S3
190	Epidemiologi	Reguler	Kesehatan Masyarakat	S3
191	Ilmu Keperawatan	Reguler	Ilmu Keperawatan	S3
192	Ilmu Bahan-bahan	Reguler	Matematika dan Ilmu Pengetahuan Alam	S3
193	Ilmu Kimia	Reguler	Matematika dan Ilmu Pengetahuan Alam	S3
194	Biologi	Reguler	Matematika dan Ilmu Pengetahuan Alam	S3
195	Farmasi	Reguler	Farmasi	S3
196	Teknik Sipil	Reguler	Teknik	S3
197	Teknik Mesin	Reguler	Teknik	S3
198	Teknik Elektro	Reguler	Teknik	S3
199	Teknik Metalurgi dan Material	Reguler	Teknik	S3
200	Arsitektur	Reguler	Teknik	S3
201	Teknik Kimia	Reguler	Teknik	S3
202	Teknik Industri	Reguler	Teknik	S3
203	Ilmu Komputer	Reguler	Ilmu Komputer	S3
204	Ilmu Ekonomi	Reguler	Ekonomi dan Bisnis	S3
205	Ilmu Manajemen	Reguler	Ekonomi dan Bisnis	S3
206	Ilmu Akuntansi	Reguler	Ekonomi dan Bisnis	S3
207	Arkeologi	Reguler	Ilmu Pengetahuan Budaya	S3
208	Ilmu Filsafat	Reguler	Ilmu Pengetahuan Budaya	S3
209	Ilmu Linguistik	Reguler	Ilmu Pengetahuan Budaya	S3
210	Ilmu Susastra (Sastra)	Reguler	Ilmu Pengetahuan Budaya	S3
211	Ilmu Sejarah	Reguler	Ilmu Pengetahuan Budaya	S3
212	Psikologi	Reguler	Psikologi	S3
213	Ilmu Hukum	Reguler	Hukum	S3
214	Ilmu Komunikasi	Reguler	Ilmu Sosial dan Ilmu Politik	S3
215	Ilmu Politik	Reguler	Ilmu Sosial dan Ilmu Politik	S3
216	Sosiologi	Reguler	Ilmu Sosial dan Ilmu Politik	S3
217	Kriminologi	Reguler	Ilmu Sosial dan Ilmu Politik	S3
218	Ilmu Kesejahteraan Sosial	Reguler	Ilmu Sosial dan Ilmu Politik	S3
219	Antropologi	Reguler	Ilmu Sosial dan Ilmu Politik	S3
220	Ilmu Administrasi	Reguler	Ilmu Administasi	S3
221	Ilmu Lingkungan	Reguler	Sekolah Ilmu Lingkungan	S3
\.


--
-- Name: program_studi_kode_seq; Type: SEQUENCE SET; Schema: sirima; Owner: arri.kurniawan
--

SELECT pg_catalog.setval('program_studi_kode_seq', 1, false);


--
-- Data for Name: rekomendasi; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY rekomendasi (tgl_review, id_pendaftaran, status, nilai, komentar) FROM stdin;
2016-03-20	1	t	99	Sangat berprestasi
2016-03-19	2	t	90	Sangat berprestasi
2016-03-29	3	t	99	Sangat berprestasi
2016-04-08	4	t	92	Sangat berprestasi
2016-03-16	5	t	92	Sangat berprestasi
2016-04-11	6	t	95	Sangat berprestasi
2016-03-17	7	f	79	Cukup Berprestasi
2016-03-22	8	f	78	Cukup Berprestasi
2016-03-22	9	f	80	Cukup Berprestasi
2016-03-21	10	f	80	Cukup Berprestasi
2016-04-11	11	f	72	Cukup Berprestasi
2016-04-15	12	f	79	Cukup Berprestasi
2016-04-05	13	f	74	Cukup Berprestasi
2016-04-09	14	f	71	Cukup Berprestasi
2016-04-12	15	f	78	Cukup Berprestasi
2016-03-16	16	f	77	Cukup Berprestasi
2016-03-27	17	f	79	Cukup Berprestasi
2016-04-03	18	f	71	Cukup Berprestasi
2016-03-27	19	f	74	Cukup Berprestasi
2016-03-25	20	f	80	Cukup Berprestasi
2016-03-18	21	f	70	Cukup Berprestasi
2016-04-05	22	f	72	Cukup Berprestasi
2016-03-22	23	f	80	Cukup Berprestasi
2016-03-19	24	f	76	Cukup Berprestasi
2016-04-05	25	f	79	Cukup Berprestasi
2016-03-24	26	f	75	Cukup Berprestasi
2016-04-15	27	f	70	Cukup Berprestasi
2016-04-13	28	f	74	Cukup Berprestasi
2016-04-13	29	f	72	Cukup Berprestasi
2016-03-24	30	f	73	Cukup Berprestasi
2016-04-13	31	f	72	Cukup Berprestasi
2016-03-31	32	f	76	Cukup Berprestasi
2016-04-06	33	f	75	Cukup Berprestasi
2016-03-30	34	f	73	Cukup Berprestasi
2016-03-20	35	f	78	Cukup Berprestasi
2016-03-21	36	f	71	Cukup Berprestasi
2016-04-04	37	f	72	Cukup Berprestasi
2016-04-15	38	f	70	Cukup Berprestasi
2016-03-15	39	f	72	Cukup Berprestasi
2016-03-26	40	f	79	Cukup Berprestasi
2016-04-10	41	f	76	Cukup Berprestasi
2016-04-14	42	f	77	Cukup Berprestasi
2016-04-12	43	f	73	Cukup Berprestasi
2016-03-20	44	f	78	Cukup Berprestasi
2016-04-14	45	f	77	Cukup Berprestasi
2016-04-15	46	f	74	Cukup Berprestasi
2016-04-06	47	f	72	Cukup Berprestasi
2016-04-07	48	f	76	Cukup Berprestasi
2016-04-15	49	f	80	Cukup Berprestasi
2016-04-08	50	f	75	Cukup Berprestasi
2016-03-22	51	f	72	Cukup Berprestasi
2016-04-13	52	f	79	Cukup Berprestasi
2016-04-02	53	f	79	Cukup Berprestasi
2016-03-17	54	f	74	Cukup Berprestasi
2016-04-05	55	f	72	Cukup Berprestasi
2016-03-17	56	f	76	Cukup Berprestasi
2016-04-11	57	f	71	Cukup Berprestasi
2016-04-13	58	f	74	Cukup Berprestasi
2016-03-23	59	f	76	Cukup Berprestasi
2016-04-12	60	f	76	Cukup Berprestasi
2016-03-28	61	f	76	Cukup Berprestasi
2016-04-14	62	f	79	Cukup Berprestasi
2016-04-07	63	f	72	Cukup Berprestasi
2016-03-24	64	f	78	Cukup Berprestasi
2016-04-05	65	f	75	Cukup Berprestasi
2016-04-04	66	f	76	Cukup Berprestasi
2016-03-27	67	f	73	Cukup Berprestasi
2016-04-07	68	f	76	Cukup Berprestasi
2016-03-28	69	f	71	Cukup Berprestasi
2016-04-06	70	f	72	Cukup Berprestasi
2016-04-12	71	f	73	Cukup Berprestasi
2016-04-03	72	f	76	Cukup Berprestasi
2016-03-16	73	f	78	Cukup Berprestasi
2016-04-09	74	t	96	Sangat berprestasi
2016-03-28	75	t	96	Sangat berprestasi
2016-04-15	76	t	93	Sangat berprestasi
2016-04-12	77	t	96	Sangat berprestasi
2016-03-31	78	t	93	Sangat berprestasi
2016-04-13	79	t	99	Sangat berprestasi
2016-03-21	80	t	98	Sangat berprestasi
2016-03-28	81	f	75	Cukup Berprestasi
2016-03-28	82	f	80	Cukup Berprestasi
2016-04-05	83	f	78	Cukup Berprestasi
2016-03-21	84	f	78	Cukup Berprestasi
2016-04-11	85	f	75	Cukup Berprestasi
2016-04-14	86	f	74	Cukup Berprestasi
2016-04-07	87	f	80	Cukup Berprestasi
2016-04-01	88	f	75	Cukup Berprestasi
2016-03-20	89	f	73	Cukup Berprestasi
2016-03-26	90	f	70	Cukup Berprestasi
2016-03-19	91	f	71	Cukup Berprestasi
2016-03-24	92	f	76	Cukup Berprestasi
2016-03-22	93	f	78	Cukup Berprestasi
2016-03-17	94	f	70	Cukup Berprestasi
2016-04-11	95	f	75	Cukup Berprestasi
2016-03-22	96	f	77	Cukup Berprestasi
2016-03-29	97	f	79	Cukup Berprestasi
2016-03-18	98	f	73	Cukup Berprestasi
2016-03-28	99	f	73	Cukup Berprestasi
2016-03-27	100	f	71	Cukup Berprestasi
2016-03-22	101	f	72	Cukup Berprestasi
2016-03-26	102	f	80	Cukup Berprestasi
2016-04-07	103	f	76	Cukup Berprestasi
2016-03-29	104	f	70	Cukup Berprestasi
2016-04-11	105	f	73	Cukup Berprestasi
2016-03-15	106	f	73	Cukup Berprestasi
2016-03-19	107	f	77	Cukup Berprestasi
2016-04-14	108	f	74	Cukup Berprestasi
2016-03-27	109	f	73	Cukup Berprestasi
2016-03-24	110	f	70	Cukup Berprestasi
2016-03-20	111	f	77	Cukup Berprestasi
2016-04-04	112	f	76	Cukup Berprestasi
2016-04-03	113	f	74	Cukup Berprestasi
2016-03-20	114	f	73	Cukup Berprestasi
2016-03-26	115	f	73	Cukup Berprestasi
2016-04-14	116	f	77	Cukup Berprestasi
2016-03-28	117	f	77	Cukup Berprestasi
2016-04-04	118	f	70	Cukup Berprestasi
2016-03-20	119	f	72	Cukup Berprestasi
2016-04-04	120	f	71	Cukup Berprestasi
2016-03-30	121	f	77	Cukup Berprestasi
2016-03-28	122	f	75	Cukup Berprestasi
2016-03-17	123	f	77	Cukup Berprestasi
2016-04-13	124	f	76	Cukup Berprestasi
2016-03-22	125	f	74	Cukup Berprestasi
2016-03-31	126	f	76	Cukup Berprestasi
2016-03-19	127	f	78	Cukup Berprestasi
2016-03-25	128	f	75	Cukup Berprestasi
2016-04-09	129	f	80	Cukup Berprestasi
2016-04-11	130	f	73	Cukup Berprestasi
2016-04-11	131	f	75	Cukup Berprestasi
2016-04-14	132	f	75	Cukup Berprestasi
2016-04-14	133	f	80	Cukup Berprestasi
2016-04-03	134	f	76	Cukup Berprestasi
2016-03-31	135	f	74	Cukup Berprestasi
2016-04-07	136	f	75	Cukup Berprestasi
2016-04-05	137	f	75	Cukup Berprestasi
2016-03-21	138	f	76	Cukup Berprestasi
2016-03-30	139	f	72	Cukup Berprestasi
2016-03-22	140	f	79	Cukup Berprestasi
2009-03-27	141	t	100	Sangat berprestasi
2009-03-17	142	t	93	Sangat berprestasi
2009-03-19	143	t	90	Sangat berprestasi
2009-04-11	144	t	98	Sangat berprestasi
2009-03-17	145	t	91	Sangat berprestasi
2009-03-17	146	t	99	Sangat berprestasi
2009-04-02	147	t	100	Sangat berprestasi
2009-04-07	148	t	96	Sangat berprestasi
2009-03-27	149	f	75	Cukup Berprestasi
2009-04-08	150	f	71	Cukup Berprestasi
2009-04-06	151	f	79	Cukup Berprestasi
2009-04-05	152	f	72	Cukup Berprestasi
2009-03-26	153	f	73	Cukup Berprestasi
2009-04-04	154	f	70	Cukup Berprestasi
2009-03-30	155	f	77	Cukup Berprestasi
2009-04-07	156	f	76	Cukup Berprestasi
2009-04-10	157	f	75	Cukup Berprestasi
2009-04-01	158	f	74	Cukup Berprestasi
2009-03-15	159	f	80	Cukup Berprestasi
2009-04-12	160	f	71	Cukup Berprestasi
2009-03-30	161	f	75	Cukup Berprestasi
2009-03-26	162	f	71	Cukup Berprestasi
2009-03-24	163	f	70	Cukup Berprestasi
2009-04-07	164	f	72	Cukup Berprestasi
2009-03-26	165	f	77	Cukup Berprestasi
2009-04-13	166	f	71	Cukup Berprestasi
2009-03-27	167	f	76	Cukup Berprestasi
2009-04-08	168	f	74	Cukup Berprestasi
2009-04-09	169	f	70	Cukup Berprestasi
2009-04-01	170	f	73	Cukup Berprestasi
2009-03-21	171	f	78	Cukup Berprestasi
2009-03-24	172	f	80	Cukup Berprestasi
2009-03-24	173	f	78	Cukup Berprestasi
2009-03-30	174	f	80	Cukup Berprestasi
2009-04-07	175	f	77	Cukup Berprestasi
2009-03-31	176	f	79	Cukup Berprestasi
2009-03-16	177	f	77	Cukup Berprestasi
2009-03-29	178	f	73	Cukup Berprestasi
2009-04-15	179	f	79	Cukup Berprestasi
2009-04-06	180	f	76	Cukup Berprestasi
2009-04-13	181	f	75	Cukup Berprestasi
2009-04-06	182	f	77	Cukup Berprestasi
2009-04-14	183	f	74	Cukup Berprestasi
2009-04-06	184	f	76	Cukup Berprestasi
2009-03-23	185	f	70	Cukup Berprestasi
2009-04-12	186	f	74	Cukup Berprestasi
2009-04-05	187	f	70	Cukup Berprestasi
2009-04-03	188	f	80	Cukup Berprestasi
2009-03-16	189	f	71	Cukup Berprestasi
2009-04-06	190	f	74	Cukup Berprestasi
2009-03-27	191	f	73	Cukup Berprestasi
2009-04-03	192	f	78	Cukup Berprestasi
2009-03-15	193	f	75	Cukup Berprestasi
2009-04-14	194	f	71	Cukup Berprestasi
2009-04-03	195	f	74	Cukup Berprestasi
2009-04-11	196	f	74	Cukup Berprestasi
2009-03-25	197	f	80	Cukup Berprestasi
2009-03-31	198	f	74	Cukup Berprestasi
2009-03-31	199	f	71	Cukup Berprestasi
2009-04-10	200	f	79	Cukup Berprestasi
\.


--
-- Data for Name: ruang_ujian; Type: TABLE DATA; Schema: sirima; Owner: arri.kurniawan
--

COPY ruang_ujian (kota, tempat, id) FROM stdin;
Depok	Kampus UI Depok	1
Depok	Kampus UI Depok	2
Depok	Kampus UI Depok	3
Depok	Kampus UI Depok	4
Depok	Kampus UI Depok	5
Depok	Kampus UI Depok	6
Depok	Kampus UI Depok	7
Depok	Kampus UI Depok	8
Depok	Kampus UI Depok	9
Depok	Kampus UI Depok	10
Jakarta Pusat	Kampus UI Salemba	1
Jakarta Pusat	Kampus UI Salemba	2
Jakarta Pusat	Kampus UI Salemba	3
Jakarta Pusat	Kampus UI Salemba	4
Jakarta Pusat	Kampus UI Salemba	5
Jakarta Pusat	Gedung Serbaguna Jakpus	1
Jakarta Pusat	Gedung Serbaguna Jakpus	2
Jakarta Timur	Gedung Serbaguna Jaktim	1
Jakarta Timur	Gedung Serbaguna Jaktim	2
Jakarta Selatan	Gedung Serbaguna Jaksel	1
Jakarta Selatan	Gedung Serbaguna Jaksel	2
Depok	Gedung Serbaguna Depok	1
Depok	Gedung Serbaguna Depok	2
Bekasi	Gedung Serbaguna Bekasi	1
Bekasi	Gedung Serbaguna Bekasi	2
Tangerang	Gedung Serbaguna Tangerang	1
Tangerang	Gedung Serbaguna Tangerang	2
Tangerang Selatan	Gedung Serbaguna Tangsel	1
Tangerang Selatan	Gedung Serbaguna Tangsel	2
Bogor	Gedung Serbaguna Bogor	1
Bogor	Gedung Serbaguna Bogor	2
Bandung	Gedung Serbaguna Bandung	1
Bandung	Gedung Serbaguna Bandung	2
Jogjakarta	Gedung Serbaguna Jogjakarta	1
Jogjakarta	Gedung Serbaguna Jogjakarta	2
Surabaya	Gedung Serbaguna Surabaya	1
Surabaya	Gedung Serbaguna Surabaya	2
Makasar	Gedung Serbaguna Makasar	1
Makasar	Gedung Serbaguna Makasar	2
Medan	Gedung Serbaguna Medan	1
Medan	Gedung Serbaguna Medan	2
Padang	Gedung Serbaguna Padang	1
Padang	Gedung Serbaguna Padang	2
Palembang	Gedung Serbaguna Palembang	1
Palembang	Gedung Serbaguna Palembang	2
\.


--
-- Name: akun akun_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY akun
    ADD CONSTRAINT akun_pkey PRIMARY KEY (username);


--
-- Name: jadwal_penting jadwal_penting_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY jadwal_penting
    ADD CONSTRAINT jadwal_penting_pkey PRIMARY KEY (nomor, tahun, jenjang, waktu_mulai);


--
-- Name: jenjang jenjang_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY jenjang
    ADD CONSTRAINT jenjang_pkey PRIMARY KEY (nama);


--
-- Name: lokasi_jadwal lokasi_jadwal_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY lokasi_jadwal
    ADD CONSTRAINT lokasi_jadwal_pkey PRIMARY KEY (kota, tempat, nomor_periode, tahun_periode, jenjang, waktu_awal);


--
-- Name: lokasi_ujian lokasi_ujian_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY lokasi_ujian
    ADD CONSTRAINT lokasi_ujian_pkey PRIMARY KEY (kota, tempat);


--
-- Name: pelamar pelamar_email_key; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pelamar
    ADD CONSTRAINT pelamar_email_key UNIQUE (email);


--
-- Name: pelamar pelamar_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pelamar
    ADD CONSTRAINT pelamar_pkey PRIMARY KEY (username);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id);


--
-- Name: pendaftaran pendaftaran_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_pkey PRIMARY KEY (id);


--
-- Name: pendaftaran_prodi pendaftaran_prodi_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_prodi
    ADD CONSTRAINT pendaftaran_prodi_pkey PRIMARY KEY (id_pendaftaran, kode_prodi);


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: pendaftaran_semas pendaftaran_semas_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas
    ADD CONSTRAINT pendaftaran_semas_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: pendaftaran_semas_sarjana pendaftaran_semas_sarjana_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas_sarjana
    ADD CONSTRAINT pendaftaran_semas_sarjana_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: pendaftaran_uui pendaftaran_uui_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_uui
    ADD CONSTRAINT pendaftaran_uui_pkey PRIMARY KEY (id_pendaftaran);


--
-- Name: penerimaan_prodi penerimaan_prodi_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY penerimaan_prodi
    ADD CONSTRAINT penerimaan_prodi_pkey PRIMARY KEY (nomor_periode, tahun_periode, kode_prodi);


--
-- Name: pengawas pengawas_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pengawas
    ADD CONSTRAINT pengawas_pkey PRIMARY KEY (nomor_induk);


--
-- Name: periode_penerimaan periode_penerimaan_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY periode_penerimaan
    ADD CONSTRAINT periode_penerimaan_pkey PRIMARY KEY (nomor, tahun);


--
-- Name: program_studi program_studi_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY program_studi
    ADD CONSTRAINT program_studi_pkey PRIMARY KEY (kode);


--
-- Name: rekomendasi rekomendasi_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY rekomendasi
    ADD CONSTRAINT rekomendasi_pkey PRIMARY KEY (tgl_review, id_pendaftaran);


--
-- Name: ruang_ujian ruang_ujian_pkey; Type: CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY ruang_ujian
    ADD CONSTRAINT ruang_ujian_pkey PRIMARY KEY (kota, tempat, id);


--
-- Name: pendaftaran_prodi hitung_pelamar_diterima_trigger; Type: TRIGGER; Schema: sirima; Owner: arri.kurniawan
--

CREATE TRIGGER hitung_pelamar_diterima_trigger AFTER UPDATE OF status_lulus ON pendaftaran_prodi FOR EACH ROW EXECUTE PROCEDURE hitung_pelamar_diterima();


--
-- Name: pendaftaran_prodi hitung_pelamar_trigger; Type: TRIGGER; Schema: sirima; Owner: arri.kurniawan
--

CREATE TRIGGER hitung_pelamar_trigger AFTER INSERT OR DELETE OR UPDATE ON pendaftaran_prodi FOR EACH ROW EXECUTE PROCEDURE hitung_pelamar();


--
-- Name: jadwal_penting jadwal_penting_jenjang_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY jadwal_penting
    ADD CONSTRAINT jadwal_penting_jenjang_fkey FOREIGN KEY (jenjang) REFERENCES jenjang(nama) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: jadwal_penting jadwal_penting_nomor_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY jadwal_penting
    ADD CONSTRAINT jadwal_penting_nomor_fkey FOREIGN KEY (nomor, tahun) REFERENCES periode_penerimaan(nomor, tahun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lokasi_jadwal lokasi_jadwal_kota_tempat_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY lokasi_jadwal
    ADD CONSTRAINT lokasi_jadwal_kota_tempat_fkey FOREIGN KEY (kota, tempat) REFERENCES lokasi_ujian(kota, tempat) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lokasi_jadwal lokasi_jadwal_nomor_periode_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY lokasi_jadwal
    ADD CONSTRAINT lokasi_jadwal_nomor_periode_fkey FOREIGN KEY (nomor_periode, tahun_periode, jenjang, waktu_awal) REFERENCES jadwal_penting(nomor, tahun, jenjang, waktu_mulai) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pelamar pelamar_username_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pelamar
    ADD CONSTRAINT pelamar_username_fkey FOREIGN KEY (username) REFERENCES akun(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pembayaran pembayaran_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_semas(id_pendaftaran) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran pendaftaran_nomor_periode_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_nomor_periode_fkey FOREIGN KEY (nomor_periode, tahun_periode) REFERENCES periode_penerimaan(nomor, tahun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran pendaftaran_pelamar_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran
    ADD CONSTRAINT pendaftaran_pelamar_fkey FOREIGN KEY (pelamar) REFERENCES pelamar(username) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_prodi pendaftaran_prodi_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_prodi
    ADD CONSTRAINT pendaftaran_prodi_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_prodi pendaftaran_prodi_kode_prodi_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_prodi
    ADD CONSTRAINT pendaftaran_prodi_kode_prodi_fkey FOREIGN KEY (kode_prodi) REFERENCES program_studi(kode) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_semas pendaftaran_semas_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas
    ADD CONSTRAINT pendaftaran_semas_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_semas pendaftaran_semas_lokasi_kota_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas
    ADD CONSTRAINT pendaftaran_semas_lokasi_kota_fkey FOREIGN KEY (lokasi_kota, lokasi_tempat) REFERENCES lokasi_ujian(kota, tempat) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_semas(id_pendaftaran) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_jenjang_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_jenjang_fkey FOREIGN KEY (jenjang) REFERENCES jenjang(nama) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_semas_pascasarjana pendaftaran_semas_pascasarjana_jenjang_terakhir_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas_pascasarjana
    ADD CONSTRAINT pendaftaran_semas_pascasarjana_jenjang_terakhir_fkey FOREIGN KEY (jenjang_terakhir) REFERENCES jenjang(nama) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_semas_sarjana pendaftaran_semas_sarjana_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_semas_sarjana
    ADD CONSTRAINT pendaftaran_semas_sarjana_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_semas(id_pendaftaran) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pendaftaran_uui pendaftaran_uui_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pendaftaran_uui
    ADD CONSTRAINT pendaftaran_uui_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: penerimaan_prodi penerimaan_prodi_kode_prodi_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY penerimaan_prodi
    ADD CONSTRAINT penerimaan_prodi_kode_prodi_fkey FOREIGN KEY (kode_prodi) REFERENCES program_studi(kode) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: penerimaan_prodi penerimaan_prodi_nomor_periode_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY penerimaan_prodi
    ADD CONSTRAINT penerimaan_prodi_nomor_periode_fkey FOREIGN KEY (nomor_periode, tahun_periode) REFERENCES periode_penerimaan(nomor, tahun) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pengawas pengawas_lokasi_kota_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY pengawas
    ADD CONSTRAINT pengawas_lokasi_kota_fkey FOREIGN KEY (lokasi_kota, lokasi_tempat, lokasi_id) REFERENCES ruang_ujian(kota, tempat, id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: program_studi program_studi_jenjang_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY program_studi
    ADD CONSTRAINT program_studi_jenjang_fkey FOREIGN KEY (jenjang) REFERENCES jenjang(nama) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rekomendasi rekomendasi_id_pendaftaran_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY rekomendasi
    ADD CONSTRAINT rekomendasi_id_pendaftaran_fkey FOREIGN KEY (id_pendaftaran) REFERENCES pendaftaran_uui(id_pendaftaran) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ruang_ujian ruang_ujian_kota_fkey; Type: FK CONSTRAINT; Schema: sirima; Owner: arri.kurniawan
--

ALTER TABLE ONLY ruang_ujian
    ADD CONSTRAINT ruang_ujian_kota_fkey FOREIGN KEY (kota, tempat) REFERENCES lokasi_ujian(kota, tempat) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

